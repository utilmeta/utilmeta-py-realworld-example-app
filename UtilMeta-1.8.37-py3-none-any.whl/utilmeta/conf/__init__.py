from .settings import *
from utilmeta.util.env import Env

config = Config(__name__, root_api='', production=False)

BACKGROUND = False
# this is a variable set by context, if during background task BACKGROUND=True
# for request service BACKGROUND=False, used to configure config in different way
