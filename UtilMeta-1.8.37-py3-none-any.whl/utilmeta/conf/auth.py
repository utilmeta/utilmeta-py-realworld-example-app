from typing import List, Union, Callable
from utilmeta.util.common import get_fields, get_field, import_util, one_to, \
    MetaHeader, get_field_name, get_domain, model_tag, get_many_field_names
from utilmeta.util.base import Util
from typing import Type, Optional
from datetime import timedelta


class Auth(Util):
    PBKDF2_SHA256 = 'django.contrib.auth.hashers.PBKDF2PasswordHasher'
    PBKDF2_SHA1 = 'django.contrib.auth.hashers.PBKDF2SHA1PasswordHasher'
    ARGON2 = 'django.contrib.auth.hashers.Argon2PasswordHasher'
    BCRYPT_SHA256 = 'django.contrib.auth.hashers.BCryptSHA256PasswordHasher'
    BCRYPT = 'django.contrib.auth.hashers.BCryptPasswordHasher'
    SHA1 = 'django.contrib.auth.hashers.SHA1PasswordHasher'
    MD5 = 'django.contrib.auth.hashers.MD5PasswordHasher'
    UNSALTED_SHA1 = 'django.contrib.auth.hashers.UnsaltedSHA1PasswordHasher'
    UNSALTED_MD5 = 'django.contrib.auth.hashers.UnsaltedMD5PasswordHasher'
    CRYPT = 'django.contrib.auth.hashers.CryptPasswordHasher'

    BASIC = 'BASIC'
    VENDOR = 'VENDOR'
    JWT = 'JWT'
    SIGNATURE = 'SIGNATURE'     # stateless access_key / secret_key as signature
    SESSION = 'SESSION'         # session auth: use identical session cache
    # ACTIVE = 'ACTIVE'           # active auth: get auth service user each time a user is required
    # PASSIVE = 'PASSIVE'
    # COMBINED = 'COMBINED'

    DEFAULT_ADMIN_MODEL = 'utilmeta.ops.models.admin.Admin'

    HS256 = 'HS256'
    HS384 = 'HS384'
    HS512 = 'HS512'
    RS256 = 'RS256'
    RS384 = 'RS384'
    RS512 = 'RS512'
    ES256 = 'ES256'
    ES384 = 'ES384'
    ES512 = 'ES512'

    def __init__(self, *,
                 _enabled: bool = True,
                 auth_service: str = None,  # use other auth service to authorize user
                 auth_strategy: Union[str, List[str]] = SESSION,
                 # auth strategy support multiple strategies
                 # like commonly SESSION (for common client) and SIGNATURE (for vendor integration)

                 # active auth: get auth service user each time a user is required
                 # passive auth: when login at auth service will inform all backward dependencies
                 #               and sync session id
                 # combined auth: use passive auth, if requested user not found, turn to active auth

                 auth_scheme_name: str = None,
                 basic_auth_username_field: str = None,
                 jwt_encode_algorithm: str = HS256,
                 jwt_secret_key: str = None,
                 jwt_token_field: str = None,

                 user_model: str = None,
                 auth_model: str = None,
                 admin_model: str = DEFAULT_ADMIN_MODEL,
                 access_model: str = None,
                 access_user_field: str = None,

                 # def getter(user, login: bool = False): pass
                 allowed_addresses: Union[str, List[str], Callable] = None,

                 login_fields: Union[List[str], str, tuple] = None,
                 password_field: str = None,
                 active_field: str = None,

                 signup_time_field: str = None,
                 last_login_time_field: str = None,
                 last_login_ip_field: str = None,
                 last_activity_field: str = None,

                 access_key_field: str = 'access_key',
                 secret_key_field: str = 'secret_key',
                 access_key_header: str = MetaHeader.ACCESS_KEY,
                 signature_header: str = MetaHeader.SIGNATURE,
                 timestamp_header: str = MetaHeader.TIMESTAMP,
                 auth_timeout: Union[Callable, int] = 5,

                 default_salt_length: int = 32,
                 login_required_message: str = None,
                 hashers=(PBKDF2_SHA256,)
                 ):
        if isinstance(auth_strategy, str):
            auth_strategy = [auth_strategy]
        self.auth_strategies = list(auth_strategy)
        self.access_key_field = get_field_name(access_key_field)
        self.secret_key_field = get_field_name(secret_key_field)
        self.access_key_header = access_key_header
        self.signature_header = signature_header
        self.timestamp_header = timestamp_header
        self.auth_timeout = auth_timeout
        self.allowed_addresses = allowed_addresses

        super().__init__(locals())
        self.user_model = user_model
        self.auth_model = auth_model
        self.auth_service = auth_service
        # can only set session from auth service

        assert isinstance(default_salt_length, int) and default_salt_length > 8,\
            f'Auth default_salt_length must be a int > 8, got {default_salt_length}'

        if isinstance(login_fields, str):
            login_fields = (login_fields, )
        self.login_fields = tuple(login_fields) if login_fields else []
        self.hashers = hashers

        self.password_field = password_field
        self.active_field = active_field

        self.login_required_message = login_required_message
        self.basic_auth_username_field = basic_auth_username_field or 'id'
        self.auth_scheme_name = (auth_scheme_name or self.auth_strategies[0]).capitalize()
        self.jwt_encode_algorithm = jwt_encode_algorithm
        self.jwt_secret_key = jwt_secret_key
        self.jwt_token_field = jwt_token_field

        self.auth_user_field = None
        self.auth_user_relate = None
        self.not_apply_prep = False

        self.admin_model = admin_model
        self.access_model = access_model
        self.access_user_field = access_user_field
        self.signup_time_field = signup_time_field

        self.last_login_time_field = last_login_time_field
        self.last_login_ip_field = last_login_ip_field
        self.last_activity_field = last_activity_field

        self.AuthModel = None
        self.AdminModel = None
        self.UserModel = None
        self.AccessModel = None

        self._enabled = _enabled
        self.default_salt_length = default_salt_length
        self.encoded_password_min_length = 66 + default_salt_length
        self.user_template = {}
        self.auth_template = {}
        self.models_loaded = False

    @property
    def auth_config(self):
        conf = dict(
            strategies=self.auth_strategies,
        )
        if self.signature_auth:
            conf.update(
                access_key=self.access_key_header,
                timestamp=self.timestamp_header,
                signature=self.signature_header
            )
        return conf

    @property
    def enabled(self):
        return self._enabled and self.UserModel or self.AccessModel or self.auth_service

    @property
    def relate_fields(self):
        return get_many_field_names(self.UserModel)

    def get_model_role(self, model):
        import inspect
        if not inspect.isclass(model):
            return None
        if self.UserModel and issubclass(model, self.UserModel):
            return 'user'
        if self.AuthModel and issubclass(model, self.AuthModel):
            return 'auth'
        if self.AdminModel and issubclass(model, self.AdminModel):
            return 'admin'
        if self.AccessModel and issubclass(model, self.AccessModel):
            return 'access'
        return None

    @property
    def signature_auth(self):
        return self.SIGNATURE in self.auth_strategies

    @property
    def basic_auth(self):
        return self.BASIC in self.auth_strategies

    @property
    def session_auth(self):
        return self.SESSION in self.auth_strategies

    @property
    def vendor_auth(self):
        return self.VENDOR in self.auth_strategies

    @property
    def jwt_auth(self):
        return self.JWT in self.auth_strategies

    @property
    def stateless(self):
        return self.signature_auth or self.vendor_auth

    @property
    def user_as_access(self):
        return self.UserModel is self.AccessModel

    def check(self):
        if not self._enabled:
            return
        if not self.auth_service:
            assert self.user_model, f'Auth config must specify user_model, useless you user ' \
                               f'model is inherit from utilmeta.models.BaseUser'
            if not self.vendor_auth and not self.signature_auth:
                assert self.login_fields,\
                    f'Auth config must specify login_fields'

    def load_models(self, admin: bool = False):
        from django.db.models import CharField, OneToOneField, BooleanField, \
            DateTimeField, GenericIPAddressField
        from django.core.exceptions import FieldDoesNotExist
        from utilmeta.models import BaseUser
        from utilmeta.fields import PasswordField
        from django.apps import apps

        if admin:
            if not self.admin_model:
                raise ValueError('Auth: admin_model not specified')
            from django.db.models import Model
            admin = import_util(self.admin_model)
            if not issubclass(admin, Model):
                raise TypeError
            self.AdminModel = admin

        if self.auth_service or not self._enabled:
            return
        rules = [
            (self.signup_time_field, 'signup_time', DateTimeField),
            (self.last_login_time_field, 'last_login_time', DateTimeField),
            (self.last_login_ip_field, 'last_login_ip', (GenericIPAddressField, CharField)),
            (self.last_activity_field, 'last_activity', DateTimeField),
            (self.active_field, 'active', BooleanField),
            (self.basic_auth_username_field, None, None),
            (self.jwt_token_field, None, None),
        ]
        classes: list = BaseUser.__subclasses__()
        if classes:
            t: Type[BaseUser] = classes[0]
            tag = model_tag(t)
            if self.user_model and self.user_model.lower() != tag.lower():
                raise ValueError(f'Invalid user model: {self.user_model}, should be {tag}')
            self.user_model = tag
            self.UserModel = t
            if not self.login_fields:
                self.login_fields = [f.field.name for f in [BaseUser.username, BaseUser.email] if
                                     f.field.name in [d.name for d in get_fields(t)]]

            for name, default, types in rules:
                _name = name
                name = name or default
                if not name:
                    continue
                try:
                    f = get_field(self.UserModel, name)
                except FieldDoesNotExist:
                    continue
                if not types:
                    continue
                assert isinstance(f, types), f'Auth user field: {name} ' \
                                             f'must be instance of {types}, got {f}'
                if default and not _name:
                    setattr(self, f'{default}_field', name)

            if t.password and isinstance(t.password.field, CharField):
                self.password_field = BaseUser.password.field.name

            self.allowed_addresses = t.get_allowed_addresses

        elif self.user_model:
            self.UserModel = apps.get_model(self.user_model)
            for name, default, types in rules:
                if not name:
                    continue
                f = get_field(self.UserModel, name)
                if not types:
                    continue
                assert isinstance(f, types), f'Auth user field: {name} ' \
                                             f'must be instance of {types}, got {f}'

        if self.stateless:
            # after assign user model
            return

        if not self.UserModel:
            return
            # raise ValueError('conf.Auth: UserModel not specified, use user_model=<app_label>.<model_name>')
        # to ensure the code from origin django work well for password
        # allow the password-field that is not PasswordField instance
        # mark and add hash before the value is set
        if self.access_model:
            self.AccessModel = apps.get_model(self.access_model)
            f = get_field(self.AccessModel, self.access_user_field)
            assert one_to(f) or f.primary_key, \
                f'Access model user field must be a OneToOneField or pk(as user model), got {f}'
            get_field(self.AccessModel, self.access_key_field, cascade=False)
            get_field(self.AccessModel, self.secret_key_field, cascade=False)

        password_field = None

        if self.auth_model:
            self.AuthModel = apps.get_model(self.auth_model)

            if self.password_field:
                password_field = get_field(self.AuthModel, self.password_field)

            for field in get_fields(self.AuthModel):
                if field.one_to_one and field.related_model == self.UserModel:
                    field: OneToOneField
                    self.auth_user_field = field.name
                    self.auth_user_relate = field.related_query_name()
                if not password_field:
                    if isinstance(field, PasswordField):
                        if password_field:
                            raise ValueError('There is more than one PasswordField in AuthModel, '
                                             'please specify the password_field')
                        password_field = field

            assert hasattr(self.UserModel, self.auth_user_relate), \
                ValueError("Auth Model's OneToOne user require a related_name since occur error when using default")
            if not self.auth_user_field:
                raise AttributeError("Auth Model must has a OneToOneField or OneToOneRel to User Model")
            if not password_field:
                raise AttributeError("Auth Model must has a PasswordField")
        else:
            if self.password_field:
                password_field = get_field(self.UserModel, self.password_field)
            else:
                for field in get_fields(self.UserModel):
                    if isinstance(field, PasswordField):
                        if password_field and password_field != field:
                            raise ValueError('There is more than one PasswordField in UserModel, '
                                             'please specify the password_field')
                        password_field = field

        for field in get_fields(self.UserModel):
            if field.name in self.login_fields:
                assert field.unique, ValueError(f"Auth Config's login_field {field} must be unique")
        assert isinstance(password_field, CharField), \
            f'Auth password_field must be a CharField or its subclass, got {password_field}'
        if isinstance(password_field, PasswordField):
            self.not_apply_prep = True
        else:
            print('WARNING: you are using non-PasswordField as a password field,\n you should call Auth.register(data)'
                  'to create a user or apply password hasher manually,\n UtilMeta recommend to use '
                  'PasswordField to save password')
            if password_field.max_length < self.encoded_password_min_length:
                raise ValueError(f'Auth password field: {password_field} max_length: '
                                 f'{password_field.max_length}\n is less than min encoded password length: '
                                 f'{self.encoded_password_min_length}, UtilMeta recommend to use '
                                 f'PasswordField to save password')
        if password_field:
            self.password_field = password_field.name
        self.models_loaded = True
        from utilmeta.utils import Field
        self.user_template = Field.gen_for(self.UserModel)
        if self.AuthModel:
            self.auth_template = Field.gen_for(self.AuthModel)

    def gen(self):
        return {
            'PASSWORD_HASHERS': self.hashers
        }


class Cookie(Util):
    Lax = 'Lax'
    Strict = 'Strict'

    def __init__(self, age: int = 31449600, domain: str = None, name: str = '',
                 path: str = '/', secure: bool = False, cross_domain: bool = False,
                 http_only: bool = False, same_site: Optional[str] = 'Lax'):
        super().__init__(locals())
        self.age = age
        self.domain = domain
        self.secure = secure
        self.http_only = http_only
        self.same_site = same_site
        self.name = name
        self.path = path
        self.cross_domain = cross_domain

        self._prefix = ''

    @property
    def prefix(self):
        return '_'.join([self._prefix, 'COOKIE'])

    def set_domain(self, domain: str):
        if not self.cross_domain:
            return
        if self.domain:
            return
        if not domain:
            return
        self.domain = get_domain(domain)

    @prefix.setter
    def prefix(self, val):
        self._prefix = val

    def gen(self):
        config = {
            'AGE': self.age,
            'DOMAIN': self.domain,
            'HTTPONLY': self.http_only,
            'NAME': self.name,
            'PATH': self.path,
            'SAMESITE': str(self.same_site),
            'SECURE': self.secure
        }
        return {f'{self.prefix}_{key}': val for key, val in config.items()}


class Csrf(Util):
    def __init__(self, cookie: Cookie = Cookie(),
                 header_name: str = 'HTTP_X_CSRFTOKEN', use_sessions: bool = False,
                 trusted_origins: List[str] = ()):
        super().__init__(locals())
        self.header_name = header_name
        self.use_sessions = use_sessions

        assert isinstance(trusted_origins, (tuple, list, set)), f'Invalid trusted_origins: {trusted_origins}'
        self.trusted_origins = trusted_origins
        assert isinstance(cookie, Cookie)
        cookie.prefix = 'CSRF'
        if not cookie.name:
            cookie.name = 'csrftoken'
        self.cookie = cookie

    def gen(self):
        return {
            'CSRF_HEADER_NAME': self.header_name,
            'CSRF_TRUSTED_ORIGINS': self.trusted_origins,
            'CSRF_USE_SESSIONS': self.use_sessions,
            **self.cookie.gen()
        }


class Session(Util):
    DJANGO_DB = "django.contrib.sessions.backends.db"
    DJANGO_CACHE_DB = "django.contrib.sessions.backends.cache_db"

    CACHE = "django.contrib.sessions.backends.cache"
    FILE = "django.contrib.sessions.backends.file"
    COOKIE = "django.contrib.sessions.backends.signed_cookies"

    DB = 'utilmeta.util.session.db'
    CACHED_DB = 'utilmeta.util.session.cached_db'
    CLUSTER_CACHED_DB = 'utilmeta.util.session.cluster_cached_db'
    CLUSTER_CACHE = 'utilmeta.util.session.cluster_cache'

    PICKLE = 'django.contrib.sessions.serializers.PickleSerializer'
    DJANGO_JSON = 'django.contrib.sessions.serializers.JSONSerializer'
    JSON = 'utilmeta.util.common.encoder.JSONSerializer'

    def __init__(self, engine: str = DB, cache_alias: str = 'default',
                 cluster_scope: bool = False, from_service: str = None,

                 verify_ip_identical: Union[bool, Callable] = False,
                 verify_ua_identical: Union[bool, Callable] = False,
                 limit_per_user: Union[int, Callable] = None,
                 user_preemptive: Union[bool, Callable] = None,
                 user_expiry_age: Union[int, timedelta, Callable] = None,

                 human_ua_only: bool = True,
                 public_ip_only: bool = None,

                 cookie: Cookie = Cookie(http_only=True),
                 serializer: str = JSON,
                 cycle_key_at_login: bool = True,
                 file_path: str = None, **options
                 ):

        super().__init__(locals())

        assert isinstance(cookie, Cookie)
        assert serializer in (self.PICKLE, self.JSON), f'Invalid Session serializer: {serializer}'

        self.engine = engine

        self.serializer = serializer
        if self.engine == self.COOKIE and self.serializer == self.PICKLE:
            raise ValueError('Session using Cookie backend and pickle serializer may cause remote code execution, '
                             'please choose another engine or serializer')

        self.cache_alias = cache_alias
        self.file_path = file_path
        self.human_ua_only = human_ua_only
        self.public_ip_only = public_ip_only

        self.verify_ip_identical = verify_ip_identical
        self.verify_ua_identical = verify_ua_identical
        if user_preemptive is not None and not limit_per_user:
            raise ValueError(f'Session.user_preemptive only works when Session.limit_per_user is set')

        self.user_preemptive = user_preemptive

        if limit_per_user is not None:
            assert self.use_db, f'Session.user_max_session enable requires to use engine in' \
                                f' {[self.DB, self.CACHED_DB, self.CLUSTER_CACHED_DB]}, got {self.engine}'

            assert callable(limit_per_user) or isinstance(limit_per_user, int) and limit_per_user > 0, \
                f'Session.user_max_session must be a callable or a positive integer, got {limit_per_user}'

        self.limit_per_user = limit_per_user
        self.expiry_age = user_expiry_age

        if cluster_scope:
            # assert cookie.cross_domain, f'Session with cluster_scope=True require to turn Cookie(cross_domain=True)'
            if engine not in (self.COOKIE, self.CLUSTER_CACHE, self.CLUSTER_CACHED_DB):
                raise ValueError('Session(cluster_scope=True) only support cross_'
                                 'domain Cookie and clustered Cache backend')

        self.cluster_scope = cluster_scope
        self.engine_cls = None

        cookie.prefix = 'SESSION'
        if not cookie.name:
            cookie.name = 'sessionid'
        if self.use_cookie:
            cookie.http_only = True
        self.cookie = cookie
        self.options = options
        self.cycle_key_at_login = cycle_key_at_login
        self.from_service = from_service

    def set_default_user(self, model):
        from utilmeta.models import BaseUser
        if not issubclass(model, BaseUser):
            return
        if model.session_verify_ua:
            def _v(user):
                if user.session_verify_ua is None:
                    return self.verify_ua_identical
                return user.session_verify_ua
            self.verify_ua_identical = _v

        if model.session_verify_ip:
            def _v(user):
                if user.session_verify_ip is None:
                    return self.verify_ip_identical
                return user.session_verify_ip
            self.verify_ip_identical = _v

        if model.session_expiry_age:
            def _v(user):
                if user.session_expiry_age is None:
                    return self.expiry_age
                return user.session_expiry_age
            self.expiry_age = _v

        if model.session_limit:
            def _v(user):
                if user.session_limit is None:
                    return self.limit_per_user
                return user.session_limit
            self.limit_per_user = _v

        if model.session_preemptive:
            def _v(user):
                if user.session_preemptive is None:
                    return self.user_preemptive
                return user.session_preemptive
            self.user_preemptive = _v

    def check(self):
        import inspect
        module = import_util(self.engine)
        if not inspect.ismodule(module):
            raise ValueError(f'Session.engine string must be a python module path, got {module}')
        cls = getattr(module, 'SessionStore')
        from django.contrib.sessions.backends.base import SessionBase
        assert inspect.isclass(cls) and issubclass(cls, SessionBase),\
            f'Session.engine class must be subclass of {SessionBase}, got {cls}'
        self.engine_cls = cls

    @property
    def use_django_db(self):
        return self.engine in (self.DJANGO_DB, self.DJANGO_CACHE_DB)

    @property
    def use_db(self):
        return self.engine in (self.DB, self.CACHED_DB, self.CLUSTER_CACHED_DB)

    @property
    def use_cache(self):
        return self.engine in (self.CACHE, self.DJANGO_CACHE_DB, self.CLUSTER_CACHE, self.CLUSTER_CACHED_DB)

    @property
    def use_cookie(self):
        return self.engine == self.COOKIE

    @property
    def use_file(self):
        return self.engine == self.FILE

    @property
    def clustered(self):
        return self.engine in (self.CLUSTER_CACHED_DB, self.CLUSTER_CACHE)

    def gen(self):
        return {
            'SESSION_CACHE_ALIAS': self.cache_alias,
            'SESSION_SERIALIZER': self.serializer,
            'SESSION_ENGINE': self.engine,
            'SESSION_EXPIRE_AT_BROWSER_CLOSE': self.expiry_age == 0,
            'SESSION_FILE_PATH': self.file_path,
            **self.cookie.gen()
        }
