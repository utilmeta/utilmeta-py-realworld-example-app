from typing import Dict, List, Optional, Union, Type
from django.db.models import Model
from utilmeta.util.common import multi, pop, \
    import_util, Key, localhost, valid_attr, SEG, \
    get_redis_info, LOCAL_IP, gen_key, get_server_ip, get_interval
from utilmeta.util.base import Util
from datetime import timedelta


def common_key_func(key, key_prefix, version):
    if key_prefix:
        key = '%s:%s' % (key_prefix, key)
    if version:
        key = '%s:%s' % (key, version)
    return key


class AutoCache(Util):
    WRITE_THROUGH = 'WRITE_THROUGH'
    # update cache then update db

    CACHE_ASIDE = 'CACHE_ASIDE'
    # Update DB, then delete the updated cache (if exists)

    WRITE_BACK = 'WRITE_BACK'
    # only update cache, push updated pk to queue, update db from cache periodically
    # NATIVE = 'utilmeta.util.cache.native.NativeCache'
    # PROXY = 'utilmeta.util.cache.proxy.ProxyCache'

    def __init__(self,
                 model_cache_cls: str = None,
                 entity_cls: str = 'utilmeta.util.cache.CacheEntity',
                 cache_alias: str = 'default',
                 # master: str = 'default', replicas: List[str] = (),
                 key_prefix: str = ...,
                 max_entries: int = None,
                 model_cache: bool = False,
                 api_cache: bool = True,
                 client_cache: bool = True,
                 entry_timeout: int = None,
                 check_timeout_interval: int = None,
                 lock_timeout: Union[int, timedelta] = 5,
                 lock_blocking_timeout: Union[int, timedelta] = 5,
                 write_back_interval: timedelta = timedelta(seconds=60),
                 fail_silently: bool = False,
                 exclude_apps: Union[List[str], str] = (),
                 load: bool = True, clean: bool = False,
                 update_strategy: str = CACHE_ASIDE):
        """
        AutoCache only support native cache or redis cache,
        otherwise you can write your custom Cache based on utilmeta.util.cache.base.BaseCache
        """

        super().__init__(locals())

        from utilmeta.util.cache import BaseModelCache, CacheEntity
        # from utilmeta.util.cache import Cache as APICache
        # assert master not in replicas
        assert update_strategy in (self.WRITE_BACK, self.CACHE_ASIDE, self.WRITE_THROUGH)

        self.master_alias = cache_alias
        self.master: Optional[Cache] = None
        # self.replicas: List[Cache] = []
        # self.replicas_alias = set(replicas)
        self.init_load = load
        self.update_strategy = update_strategy
        self.lock_timeout = get_interval(lock_timeout, null=True)
        self.lock_blocking_timeout = get_interval(lock_blocking_timeout, null=True)
        self.fail_silently = fail_silently

        if key_prefix:
            if key_prefix is not ...:
                assert isinstance(key_prefix, str), \
                    f'AutoCache key_prefix must be str, got {key_prefix}'
                assert valid_attr(key_prefix), \
                    f'AutoCache key_prefix should be a valid attr name, got {repr(key_prefix)}'

        self.key_prefix = key_prefix or None
        if update_strategy == self.WRITE_BACK:
            assert isinstance(write_back_interval, timedelta), \
                'AutoCache with update_strategy as "WRITE_BACK" must specify timedelta object <write_back_interval>'
        self.write_back_interval = write_back_interval
        self.model_proxy: Dict[Type[Model], BaseModelCache] = {}
        # self.api_caches: List[APICache] = []
        # if entry_timeout:
        #     assert isinstance(entry_timeout, int), \
        #         f"AutoCache entry_timeout must be a valid int or None, got {entry_timeout}"
        # if check_timeout_interval:
        #     assert isinstance(check_timeout_interval, int), \
        #         f'AutoCache check_timeout_interval must be a valid int or None, got {check_timeout_interval}'
        # elif entry_timeout:
        #     check_timeout_interval = int(entry_timeout / 10)
        self.check_timeout_interval = get_interval(check_timeout_interval, null=True)
        self.entry_timeout = get_interval(entry_timeout, null=True)

        self.model_cache_cls = None
        self.model_cache_cls_string = None
        if model_cache_cls:
            _model_cls = import_util(model_cache_cls)
            assert issubclass(_model_cls, BaseModelCache) and _model_cls != BaseModelCache, \
                f'AutoCache model_cache_cls must based on utilmeta.util.cache.base.BaseCache, got {_model_cls}'
            self.model_cache_cls = _model_cls
            self.model_cache_cls_string = model_cache_cls
        elif model_cache:
            raise ValueError(f'AutoCache with model_cache=True requires to set model_cache_cls')

        _entity_cls = import_util(entity_cls)
        assert issubclass(_entity_cls, CacheEntity), \
            f'AutoCache entity_cls must based on utilmeta.util.cache.CacheEntity, got {_entity_cls}'
        self.entity_cls = _entity_cls
        self.entity_cls_string = entity_cls

        self.exclude_apps = tuple(exclude_apps) if multi(exclude_apps) else (exclude_apps, )
        self.max_entries = max_entries

        self.model_cache = bool(model_cache)
        self.api_cache = bool(api_cache)
        self.client_cache = bool(client_cache)

    def gen(self, caches: Dict[str, 'Cache']):
        assert self.master_alias in caches, \
            f"AutoCache master alias: {repr(self.master_alias)} must in caches keys: {list(caches.keys())}"
        self.master = caches[self.master_alias]
        assert self.master.is_redis, \
            f'AutoCache only support Native cache (use native=True) or Redis cache, got {self.master.backend}'

    def get(self, model, default=None):
        return self.model_proxy.get(model, default)

    @property
    def caches(self):
        return list(self.model_proxy.values())

    def config_model(self, model: Type[Model],
                     not_apply: bool = False, exclude_relates: List[str] = (),
                     load_orders: tuple = (),
                     entry_timeout: int = ...,
                     load: bool = ...,
                     lock_timeout: Union[int, timedelta] = ...,
                     lock_blocking_timeout: Union[int, timedelta] = ...,
                     max_entries: int = ..., update_strategy: str = ...):

        if not self.model_cache:
            raise TypeError('AutoCache.model_cache is not enabled, config model is useless')
        if not issubclass(model, Model):
            raise TypeError(f"AutoCache.config_model should apply to a Model, got {model}")

        def apply(conf, default):
            return default if conf is ... else conf

        if not_apply:
            pop(self.model_proxy, model)

        self.model_proxy[model] = self.model_cache_cls(
            model,
            client_cache=self.client_cache,
            load_orders=load_orders,
            exclude_relates=exclude_relates,
            max_entries=apply(max_entries, self.max_entries),
            entry_timeout=apply(entry_timeout, self.entry_timeout),
            load=apply(load, self.init_load),
            update_strategy=apply(update_strategy, self.update_strategy),
            lock_timeout=apply(lock_timeout, self.lock_timeout),
            lock_blocking_timeout=apply(lock_blocking_timeout, self.lock_blocking_timeout)
        )

    def load_models(self):
        from utilmeta.util.query import MetaManager
        from django.contrib.contenttypes.models import ContentType
        from django.db.models.options import Options
        if not self.model_cache:
            return
        for ct in ContentType.objects.all():
            ct: ContentType
            model = ct.model_class()
            if not model:
                continue
            if model in self.model_proxy:
                if self.model_proxy[model] is None:
                    self.model_proxy.pop(model)
                continue
            if ct.app_label in self.exclude_apps:
                continue
            if model is ContentType:
                # don't cache content_type, change in migrations will not be able to sync to cache
                continue
            meta: Options = getattr(model, '_meta')
            meta.base_manager_name = Key.META_MANAGER
            manager = MetaManager()
            manager.name = Key.META_MANAGER
            meta.add_manager(manager)

            if meta.abstract:
                continue
            self.model_proxy[model] = self.model_cache_cls(
                model, update_strategy=self.update_strategy,
                max_entries=self.max_entries,
                client_cache=self.client_cache,
                entry_timeout=self.entry_timeout,
                lock_timeout=int(self.lock_timeout) if self.lock_timeout else None,
                lock_blocking_timeout=int(self.lock_blocking_timeout) if self.lock_blocking_timeout else None,
            )
        for cache in self.caches:
            cache.load_fields()


class Cache(Util):
    REDIS_TCP = 'redis://'
    REDIS_SSL = 'rediss://'
    UNIX = 'unix://'
    REDIS_DEFAULT_CLIENT = "django_redis.client.DefaultClient"
    REDIS_HERD_CLIENT = "django_redis.client.HerdClient"
    REDIS_SHARD_CLIENT = "django_redis.client.ShardClient"

    DB = 'django.core.cache.backends.db.DatabaseCache'
    FILE = 'django.core.cache.backends.filebased.FileBasedCache'
    DUMMY = 'django.core.cache.backends.dummy.DummyCache'
    LOCMEM = 'django.core.cache.backends.locmem.LocMemCache'
    MEMCACHED = 'django.core.cache.backends.memcached.MemcachedCache'
    PYLIBMC = 'django.core.cache.backends.memcached.PyLibMCCache'
    DJANGO_REDIS = 'django.core.cache.backends.redis.RedisCache'

    REDIS = 'django_redis.cache.RedisCache'

    REDIS_CLUSTER = 'utilmeta.util.cache.cluster.RedisClusterCache'
    MEMCACHED_CLUSTER = 'utilmeta.util.cache.cluster.MemcachedClusterCache'

    TYPES = ('db', 'file', 'dummy', 'locmem', 'memcached', 'redis')
    REPLICA_SUPPORTS = ('redis',)

    @staticmethod
    def auto_random():
        return gen_key(128, alnum=True)

    class Redis(Util):
        DEBUG = 'debug'
        VERBOSE = 'verbose'
        NOTICE = ' notice'
        WARNING = 'warning'

        volatile_lru = 'volatile-lru'
        allkeys_lru = 'allkeys-lru'
        volatile_random = 'volatile-random'
        allkeys_random = 'allkeys-random'
        volatile_ttl = 'volatile-ttl'
        noeviction = 'noeviction'

        def __init__(self, template: str, *, daemonize: bool = False, supervised: str = 'no',
                     timeout: int = 0, bind: Union[str, List[str]] = LOCAL_IP,
                     loglevel: str = NOTICE, logfile: str = '', pidfile: str = '',
                     save: dict = None, tcp_keepalive: int = 0,
                     readonly: bool = None, maxmemory: int = None, maxclients: int = 10000,
                     databases: int = 16, dir: str = None,
                     replica_of: 'Cache' = None,
                     replica_serve_stale_data: bool = True,
                     replica_read_only: bool = True,
                     replica_priority: int = 100,
                     maxmemory_policy: str = noeviction, appendonly: bool = False):
            """
            This class will work with Cache config to generate redis_<port>.conf file ,
            port / requirepass settings are coordinate to base Cache config
            """
            super().__init__(locals())
            assert template and isinstance(template, str), \
                f'Cache.Redis <template> as the path of redis.conf \n' \
                f' to ensure all the settings are properly configured, \n' \
                f'usually set to /etc/redis/redis.conf or /usr/local/redis/redis.conf \n, got {template}'

            assert maxmemory_policy in (self.volatile_lru, self.allkeys_lru, self.volatile_random,
                                        self.volatile_ttl, self.allkeys_random, self.noeviction)
            self.requirepass = ''
            self.bind = LOCAL_IP
            self.port = 6379
            self.local = True
            self.replicaof: Optional[Cache] = None
            self.conf = {}
            self.alias = ''
            self.databases = databases
            self.template = template
            self.dir = dir

            del template

            if save:
                for key, val in save.items():
                    self.conf[f'save {key}'] = val

            for key, val in locals().items():
                key: str
                if SEG in key:
                    continue
                if key in ('self', 'save') or val is None:
                    continue
                if isinstance(val, bool):
                    val = 'yes' if val else 'no'
                elif isinstance(val, str):
                    if not val:
                        # prevent tos set empty str
                        continue
                self.conf[key.replace('_', '-')] = val

        def gen(self, run_dir):
            if self.dir is None:
                self.dir = run_dir
                self.conf['dir'] = run_dir
            self.conf.update({
                'bind': self.bind,
                'port': self.port,
                'requirepass': self.requirepass,
            })
            if self.replicaof:
                self.conf['replicaof'] = f'{self.replicaof.host} {self.replicaof.port}'
                self.conf['masterauth'] = self.replicaof.password

        @property
        def config(self):
            config = ''
            conf_dict = dict(self.conf)
            content = open(self.template, 'r').read()
            for line in content.splitlines():
                if line.startswith('#') or not line.strip(' '):
                    continue
                find = False
                for key in list(conf_dict.keys()):
                    if line.startswith(key + ' '):
                        config += f'{key} {conf_dict.pop(key)}\n'
                        find = True
                if find:
                    continue
                config += line + '\n'
            for key, val in conf_dict.items():
                config += f'{key} {val}\n'
            return config

        @property
        def filename(self):
            return f'redis_{self.alias}_{self.port}.conf'

    def __init__(self, *, backend: str, host: str = LOCAL_IP, private_ip_host: bool = False,
                 port: int = 0, timeout: int = 300, location: str = '',
                 password: str = '', prefix: str = None, max_entries: int = None,
                 cluster_update_interval: int = 30,
                 cluster_task_timeout: int = 3,
                 alert_size_limit_mb: Union[int, float] = None,
                 redis_db: int = 0, redis_scheme: str = REDIS_TCP,
                 redis_config: Redis = None, options: dict = None, replicas: List['Cache'] = None,
                 redis_client: str = REDIS_DEFAULT_CLIENT, function=None):

        super().__init__(locals())

        if options:
            assert type(options) == dict
        if function:
            assert callable(function)
        else:
            function = common_key_func

        if timeout:
            assert timeout > 0
        assert type(redis_db) == int and redis_db >= 0

        self._size_limit = None
        if alert_size_limit_mb:
            assert isinstance(alert_size_limit_mb, (int, float)), \
                "Cache size_limit must be a valid number"
            self._size_limit = int(alert_size_limit_mb * (1024 ** 2))

        self.backend = backend
        self.is_database = self.backend in (self.DB,)
        self.is_redis = self.backend in (self.REDIS, self.REDIS_CLUSTER)
        self.is_locmem = self.backend in (self.LOCMEM,)
        self.is_pylibmc = self.backend in (self.PYLIBMC,)
        self.is_memcached = self.backend in (self.MEMCACHED, self.MEMCACHED_CLUSTER)

        self.client = redis_client
        self.host = host
        self.local = localhost(host)
        if self.local:
            self.host = LOCAL_IP

        self.private_ip_host = private_ip_host
        self.port = port
        self.db = redis_db
        self.password = password
        self.timeout = timeout
        self.prefix = prefix
        self.function = function
        self.alias = None

        self.max_entries = max_entries
        self.cluster_update_interval = cluster_update_interval
        self.cluster_task_timeout = cluster_task_timeout

        self.type = None
        for t in self.TYPES:
            if t in self.backend.lower():
                self.type = t
        if not self.port:
            if self.is_redis:
                self.port = 6379
            elif self.is_memcached:
                self.port = 11211

        if redis_config:
            assert isinstance(redis_config, self.Redis)
            assert self.db < redis_config.databases, \
                f"Cache redis_db: {self.db} index out of redis databases: {redis_config.databases}"
            assert self.is_redis

        self.replicas = replicas or []
        if self.replicas:
            if self.type not in self.REPLICA_SUPPORTS:
                raise ValueError(f'{self.type} Cache not support replicas, '
                                 f'please choose from {self.REPLICA_SUPPORTS}')

        for rep in self.replicas:
            if rep.redis_config:
                rep.redis_config.replicaof = self
            if rep.replicas:
                raise ValueError('replica of Cache cannot have replicas')

        schemes = (self.REDIS_TCP, self.REDIS_SSL, self.UNIX)
        assert redis_scheme in schemes, f'Invalid redis_scheme: {redis_scheme}, must in {schemes}'
        self.redis_scheme = redis_scheme
        self.redis_config: Optional[Cache.Redis] = redis_config
        if self.redis_config:
            self.redis_config.requirepass = self.password
            self.redis_config.port = self.port
            self.redis_config.bind = ' '.join(self.bind_hosts)

        if self.is_database and not location:
            location = '_cache'

        self.location = location or self.redis_location if self.is_redis else ''
        self.options = options or self.redis_option if self.is_redis else {}
        self.cluster_scope = None

    @property
    def ops_store(self):
        return self.is_redis or self.is_memcached

    @property
    def bind_host(self):
        if not self.local:
            return self.host
        if self.private_ip_host:
            return get_server_ip(private_only=True)
        return self.host

    @property
    def bind_hosts(self):
        host = self.bind_host
        if host != LOCAL_IP:
            return [LOCAL_IP, host]
        return [host]

    @property
    def clustered(self):
        return self.backend in (self.MEMCACHED_CLUSTER, self.REDIS_CLUSTER)

    @property
    def caches(self):
        return [self, *self.replicas]

    @property
    def size_limit(self):
        if self.is_redis:
            info = get_redis_info(self.alias)
            return min(info.get('maxmemory', 0), self._size_limit or 0)
        return self._size_limit

    @property
    def connected(self):
        if self.is_redis:
            return bool(get_redis_info(self.alias))
        return True

    @classmethod
    def gen(cls, option_dict: Dict[str, 'Cache'], file_path: str = '') -> dict:
        config = {}
        locations = []
        for name, conf in option_dict.items():
            assert isinstance(conf, cls)
            if conf.redis_config:
                conf.redis_config.alias = name
                filename = conf.redis_config.filename
                if not conf.local:
                    print(f'WARNING: you setup a non-local redis server '
                          f'and present a Redis config,\nthe auto-generated'
                          f'redis config file could not be auto deployed,\n'
                          f'you need to clip the config file: <{filename}>'
                          f'in /deploy/config to the target server '
                          f'and manually run <redis-server {filename}>')

            loc = conf.location
            assert loc not in locations, f'caches location crash at {loc}'
            locations.append(loc)
            conf.alias = name
            if conf.backend == cls.FILE and not conf.location:
                conf.location = file_path
            config[conf.alias] = conf.node_gen()
            for i, r in enumerate(conf.replicas):
                r.alias = f'{name}:{i}'
                if r.redis_config:
                    r.redis_config.alias = r.alias
                config[r.alias] = r.node_gen()
        return config

    def expose(self):
        self.cluster_scope = True
        self.prefix = None
        self.function = lambda key, *_: key

    def node_gen(self) -> dict:
        return {
            'BACKEND': self.backend,
            'KEY_FUNCTION': self.function,
            'KEY_PREFIX': self.prefix,
            'LOCATION': self.location,
            'OPTIONS': self.options,
            'TIMEOUT': self.timeout,
            'MAX_ENTRIES': self.max_entries,
            # properties that used in ClusterCache
            'CACHE_ALIAS': self.alias,
            'TASK_TIMEOUT': self.cluster_task_timeout,
            'UPDATE_INTERVAL': self.cluster_update_interval
        }

    @property
    def redis_option(self):
        return {
            'CLIENT_CLASS': self.client,
            "PASSWORD": self.password
        }

    @property
    def redis_location(self):
        return f'{self.redis_scheme}{self.host}:{self.port}/{self.db}'

    @property
    def host_location(self):
        return f'{self.host}:{self.port}' if self.port else self.location
