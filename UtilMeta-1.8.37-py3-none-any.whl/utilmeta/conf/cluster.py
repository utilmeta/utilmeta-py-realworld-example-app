from utilmeta.util.base import Util
from .common import Version
from typing import List, Union, Dict, Optional, Callable, TYPE_CHECKING
from utilmeta.util.common import SERVER_ERROR_STATUSES, \
    SCHEMES, model_tag, get_interval, get_hostname, import_util
from django.utils.functional import cached_property
if TYPE_CHECKING:
    from utilmeta.ops.schema.service import InstanceSchema
    from utilmeta.fields import CrossServiceKey
from datetime import timedelta
from urllib.parse import urlparse
from .infrastructure import WebServer


class Service(Util):
    def __init__(self, ops_api: str = None, invoke_token: str = None,
                 public_host: str = None,
                 scope: Optional[Union[str, List[str]]] = '*',
                 utilmeta_project: str = None,
                 version: Union[str, Version] = None,
                 access_key: str = None,
                 secret_key: str = None,
                 ):
        super().__init__(locals())
        if ops_api:
            if urlparse(ops_api).scheme not in SCHEMES:
                raise ValueError(f'Service ops_api: {repr(ops_api)} should specify a valid scheme (http / https)')
        self.ops_api = ops_api
        self.invoke_token = invoke_token
        self.scope = scope
        self.version = version
        self.public_scheme = urlparse(public_host or ops_api).scheme
        self.public_host = get_hostname(public_host or ops_api)


class Proxy(Util):
    def __init__(self, native: bool = None,   # usually set as: not PRODUCTION
                 gateway: Union[WebServer, List[WebServer]] = None,
                 check_instances_db: bool = True,
                 approved_services: List[str] = None,
                 approval_required: bool = False,
                 private_only: bool = True,
                 disconnect_window: timedelta = timedelta(seconds=30),
                 # time window to determine whether service is disconnected
                 representative_only: bool = True
                 # only representative of the
                 ):

        super().__init__(locals())
        self.native = native
        self.gateways = [gateway] if isinstance(gateway, WebServer) else list(gateway or [])
        self.check_instances_db = check_instances_db
        self.approved_services = approved_services
        self.approval_required = approval_required
        # if private_only:
        #     assert private_host, f'Proxy with private_only=True must specify' \
        #                          f' a private_host (resolve to private location)'
        self.private_only = private_only
        self.disconnect_window = disconnect_window
        self.representative_only = representative_only


class Cluster(Util):
    DEFAULT_MANAGER = 'utilmeta.ops.cluster.ClusterManager'

    def __init__(self, invoke_token: str = None,
                 expose: bool = False,  # expose api (mount to proxy)
                 template_dir: str = None,
                 single_endpoint: bool = True,
                 proxy: Union[Service, Proxy] = None,
                 action_token_required: bool = True,
                 enable_log_tracing: bool = True,
                 upstream_name: str = None,
                 default_timeout: Union[int, timedelta] = timedelta(seconds=30),
                 health_check_timeout: Union[int, timedelta] = timedelta(seconds=5),
                 health_check_max_retries: int = 3,
                 health_check_retry_interval: Union[int, timedelta] = timedelta(seconds=0.5),

                 proxy_timeout: Union[int, timedelta] = timedelta(seconds=10),        # proxy
                 virtual_nodes: List[int] = (3, 2),      # start with 2 nodes
                 async_on_delete: bool = True,
                 internals: Dict[str, Service] = None,
                 externals: Dict[str, Service] = None,

                 manager_cls: str = DEFAULT_MANAGER,
                 check_instances_db: bool = True,
                 switch_on: bool = True,
                 switch_on_timeout: bool = True,
                 switch_on_server_error: bool = True,
                 switch_on_statuses: List[int] = None,
                 switch_on_idempotent_only: bool = True,
                 additional_options: dict = None,

                 max_retries: int = 1,
                 service_cache: str = 'default',     # service level cache
                 # cluster_session: bool = True,  # session cache is shared among cluster
                 # cluster_cache: str = None,     # cluster level cache
                 instance_rank_algorithm: Callable[[List['InstanceSchema']], List['InstanceSchema']] = None,
                 instance_score_algorithm: Callable[[List['InstanceSchema']], Dict['InstanceSchema', int]] = None,
                 # support self-defined select algorithm
                 ):
        super().__init__(locals())
        self.unique_name = None
        self.is_proxy = isinstance(proxy, Proxy)
        self.proxy_config: Proxy = proxy if self.is_proxy else None
        self.proxy_service: Service = proxy if isinstance(proxy, Service) else None
        self.expose = self.is_proxy or expose
        self.single_endpoint = single_endpoint
        self.internals = internals or {}
        self.externals = externals or {}
        self.invoke_token = invoke_token
        self.action_token_required = action_token_required and not expose
        self.rank_algorithm = instance_rank_algorithm
        self.score_algorithm = instance_score_algorithm
        self.service_cache_alias = service_cache
        self.async_on_delete = async_on_delete
        self.enable_log_tracing = enable_log_tracing
        self.check_instances_db = check_instances_db
        self.manager_cls_string = manager_cls

        if self.proxy_service:
            assert self.proxy_service.ops_api and self.proxy_service.invoke_token, \
                f'Cluster proxy service require to set ops_api (got {repr(self.proxy_service.ops_api)})' \
                f' and invoke_token (got {repr(self.proxy_service.invoke_token)})'

        if self.is_proxy or not self.proxy_service and self.expose:
            assert invoke_token, f'proxy or expose service node must config a invoke_token'
        if externals:
            for alias, srv in externals.items():
                assert srv.invoke_token and srv.ops_api
        self.template_dir = template_dir
        self.cross_service_relates = {}
        self.default_timeout = get_interval(default_timeout)
        self.proxy_timeout = get_interval(proxy_timeout)
        self.health_check_timeout = get_interval(health_check_timeout)
        self.health_check_max_retries = health_check_max_retries
        self.health_check_retry_interval = get_interval(health_check_retry_interval, null=True)

        self._relates_keys = []
        self._backwards: Dict[str, List['CrossServiceKey']] = {}      # stored for remote deletion
        # self._resolver = {}     # proxy's dynamic resolver for debug server
        # self._instance_id = None
        self.virtual_nodes = virtual_nodes
        self.options = additional_options or {}
        self.switch_on = switch_on
        self.switch_on_timeout = switch_on_timeout
        self.switch_on_statuses = switch_on_statuses or []
        if switch_on_server_error:
            self.switch_on_statuses = set(self.switch_on_statuses).union(SERVER_ERROR_STATUSES)
        self.switch_on_idempotent_only = switch_on_idempotent_only
        self.max_retries = max_retries
        self.upstream_name = upstream_name

        self._manager = None
        # self.services: Dict[str, 'ServiceSchema'] = {}
        # self._caches = {}

    def load(self):
        self._manager = self.manager_cls(self)
        return self._manager

    def get_virtual_nodes(self, nodes: int):
        if nodes <= 1:
            return 1
        try:
            return self.virtual_nodes[nodes - 2]
        except IndexError:
            return 1

    @cached_property
    def manager_cls(self):
        from utilmeta.ops.cluster import ClusterManager
        if not self.manager_cls_string:
            return ClusterManager
        cls = import_util(self.manager_cls_string)
        if not issubclass(cls, ClusterManager):
            raise TypeError(f'Cluster.manager_cls must inherit {self.DEFAULT_MANAGER}, got {cls}')
        return cls

    @property
    def manager(self):
        from utilmeta.ops.cluster import ClusterManager
        manager: ClusterManager = self._manager
        if not manager:
            return self.load()
        return manager

    @property
    def proxy_next_upstream(self) -> str:
        if not self.switch_on:
            return 'off'
        options = ['error']
        statuses = [500, 502, 503, 504, 403, 404, 429]
        for status in statuses:
            if status in self.switch_on_statuses:
                options.append(f'http_{status}')
        if self.switch_on_timeout:
            options.append('timeout')
        if not self.switch_on_idempotent_only:
            options.append('non_idempotent')
        return ' '.join(options)

    @property
    def register_required(self):
        return not self.is_proxy and self.proxy_service

    @property
    def cache(self):
        from django.core.cache import caches
        from utilmeta.util.cache.cluster import BaseClusterCache
        cache: BaseClusterCache = caches[self.service_cache_alias]
        return cache

    # @property
    # def redis_con(self):
    #     try:
    #         from utilmeta.conf import config
    #         if config.caches[self.service_cache_alias].is_redis:
    #             from redis.client import Redis
    #             from django_redis import get_redis_connection
    #             con: Redis = get_redis_connection(self.service_cache_alias)
    #             return con
    #     except Exception as e:
    #         if e:
    #             return None
    #     return None

    def add_cross_key(self, field: 'CrossServiceKey'):
        """
        service relates stores other services relates (BACKWARD) which cannot produced in current server
        (in case that FORWARD relates is generated locally and can easily accessed in memory)
        Data Structure of Service relates:
        {
            'www': [{
                'model': 'forum.Content',
                'field': 'creator',
                'target': 'user.User',
                'relate': 'contents',
                'unique': False,
            }]
        }
        when new BACKWARD relates is added, service should walk through the model to check whether
        the relate name is conflicted (with model fields or other relate names)
        """
        from utilmeta.fields import CrossServiceKey
        if not isinstance(field, CrossServiceKey):
            raise TypeError(f'Invalid field: {field}, must be CrossServiceKey object')
        rel_key = (model_tag(field.model, lower=True), field.name)
        if rel_key in self._relates_keys:
            return

        if field.service_name not in self.cross_service_relates:
            self.cross_service_relates[field.service_name] = []
        self.cross_service_relates[field.service_name].append(dict(
            model=model_tag(field.model, lower=True),
            field=field.name,
            target=field.target_model,
            relate=field.related_name,
            unique=field.unique  # one to one field
        ))
        self.cross_service_relates[field.service_name].sort(
            key=lambda item: '%s.%s' % (item["model"], item["field"]))
        self._relates_keys.append(rel_key)
        target = f'{field.service_name}:{field.target_model}'
        if target in self._backwards:
            self._backwards[target].append(field)
        else:
            self._backwards[target] = [field]

    def get_cross_keys(self, service: str, remote_model: str) -> List['CrossServiceKey']:
        return self._backwards.get(f'{service}:{remote_model.lower()}', [])

    def deploy(self, routine: bool = False):
        if not self.is_proxy:
            if routine:
                return
            raise ValueError('cluster deploy requires to be proxy')
        if not self.proxy_config.gateways:
            if routine:
                return
            raise ValueError(f'Gate way not set in your proxy config')
        for gateway in self.proxy_config.gateways:
            gateway(routine=routine)
