import math
import os
from typing import List, Union, Dict, Tuple, Optional, Callable, Type
from utilmeta.util.common import LOG_LEVELS, LogLevel, Attr, MetaHeader, HTTPMethod, Static, multi, \
    METHOD_DEFAULT_STATUS, ERROR_STATUS, FRAMEWORKS, Key, model_tag, get_interval, Param, import_util
from utilmeta.util.base import Util
from utilmeta.util.parser.base import Options
from django.utils.functional import cached_property


from datetime import timedelta

DEFAULT_APPS = {
    'content': 'django.contrib.contenttypes',
    'static': 'django.contrib.staticfiles',
    'session': 'django.contrib.sessions',
}


__all__ = ['Version', 'Log', 'Mail', 'App', 'Http', 'Preference', 'DEFAULT_APPS']


class Version(Util):
    def __init__(self, major: int, minor: int = 0, patch: int = 0, meta: str = None, auto: bool = False):
        super().__init__(locals())
        self.major = int(major)
        self.minor = int(minor)
        self.patch = int(patch)
        self.meta = meta
        self.auto = auto

    def __str__(self):
        version = f'{self.major}.{self.minor or 0}.{self.patch or 0}'
        if self.meta:
            version += '-' + str(self.meta)
        return version

    def __repr__(self):
        return str(self)

    def __eq__(self, other: 'Version'):
        return self.major == other.major and self.minor == other.minor\
               and self.patch == other.patch and self.meta == other.meta

    def compat(self):
        pass

    @classmethod
    def decode(cls, version_str: str) -> 'Version':
        meta = None
        if '-' in version_str:
            version_str, meta = version_str.split('-')
        major, minor, patch = version_str.split('.')
        return cls(major=major, minor=minor, patch=patch, meta=meta)

    def choice(self, versions: List['Version']):
        """
        choose the most compatible version
        """
        pass


class App(Util):
    def __init__(self, base: str, apps_dir: str = None, apps: List[str] = None):
        """
        use this way to lazy-load (by string) class to avoid recursive dependency
        the registered class's name is unique among the app (case-insensitively)
        (usually be Module/Model/Schema/API (with Meta class))
        use <app_label>.<class_name> to quote the target class if quoter is not in that app
        simply use <class_name> if the quoter is under the same app with quote class

        all the class supporting lazy load will call config.app.register(cls) after class initialized
        data structure:
        {
            <class Module>: {
                'app1': {
                    lower('Module1'): (<class Module1>, [Field(...), Field(...)]),
                    lower('Module2'): (None, [lambda: Field(...)])
                }
                'app2': {}
            }
        }
        layers:
        1: quote-class -> apps
        2: app -> classes
        3: class-name -> (Optional[target-class], List[referrer-setter])
        """
        super().__init__(locals())
        self._apps_path = None
        installed_apps = []
        hosted_labels = []
        if apps_dir:
            self._apps_path = os.path.join(base, apps_dir)
            assert os.path.exists(self._apps_path), \
                ValueError(f"Config apps_path: {self._apps_path} not exists")
            app_path = apps_dir.strip('/').replace('/', '.')
            hosted_labels = [p for p in next(os.walk(self._apps_path))[1] if '__' not in p]
            installed_apps += [f'{app_path}.{app}' for app in hosted_labels]
        else:
            hosted_labels = [app.split('.')[-1] for app in apps
                             if not any([app.startswith(fm + '.') for fm in FRAMEWORKS])]
            installed_apps += list(apps)
        self._hosted_labels = hosted_labels
        if installed_apps:
            installed_apps.append(DEFAULT_APPS['content'])
        self._apps = installed_apps
        self._data: Dict[type, Dict[str, Dict[str, Tuple[Optional[type], List[Callable]]]]] = {}

    @classmethod
    def get_app_label(cls, path):
        if not path:
            return Attr.MAIN
        from django.apps.registry import apps, AppConfig
        for key, cfg in apps.app_configs.items():
            cfg: AppConfig
            if path.startswith(cfg.name):
                return cfg.label
        return Attr.MAIN

    def register(self, path, cls: type):
        app_label = self.get_app_label(path)
        t = type(cls)
        apps = self._data.get(t)
        cls_name = cls.__name__.lower()
        cls_info = (cls, [])
        if apps:
            classes = apps.get(app_label)
            if classes:
                _cls = classes.get(cls_name)
                if _cls:
                    if not _cls[0]:
                        classes[cls_name] = (cls, _cls[1])
                    elif cls != _cls[0]:
                        raise ValueError(f'App register failed: class type:{t} for app: <{app_label}> '
                                         f'detected duplicate class name: <{cls.__name__}>')
                    return
                classes[cls_name] = cls_info
            else:
                apps[app_label] = {cls_name: cls_info}
        else:
            self._data[t] = {app_label: {cls_name: cls_info}}

    def register_referrer(self, path, lazy_str: str, cls: type, setter: Callable):
        if '.' in lazy_str:
            try:
                app_label, cls_name = lazy_str.split('.')
            except ValueError:
                raise ValueError(f'Invalid lazy import string: {repr(lazy_str)} should be <app_label>.<class_name> '
                                 f'or <class_name> only if refer to the class inside current app')
        else:
            app_label, cls_name = self.get_app_label(path), lazy_str
        cls_name = cls_name.lower()
        t = type(cls)
        apps = self._data.get(t)
        cls_info = (None, [setter])
        if apps:
            classes = apps.get(app_label)
            if classes:
                _cls_setters = classes.get(cls_name)
                if _cls_setters:
                    _cls = _cls_setters[0]
                    setters = _cls_setters[1]
                    setters.append(setter)
                else:
                    _cls = None
                    setters = [setter]
                classes[cls_name] = (_cls, setters)
            else:
                apps[app_label] = {cls_name: cls_info}
        else:
            self._data[t] = {app_label: {cls_name: cls_info}}

    def assign_all(self):
        for cls_type, apps in self._data.items():
            for app_label, classes in apps.items():
                for cls_name, (target, setters) in classes.items():
                    if not target:
                        raise ValueError(f'{app_label}.{cls_name} is not registered, please check for the name')
                    for setter in setters:
                        setter(target)

    def append(self, app: str):
        self._apps.append(app)

    @property
    def path(self):
        return self._apps_path

    def __contains__(self, item):
        return item in self._apps

    @classmethod
    def app_labels(cls) -> List[str]:
        from django.apps.registry import apps
        labels = []
        for key, cfg in apps.app_configs.items():
            labels.append(cfg.label)
        return labels

    def generate(self):
        from django.apps.registry import apps, AppConfig
        from django.db.models.options import Options
        from django.db.models import Model
        from utilmeta.util.field import Field
        from utilmeta.conf import config
        values = {}
        for i, (key, cfg) in enumerate(apps.app_configs.items()):
            cfg: AppConfig
            if cfg.label not in self._hosted_labels:
                # vendor app
                continue
            models = {}
            for name, model in cfg.models.items():
                model: Type[Model]
                meta: Options = getattr(model, Key.META)
                base = Field.get_first_base(model)
                if meta.auto_created:
                    continue
                models[model.__name__.lower()] = dict(
                    name=model.__name__,
                    base=model_tag(base) if base else None,
                    role=config.auth.get_model_role(model),
                    table=meta.db_table,
                    fields=Field.gen_field_values(model),
                    relations=Field.gen_relations(model),
                    document=model.__doc__ or ''
                )
            values[cfg.label] = models
        return values

    def gen(self):
        return {
            'INSTALLED_APPS': self._apps,
        }


class Log(Util):
    Level = LogLevel
    DEBUG = 'DEBUG'
    INFO = 'INFO'
    WARN = 'WARN'
    ERROR = 'ERROR'
    URGENT = 'URGENT'

    DEFAULT_MANAGER = 'utilmeta.ops.log.LogManager'

    def __init__(self, *,
                 console: bool = False, file: str = '',
                 # using cache as a temporary storage before saving to db
                 # usw 2 strategy to save: time_interval / max_entries
                 # cache_storage: bool = True,
                 # cache_local_memory: bool = False,
                 cache_max_entries: int = None,
                 fallback_file_path: str = None,    # a fallback path when ops db saving is failed
                 omit_api_log_generate: bool = True,
                 omit_task_log_generate: bool = False,
                 # use another thread (common thread pool for log generate)
                 api_log_pre_save_hook: Callable = None,
                 job_log_pre_save_hook: Callable = None,
                 manager_cls: str = DEFAULT_MANAGER,
                 # called before log is save with pre_save_hook(request, response)
                 # executed in another thread for not blocking main request thread
                 # so this hook can contains time consuming queries

                 # mail_list: List[str] = (),
                 # send_mail_level: str = LogLevel.URGENT,
                 # send_mail_interval_limit: Union[int, timedelta] = 60 * 60,
                 process_context_timeout: timedelta = timedelta(hours=1),
                 foreground_save_timeout: Union[int, float, timedelta] = timedelta(milliseconds=200),
                 log_persist_level: str = LogLevel.WARN,
                 log_persist_time_limit: timedelta = 1,
                 volatile_maintain: timedelta = timedelta(days=1),
                 maintain: timedelta = timedelta(days=30),
                 data_store_level: str = LogLevel.WARN,
                 headers_store_level: str = LogLevel.WARN,
                 result_store_level: str = LogLevel.WARN,
                 parse_user_agent: bool = False,
                 exclude_http_methods: List[str] =
                 (HTTPMethod.OPTIONS, HTTPMethod.CONNECT, HTTPMethod.TRACE, HTTPMethod.HEAD),
                 # store_db_queries: bool = False,
                 log_db_query: bool = True,     # including counts and slow queries
                 query_store_time_limit: Optional[timedelta] = timedelta(milliseconds=200)
                 ):

        super().__init__(locals())
        assert result_store_level in LOG_LEVELS
        assert data_store_level in LOG_LEVELS
        assert headers_store_level in LOG_LEVELS
        assert log_persist_level in LOG_LEVELS

        # self.cache_storage = cache_storage
        self.cache_max_entries = cache_max_entries or 100
        self.log_persist_level = LOG_LEVELS.index(log_persist_level)
        self.log_persist_time_limit = get_interval(log_persist_time_limit)
        self.query_limit = get_interval(query_store_time_limit, null=True)
        self.parse_user_agent = parse_user_agent
        self.log_db_query = log_db_query
        self.result_store_level = LOG_LEVELS.index(result_store_level)
        self.headers_store_level = LOG_LEVELS.index(headers_store_level)
        self.data_store_level = LOG_LEVELS.index(data_store_level)
        self.api_log_pre_save_hook = api_log_pre_save_hook
        self.job_log_pre_save_hook = job_log_pre_save_hook
        self.print = console
        self.log_file = file
        self.omit_api_log_generate = omit_api_log_generate
        self.omit_task_log_generate = omit_task_log_generate
        self.volatile_maintain = get_interval(volatile_maintain, ge=timedelta(hours=1))
        self.maintain = get_interval(maintain, ge=self.volatile_maintain)

        self.foreground_save_timeout = get_interval(foreground_save_timeout, null=True)
        self.process_context_timeout = get_interval(process_context_timeout)
        self.exclude_http_methods = [method.upper() for method in exclude_http_methods]
        self.manager_cls_string = manager_cls
        # self.log_file_split_size = log_file_split_size

    @cached_property
    def manager_cls(self):
        from utilmeta.ops.log import LogManager
        if not self.manager_cls_string:
            return LogManager
        cls = import_util(self.manager_cls_string)
        if not issubclass(cls, LogManager):
            raise TypeError(f'Log.manager_cls must inherit {self.DEFAULT_MANAGER}, got {cls}')
        return cls


class Mail(Util):
    SMTP = 'django.core.mail.backends.smtp.EmailBackend'
    CONSOLE = 'django.core.mail.backends.console.EmailBackend'
    DUMMY = 'django.core.mail.backends.dummy.EmailBackend'
    FILE = 'django.core.mail.backends.filebased.EmailBackend'
    LOCMEM = 'django.core.mail.backends.locmem.EmailBackend'

    NETEASE_163 = 'smtp.163.com'
    NETEASE_126 = 'smtp.126.com'
    QQ = 'smtp.qq.com'
    GMAIL = 'smtp.gmail.com'

    # DEFAULT_TEMPLATE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'util/assets/log_mail.html')

    def __init__(self, host: str, user: str, password: str, backend: str = SMTP, use_tls: bool = False,
                 use_ssl: bool = False, port: int = 25, default_from: str = '',
                 # admin_emails: List[str] = (),
                 # alert_template_file: str = DEFAULT_TEMPLATE,
                 # alert_min_send_interval: Union[int, timedelta] = 60 * 60,
                 options: dict = None
                 ):

        super().__init__(locals())
        assert backend in (self.SMTP, self.CONSOLE, self.DUMMY, self.FILE, self.LOCMEM),\
            f'Invalid mail backend: {backend}'
        self.host = host
        self.user = user
        self.password = password
        self.backend = backend
        self.use_tls = use_tls
        self.use_ssl = use_ssl
        self.port = port
        self.options = options or {}
        if not default_from:
            self.default_from = f'<{self.user}>'
        else:
            self.default_from = default_from

    def gen(self) -> dict:
        return {
            'EMAIL_BACKEND': self.backend,
            'EMAIL_HOST': self.host,
            'EMAIL_PORT': self.port,
            'EMAIL_USE_TLS': self.use_tls,
            'EMAIL_USE_SSL': self.use_ssl,
            'DEFAULT_FROM_EMAIL': self.default_from,
            'EMAIL_HOST_USER': self.user,
            'EMAIL_HOST_PASSWORD': self.password,
            **self.options
        }


class Http(Util):
    def __init__(self, expose_headers: Union[str, List[str]] = (MetaHeader.SERVER_VERSION,),
                 error_status: Dict[Type[Exception], int] = ERROR_STATUS,
                 method_status: Dict[str, int] = METHOD_DEFAULT_STATUS):
        super().__init__(locals())
        if isinstance(expose_headers, str):
            expose_headers = [expose_headers]
        self.expose_headers = list(expose_headers)
        _error_status = dict(ERROR_STATUS)
        _error_status.update(error_status)
        self.error_status = _error_status
        _method_status = dict(METHOD_DEFAULT_STATUS)
        _method_status.update(method_status)
        self.method_status = method_status


class Preference(Util):
    BASE_PARSER_CLS = 'utilmeta.util.parser.base.Parser'
    FUNCTION_PARSER_CLS = 'utilmeta.util.parser.func.FunctionParser'
    CLASS_PARSER_CLS = 'utilmeta.util.parser.cls.ClassParser'
    REQUEST_PARSER_CLS = 'utilmeta.util.parser.req.RequestParser'
    MODULE_PARSER_CLS = 'utilmeta.util.parser.mod.ModuleParser'

    JSON_ENCODER_CLS = 'utilmeta.util.common.encoder.MetaJSONEncoder'

    DEFAULT_SCHEMA_GENERATOR_CLS = 'utilmeta.util.query.schema.SchemaGenerator'
    DEFAULT_MODULE_QUERYSET_CLS = 'utilmeta.util.query.manager.MetaQuerySet'

    class ParamOption(Static):
        dataframe = 'dataframe'
        template = 'template'
        exclude = 'exclude'
        offset = 'offset'
        limit = 'limit'
        field = 'field'
        order = 'order'
        page = 'page'
        rows = 'rows'
        key = 'key'
        query = 'query'

    def __init__(self,
                 json_encoder_allow_nan: bool = None,
                 json_encoder_ensure_ascii: bool = None,
                 json_encoder_sort_keys: bool = None,
                 json_encoder_skip_keys: bool = None,
                 json_field_nan_value: Optional[str] = 'NaN',       # only work for JSONField
                 json_field_inf_value: Optional[str] = 'Infinity',  # only work for JSONField
                 json_encoder_cls: str = JSON_ENCODER_CLS,
                 json_decoder_cls: str = None,

                 base_parser_options: Options = None,
                 base_parser_cls: str = BASE_PARSER_CLS,
                 function_parser_cls: str = FUNCTION_PARSER_CLS,
                 class_parser_cls: str = CLASS_PARSER_CLS,
                 request_parser_cls: str = REQUEST_PARSER_CLS,
                 module_parser_cls: str = MODULE_PARSER_CLS,

                 schema_generator_cls: str = DEFAULT_SCHEMA_GENERATOR_CLS,
                 module_queryset_cls: str = DEFAULT_MODULE_QUERYSET_CLS,

                 param_dataframe_name: str = Param.dataframe,
                 param_template_name: str = Param.template,
                 param_exclude_name: str = Param.exclude,
                 param_offset_name: str = Param.offset,
                 param_limit_name: str = Param.limit,
                 param_field_name: str = Param.field,
                 param_order_name: str = Param.order,
                 param_page_name: str = Param.page,
                 param_rows_name: str = Param.rows,
                 param_key_name: str = Param.key,
                 route_query_name: str = Param.query,
                 ):
        super().__init__(locals())

        self.param_options = {key: self.__spec_kwargs__.get(f'param_{key}_name', Param.dict().get(key))
                              for key in self.ParamOption.gen()}

        if isinstance(json_field_nan_value, float):
            if math.isinf(json_field_nan_value) or math.isnan(json_field_nan_value):
                raise TypeError(f'Invalid nan value: {json_field_nan_value}')
        if isinstance(json_field_inf_value, float):
            if math.isinf(json_field_inf_value) or math.isnan(json_field_inf_value):
                raise TypeError(f'Invalid inf value: {json_field_inf_value}')

        self.json_field_nan_value = json_field_nan_value
        self.json_field_inf_value = json_field_inf_value
        self.json_encoder_allow_nan = json_encoder_allow_nan
        self.json_encoder_ensure_ascii = json_encoder_ensure_ascii
        self.json_encoder_sort_keys = json_encoder_sort_keys
        self.json_encoder_skip_keys = json_encoder_skip_keys

        self.base_parser_options = base_parser_options
        self.base_parser_cls_string = base_parser_cls
        self.function_parser_cls_string = function_parser_cls
        self.class_parser_cls_string = class_parser_cls
        self.request_parser_cls_string = request_parser_cls
        self.module_parser_cls_string = module_parser_cls
        self.json_encoder_cls_string = json_encoder_cls
        self.json_decoder_cls_string = json_decoder_cls
        self.schema_generator_cls_string = schema_generator_cls
        self.module_queryset_cls_string = module_queryset_cls

    def process_json_value(self, data):
        if isinstance(data, float):
            if math.isnan(data):
                return self.json_field_nan_value
            if math.isinf(data):
                if not isinstance(self.json_field_inf_value, str):
                    return self.json_field_inf_value
                neg = str(data).startswith('-')
                return ('-' if neg else '') + self.json_field_inf_value
            return data

        elif multi(data):
            return [self.process_json_value(d) for d in data]
        elif isinstance(data, dict):
            return {k: self.process_json_value(v) for k, v in data.items()}
        return data

    def get_param_name(self, param: str):
        return self.param_options.get(param, f'@{param}')

    @cached_property
    def base_parser_cls(self):
        from utilmeta.util.parser.base import Parser
        if not self.base_parser_cls_string:
            return Parser
        cls = import_util(self.base_parser_cls_string)
        if not issubclass(cls, Parser):
            raise TypeError(f'Preference.base_parser_cls must inherit {self.BASE_PARSER_CLS}, got {cls}')
        return cls

    @cached_property
    def function_parser_cls(self):
        from utilmeta.util.parser.func import FunctionParser
        if not self.function_parser_cls_string:
            return FunctionParser
        cls = import_util(self.function_parser_cls_string)
        if not issubclass(cls, FunctionParser):
            raise TypeError(f'Preference.function_parser_cls must inherit {self.FUNCTION_PARSER_CLS}, got {cls}')
        return cls

    @cached_property
    def class_parser_cls(self):
        from utilmeta.util.parser.cls import ClassParser
        if not self.class_parser_cls_string:
            return ClassParser
        cls = import_util(self.class_parser_cls_string)
        if not issubclass(cls, ClassParser):
            raise TypeError(f'Preference.class_parser_cls must inherit {self.CLASS_PARSER_CLS}, got {cls}')
        return cls

    @cached_property
    def request_parser_cls(self):
        from utilmeta.util.parser.req import RequestParser
        if not self.request_parser_cls_string:
            return RequestParser
        cls = import_util(self.request_parser_cls_string)
        if not issubclass(cls, RequestParser):
            raise TypeError(f'Preference.request_parser_cls must inherit {self.REQUEST_PARSER_CLS}, got {cls}')
        return cls

    @cached_property
    def module_parser_cls(self):
        from utilmeta.util.parser.mod import ModuleParser
        if not self.module_queryset_cls_string:
            return ModuleParser
        cls = import_util(self.module_queryset_cls_string)
        if not issubclass(cls, ModuleParser):
            raise TypeError(f'Preference.module_queryset_cls must inherit {ModuleParser}, got {cls}')
        return cls

    @cached_property
    def json_encoder_cls(self):
        from json import JSONEncoder
        if not self.json_encoder_cls_string:
            return JSONEncoder
        cls = import_util(self.json_encoder_cls_string)
        if not issubclass(cls, JSONEncoder):
            raise TypeError(f'Preference.json_encoder_cls must inherit {JSONEncoder}, got {cls}')
        return cls

    @cached_property
    def json_decoder_cls(self):
        from json import JSONDecoder
        if not self.json_decoder_cls_string:
            return JSONDecoder
        cls = import_util(self.json_decoder_cls_string)
        if not issubclass(cls, JSONDecoder):
            raise TypeError(f'Preference.json_decoder_cls must inherit {JSONDecoder}, got {cls}')
        return cls
