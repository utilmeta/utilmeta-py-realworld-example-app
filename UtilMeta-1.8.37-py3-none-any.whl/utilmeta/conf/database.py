import os
from typing import Dict, List, Tuple, Optional
import random
from utilmeta.util.common import http_header, multi, LOCAL_IP, localhost, DB
from utilmeta.util.base import Util


class Database(Util):
    POOLED_POSTGRESQL = 'utilmeta.util.query.pooled_backends.postgresql'
    POOLED_GEVENT_POSTGRESQL = 'utilmeta.util.query.pooled_backends.postgresql_gevent'

    POOLED_MYSQL = 'utilmeta.util.query.pooled_backends.mysql'
    POOLED_ORACLE = 'utilmeta.util.query.pooled_backends.oracle'

    SQLITE = 'django.db.backends.sqlite3'
    ORACLE = 'django.db.backends.oracle'
    MYSQL = 'django.db.backends.mysql'
    POSTGRESQL = 'django.db.backends.postgresql'

    def __init__(self, name: str, engine: str = POSTGRESQL, apps: List[str] = None,
                 user: str = '', time_zone: str = None, replicas: List['Database'] = None,
                 # alert_size_limit_gb: Union[int, float] = None,
                 conn_max_age: Optional[int] = 0,

                 max_connections: int = None,
                 conn_clear_threshold: int = None,
                 active_connection_timeout: int = 60,
                 idle_connection_timeout: int = 120,

                 # pool_enabled: bool = False,
                 pool_min_connections: int = 0,
                 pool_max_connections: int = 16,
                 pool_get_conn_timeout: int = 5,
                 pool_get_conn_retry_interval: float = 0.01,
                 password: str = '', host: str = '', port: int = 0, options: dict = None):

        super().__init__(locals())
        self.engine = engine
        self.name = name
        self.user = user
        if isinstance(apps, str):
            apps = [apps]
        if apps:
            assert multi(apps), f'Database apps must be str list, got {apps}'

        self.apps = apps or []
        self.password = password
        self.host = host or LOCAL_IP
        self.port = port
        self.options = {http_header(opt): val for opt, val in options.items()} if options else {}
        self.base_dir = ''
        self.type = None
        self.alias = None
        self.time_zone = time_zone
        self.replicaof = None
        self.replicas = replicas or []
        if max_connections:
            assert isinstance(max_connections, int) and max_connections > 0
        if conn_clear_threshold:
            assert isinstance(conn_clear_threshold, int) and conn_clear_threshold > 0
        self.max_connections = max_connections
        self.clear_threshold = conn_clear_threshold
        self.idle_connection_timeout = idle_connection_timeout
        self.active_connection_timeout = active_connection_timeout

        for rep in self.replicas:
            rep.replicaof = self
            if rep.replicas:
                raise ValueError('replica of Database cannot have replicas')

        for t in DB.gen():
            if str(t).lower() in self.engine.lower():
                self.type = t
                break

        # self.size_limit = None
        # if alert_size_limit_gb:
        #     assert isinstance(alert_size_limit_gb, int) or isinstance(alert_size_limit_gb, float), \
        #         "Database size_limit must be a valid number"
        #     self.size_limit = int(alert_size_limit_gb * (1024 ** 3))

        if not self.port:
            if self.type == DB.MySQL:
                self.port = 3306
            elif self.type == DB.PostgreSQL:
                self.port = 5432
            elif self.type != DB.SQLite:
                raise ValueError("Database which not has default port require the port settings")

        if self.engine != self.SQLITE:
            assert self.user and self.password, \
                ValueError('Database (except sqlite3) must has user/password, fill the params')
        if conn_max_age:
            assert isinstance(conn_max_age, int), \
                f'Database conn_max_age must be a int seconds or None, got {conn_max_age}'
        self.conn_max_age = None if self.pooled else conn_max_age
        self.pool_min_connections = pool_min_connections
        self.pool_max_connections = pool_max_connections
        self.pool_get_conn_timeout = pool_get_conn_timeout
        self.pool_get_conn_retry_interval = pool_get_conn_retry_interval
        self._pool_manager = None

    @property
    def dbs(self):
        return [self, *self.replicas]

    @property
    def local(self) -> bool:
        if self.engine == self.SQLITE:
            return True
        return localhost(self.host)

    @property
    def file(self):
        if self.engine == self.SQLITE:
            if os.path.isabs(self.name):
                return self.name
            return os.path.join(self.base_dir, self.name + '.sqlite3')
        return None

    @property
    def location(self):
        if self.engine == self.SQLITE:
            return self.file
        return f'{self.host}:{self.port}'

    def get_pooled_key(self):
        if not self.pooled:
            return None
        from threading import current_thread
        return current_thread().ident

    @classmethod
    def locations(cls, dbs: List[Tuple['Database', str]]):
        locations = set()
        for db, ip in dbs:
            if db.engine == Database.SQLITE:
                loc = f'{ip}:{db.file}'
            else:
                loc = f'{ip}:{db.port}' if db.local else db.location
            locations.add(loc)
        return locations

    @classmethod
    def gen(cls, option_dict, base_dir: str = '') -> Tuple[dict, type]:
        databases = []
        app_dbs = {}
        for name, conf in option_dict.items():
            assert isinstance(conf, Database), f'Invalid config type: {type(conf)}, must be Database'
            conf.alias = name
            conf.base_dir = base_dir
            databases.append(conf)
            replicas = []
            for i, rep in enumerate(conf.replicas):
                rep.alias = f'{name}:{i}'
                replicas.append(rep.alias)
                rep.base_dir = base_dir
                databases.append(rep)

            if conf.apps:
                for app in conf.apps:
                    if app in app_dbs:
                        raise ValueError('Database app cannot divided into different databases,'
                                         ' please use Shard if you need to sharding models')

                    app_dbs[app] = (name, replicas)

        return {db.alias: db.node_gen() for db in databases}, cls.gen_router(app_dbs)

    @classmethod
    def gen_router(cls, app_dbs: Dict[str, Tuple[str, List[str]]]):
        if not app_dbs:
            return None

        class Router:
            @staticmethod
            def db_for_read(model, **hints):
                app = model._meta.app_label
                if app not in app_dbs:
                    return None
                master, replicas = app_dbs[app]
                return random.choice(replicas) if replicas else master

            @staticmethod
            def db_for_write(model, **hints):
                app = model._meta.app_label
                if app not in app_dbs:
                    return None
                master, replicas = app_dbs[app]
                return master

            @staticmethod
            def allow_relation(obj1, obj2, **hints):
                return None

            @staticmethod
            def allow_migrate(db, app_label, model_name=None, **hints):
                if app_label in app_dbs:
                    master, replicas = app_dbs[app_label]
                    return db in [master, *replicas]
                else:
                    return None

        return Router

    @property
    def pool_manager(self):
        return self._pool_manager

    @property
    def pooled(self):
        return self.engine in (self.POOLED_MYSQL, self.POOLED_POSTGRESQL, self.POOLED_ORACLE,
                               self.POOLED_GEVENT_POSTGRESQL)

    @property
    def pooled_green_backend(self):
        if self.engine == self.POOLED_GEVENT_POSTGRESQL:
            return 'gevent'
        return None

    def load_pool_manager(self):
        if not self.pooled:
            return
        if self.engine == self.POOLED_POSTGRESQL:
            from psycopg2.pool import ThreadedConnectionPool
            self._pool_manager = ThreadedConnectionPool(
                maxconn=self.pool_max_connections,
                minconn=self.pool_min_connections,
                dbname=self.name,
                user=self.user,
                password=self.password,
                host=self.host,
                port=self.port
            )
        elif self.engine == self.POOLED_MYSQL:
            pass

    def node_gen(self) -> dict:
        if self.engine == self.SQLITE:
            return {
                'ENGINE': self.engine,
                'NAME': self.file,
                **self.options
            }
        return {
            'ENGINE': self.engine,
            'HOST': self.host,
            'PORT': self.port,
            'NAME': self.name,
            'USER': self.user,
            'TIME_ZONE': self.time_zone,
            'PASSWORD': self.password,
            'CONN_MAX_AGE': self.conn_max_age,
            'DISABLE_SERVER_SIDE_CURSORS': self.pooled,
            **self.options
        }
