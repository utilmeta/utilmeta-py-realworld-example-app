import os
import re
import sys
import multiprocessing
from typing import Union, List, Dict, Optional, TYPE_CHECKING, Callable
from utilmeta.util.common import multi, Scheme, gen_key, Key, get_interval, \
    get_origin, TimeZone, duplicate, PY_NAMES, get_server_ip, remove_file, guess_mime_type, \
    LOCAL, LOCAL_IP, localhost, path_join, sys_deployable, write_to, COMMON_ERRORS, \
    check_requirement, ReqType, get_real_file, sys_user_exists, sys_user_add, find_port, \
    distinct, parse_socket, process_url, get_processes, DB, ignore_errors, distinct_add
from django.utils.functional import cached_property
from datetime import timedelta
from utilmeta.util.base import Util
from .infrastructure import *
from datetime import datetime
import time
import pytz
import warnings

SERVER_UTCOFFSET = -time.timezone
if TYPE_CHECKING:
    from utilmeta.bin.commands.base import Service

PUBLIC_HTTP = '0.0.0.0:80'
PUBLIC_HTTPS = '0.0.0.0:443'


class Lock:
    register = 'register'


class Time(Util):
    DATE_DEFAULT = '%Y-%m-%d'
    TIME_DEFAULT = '%H:%M:%S'
    DATETIME_DEFAULT = "%Y-%m-%d %H:%M:%S"
    TimeZone = TimeZone

    def __init__(self, *, date_format: str = DATE_DEFAULT, time_format: str = TIME_DEFAULT, use_tz: bool = None,
                 datetime_format: str = DATETIME_DEFAULT, time_zone: str = TimeZone.UTC):
        super().__init__(locals())
        self.time_format = time_format
        self.date_format = date_format
        self.datetime_format = datetime_format
        #   assert time_zone in TIME_ZONES, f'Invalid time_zone: {TIME_ZONES}'
        self.time_zone = time_zone
        self.use_tz = use_tz

    def gen(self):
        config = {
            'DATETIME_FORMAT': self.datetime_format,
            'DATE_FORMAT': self.date_format,
            'TIME_ZONE': self.time_zone,
        }
        if self.use_tz is not None:
            config['USE_TZ'] = self.use_tz
        return config

    @property
    def server_utcoffset(self) -> int:
        # django might change the timezone in Unix systems
        # so record SERVER_UTCOFFSET before configure django
        return SERVER_UTCOFFSET

    @property
    def timezone(self):
        return pytz.timezone(self.time_zone)

    @property
    def timezone_utcoffset(self) -> int:
        return int(datetime.now(pytz.timezone(self.time_zone)).utcoffset().total_seconds())
        
    @property
    def value_utcoffset(self) -> int:
        if self.use_tz:
            return 0
        return self.timezone_utcoffset


class Host(Util):
    @staticmethod
    def parse_hosts(hosts: list):
        _hosts = []
        for host in hosts:
            host: str
            if ':' in host:
                _hosts.append(host.split(':')[0])
            else:
                _hosts.append(host)
        return distinct(_hosts)
    
    def __str__(self):
        return self.host
    
    def __init__(self, product: str = None, private_only: bool = False,
                 private_host: str = None, private_https: bool = False,
                 develop: str = '127.0.0.1:8000', allows: List[str] = (LOCAL_IP, LOCAL),
                 remove_www_prefix: bool = False):
        super().__init__(locals())
        if not private_only:
            assert product, f'Public service must specify a product host'

        self.production_host = get_origin(product, with_scheme=False)
        self.development_host = get_origin(develop, with_scheme=False)

        self.private_host = private_host
        self.private_only = private_only
        self.private_https = private_https
        self.production = False

        allows = list(set(allows).union({LOCAL, LOCAL_IP}))
        if self.private_host:
            allows.append(self.private_host)

        self.allows = [get_origin(a, trans_local=False, with_scheme=False) for a in allows] if allows else []
        if remove_www_prefix:
            assert product.count('.') == 1, \
                f'Host remove_www_prefix=True require the product' \
                f' host to be a main host like "example.com", got {repr(product)}'
        self.remove_www_prefix = remove_www_prefix

    @property
    def host(self):
        return self.service_host if self.production else self.development_host

    def remove_www(self, remote: bool = False):
        if remote:
            return self.remove_www_prefix
        return False if self.private_only else self.remove_www_prefix

    def get_host(self, remote: bool = False):
        return self.production_host if remote else self.host

    @property
    def service_host(self):
        return get_server_ip() if self.private_only else self.production_host

    @property
    def local(self):
        return localhost(self.host)

    def gen(self, remote: bool = False, default_server: bool = False, https: bool = False):
        if remote:
            hosts = [self.production_host]
            if self.private_host and self.private_https == bool(https):
                hosts.append(self.private_host)
            return self.parse_hosts(hosts)
        if default_server:
            return [self.host]
        allowed_hosts = [self.host, self.production_host] + self.allows
        return self.parse_hosts(allowed_hosts)


class SSH(Util):
    _MUTABLE = True

    def __init__(self, host: str, port: int = 22,
                 username: str = 'root',
                 password: str = None,
                 key_file: str = None):
        super().__init__(locals())
        if host == LOCAL_IP:
            raise ValueError('localhost ip require no explicit ssh')
        assert username, f'SSH connection should specify a username'
        assert password or key_file
        self.host = host
        self.username = username
        self.password = password
        self.key_file = key_file
        self.port = port

        self._ssh = None
        self._sftp = None

    def __enter__(self):
        import paramiko
        auth = dict(username=self.username)
        if self.password:
            auth.update(password=self.password)
        if self.key_file:
            auth.update(pkey=paramiko.RSAKey.from_private_key_file(self.key_file))
        self._ssh = paramiko.SSHClient()
        self._ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self._ssh.connect(self.host, **auth)
        transport = paramiko.Transport((self.host, self.port))
        transport.connect(**auth)
        self._sftp = paramiko.SFTPClient.from_transport(transport)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._sftp.close()
        self._ssh.close()

    def put_file(self, source, target):
        if not self._sftp:
            self.__enter__()
        self._sftp.put(source, target)

    def get_content(self, lines, console: bool = True):
        content = ''
        if not lines:
            return content
        for line in lines.readlines():
            content += line
            if console:
                print(f'{self.username}@{self.host}:', line)
        return content

    def exec_command(self, command: str):
        if not self._ssh:
            self.__enter__()
        _in, stdout, stderr = self._ssh.exec_command(command)
        out, err = self.get_content(stdout), self.get_content(stderr)
        return out + err


class Https(Util):
    def __init__(self, cert: Union[str, List[str]],
                 cert_key: Union[str, List[str]],
                 cert_chain: Union[str, List[str]] = None,
                 http2: bool = False, hsts: int = 0,
                 stapling: bool = False, http_rewrite: bool = True,
                 production_only: bool = True, secure_cookies: bool = True,
                 session_timeout: timedelta = None, session_cache: str = None,
                 protocols: Union[List[str], str] = None, ciphers: Union[List[str], str] = None):
        super().__init__(locals())
        if isinstance(cert, str):
            cert = [cert]
        if isinstance(cert_key, str):
            cert_key = [cert_key]
        if cert_chain and isinstance(cert_chain, str):
            cert_chain = [cert_chain]

        self.cert = cert
        self.cert_key = cert_key
        self.cert_chain = cert_chain

        assert cert and cert_key, f'Https config must specify a cert and cert_key'
        self.http2 = http2
        if multi(protocols):
            protocols = ' '.join(protocols)
        if multi(ciphers):
            ciphers = ' '.join(ciphers)
        self.protocols = protocols
        self.ciphers = repr(ciphers) if ciphers else None
        if hsts is True:
            hsts = 3600 * 24 * 365
        self.hsts = hsts
        if session_timeout:
            assert isinstance(session_timeout, timedelta), \
                f'Https session_timeout must be a timedelta object, got {session_timeout}'

        self.http_rewrite = http_rewrite
        self.stapling = stapling
        self.session_timeout = session_timeout
        self.session_cache = session_cache
        self.production_only = production_only
        self.secure_cookies = secure_cookies


class Deploy(Util):
    AUTO_WORKERS = multiprocessing.cpu_count() * 2 + 1
    AUTO_PORT = find_port()
    # AUTO_MAX_CONN = get_max_socket_conn()
    AUTO_FILE = '{0}.{1}'

    def __init__(self, *,
                 # ----------- COMMON SETTINGS  (for both uwsgi and gunicorn)
                 user: Union[str, int] = None,
                 group: Union[str, int] = None,

                 socket: Union[str, int] = AUTO_PORT(8000, 9000),

                 workers: int = AUTO_WORKERS,
                 threads: int = 1,
                 worker_class: str = None,
                 worker_connections: int = None,

                 worker_load_app: bool = False,
                 auto_reload: bool = False,

                 # max_worker_lifetime: Union[int, timedelta] = None,
                 max_worker_requests: int = None,
                 max_worker_requests_delta: int = None,

                 max_instance_requests: int = None,
                 min_instance_lifetime: timedelta = None,
                 max_instance_lifetime: timedelta = None,
                 max_instance_lifetime_delta: timedelta = None,
                 max_instance_memory: Union[int, float] = None,
                 instance_restart_window: Union[int, timedelta] = 120,
                 instance_max_consecutive_restarts: int = 5,
                 instance_memory_exceed_force_restart: bool = True,
                 wsgi_production_only: bool = True,

                 listen_backlog: int = None,  # max number of pending tasks
                 pid_file: str = AUTO_FILE,
                 log_file: str = AUTO_FILE,
                 id_file: str = None,
                 # -----------
                 # container: Docker = None,
                 python_path: str = None,
                 https: Union[Https, bool] = None,
                 wsgi_server: WSGI = WSGI(...),
                 web_server: WebServer = None,
                 # -----------
                 static_url: Optional[str] = '/', index_file: str = None,
                 index_default: bool = True,
                 # use index file as the last resort of url resolve, usually used in front-back separate apps
                 media_access: Union[List[str], Dict[str, Union[str, List[str]]]] = None,
                 media_alert_size_limit_gb: Union[int, float] = None,
                 system_daemon: bool = True,
                 # -------------
                 post_fork_callback: Callable = None,
                 health_check_timeout: Union[int, timedelta] = timedelta(seconds=2),
                 health_check_max_retries: int = 3,
                 health_check_retry_interval: Union[int, timedelta] = timedelta(seconds=0.5),

                 check_deployed: bool = True,
                 check_deployed_timeout: timedelta = timedelta(seconds=30),
                 check_deployed_max_reties: int = 5,
                 check_deployed_retry_interval: timedelta = timedelta(seconds=5),

                 deployed_callback: Callable = None,
                 ):

        super().__init__(locals())
        self.python_path = python_path or sys.executable

        self.uid = user
        self.gid = group or 'utilmeta'

        if web_server:
            assert isinstance(web_server, WebServer), f'Invalid web_server {web_server}'
            web_server.deploy = self
        assert isinstance(wsgi_server, WSGI), f'Invalid wsgi_server {wsgi_server}'
        wsgi_server.deploy = self

        self.web_server = web_server
        self.wsgi_server = wsgi_server
        if not self.wsgi_server.UNIX_FILE_SUPPORT and socket == self.AUTO_FILE:
            raise ValueError(f'Deploy wsgi_server: {self.wsgi_server} does not support file socket, '
                             f'use port socket or change to another wsgi_server')

        self._service: Optional['Service'] = None
        if multi(media_access):
            media_access = {process_url(path): path for path in media_access}
        elif isinstance(media_access, dict):
            media_access = {process_url(url): path for url, path in media_access.items()}
        elif media_access:
            raise TypeError(f'Deploy media access must be a <url>:<path> dict or a <path> list, got {media_access}')
        self.media_access: Dict[str, Union[str, List[str]]] = media_access or {}
        self.static_url = process_url(static_url) if static_url else None

        self.worker_class = worker_class
        self.worker_connections = worker_connections
        self.worker_load_app = worker_load_app

        self.max_worker_requests = max_worker_requests
        # self.max_worker_lifetime = get_interval(max_worker_lifetime, null=True)
        self.max_worker_requests_delta = max_worker_requests_delta

        self.wsgi_production_only = wsgi_production_only
        self.max_instance_requests = max_instance_requests
        self.max_instance_lifetime = get_interval(max_instance_lifetime, null=True)
        self.min_instance_lifetime = get_interval(min_instance_lifetime, null=True)
        self.max_instance_lifetime_delta = get_interval(max_instance_lifetime_delta, null=True)
        self.max_instance_memory_percent = None
        self.max_instance_memory_bytes = None
        self.instance_restart_window = get_interval(instance_restart_window)
        self.instance_max_consecutive_restarts = instance_max_consecutive_restarts
        self.health_check_timeout = get_interval(health_check_timeout)
        self.health_check_max_retries = health_check_max_retries
        self.health_check_retry_interval = get_interval(health_check_retry_interval, null=True)

        self.system_daemon = system_daemon
        if max_instance_memory:
            if max_instance_memory > 1:
                self.max_instance_memory_bytes = max_instance_memory
            elif max_instance_memory > 0:
                self.max_instance_memory_percent = max_instance_memory * 100

        self.listen_backlog = listen_backlog
        self.id_file = id_file

        # self.wsgi_module = wsgi
        self.auto_reload = auto_reload
        self.workers = workers
        self.threads = threads

        self.https_proxied = isinstance(https, bool) and bool(https)
        self.https = https if isinstance(https, Https) else None

        if index_file:
            assert index_file.endswith('.html') or index_file.endswith('.htm'), \
                f'Deploy index_file should be a HTML file, got {index_file}'
        self.index_file = index_file
        self.index_default = index_default

        self.pid_file = pid_file
        self.log_file = log_file
        self.socket, self.file_socket = parse_socket(socket)
        self.size_limit = None
        if media_alert_size_limit_gb:
            assert isinstance(media_alert_size_limit_gb, int) or isinstance(media_alert_size_limit_gb, float), \
                "Database size_limit must be a valid number"
            self.size_limit = int(media_alert_size_limit_gb * (1024 ** 3))
        self.root_routes = []

        self.post_fork_callback = post_fork_callback    # worker forked callback
        # from utilmeta.util.common import omit
        self.deployed_callback = deployed_callback
        self.check_deployed_timeout = get_interval(check_deployed_timeout)
        assert check_deployed_max_reties >= 1
        self.check_deployed_max_reties = check_deployed_max_reties
        self.check_deployed = check_deployed
        self.check_deployed_retry_interval = check_deployed_retry_interval.total_seconds()
        self.instance_memory_exceed_force_restart = instance_memory_exceed_force_restart
        self._info = {}

    def get_instance_lifetime_delta(self) -> float:
        if not self.max_instance_lifetime_delta:
            return 0
        import random
        return (random.random() * 2 - 1) * self.max_instance_lifetime_delta

    @property
    def service(self):
        return self._service

    @service.setter
    def service(self, srv: 'Service'):
        from utilmeta.bin.commands.base import Service
        if not isinstance(srv, Service):
            return
        self._service = srv
        self.uid = self.uid or f'admin-{srv.base_name}'

    @property
    def processes(self):
        import psutil
        processes = get_processes(self.wsgi_class, contains=self.service.base)
        if processes:
            return processes
        current_proc = psutil.Process(os.getpid())
        parent = current_proc
        processes = current_proc.children()
        if not processes:
            parent = current_proc.parent()
        if parent:
            processes = [parent, *processes]
        return [p for p in processes if any([name in p.name() for name in PY_NAMES])]

    @property
    def worker_processes(self):
        import psutil
        if self.main_pid:
            master = psutil.Process(self.main_pid)
            return master.children()
        processes = get_processes(self.wsgi_class, contains=self.service.base)
        return [p for p in processes if not p.children()]

    class WorkerLock:
        def __init__(self, name: str, service: 'Service', file_dir: str, timeout: int = 10):
            # consider there might be new workers forked during runtime (uwsgi cheap system)
            self.name = name
            self.service = service
            self.acquired = False
            self.key = None
            self.redis_con = None
            self.file_dir = file_dir
            self.pid = os.getpid()
            self.timeout = timeout
            cfg = service.config
            if cfg.ops and cfg.ops.redis_con:
                self.key = f'{cfg.cache_prefix}#LOCK#{self.name}'
                self.redis_con = cfg.ops.redis_con

        @property
        def file_path(self):
            return os.path.join(self.file_dir, f'{self.service.name}.{self.name}.lock')

        @property
        def log_path(self):
            return os.path.join(self.file_dir, f'{self.service.name}.{self.name}.lock.log')

        def check_released(self):
            if self.key:
                return not self.redis_con.get(self.key)
            return not os.path.exists(self.file_path)

        def wait_till_release(self, callback: Callable, timeout: int = 15, interval: float = 0.5):
            import time
            start = time.time()
            while True:
                if self.check_released():
                    callback()
                    break
                time.sleep(interval)
                if time.time() - start >= timeout:
                    break

        @property
        def is_worker(self):
            import psutil
            return psutil.Process(os.getpid()).parent().name() in PY_NAMES

        def __enter__(self):
            import psutil
            if not self.is_worker:
                self.acquired = False
            elif self.key:
                self.redis_con.set(self.key, self.pid, nx=True, ex=self.timeout)
                acquired_pid: bytes = self.redis_con.get(self.key)
                if acquired_pid:
                    pid = acquired_pid.decode()
                    self.acquired = pid == str(self.pid)
                    if not self.acquired:
                        try:
                            psutil.Process(int(pid))
                        except (*COMMON_ERRORS, psutil.NoSuchProcess):
                            self.redis_con.delete(self.key)
                        self.redis_con.set(self.key, self.pid, nx=True, ex=self.timeout)
                        self.acquired = self.redis_con.get(self.key).decode() == str(self.pid)
                # safest method to acquire lock
            else:
                # simply choose the lowest pid number to avoid competition write
                proc = psutil.Process(self.pid)
                lowest = min([p.pid for p in proc.parent().children() if p.name() in PY_NAMES])
                self.acquired = lowest == self.pid
                if self.acquired:
                    write_to(self.file_path, content=str(self.pid))
            if self.acquired:
                write_to(self.log_path, content=f'({datetime.now()}) [{self.pid}] acquired <{self.name}> lock')
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if not self.acquired:
                return
            if self.key:
                self.redis_con.delete(self.key)
            elif os.path.exists(self.file_path):
                os.remove(self.file_path)

    def acquire_worker_lock(self, name: str):
        return self.WorkerLock(name=name, service=self.service, file_dir=self.service.runtime_root)

    @property
    def exec_path(self):
        return os.path.dirname(get_real_file(self.python_path))

    @property
    def wsgi_class(self):
        return self.wsgi_server.__class__.__name__.lower()

    @property
    def scheme(self):
        return Scheme.HTTPS if (self.https or self.https_proxied) else Scheme.HTTP

    @property
    def root_url(self):
        return process_url(self.service.root_url)

    def socket_path(self, http_scheme: bool = True, unix_scheme: bool = True):
        if self.file_socket:
            return 'unix:%s' % self.socket if unix_scheme else self.socket
        return 'http://%s' % self.socket if http_scheme else self.socket

    @property
    def socket_value(self):
        return self.socket_path(http_scheme=not isinstance(self.wsgi_server, UWSGI))

    @property
    def nginx_includes(self):
        if not isinstance(self.web_server, Nginx):
            return ''
        if isinstance(self.wsgi_server, UWSGI):
            return 'include %s;' % self.web_server.uwsgi_params
        return self.wsgi_server.proxy_config

    @property
    def nginx_proxy_name(self):
        if not isinstance(self.web_server, Nginx):
            return ''
        if isinstance(self.wsgi_server, UWSGI):
            return 'uwsgi_pass'
        return 'proxy_pass'

    @property
    def static_dirs(self):
        dirs = [(self.static_url.rstrip('/'), self.service.static_root)] \
            if self.static_url and self.service.static_root else []
        for url, path in self.media_access.items():
            url = url.rstrip('/')   # The prefix '/' in the STATICFILES_DIRS setting must not end with a slash.
            if isinstance(path, str):
                dirs.append((url, path))
            elif multi(path):
                for p in path:
                    dirs.append((url, p))
        return dirs

    @property
    def index_path(self):
        return path_join(self.service.static_root, self.index_file, create=True)

    @property
    def default_handler(self):
        from django.urls import re_path
        from django.http.response import HttpResponseNotFound

        def default_not_found(*_, **__):
            return HttpResponseNotFound()

        return re_path('(.*)', default_not_found)

    @property
    def url_resolver(self):
        from django.urls import re_path
        from django.views.static import serve
        from django.http.response import Http404
        from functools import wraps
        urls = []

        @wraps(serve)
        def _serve(request, *args, **kwargs):
            try:
                resp = serve(request, *args, **kwargs)
                resp.headers['Content-Type'] = guess_mime_type(kwargs.get('path'))[0]
                return resp
            except Http404:
                return self.get_index_file(request)

        if self.service.production:
            if self.web_server:
                # at production mode, staticfiles is handled by web-server
                return urls
            elif self.static_url or self.media_access:
                print('Auto Deploy Warning: you are deploying staticfiles '
                      'with WSGI server (web-server not specified),'
                      ' which is not recommended')
        for url, dir in self.media_access.items():
            urls.append(re_path(self.static_reg(url), serve, kwargs=dict(document_root=dir)))
        if self.service.static_root and self.static_url:
            urls.append(re_path(
                self.static_reg(), _serve if self.index_file else serve,
                kwargs=dict(document_root=self.service.static_root))
            )
        return urls

    @cached_property
    def main_pid(self):
        import psutil
        proc = psutil.Process(os.getpid())
        if proc.children():
            return proc.pid
        if proc.parent().name() in PY_NAMES:
            return proc.parent().pid
        return proc.pid

    def check_worker_class(self):
        if not self.worker_class or self.worker_class == WSGI.SYNC:
            return
        if not self.service.production or not sys_deployable:
            return

        if self.worker_class == WSGI.GEVENT:
            check_requirement('gevent')
        elif self.worker_class == WSGI.TORNADO:
            if isinstance(self.wsgi_server, Gunicorn):
                raise TypeError(f'Gunicorn not support {self.worker_class} as worker class, use UWSGI')
            check_requirement('tornado')
        else:
            if isinstance(self.wsgi_server, UWSGI):
                raise TypeError(f'uWSGI not support {self.worker_class} as worker class, please choose from'
                                f' gevent and tornado')
            if self.worker_class == WSGI.ASYNC:
                pass
            elif self.worker_class == WSGI.EVENTLET:
                check_requirement('eventlet')
            elif self.worker_class == WSGI.GAIOHTTP:
                check_requirement('aiohttp')
            else:
                raise ValueError(f'Invalid worker class: <{self.worker_class}>')

    def check_user(self):
        if {'root', '0', 0}.intersection({self.uid, self.gid}):
            raise ValueError('Forbidden to use root as user or group at production for security reasons')
        group = self.gid
        user = self.uid
        if not sys_user_exists(group, group=True):
            print(f'meta INFO: add group {group}')
            sys_user_add(name=group, add_group=True)
        if not sys_user_exists(user):
            print(f'meta INFO: add user {user}')
            sys_user_add(name=user, home=self.service.base, login=False, group=group)
        dirs = {
            # self.service.path,
            self.service.runtime_root,  # runtime temporary field needed in worker process
            self.service.media_root,    # need to write data to media dir
            self.service.config_root    # need to write config
            # (important, restart triggered by auto restart with non-root permission must have write access to files)
        }
        if self.file_socket:
            dirs.add(os.path.dirname(self.socket))
        if sys_deployable:
            for path in dirs:
                if not path:
                    continue
                os.system(f'sudo chown -R {user}:{group} {path}/')

    def reset_instance_id(self, origin, to):
        if self.id_file:
            return
        origin_id_file = os.path.join(self.service.runtime_root, '%s.id' % origin)
        to_id_file = os.path.join(self.service.runtime_root, '%s.id' % to)
        if os.path.exists(origin_id_file):
            write_to(to_id_file, content=open(origin_id_file, 'r').read())

    @property
    def instance_id(self):
        instance_id = self._info.get(Key.INSTANCE)
        if instance_id:
            return instance_id
        if not self.service:
            raise ValueError(f'Service not loaded')
        id_file = '%s.id' % self.service.config.service_name
        file = os.path.join(self.service.runtime_root, id_file)
        inst_id = None
        if os.path.exists(file):
            inst_id = open(file, 'r').read().replace('\n', '').strip()
            if len(inst_id) != 6:
                remove_file(file)
                inst_id = None
        if not inst_id:
            from utilmeta.ops.models.common import id_generator
            inst_id = id_generator()
            write_to(file, content=inst_id)
        self._info[Key.INSTANCE] = inst_id
        return inst_id

    def switch_deploy(self):
        if self.python_path != sys.executable:
            # other python path, check and install utilmeta
            if not os.path.exists(self.python_path):
                raise FileNotFoundError(f'Deploy python_path: {repr(self.python_path)} not found')
            meta = os.path.join(self.exec_path, 'meta')
            if not os.path.exists(meta):
                from utilmeta import __version__
                pip = os.path.join(self.exec_path, 'pip')
                os.system(f'{pip} install utilmeta=={__version__}')
            print(f'Switch to python at: {self.python_path}')
            os.system(f'{self.python_path} -m utilmeta deploy')
            # deploy from other python path and exit this process

    def get_index_file(self, request: ReqType):
        from django.http.response import HttpResponse, HttpResponseNotAllowed
        if request.method == 'GET':
            return HttpResponse(open(self.index_path, 'r').read(), content_type='text/html')
        return HttpResponseNotAllowed(['GET'])

    def static_reg(self, url: str = None):
        if url is None:
            url = self.static_url
        return r'^%s(?P<path>.*)$' % re.escape(url.lstrip('/'))

    @ignore_errors
    def worker_post_fork(self, *args, **kwargs):
        # load shared data between workers
        config = self.service.config
        if not config.utilmeta:
            try:
                from utilmeta.service import UtilMeta
                UtilMeta(config=config).generate()
            except Exception as e:
                warnings.warn(f'WORKER SETUP ERROR: {e}')

        if self.post_fork_callback:
            config.preference.function_parser_cls(self.post_fork_callback)(*args, **kwargs)

        if config.cluster and config.cluster.is_proxy and config.cluster.proxy_config.native:
            # load proxy for every worker when debug (production will use web server as load balance)
            root = config.utilmeta.root or config.utilmeta.resolve()
            if root:
                root.load_proxy()

        if config.ops:
            with self.acquire_worker_lock(Lock.register) as lock:
                if lock.acquired:
                    # no matter if cluster is enabled
                    config.cluster_manager.init_service()

        # lock all utilities for all worker
        self._lock_all()
        # lock before make request in case that Logger is locked

        if config.worker_cycle_required:
            if config.monitor.worker_monitor_interval:
                config.monitor.get_worker_task(master=False).start(block=False)
            else:
                warnings.warn('Worker cycle required but no worker interval are set')

    def get_confirm_key(self, name: str):
        return f'{self.service.config.cache_prefix}#CONFIRM#{name}'

    def gen_confirm_token(self, name: str, get: bool = False) -> Optional[str]:
        """
        generate a one-time validation token
        """
        ops = self.service.config.ops
        if not ops:
            raise TypeError('Operations config required')
        key = self.get_confirm_key(name)
        token = gen_key(32, alnum=True)
        if get:
            return ops.cache.get(key, token)
        ops.cache.set(key, token, timeout=60)
        return token

    def gen(self) -> dict:
        if not self.service:
            raise ValueError('Deploy service have not configured')
        root_static_dirs = list(os.walk(self.service.static_root))[0][1] if self.service.static_root else []
        root_routes = [url.strip('/') for url in
                       [self.root_url, self.static_url,
                        *self.media_access, *root_static_dirs] if url]
        dup = duplicate(root_routes)
        if dup:
            raise ValueError(f'Deploy set error: root_url, static urls, media urls '
                             f'should be distinct, got duplicates: {dup}')
        self.root_routes = list(set([url.split('/')[0] for url in root_routes if url]))

        if not self.service.media_root:
            assert not self.media_access, \
                f'Deploy <media-root> is not defined in your meta.ini, ' \
                f'so media_access: {self.media_access} is redundant'
        else:
            for url in list(self.media_access.keys()):
                path = self.media_access[url]
                if not url.strip('/'):
                    raise ValueError(f'Deploy media_access cannot use root url to access {path}, '
                                     f'consider set it to static_root and use static_url="/"')
                if isinstance(path, str):
                    path = path_join(self.service.media_root, path, dir=True, create=True)
                else:
                    path = [path_join(self.service.media_root, p, dir=True, create=True) for p in path]
                self.media_access[url] = path

        if self.service.auto_deploy:
            wsgi_name = self.service.get_name('wsgi')
            if self.service.log_root:
                self.log_file = path_join(self.service.log_root, self.log_file.format(wsgi_name, 'log'), create=True)
            else:
                if not os.path.exists(self.log_file):
                    raise ValueError('Service log-root is not defined in your meta.ini, will'
                                     f' not generate auto log file, got file: {self.log_file} that not exists')
            if self.service.runtime_root:
                self.pid_file = path_join(self.service.runtime_root,
                                          self.pid_file.format(wsgi_name, 'pid'), create=True)
                if self.file_socket:
                    if not isinstance(self.web_server, Nginx):
                        raise TypeError(f'Deploy file socket: {self.socket}'
                                        f' should deploy with Nginx web_server, got {self.web_server}')
                    self.socket = path_join(self.service.runtime_root,
                                            self.socket.format(wsgi_name, 'sock'), ignore=True)
            else:
                if not os.path.exists(self.pid_file):
                    raise ValueError('Service runtime-root is not defined in your meta.ini, will'
                                     f' not generate auto pid file, got file: {self.log_file} that not exists')
                if self.file_socket and not os.path.exists(self.socket):
                    raise ValueError('Service runtime-root is not defined in your meta.ini, will'
                                     f' not generate auto socket file, got file: {self.log_file} that not exists')

            self.wsgi_server.gen()
            if self.web_server:
                self.web_server.gen()
            # do not create sock file, current user (most likely be root) maybe not the user who run the service
            # usually cause permission error

        config = {'WSGI_APPLICATION': self.service.wsgi.replace(':', '.'), 'MEDIA_URL': None}
        if self.service.media_root:
            config['MEDIA_ROOT'] = self.service.media_root
        return config

    @property
    def absolute_meta(self):
        if not sys_deployable:
            return 'meta'
        return os.environ.get('META_ABSOLUTE_PATH') or os.popen('which meta').read().strip() or 'meta'

    @property
    def absolute_python(self):
        if not sys_deployable:
            return 'python'

        def test_alias(alias):
            path = os.popen(f'which {alias}').read().strip()
            if not path:
                return None
            return path

        for al in ['python', 'python3']:
            py = test_alias(al)
            if py:
                return py

        return 'python'

    def get_systemd(self):
        if not self.service:
            raise ValueError(f'Service not set')
        return Systemd(
            name=self.service.service_name,
            description=self.service.config.description,
            work_dir=self.service.path,
            start_command=self.wsgi_server.start_command,
            pre_start_command=f'{self.absolute_meta} deploy --pre',
            post_start_command=f'{self.absolute_meta} deploy --post',
            stop_command=self.wsgi_server.stop_command('$MAINPID'),
            reload_command=self.wsgi_server.reload_command('$MAINPID')
        )

    def get_task_systemd(self):
        if not self.service:
            raise ValueError(f'Service not set')
        task = self.service.config.task
        if not task:
            raise ValueError(f'Task system not enabled')
        start_command = f'{self.absolute_python} {self.service.generate_task_initiator()}'
        stop_command = 'sudo /bin/kill -9 $MAINPID'
        return Systemd(
            name=self.service.task_name,
            user=self.uid if not task.root_user else None,
            group=self.gid if not task.root_user else None,
            environments=dict(
                PYTHONPATH=self.service.path,
            ),
            description=f'UtilMeta Service: {self.service.service_name} Task System',
            work_dir=self.service.path,
            start_command=start_command,
            stop_command=stop_command,
            reload_command=f'{stop_command} && {start_command}'
            # reload_command='sudo /bin/kill -HUP $MAINPID',
        )

    def get_patches(self) -> List[str]:
        from utilmeta.conf import config
        patches = []
        if not config.production:
            return patches
        if self.worker_class == UWSGI.GEVENT:
            # distinct_add(patches, ['gevent'])
            for db in config.databases.values():
                if db.type == DB.PostgreSQL:
                    distinct_add(patches, ['gevent_postgresql'])
        return patches

    @property
    def is_green(self):
        from utilmeta.conf import config
        if not config.production:
            return False
        return self.worker_class in [UWSGI.GEVENT, UWSGI.GTHREAD, UWSGI.GAIOHTTP, UWSGI.EVENTLET]
