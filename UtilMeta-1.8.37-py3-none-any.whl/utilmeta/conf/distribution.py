from utilmeta.util.base import Util
from utilmeta.util.common import ELEMENTS, MAX_BASE, based_number
from datetime import timedelta, datetime


class Dist(Util):
    MAX_INCR_LIMIT_EXP = 6
    MIN_INCR_LIMIT_EXP = 2

    MAX_NODE_LIMIT_EXP = 5
    MIN_NODE_LIMIT_EXP = 1

    STRONG = 'STRONG'
    WEAK = 'WEAK'
    CAUSAL = 'CASUAL'
    EVENTUAL = 'EVENTUAL'
    READ_AFTER_WRITE = 'READ_AFTER_WRITE'
    MONO_READ = 'MONO_READ'

    def __init__(self, *, db: str = 'default', cache: str = 'default',
                 consistency: str = EVENTUAL,
                 time_endurance: timedelta = timedelta(days=365 * 50),
                 id_epoch_time: datetime = None,
                 id_with_flag: bool = False,
                 id_strict_valid_time: bool = False,
                 id_cache_sync_num: int = 1,
                 id_zip_base: int = len(ELEMENTS),
                 id_random_digits: int = 2,
                 id_incr_digits: int = 4,
                 id_node_digits: int = 3):

        assert 10 <= id_zip_base <= MAX_BASE, f'Distribution id_zip_base should in [10, {MAX_BASE}]'
        assert self.MIN_INCR_LIMIT_EXP <= id_incr_digits <= self.MAX_INCR_LIMIT_EXP,\
            f'Distribution id_incr_limit_exp should in [{self.MIN_INCR_LIMIT_EXP}, {self.MAX_INCR_LIMIT_EXP}]'
        assert self.MIN_NODE_LIMIT_EXP <= id_node_digits <= self.MAX_NODE_LIMIT_EXP, \
            f'Distribution id_node_limit_exp should in [{self.MIN_NODE_LIMIT_EXP}, {self.MAX_NODE_LIMIT_EXP}]'
        if id_epoch_time:
            assert isinstance(id_epoch_time, datetime), \
                f'Distribution id_epoch_time should be a datetime object, got {id_epoch_time}'
        super().__init__(locals())
        self.db_alias = db
        self.cache_alias = cache
        self.id_epoch_time = id_epoch_time
        self.zip_base = int(id_zip_base)
        self.incr_digits = int(id_incr_digits)
        self.node_digits = int(id_node_digits)
        self.node_id = 1
        self.with_flag = id_with_flag
        self.time_endurance = time_endurance
        # ensure that at least in such time range, the id length of a given zip base will not change
        self.rand_digits = id_random_digits
        self.strict_valid_time = id_strict_valid_time
        self.length = self.check_length()
        self.sync_num = id_cache_sync_num

    @property
    def tag_digits(self):
        return self.incr_digits + self.node_digits + self.rand_digits

    def check_length(self) -> int:
        lot = datetime.now().timestamp()
        hit = (datetime.now() + self.time_endurance).timestamp()
        if self.id_epoch_time:
            lot = lot - self.id_epoch_time.timestamp()
            hit = hit - self.id_epoch_time.timestamp()
        lo = str(int(lot)) + '0' * self.tag_digits
        hi = str(int(hit)) + '9' * self.tag_digits
        lo_len = len(based_number(int(lo), base=self.zip_base))
        hi_len = len(based_number(int(hi), base=self.zip_base))
        if lo_len != hi_len:
            raise ValueError(f'Distribution ID in given time endurance: '
                             f'{self.time_endurance} could not satisfied the identical length, \n'
                             f'with the lowest at {lo_len} and highest at {hi_len}, '
                             f'you need to tune the id_zip_base to find an identical '
                             f'situation or lower the time_endurance')
        flag = 1 if self.with_flag else 0
        return lo_len + flag

    def get_incr_tag(self, incr_num: int) -> str:
        value = str(incr_num)[-self.incr_digits:]
        zeros = (self.incr_digits - len(value)) * '0'
        return zeros + value

    @property
    def node_tag(self) -> str:
        value = str(self.node_id)[-self.node_digits:]
        zeros = (self.node_digits - len(value)) * '0'
        return zeros + value

    @property
    def cache(self):
        from django.core.cache import caches
        from utilmeta.util.cache.cluster import BaseClusterCache
        cache: BaseClusterCache = caches[self.cache_alias]
        return cache
