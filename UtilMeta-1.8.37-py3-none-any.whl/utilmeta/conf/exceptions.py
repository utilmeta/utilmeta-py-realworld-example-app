

class ConfigError(Exception):
    pass


class UnsetError(ConfigError):
    # some config require to set a value in some condition but remain empty (None)
    pass
