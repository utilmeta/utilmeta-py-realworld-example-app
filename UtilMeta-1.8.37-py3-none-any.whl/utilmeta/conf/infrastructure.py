import os
from typing import Union, List, Dict, Optional, TYPE_CHECKING, Any, Tuple
from utilmeta.util.common import multi, Scheme, get_hostname, LOCAL_IP, ALL_IP,\
    path_join, load_ini, write_config, running, sys_deployable, write_to, \
    run, UTF_8, parse_socket, process_url, JOINER, JOINER2
from utilmeta.util.base import Util

__all__ = ['WebServer', 'WSGI', 'Apache', 'Nginx', 'UWSGI', 'Gunicorn', 'Daemon', 'Systemd']

if TYPE_CHECKING:
    from .deploy import Deploy, SSH, Https


class Daemon(Util):
    pass


class Systemd(Daemon):
    BASE_DIR = '/usr/lib/systemd/system'

    def __init__(self, name: str, description: str = None,
                 kill_mode: str = 'control-group', work_dir: str = None,
                 start_command: str = None,
                 pre_start_command: str = None,
                 post_start_command: str = None,
                 reload_command: str = None,
                 stop_command: str = None,
                 environments: Dict[str, str] = None,
                 user: str = None, group: str = None, restart_seconds: int = 30):
        """
        All of the params here is usually filled by inside utils
        """
        super().__init__(locals())
        assert name
        self.name = name
        self.description = description or ''
        self.start_command = start_command or ''
        self.reload_command = reload_command or ''
        self.stop_command = stop_command or ''
        self.pre_start_command = pre_start_command or ''
        self.post_start_command = post_start_command or ''
        self.user = user
        self.group = group
        self.restart_seconds = restart_seconds
        self.kill_mode = kill_mode
        self.work_dir = work_dir
        self.environments = environments

    @property
    def service_name(self):
        return f'{self.name}.service'

    @property
    def service_path(self):
        return os.path.join(self.BASE_DIR, self.service_name)

    @property
    def env_string(self):
        if not self.environments:
            return ''
        values = []
        for key, val in self.environments.items():
            values.append(f'Environment={key}={val}')
        return '\n'.join(values)

    @property
    def config(self):
        return """
[Unit]
Description={desc}
Wants = network-online.target
After = network.target network-online.target

[Service]
Type=simple
{user}
{group}
{env}
WorkingDirectory={work_dir}

ExecStart={start_command}
ExecStartPre={pre_start_command}
ExecStartPost={post_start_command}
ExecReload={reload_command}
ExecStop={stop_command}
RemainAfterExit=yes

RuntimeDirectory=utilmeta
Restart=always
KillMode={kill_mode}
Restart=on-failure
RestartSec={restart_seconds}s


[Install]
WantedBy=multi-user.target
        """.format(
            desc=self.description or 'UtilMeta Service',
            env=self.env_string,
            start_command=self.start_command,
            pre_start_command=self.pre_start_command,
            post_start_command=self.post_start_command,
            stop_command=self.stop_command,
            reload_command=self.reload_command,
            user=f'User={self.user}' if self.user else '',
            group=f'Group={self.group}' if self.group else '',
            restart_seconds=self.restart_seconds,
            kill_mode=self.kill_mode,
            work_dir=self.work_dir
        )

    @property
    def exists(self):
        return os.path.exists(self.service_path)

    @property
    def active(self):
        # return 0 means active
        return not os.system(f'systemctl is-active --quiet {self.name}')

    def apply(self):
        ex = self.exists
        write_to(self.service_path, self.config)
        os.system('sudo systemctl daemon-reload')
        if not ex:
            self.enable()
        return not ex

    def reload(self):
        return os.system(f'sudo systemctl reload {self.name}')

    def enable(self):
        return os.system(f'sudo systemctl enable {self.name}')

    def start(self):
        return os.system(f'sudo systemctl start {self.name}')

    def stop(self):
        return os.system(f'sudo systemctl stop {self.name}')

    def restart(self):
        return os.system(f'sudo systemctl restart {self.name}')

    def status(self):
        return os.system(f'systemctl status {self.name}')

    def __call__(self):
        if self.apply():
            # first time
            return self.start()
        if self.active:
            if self.reload():
                # not success
                return self.restart()
            return
        return self.restart()


class WebServer(Util):
    UNIX_SOCKET_SUPPORT = False
    UPSTREAM_PROXY_SUPPORT = False

    def __init__(self, file: str, *,
                 ssh_host: 'SSH' = None,
                 # ssh_host: str = None,     # use a remote host to deploy web server (use sftp to transfer file)
                 # ssh_username: str = 'root',
                 # ssh_password: str = None,
                 # ssh_key_file: str = None,
                 https: 'Https' = None,
                 link: str,
                 main: str = None,
                 includes: List[str] = ()):
        super().__init__(locals())
        self.ssh_host = ssh_host
        self.file = file
        self.link = link
        self.main = main
        self.includes = includes
        self.deploy: Optional['Deploy'] = None
        self._https = https

    @property
    def type(self):
        return self.__class__.__name__.lower()

    @property
    def port(self):
        return 443 if self.https else 80

    @property
    def host(self):
        return self.ssh_host.host if self.ssh_host else LOCAL_IP

    @property
    def remote(self):
        return bool(self.ssh_host)

    @property
    def api_routes(self):
        try:
            return self.deploy.service.config.utilmeta.get_routes(api_only=True)
        except AttributeError:
            return None

    @property
    def scheme(self):
        return Scheme.HTTPS if self.https else Scheme.HTTP

    @property
    def https(self):
        return self._https or self.deploy.https

    @property
    def service(self):
        return self.deploy.service

    def gen(self):
        self.file = path_join(self.service.config_root, self.service.get_name(self.file), create=True)

    def load(self):
        raise NotImplementedError

    def exec_commands(self):
        raise NotImplementedError

    @property
    def local_content(self):
        if not os.path.exists(self.file):
            return None
        return open(self.file, 'r').read()

    def apply_multiple(self):
        raise NotImplementedError

    def __call__(self, routine: bool = False):
        config = self.config
        identical = self.local_content == config

        if self.ssh_host:
            if not identical:
                write_to(self.file, config)

            if routine and identical:
                print('Remote web server generated configuration is identical with local file')
                return
            self.exec_commands()    # raise Error will catch and display by upper layer
            print(f'Web server configuration file remotely loaded at {self.ssh_host.host}{self.link}')
        else:
            if self.service.multi_instances:
                identical = self.apply_multiple()

            if identical:
                print('Web server generated configuration is identical with local file')
                return

            if not self.service.multi_instances:
                write_to(self.file, config)
                try:
                    if os.readlink(self.link) != self.file:
                        raise FileNotFoundError
                except (OSError, FileNotFoundError):
                    os.symlink(self.file, self.link)
            self.load()

            if self.service.multi_instances:
                print(f'{self.__class__.__name__} web server loaded instance location')
            else:
                print(f'{self.__class__.__name__} web server loaded with config file linked at {self.link}')

    @classmethod
    def success(cls, content: str, default=None):
        errors = ['error', 'fail', 'denied']
        successes = ['ok', 'success']
        for err in errors:
            if err in content:
                return False
        for ok in successes:
            if ok in content:
                return True
        return default

    @property
    def config(self) -> str:
        raise NotImplementedError


class Apache(WebServer):
    def __init__(self, file: str, *, link: str, main: str = None,
                 includes: List[str] = (), ssh_host: 'SSH' = None):
        super().__init__(file, link=link, main=main, includes=includes, ssh_host=ssh_host)

    @property
    def include_str(self):
        return JOINER.join([f'Include {i}' for i in self.includes])

    @property
    def commands(self):
        commands = [('a2enmod proxy', 'a2enmod mod_proxy'),
                    ('a2enmod proxy_http', 'a2enmod mod_proxy_http'),
                    ('a2enmod rewrite', 'a2enmod mod_rewrite')]
        if self.https:
            commands.append(('a2enmod ssl', 'a2enmod mod_ssl'))
            if self.https.hsts:
                commands.append(('a2enmod headers', 'a2enmod mod_headers'))
            if self.https.http2:
                commands.append(('a2enmod http2', 'a2enmod mod_http2'))
        commands += ['apachectl -t', 'apachectl -k graceful']
        return commands

    def exec_commands(self):
        with self.ssh_host as ssh:
            for main, backup in self.commands:
                if not self.success(ssh.exec_command(main), default=True):
                    if not self.success(ssh.exec_command(backup), default=True):
                        raise ValueError('apache auto-config failed')

    def load(self):
        if self.main:
            main_content = open(self.main, 'r').read()
            if 'ServerName' not in main_content:
                write_to(self.main, f'ServerName {self.service.host}', mode='a')
        for cmd in self.commands:
            main = cmd
            backups = []
            if isinstance(cmd, tuple):
                main, *backups = cmd
            run(main, *backups)

    @property
    def ssl_config(self):
        if not self.https:
            return []
        ssl_config = ['SSLEngine on']
        for cert in self.https.cert:
            ssl_config.append(f"SSLCertificateFile {cert}")
        for cert_key in self.https.cert_key:
            ssl_config.append(f"SSLCertificateKeyFile {cert_key}")

        if self.https.cert_chain:
            ssl_config.append(f'SSLCertificateChainFile {self.https.cert_chain}')
        if self.https.protocols:
            ssl_config.append(f'SSLProtocol {self.https.protocols}')
        if self.https.ciphers:
            ssl_config.append(f'SSLCipherSuite {self.https.ciphers}')
        if self.https.stapling:
            ssl_config.append("SSLUseStapling on")
        if self.https.session_cache:
            ssl_config.append(f"SSLSessionCache {self.https.session_cache}")
        if self.https.session_timeout:
            ssl_config.append(f"SSLSessionCacheTimeout {self.https.session_timeout.total_seconds()}s")
        if self.https.hsts:
            ssl_config.append(f'Header add Strict-Transport-Security "max-age={self.https.hsts}"')
        return JOINER.join(ssl_config)

    @property
    def static_access(self) -> str:
        access = ''

        def conf(u, p):
            return """
<Directory "{path}">
    Require all granted
</Directory>
Alias {url} "{path}/"
                    """.format(url=u, path=p)

        # add / after path, eg. url is /image/ load to /path/to/image/

        for url, path in self.deploy.media_access.items():
            if isinstance(path, str):
                access += conf(url, path)
            elif multi(path):
                for d in path:
                    access += conf(url, d)
        return access
        # there seems few way to implement nginx try_files in apache
        # this code will probably not work, when i find solution later will override

    @property
    def config(self):
        if not self.deploy or not self.service:
            raise ValueError('Deploy service have not configured')
        index_config = """
<Directory "{static_root}">
    Require all granted
</Directory>
DocumentRoot {static_root}
DirectoryIndex {index}
    """.format(static_root=self.service.static_root,
               index=self.deploy.index_file) if self.deploy.index_file else ''

        prepend_servers = []
        rewrites = []

        aliases = 'ServerAlias %s' % ' '.join(self.service.host.allows) if self.service.host.allows else ''

        if self.service.host.remove_www:
            rewrites.append("""
RewriteCond %{{HTTP_HOST}} www.{host}
RewriteRule ^(.*)$ {scheme}://{host}/$1 [L,R=301]
            """.format(host=self.service.host, scheme=self.scheme))

        if self.https and self.https.http_rewrite:
            prepend_servers.append("""
<VirtualHost *:80>
ServerName {host}
{alias}
RewriteEngine On
RewriteRule ^(.*)$ https://{host}/$1 [L,R=301]
</VirtualHost> 
            """.format(host=self.service.host,
                       alias=f'ServerAlias www.{self.service.host}'
                       if self.service.host.remove_www else ''))

        rewrite_content = JOINER.join(['RewriteEngine On', *rewrites]) if rewrites else ''

        return """
{prepend}
<VirtualHost *:{port}>
ServerName {host}
{protocol}
{aliases}
{rewrites}
{ssl}
{index}
{access}
ProxyPass {api} http://{socket}{api}
ProxyPassReverse {api} http://{socket}{api}
{default}
</VirtualHost>
            """.format(
            prepend=JOINER.join(prepend_servers),
            host=self.service.host,
            aliases=aliases,
            protocol='Protocols h2 http/1.1' if self.https and self.https.http2 else '',
            rewrites=rewrite_content,
            port='443' if self.https else '80',
            ssl=self.ssl_config if self.https else '',
            socket=self.deploy.socket,
            index=index_config,
            api=self.deploy.root_url,
            access=self.static_access,
            default='FallbackResource /' if self.deploy.index_default else ''
        )


class Nginx(WebServer):
    UNIX_SOCKET_SUPPORT = True
    UPSTREAM_PROXY_SUPPORT = True

    LEAST_CONN = 'least_conn'
    IP_HASH = 'ip_hash'
    URL_HASH = 'hash $request_uri'
    WEIGHT = 'weight'

    def __init__(self, file: str, *, link: str,
                 main: str = '/etc/nginx/nginx.conf',
                 default: str = '/etc/nginx/sites-enabled/default',
                 charset: str = UTF_8,
                 upstream_strategy: str = WEIGHT, https: 'Https' = None,
                 access_log: str = None, error_log: str = None, includes: List[str] = (),
                 uwsgi_params: str = '', default_server: bool = False, ssh_host: 'SSH' = None):
        super().__init__(file, link=link, main=main, includes=includes, ssh_host=ssh_host)
        if not uwsgi_params:
            if self.main:
                uwsgi_params = os.path.join(os.path.dirname(self.main), 'uwsgi_params')
            else:
                uwsgi_params = '/etc/nginx/uwsgi_params'
        self.uwsgi_params = uwsgi_params
        self.charset = charset
        self.access_log = access_log
        self.error_log = error_log
        self.default_server = default_server
        self.upstream_strategy = upstream_strategy
        self.default = default
        self._https = https

    @property
    def weight_upstream(self):
        return self.upstream_strategy == self.WEIGHT

    @property
    def api_pattern(self) -> str:
        routes = self.api_routes
        if routes:
            if len(routes) == 1:
                return process_url(routes[0])
            return '~ /(%s)/' % '|'.join(routes)
        return '/'

    @property
    def ssl_config(self):
        if not self.https:
            return []
        ssl_config = []
        for cert in self.https.cert:
            ssl_config.append(f"ssl_certificate {cert};")
        for cert_key in self.https.cert_key:
            ssl_config.append(f"ssl_certificate_key {cert_key};")

        if self.https.protocols:
            ssl_config.append(f"ssl_protocols {self.https.protocols};")
        if self.https.ciphers:
            ssl_config.append(f"ssl_ciphers {self.https.ciphers};")
        if self.https.stapling:
            ssl_config.append("ssl_stapling on;")
            ssl_config.append("ssl_stapling_verify on;")
        if self.https.session_cache:
            ssl_config.append(f"ssl_session_cache {self.https.session_cache}")
        if self.https.session_timeout:
            ssl_config.append(f"ssl_session_timeout {self.https.session_timeout.total_seconds()}s;")
        if self.https.hsts:
            ssl_config.append(f'add_header Strict-Transport-Security "max-age={self.https.hsts}";')
        return JOINER.join(ssl_config)

    @property
    def include_str(self):
        return JOINER.join([f'include {i};' for i in self.includes])

    @property
    def static_access(self) -> str:
        access = ''
        for url, path in self.deploy.media_access.items():
            if isinstance(path, str):
                access += """
    location {url}{{
       alias {path}/;
    }}
                    """.format(url=url, path=path)
            # alias append / at last, but root reserve the naked dir
            elif multi(path):
                access += """
    location ~ ^{url}?(.*)$ {{
        try_files {dirs};
    }}
                    """.format(url=url, dirs=' '.join([f'{d}/$1' for d in path]))
        return access

    @property
    def proxy_config(self) -> Tuple[str, str]:
        cluster = self.deploy.service.config.cluster
        if not cluster or not cluster.is_proxy or not self.remote:
            return '', ''
        ups_temp = """
upstream {name} {{
    {strategy}
    {servers}
}}
            """
        loc_temp = """
    location {route}{{
        proxy_pass http://{name};
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header REMOTE_ADDR $remote_addr;
        proxy_next_upstream {switch};
    }}
            """
        upstreams = []
        locations = []

        from utilmeta.ops.models.service import Service
        for service in Service.objects.filter(expose=True).order_by('init_time'):
            service: Service
            upstream_name = (cluster.upstream_name or service.name) if service.this else service.name
            servers = []
            for inst, score in cluster.manager.get_instances_scores(service.name):
                server = get_hostname(inst.base_url)
                options = dict(inst.options)
                if self.weight_upstream:
                    options.update(weight=score)
                options.update(
                    max_fails=inst.max_retries,
                    fail_timeout=int(inst.proxy_timeout)
                )
                option_config = []
                for key, val in options.items():
                    if val is True:
                        option_config.append(key)
                    elif val is not None:
                        option_config.append(f'{key}={val}')

                servers.append(f'server {server} %s;' % ' '.join(option_config))
            if not servers:
                continue
            upstreams.append(ups_temp.format(
                name=upstream_name,
                strategy='' if self.weight_upstream else self.upstream_strategy,
                servers=JOINER.join(servers)
            ))
            if cluster.single_endpoint:
                route = process_url(service.name)
            else:
                route = '~ ^/(%s)(?:/(.*))?$ ' % '|'.join(service.root_routes)
            locations.append(loc_temp.format(
                route=route,
                name=upstream_name,
                switch=cluster.proxy_next_upstream
            ))
        return '\n'.join(upstreams), JOINER.join(locations)

    @property
    def prepend_servers(self):
        ssl_config = self.ssl_config if self.https else ''
        prepend_servers = []
        host = self.service.host.get_host(remote=self.remote)

        if self.service.host.remove_www(remote=self.remote):
            if self.https:
                if self.https.http_rewrite:
                    prepend_servers.append("""
server{{
    listen 80;
    server_name {host} www.{host};
    return 301 https://{host}$request_uri;
}}
                            """.format(host=host))
                prepend_servers.append("""
server{{
    listen 443;
    server_name www.{host};
    return 301 https://{host}$request_uri;
    {ssl}
}}
                        """.format(host=host, ssl=ssl_config))
            else:
                prepend_servers.append("""
server{{
    listen 80;
    server_name www.{host};
    return 301 http://{host}$request_uri;
}}
                        """.format(host=host))
        elif self.https and self.https.http_rewrite:
            prepend_servers.append("""
server{{
    listen 80;
    server_name {hosts};
    return 301 https://{host}$request_uri;
}}
                        """.format(
                host=host,
                hosts=' '.join(self.service.host.gen(remote=self.remote, https=True)))
            )

        return prepend_servers

    def load_locations_path(self):
        if self.main:
            path = os.path.join(os.path.dirname(self.main), 'locations')
        else:
            path = os.path.join(self.service.config_root, 'locations')
        if not os.path.exists(path):
            os.makedirs(path)
        return path

    @property
    def server_config(self):
        return """
server{{
    listen 80 default_server;
    server_name _;
    charset {charset};
    include {locations}/*.conf;
}}
""".format(
            charset=self.charset,
            locations=self.load_locations_path()
        )

    @property
    def api_config(self) -> str:
        if not self.deploy or not self.service:
            raise ValueError('Deploy service have not configured')

        if self.service.config.root_url:
            route = self.deploy.root_url
        else:
            route = '~ ^/(%s)(?:/(.*))?$ ' % '|'.join(self.service.config.utilmeta.root_routes)

        return """
    location {api}{{
        {include}
        {proxy} {socket};
    }}""".format(
            api=route,
            include=self.deploy.nginx_includes,
            socket=self.deploy.socket_value,
            proxy=self.deploy.nginx_proxy_name
        )

    @property
    def index_config(self) -> str:
        try_files = ['$uri', '$uri/']
        if self.deploy.index_default:
            try_files.append(f'/{self.deploy.index_file}')

        return """
    location {static_url}{{
        root {static_root};
        index {index};
        try_files {files};
    }}
                    """.format(
            static_root=self.service.static_root,
            index=self.deploy.index_file,
            files=' '.join(try_files),
            static_url=self.deploy.static_url
        ) if self.deploy.index_file else ''

    @property
    def config(self):
        if not self.deploy or not self.service:
            raise ValueError('Deploy service have not configured')
        ports = ['80']
        if self.https:
            ports = ['443', 'ssl']
            if self.https.http2:
                ports.append('http2')

        prepend = self.prepend_servers
        hosts = self.service.host.gen(remote=self.remote, default_server=self.default_server, https=self.https)
        if self.default_server and not self.remote:
            # must be only one server for default_server, or got nginx: [emerg] a duplicate default server
            ports.append('default_server')
        proxy_upstreams, proxy_locations = self.proxy_config
        if not proxy_locations:
            proxy_locations = self.api_config

        if self.remote and self.service.host.private_host and self.https and not self.service.host.private_https:
            prepend.append("""
server{{
    listen 80;
    server_name {host};
    charset {charset};
    {include}
    {proxy}
}}
        """.format(
                charset=self.charset,
                host=self.service.host.private_host,
                proxy=proxy_locations,
                include=self.include_str,
            ))

        return """
{upstream}
{prepend}
server{{
    listen {port};
    server_name {hosts};
    charset {charset};
    {include}
    {ssl}
    {proxy}
    {static}
    {index}
}}
        """.format(
            upstream=proxy_upstreams,
            proxy=proxy_locations,
            prepend=JOINER.join(prepend),
            include=self.include_str,
            port=' '.join(ports),
            charset=self.charset,
            ssl=self.ssl_config if self.https else '',
            static=self.static_access,
            index=self.index_config,
            hosts=' '.join(hosts),
        )

    def exec_commands(self):
        put = f"sudo echo \'{self.config}\' | sudo tee {self.link} >> /dev/null"
        with self.ssh_host as ssh:
            ssh.exec_command(put)

            if not self.success(ssh.exec_command('sudo nginx -t')):
                raise ValueError('nginx configuration test failed')

            if not self.success(ssh.exec_command('sudo nginx -s reload'), default=True):
                if self.main:
                    if not self.success(ssh.exec_command(f'sudo nginx -c {self.main}'), default=True):
                        raise ValueError('nginx configuration load failed')
                else:
                    raise ValueError('nginx configuration reload failed')

    def apply_multiple(self) -> bool:
        write_to(self.default, self.server_config)
        loc_path = os.path.join(self.load_locations_path(), f'{self.service.name}.{self.service.base_name}.conf')
        identical = os.path.exists(loc_path) and open(loc_path, 'r').read() == self.api_config
        if identical:
            return True
        write_to(loc_path, self.api_config)
        return False

    def load(self):
        run('sudo nginx -t')
        if os.system('sudo nginx -s reload'):
            if self.main:
                run(f'sudo nginx -c {self.main}')


class WSGI(Util):
    STATS = False
    UNIX_FILE_SUPPORT = False
    SYNC = 'sync'
    ASYNC = 'async'
    GEVENT = 'gevent'
    EVENTLET = 'eventlet'
    TORNADO = 'tornado'
    GTHREAD = 'gthread'
    GAIOHTTP = 'gaiohttp'

    def __init__(self, template: str, options: Dict[str, Any] = None):
        super().__init__(locals())
        self.template = template
        self.options = dict(options or {})
        self.deploy: Optional['Deploy'] = None
        # self.stats, self.file_stats = None, False

    @property
    def pid(self):
        pid_content = open(self.deploy.pid_file, 'r').read()
        try:
            return int(pid_content) if pid_content else None
        except (TypeError, ValueError):
            return None

    @property
    def serving(self):
        import psutil
        return self.name in psutil.Process(os.getpid()).name()

    @property
    def service(self):
        return self.deploy.service

    def gen(self):
        if not self.deploy:
            raise ValueError('Deploy config not set')
        self.template = path_join(self.service.config_root, self.service.get_name(self.template), create=True)

    @property
    def name(self):
        return self.__class__.__name__.lower()

    @property
    def absolute_path(self):
        if not sys_deployable:
            return self.name
        abs_path = os.environ.get('WSGI_ABSOLUTE_PATH')
        path = abs_path or os.popen(f'which {self.name}').read().rstrip()
        return path or self.name

    @property
    def start_command(self):
        raise NotImplementedError

    @classmethod
    def stop_command(cls, pid: str):
        return f'sudo /bin/kill -9 {pid}'

    @classmethod
    def reload_command(cls, pid: str):
        return f'sudo /bin/kill -HUP {pid}'

    def apply_fork(self):
        """
        This method should called from wsgi
        :return:
        """
        raise NotImplementedError

    @property
    def proxy_config(self):
        return ''

    @property
    def config(self):
        raise NotImplementedError

    def stop(self):
        import psutil
        if not self.pid:
            print(f'PID not provided')
            return 0
        killed = 0
        try:
            proc = psutil.Process(self.pid)
            killed = len(proc.children()) + 1
            proc.kill()
        except psutil.Error:
            os.system(self.stop_command(str(self.pid)))
        return killed

    def apply(self):
        raise NotImplementedError

    def __call__(self, *args, **kwargs):
        raise NotImplementedError


class UWSGI(WSGI):
    STATS = True
    UNIX_FILE_SUPPORT = True
    SYNC = 'sync'
    GEVENT = 'gevent'
    TORNADO = 'tornado'

    class Cheaper(Util):
        BUSYNESS = 'busyness'
        SPARE = 'spare'
        BACKLOG = 'backlog'
        MANUAL = 'manual'

        _ALGORITHMS = [BACKLOG, BUSYNESS, BACKLOG, MANUAL]

        def __init__(self, algorithm: str, min_workers: int, max_workers: int,
                     init_workers: int,
                     idle_timeout: int = None,
                     interval: int = 60,
                     spawn_step: int = 1,
                     busyness_max: int = None,
                     busyness_min: int = None,
                     busyness_log: bool = False,
                     busyness_multiplier: int = None,
                     busyness_penalty: int = None,
                     busyness_backlog_alert: int = None,
                     busyness_backlog_step: int = None,
                     busyness_backlog_multiplier: int = None,
                     ):
            super().__init__(locals())
            self.algorithm = algorithm

            assert algorithm in self._ALGORITHMS, \
                ValueError(f'UWSGI cheaper_algorithm must in {self._ALGORITHMS}, got {algorithm}')
            assert max_workers and min_workers and min_workers <= init_workers <= max_workers, \
                ValueError(
                    f'UWSGI cheaper must ensure min_workers <= init_workers <= max_workers,'
                    f' they both need to be set to not None')
            self.max_workers = max_workers
            self.min_workers = min_workers
            self.init_workers = init_workers
            self.idle_timeout = idle_timeout
            self.spawn_step = spawn_step
            self.interval = interval
            self.busyness_max = busyness_max
            self.busyness_min = busyness_min
            self.busyness_log = busyness_log
            self.busyness_multiplier = busyness_multiplier
            self.busyness_penalty = busyness_penalty
            self.busyness_backlog_alert = busyness_backlog_alert
            self.busyness_backlog_step = busyness_backlog_step
            self.busyness_backlog_multiplier = busyness_backlog_multiplier

        def gen(self) -> dict:
            config = {
                'workers': self.max_workers,
                'cheaper': self.min_workers,
                'cheaper-initial': self.init_workers,
                'cheaper-step': self.spawn_step,
                'cheaper-overload': self.interval,
                'cheaper-busyness-max': self.busyness_max,
                'cheaper-busyness-min': self.busyness_min,
                'cheaper-busyness-verbose': self.busyness_log,
                'cheaper-busyness-multiplier': self.busyness_multiplier,
                'cheaper-busyness-penalty': self.busyness_penalty,
                'cheaper-busyness-backlog-alert': self.busyness_backlog_alert,
                'cheaper-busyness-backlog-step': self.busyness_backlog_step,
                'cheaper-busyness-backlog-multiplier': self.busyness_backlog_multiplier,
            }
            return {key: val for key, val in config.items() if val is not None}

    def __init__(self, template: str, *,
                 ugreen: bool = False,
                 options: Dict[str, Any] = None,
                 stats: Union[str, int] = None,
                 harakiri: int = None,
                 #  max_worker_lifetime: int = None,
                 worker_reload_mercy: int = None,
                 reload_on_rss: int = None,
                 disable_logging: bool = True,
                 log_4xx: bool = False,
                 log_5xx: bool = False,
                 cheaper: Cheaper = None,
                 allow_signal: bool = False,
                 ):

        super().__init__(template, options=options)
        if stats:
            self.stats, self.file_stats = parse_socket(stats)
        else:
            self.stats, self.file_stats = None, False
        self.harakiri = harakiri
        self.ugreen = ugreen
        self.disable_logging = disable_logging
        self.reload_on_rss = reload_on_rss
        # self.max_worker_lifetime = max_worker_lifetime
        self.worker_reload_mercy = worker_reload_mercy
        self.log_4xx = log_4xx
        self.log_5xx = log_5xx
        if cheaper:
            assert isinstance(cheaper, self.Cheaper)
        self.cheaper = cheaper
        self.allow_signal = allow_signal

    def gen(self):
        super().gen()
        if self.file_stats:
            self.stats = path_join(
                self.service.runtime_root,
                self.stats.format(self.service.get_name('stats'), 'sock'),
                ignore=True)

    def apply_fork(self):
        try:
            import uwsgidecorators
            uwsgidecorators.postfork(self.deploy.worker_post_fork)
        except ModuleNotFoundError:
            pass

    @property
    def config(self):
        if not self.deploy or not self.service:
            raise ValueError('Deploy service have not configured')

        config = {
            'uid': self.deploy.uid,
            'gid': self.deploy.gid,
            'master': True,
            'vacuum': True,
            'strict': True,
            'enable-threads': True,
            'single-interpreter': True,
            'die-on-term': True,
            'need-app': True,
            'disable-logging': self.disable_logging,
            'py-autoreload': int(self.deploy.auto_reload),
            'module': self.service.generate_wsgi_initiator(),
            'chdir': self.service.path,
            'pidfile': self.deploy.pid_file,
            'daemonize': self.deploy.log_file,
            'lazy-apps': self.deploy.worker_load_app,
            **self.options
        }

        if self.cheaper:
            config.update(self.cheaper.gen())
        else:
            config['processes'] = self.deploy.workers

        if self.allow_signal:
            config['py-call-osafterfork'] = True
        if self.deploy.post_fork_callback:
            # import config and load post fork function
            config['import'] = self.service.config.module_name

        if self.harakiri:
            config['harakiri'] = self.harakiri
        if self.deploy.threads and not self.deploy.worker_class:
            config['no-threads-wait'] = True
            config['threads'] = self.deploy.threads
        if self.disable_logging:
            # log errors and critical requests when disable logs
            config['log-4xx'] = self.log_4xx
            config['log-5xx'] = self.log_5xx
        if self.worker_reload_mercy:
            config['worker-reload-mercy'] = self.worker_reload_mercy
        if self.deploy.listen_backlog:
            config['listen'] = self.deploy.listen_backlog
        if self.reload_on_rss:
            config['reload-on-rss'] = self.reload_on_rss
        # if self.deploy.max_worker_lifetime:
        #     config['max-worker-lifetime'] = int(self.deploy.max_worker_lifetime)

        if self.deploy.max_worker_requests:
            config['max-requests'] = self.deploy.max_worker_requests
        if self.deploy.max_worker_requests_delta:
            pass
            # max-requests-delta is supported at uwsgi 2.1
            # config['max-requests-delta'] = self.deploy.max_requests_delta
        if self.deploy.web_server:
            if self.deploy.web_server.UNIX_SOCKET_SUPPORT or self.deploy.file_socket:
                config['socket'] = self.deploy.socket
            else:
                config['http-socket'] = self.deploy.socket
        else:
            config['http'] = self.deploy.socket.replace(LOCAL_IP, ALL_IP)
        if 'pypy' in self.deploy.python_path:
            config['pypy-home'] = self.deploy.python_path

        if self.stats:
            config['stats'] = self.stats
            config['memory-report'] = True
        if self.deploy.worker_class:
            if self.deploy.worker_class == self.ASYNC:
                if self.ugreen:
                    config['ugreen'] = True
            config[self.deploy.worker_class] = self.deploy.worker_connections or 100
            # if self.deploy.worker_class == self.GEVENT:
            #     config['gevent-monkey-patch'] = True
        for k in list(config.keys()):
            if config[k] is None:
                config.pop(k)
        return config

    @property
    def current_config(self) -> dict:
        return load_ini(open(self.template, 'r').read()).get('uwsgi', {})

    @property
    def start_command(self):
        return f'sudo {self.absolute_path} --ini {self.template}'

    def stop_command(self, pid: str):
        return f'sudo {self.absolute_path} --stop {self.deploy.pid_file}'

    def reload_command(self, pid: str):
        return f'sudo {self.absolute_path} --reload {self.deploy.pid_file}'

    def apply(self):
        write_config({'uwsgi': self.config}, path=self.template)

    def __call__(self):
        # not based on current config for that the overwhelmed config will not be override
        self.apply()
        # some cases with virtualenv and versions the uwsgi executable may not at
        # the dir with executable
        pid = self.pid
        if running(pid):
            print(f'uWSGI reload at pid {pid}')
            return os.system(self.reload_command(self.deploy.pid_file))
        return os.system(self.start_command)


class Gunicorn(WSGI):
    def apply_fork(self):
        pass

    SYNC = 'sync'
    ASYNC = 'async'
    GEVENT = 'gevent'
    EVENTLET = 'eventlet'
    GTHREAD = 'gthread'
    GAIOHTTP = 'gaiohttp'

    DEFAULT_HEADERS = {
        'X-Forwarded-For': '$proxy_add_x_forwarded_for',
        'X-Forwarded-Proto': '$scheme',
        'Host': '$http_host'
    }

    def __init__(self, template: str = None, *,
                 limit_request_line: int = None,
                 limit_request_fields: int = None,
                 limit_request_field_size: int = None,
                 capture_output: bool = True,
                 proxy_redirect: bool = False, proxy_buffering: bool = False,
                 set_headers: Dict[str, str] = None, options: Dict[str, Any] = None):
        super().__init__(template, options=options)
        self.limit_request_line = limit_request_line
        self.limit_request_fields = limit_request_fields
        self.limit_request_field_size = limit_request_field_size
        self.set_headers = set_headers or self.DEFAULT_HEADERS
        self.redirect = proxy_redirect
        self.buffering = proxy_buffering
        self.capture_output = capture_output

    @property
    def start_command(self):
        return f'sudo {self.absolute_path} {self.service.generate_wsgi_initiator()} -c {self.template}'

    @property
    def proxy_config(self):
        headers = []
        for key, val in self.set_headers.items():
            headers.append(f'proxy_set_header {key} {val};')
        headers += ['proxy_redirect %s;' % ('on' if self.redirect else 'off'),
                    'proxy_buffering %s;' % ('on' if self.buffering else 'off')]
        return JOINER2.join(headers)

    @property
    def current_config(self) -> dict:
        return load_ini(open(self.template, 'r').read())

    @property
    def bind(self):
        return self.deploy.socket if self.deploy.web_server or self.deploy.file_socket \
            else self.deploy.socket.replace(LOCAL_IP, ALL_IP)

    @property
    def config(self):
        if not self.deploy or not self.service:
            raise ValueError('Deploy service have not configured')
        error_log = path_join(os.path.dirname(self.deploy.log_file),
                              self.service.get_name('error') + '.log', create=True)
        config = {
            'user': self.deploy.uid,
            'group': self.deploy.gid,
            'daemon': True,
            'preload_app': not self.deploy.worker_load_app,
            'bind': self.bind,
            'accesslog': self.deploy.log_file,
            'errorlog': error_log,
            'pidfile': self.deploy.pid_file,
            'worker_class': self.deploy.worker_class,
            'workers': self.deploy.workers,
            'chdir': self.service.path,
            'worker_connections': self.deploy.worker_connections,
            'reload': self.deploy.auto_reload,
            'capture_output': self.capture_output,
            **self.options
        }
        if not self.deploy.worker_class:
            config['threads'] = self.deploy.threads
        if self.deploy.max_worker_requests:
            config['max_requests'] = self.deploy.max_worker_requests
        if self.deploy.max_worker_requests_delta:
            config['max_requests_jitter'] = self.deploy.max_worker_requests_delta
        if self.limit_request_line:
            config['limit_request_line'] = self.limit_request_line
        if self.limit_request_fields:
            config['limit_request_fields'] = self.limit_request_fields
        if self.limit_request_field_size:
            config['limit_request_field_size'] = self.limit_request_field_size
        if self.deploy.listen_backlog:
            config['backlog'] = self.deploy.listen_backlog
        for k in list(config.keys()):
            if config[k] is None:
                config.pop(k)
        return config

    def apply(self):
        write_config(self.config, path=self.template, ini_syntax=False)
        write_to(self.template, f"""
def post_fork(server, worker):
    from {self.service.conf_module} import {self.service.conf_name}
    {self.service.conf_name}.deploy.worker_post_fork(server, worker)
                    """, mode='a')

    def __call__(self, *args, **kwargs):
        self.apply()

        pid = self.pid
        if running(pid):
            run(self.reload_command(str(pid)))
            print(f'Gunicorn loaded from config at {pid}')
        else:
            run(self.start_command)
            print(f'Gunicorn loaded from config at: {self.template}')


class Docker:
    pass
