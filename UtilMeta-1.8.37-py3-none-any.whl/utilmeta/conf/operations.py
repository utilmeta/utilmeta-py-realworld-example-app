import hashlib
from utilmeta.util.base import Util
from urllib.parse import urlparse, ParseResult
from utilmeta.util.common import MAIN_HOST, Scheme, DB, import_util, \
    exc, AlertLevel, get_interval, Dict, ALERT_LEVELS, model_tag, cached_property
from typing import List, Union, Callable, Optional, Tuple
from datetime import timedelta


class Alert(Util):
    def __init__(self,
                 default_interval: Union[int, timedelta] = 60,
                 maintain: timedelta = timedelta(days=30),

                 slow_response_threshold: Union[int, timedelta] = timedelta(seconds=5),
                 slow_response_alert_level: str = AlertLevel.WARNING,
                 slow_query_threshold: Union[int, timedelta] = timedelta(seconds=1),
                 slow_query_alert_level: str = AlertLevel.WARNING,

                 # if an alert trigger more than 10 times a day and avg count is less than 3
                 # then it is automatically detected as an unstable alert, and will notify supervisor
                 min_notify_interval: Union[int, timedelta] = timedelta(minutes=5),
                 notify_supervisor_level: Optional[str] = AlertLevel.CRITICAL,

                 error_request_alert_level: Optional[str] = AlertLevel.CRITICAL,

                 default_compress_window: timedelta = timedelta(hours=3),
                 index_trigger_min_times: int = 2,
                 task_error_trigger_min_times: int = 2,
                 downgrade_trigger_min_times: int = 2,
                 service_error_trigger_min_times: int = 1,

                 service_error_auto_relieve: bool = False,
                 downgrade_auto_relieve: bool = False,
                 task_error_auto_relieve: bool = True,
                 # if an alert is relieved after less than <trigger_min_times>,
                 # then it is not consider as an alert and will be deleted as a noisy alert
                 # also only times pass this threshold will be report

                 # this settings can only for index and task
                 # only for index and task (which next_event is less than max_retries * default_interval)
                 task_downgrade_alert_level: Optional[str] = AlertLevel.WARNING,
                 failed_execution_alert_level: Optional[str] = AlertLevel.WARNING,
                 abandon_event_alert_level: Optional[str] = AlertLevel.WARNING,
                 abandon_event_alert_interval_threshold: Union[int, timedelta] = timedelta(minutes=2),

                 default_level: str = AlertLevel.WARNING,
                 trigger_callback: Callable = None
                 ):
        super().__init__(locals())
        # for mail in admin_emails:
        #     assert re.fullmatch(Reg.EMAIL, mail), ValueError('Log mail list must contains valid mail')
        if trigger_callback:
            assert callable(trigger_callback)
        assert default_level in AlertLevel.gen()
        assert notify_supervisor_level in AlertLevel.gen()
        self.default_interval = get_interval(default_interval, ge=10)
        self.notify_supervisor_level = notify_supervisor_level
        self.min_notify_interval = get_interval(min_notify_interval, ge=self.default_interval)

        self.default_compress_window = get_interval(default_compress_window, ge=self.default_interval)
        self.service_error_auto_relieve = service_error_auto_relieve
        self.downgrade_auto_relieve = downgrade_auto_relieve
        self.task_error_auto_relieve = task_error_auto_relieve

        self.task_downgrade_alert_level = task_downgrade_alert_level
        self.index_trigger_min_times = index_trigger_min_times
        self.task_error_trigger_min_times = task_error_trigger_min_times
        self.downgrade_trigger_min_times = downgrade_trigger_min_times
        self.service_error_trigger_min_times = service_error_trigger_min_times

        self.default_level = default_level
        self.error_request_alert_level = error_request_alert_level
        self.failed_execution_alert_level = failed_execution_alert_level
        self.abandon_event_alert_level = abandon_event_alert_level
        self.abandon_event_interval_threshold = get_interval(abandon_event_alert_interval_threshold, null=True)

        self.maintain = get_interval(maintain)
        self.slow_response_threshold = get_interval(slow_response_threshold, null=True)
        self.slow_query_threshold = get_interval(slow_query_threshold, null=True)
        self.slow_response_alert_level = slow_response_alert_level
        self.slow_query_alert_level = slow_query_alert_level

        self._alert_map: dict = {}
        self._alert_task: dict = {}
        # self._index_map: Dict[str, Alert.Index] = {}

    def notify_supervisor(self, level: str):
        if not self.notify_supervisor_level:
            return False
        return ALERT_LEVELS.index(level.upper()) >= ALERT_LEVELS.index(self.notify_supervisor_level.upper())

    def get_alerts(self):
        return list(self._alert_map.values())

    @property
    def names(self):
        return list(self._alert_map)

    def get(self, name: str):
        return self._alert_map.get(name)

    def load_task(self, interval: Union[timedelta, int], schedule=None):
        from utilmeta.conf import config
        if not config.resolved:
            raise ValueError('config not set')
        from utilmeta.ops.tasks.monitor import AlertTask
        task = AlertTask(
            group='ops',
            interval=None if schedule else interval or self.default_interval,
            schedule=schedule
        )
        dup = config.task.get(task.name)
        # if interval & schedule is duplicated (with default name)
        if dup:
            return dup
        config.task.add(task)
        return task

    def add(self, *alerts, interval: Union[timedelta, int], schedule=None):
        from utilmeta.util.alert import Alert
        task = self.load_task(interval, schedule=schedule)
        for alert in alerts:
            if not isinstance(alert, Alert):
                raise TypeError(f'Invalid alert: {alert}')
            alert.task = task
            dup = self.get(alert.name)
            if dup and alert != dup:
                raise ValueError(f'Alert detect duplicate name: {alert.name} for {alert}, {dup}')
            self._alert_map[alert.name] = alert


class Monitor(Util):
    class LoadWeight(Util):
        """
        tune the weight of the load_index algorithm based on your service requirements
        load index is a key metric to measure service load
        load balance will use load_index as a reference to decide the assignment of incoming requests
        all these metric params use percentage to unify standard
        """

        def __init__(self,
                     cpu: int = 1,
                     memory: int = 4,
                     fds: int = 2, rps: int = 2,
                     db_conn: int = 4,
                     net_conn: int = 4,
                     sys_load_1: int = 5,
                     sys_load_5: int = 2,
                     sys_load_15: int = 1
                     ):

            super().__init__(locals())
            self.sys_load_1 = sys_load_1
            self.sys_load_5 = sys_load_5
            self.sys_load_15 = sys_load_15

        @property
        def index(self):
            import psutil
            try:
                l1, l5, l15 = psutil.getloadavg()
            except (AttributeError, OSError):
                l1, l5, l15 = 0, 0, 0
            index = (self.sys_load_1 * l1 + self.sys_load_5 * l5 + self.sys_load_15 * l15) / \
                    (self.sys_load_1 + self.sys_load_5 + self.sys_load_15) * psutil.cpu_count()
            return index

    class ModelConfig:
        def __init__(self, model: str, relations: List[str] = None, aggregates: dict = None):
            self.model_tag = model
            self.relations = relations
            self.aggregates = aggregates

        def get_model(self):
            from django.apps.registry import apps
            app_label, model_name = self.model_tag.split('.')
            return apps.get_model(app_label=app_label, model_name=model_name)

    def __init__(self,
                 server_monitor_interval: Union[int, timedelta] = timedelta(minutes=1),
                 data_monitor_default_interval: Union[int, timedelta] = timedelta(days=1),
                 data_monitor_models: List[str] = None,

                 cpu_percent_interval: Union[int, timedelta] = timedelta(seconds=5),
                 db_monitor_interval: Union[int, timedelta] = timedelta(minutes=2),
                 db_monitor_maintain: Union[int, timedelta] = timedelta(days=7),
                 cache_monitor_interval: Union[int, timedelta] = timedelta(minutes=5),
                 cache_monitor_maintain: Union[int, timedelta] = timedelta(days=7),

                 data_monitor_maintain: timedelta = timedelta(days=30),
                 server_monitor_maintain: timedelta = timedelta(days=30),

                 master_worker_monitor: bool = True,
                 worker_monitor_interval: Union[int, float, timedelta] = timedelta(seconds=15),
                 worker_monitor_maintain: Union[int, float, timedelta] = timedelta(hours=3),
                 worker_monitor_delta_ratio: float = 0.2,
                 worker_disconnect_interval: Union[int, timedelta] = None,
                 load_index_weight: LoadWeight = LoadWeight()
                 ):

        super().__init__(locals())
        self.worker_monitor_delta_ratio = worker_monitor_delta_ratio
        self.worker_monitor_interval = get_interval(worker_monitor_interval, ge=3, null=True)
        self.worker_disconnect_interval = get_interval(
            worker_disconnect_interval
            or timedelta(seconds=3 * worker_monitor_interval),
            ge=worker_monitor_interval
        ) if self.worker_monitor_interval else 0
        self.worker_monitor_maintain = get_interval(worker_monitor_maintain, ge=worker_monitor_interval) \
            if self.worker_monitor_interval else 0
        self.server_monitor_maintain = get_interval(server_monitor_maintain, ge=timedelta(days=1))
        self.server_monitor_interval = get_interval(server_monitor_interval, ge=10, le=timedelta(minutes=10))
        self.data_monitor_default_interval = get_interval(data_monitor_default_interval, ge=10)
        self.data_monitor_maintain = get_interval(data_monitor_maintain, ge=timedelta(days=1))
        self.cpu_percent_interval = get_interval(cpu_percent_interval, ge=0.1)
        self.master_worker_monitor = master_worker_monitor

        if load_index_weight:
            assert isinstance(load_index_weight, self.LoadWeight), \
                f'Monitor load_index_weight must be LoadWeight object, got {load_index_weight}'

        self.db_monitor_interval = get_interval(db_monitor_interval, null=True)
        self.db_monitor_maintain = get_interval(db_monitor_maintain, null=True)
        self.cache_monitor_interval = get_interval(cache_monitor_interval, null=True)
        self.cache_monitor_maintain = get_interval(cache_monitor_maintain, null=True)
        self.load_index_weight = load_index_weight
        # self.data_monitor_models = data_monitor_models
        self.task_models_config: Dict[str, List[Monitor.ModelConfig]] = {}
        self.data_monitor_models = data_monitor_models

    def load_models(self):
        if self.data_monitor_models:
            for model in self.data_monitor_models:
                self.add_model(model=model, interval=self.data_monitor_default_interval)

    @property
    def load_index(self):
        return self.load_index_weight.index

    def add_model(self, model, *, schedule=None,
                  interval: Union[int, float, timedelta] = None, relations: List[str] = None, aggregate: dict = None):
        if not isinstance(model, str):
            model = model_tag(model)
        from utilmeta.conf import config
        from utilmeta.ops.tasks.monitor import DataMonitorTask
        task = DataMonitorTask(
            group='ops',
            schedule=schedule,
            interval=None if schedule else interval or self.data_monitor_default_interval,
        )
        dup = config.task.get(task.name)
        if not dup:
            config.task.add(task)
        else:
            task = dup
        cfg = self.ModelConfig(
            model=model,
            relations=relations,
            aggregates=aggregate
        )
        if task.name in self.task_models_config:
            self.task_models_config[task.name].append(cfg)
        else:
            self.task_models_config[task.name] = [cfg]

    def get_worker_task(self, master: bool = False):
        from utilmeta.ops.tasks.monitor import WorkerMonitorTask
        from utilmeta.conf import Task
        return WorkerMonitorTask(
            master=master,
            concurrent_cls=Task.BLOCKING_POOL,
            looped=True,
            min_loop_interval=self.worker_monitor_interval,
            console_log=False
        )


class Operations(Util):
    DEFAULT_OPERATIONS_API = 'utilmeta.ops.api.OperationsAPI'

    SQLITE = 'django.db.backends.sqlite3'
    CACHE = 'CACHE'
    FILE = 'FILE'

    def __init__(self, *,
                 db: str,
                 cache: str,
                 route: str = None,     # assign a api route here
                 token: str = None,
                 backup_db_engine: str = SQLITE,
                 ignore_ops_alerts: bool = True,    # ops system tasks and apis alerts are ignored
                 api: str = DEFAULT_OPERATIONS_API,
                 secret_names: List[str] = ('password', 'token', 'secret', 'dsn', 'session_key'),
                 ops_api_document: bool = False,
                 trust_localhost: bool = False,

                 valid_host: bool = True,
                 supervisor_timeout: Union[int, float, timedelta] = timedelta(seconds=60),
                 supervisor_secure: bool = True,
                 supervisor_authorized: bool = True,
                 supervisor_max_retries: int = 3,
                 supervisor_report_metrics: bool = True,

                 # only accept authorized supervisor node, (endswith .utilmeta.com)
                 task_max_concurrent_jobs: int = 5,
                 health_check_interval: Union[int, timedelta] = 60,
                 heartbeat_interval: Union[int, timedelta] = 30,
                 clear_interval: Union[int, timedelta] = timedelta(hours=1),
                 last_activity_update_interval: Union[int, timedelta] = timedelta(minutes=2),

                 user_inactive_interval: timedelta = timedelta(seconds=300),
                 user_aggregate_maintain: timedelta = timedelta(days=30),
                 hourly_aggregate_maintain: timedelta = timedelta(days=1),
                 daily_aggregate_maintain: timedelta = timedelta(days=90),
                 monthly_aggregate_maintain: timedelta = timedelta(days=365),
                 ):

        super().__init__(locals())
        # self._info = {}
        self.db_alias = db
        self.cache_alias = cache
        self.api_cls_string = api
        self.valid_host = valid_host
        self.backup_db_engine = backup_db_engine
        self.ignore_ops_alerts = ignore_ops_alerts
        # db is None means auto db
        self._token = hashlib.sha256(token.encode("utf-8")).hexdigest() if token else None
        self._route = route

        if token:
            assert isinstance(token, str) and len(token) > 6, \
                f'For security concerns, you must specify a token with length > 6, got {token}'
        assert db, ValueError('You must select a db alias for operations')
        if not isinstance(supervisor_timeout, timedelta):
            supervisor_timeout = timedelta(seconds=supervisor_timeout)
        assert supervisor_max_retries >= 1, f'Operations supervisor_max_retries must > 1'

        assert isinstance(heartbeat_interval, int), \
            f'Operation heartbeat_interval must be a valid int seconds'
        assert 60 >= heartbeat_interval >= 5, \
            ValueError('Operation requires heartbeat_interval in 5~30 (s) '
                       '(avoid being too frequent or too slow)')

        if secret_names:
            for key in secret_names:
                assert isinstance(key, str), \
                    f'Operation secret_names is a list of str that you want to hide in log/storage data, got {key}'
        self.secret_names = [k.lower() for k in secret_names]

        self.supervisor_secure = supervisor_secure    # when set to True, only allow HTTPS heartbeat url
        self.supervisor_authorized = supervisor_authorized
        self.supervisor_timeout = get_interval(supervisor_timeout)
        self.supervisor_max_retries = supervisor_max_retries
        self.supervisor_report_metrics = supervisor_report_metrics

        self.ops_api_document = ops_api_document
        self.trust_localhost = trust_localhost
        self.health_check_interval = get_interval(health_check_interval)
        self.heartbeat_interval = get_interval(heartbeat_interval)
        self.clear_interval = get_interval(clear_interval)
        self.task_max_concurrent_jobs = task_max_concurrent_jobs

        self.last_activity_update_interval = get_interval(last_activity_update_interval)

        self.hourly_aggregate_maintain = get_interval(hourly_aggregate_maintain, ge=timedelta(days=1))
        self.daily_aggregate_maintain = get_interval(daily_aggregate_maintain, ge=timedelta(days=30))
        self.monthly_aggregate_maintain = get_interval(monthly_aggregate_maintain, ge=timedelta(days=30))
        self.user_inactive_interval = get_interval(user_inactive_interval)
        self.user_aggregate_maintain = get_interval(user_aggregate_maintain, ge=timedelta(days=1))

        self._endpoints = {}

    def is_secret(self, key: str):
        for k in self.secret_names:
            if k in key.lower():
                return True
        return False

    def valid(self, token):
        return token == self._token

    @property
    def api_route(self):
        return self._route

    @cached_property
    def api_cls(self):
        from utilmeta.core.api import API
        if not self.api_cls_string:
            from utilmeta.ops.api import OperationsAPI
            return OperationsAPI
        api = import_util(self.api_cls_string)
        if not issubclass(api, API):
            raise TypeError
        return api

    @cached_property
    def route(self):
        if self._route:
            return self._route
        from utilmeta.ops.models.service import Service
        srv = Service.current()
        if not srv:
            raise AttributeError('Service not loaded')
        return srv.ops_route

    @property
    def token(self):
        return self._token

    @property
    def cache(self):
        from django.core.cache import caches, BaseCache
        cache: BaseCache = caches[self.cache_alias]
        return cache

    @property
    def redis_con(self):
        try:
            from utilmeta.conf import config
            if config.caches[self.cache_alias].is_redis:
                from redis.client import Redis
                from django_redis import get_redis_connection
                con: Redis = get_redis_connection(self.cache_alias)
                return con
        except Exception as e:
            if e:
                return None
        return None

    @classmethod
    def authorized_url(cls, url: str):
        return urlparse(url).netloc.endswith(MAIN_HOST)

    def valid_supervisor(self, url: str):
        result: ParseResult = urlparse(url)
        if not result.scheme:
            raise ValueError(f'Invalid action_url syntax: {url}')
        if self.supervisor_secure:
            if result.scheme != Scheme.HTTPS:
                raise exc.BadRequest('This service require secured supervisor')
        if self.supervisor_authorized:
            if not result.netloc.endswith(MAIN_HOST):
                raise exc.BadRequest('This service require authorized supervisor')

    @property
    def db_support_bulk_with_pk(self):
        from utilmeta.conf import config
        db = config.databases.get(self.db_alias)
        if not db:
            return False
        return db.type != DB.SQLite

    @property
    def db_support_save_transaction(self):
        from utilmeta.conf import config
        db = config.databases.get(self.db_alias)
        if not db:
            return False
        return db.type != DB.SQLite and not db.pooled

    def add_endpoint(self, unit):
        from utilmeta.core.unit import Unit
        if not isinstance(unit, Unit):
            return
        if not unit.method or unit.endpoint_path is None or unit.__declare_path__ is None:
            return
        ident = f'{unit.method.lower()}:{unit.endpoint_path.strip("/")}'
        # from utilmeta.ops.models.utils import Endpoint, Application
        if ident not in self._endpoints:
            self._endpoints[ident] = unit

    def pop_endpoints(self):
        endpoints = self._endpoints
        self._endpoints = {}
        return endpoints
