import sys
import os
from typing import Dict, Union, List, TYPE_CHECKING, Optional
from .cache import Cache, AutoCache
from .database import Database
from .operations import Operations, Monitor, Alert
from .deploy import Deploy, Host, Time, \
    Apache, Nginx, SSH, Https, UWSGI, Gunicorn
from .auth import Auth, Csrf, Session, Cookie
from .task import Task
from .cluster import Cluster, Service, Proxy
from .common import Log, Mail, Http, Version, App, Preference, DEFAULT_APPS
from .distribution import Dist
from datetime import datetime
from utilmeta.util.common import multi, gen_key, Env, SCHEME, \
    Scheme, LOCAL, check_requirement, Key, get_ip, time_now, \
    get_server_ip, url_join, LOCAL_IP, get_netloc, Attr, DB
from utilmeta.util.base import Util
from django.utils.functional import cached_property


DEFAULT_MIDDLEWARES = [
    'django.middleware.security.SecurityMiddleware',
    'utilmeta.util.common.middleware.CookieMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

__all__ = ['DEFAULT_MIDDLEWARES', 'DEFAULT_APPS', 'Database', 'Version', 'Task',
           'Config', 'Cache', 'Session', 'AutoCache', 'Service', 'Cluster', 'Proxy',
           'Log', 'Mail', 'Operations', 'Auth', 'Deploy', 'Time', 'Http', 'Alert',
           'Apache', 'Nginx', 'SSH', 'Https', 'UWSGI', 'Gunicorn', 'Preference',
           'Host', 'Monitor', 'Csrf', 'Cookie', 'Dist']


class Config(Util):
    def __init__(self, module_name, *,
                 production: bool,
                 localhost: bool = False,
                 name: str = None, description: str = '',
                 version: Version = Version(0, 1, 0),
                 root_api: str,
                 root_url: str = 'api',
                 ops: Operations = None,
                 monitor: Monitor = None,
                 log: Log = None,
                 auto_cache: AutoCache = None,
                 apps_dir: str = None,
                 apps: Union[tuple, List[str]] = (),
                 host: Union[str, Host] = '127.0.0.1',
                 preference: Preference = Preference(),
                 middlewares: Union[tuple, List[str]] = (),
                 requirements: Union[tuple, List[str]] = (),
                 time: Time = Time(),
                 databases: Dict[str, Database] = None,
                 caches: Dict[str, Cache] = None,
                 mail: Mail = None,
                 routers: Union[tuple, List[str]] = (),
                 auth: Auth = Auth(_enabled=False),
                 csrf: Csrf = Csrf(),
                 http: Http = Http(),
                 task: Task = None,
                 dist: Dist = None,
                 alert: Alert = None,
                 cluster: Cluster = None,
                 session: Session = None,
                 deploy: Deploy = Deploy(),
                 readonly: bool = False,
                 ):

        super().__init__(locals())
        from utilmeta.bin.meta import MetaManagement
        if TYPE_CHECKING:
            from utilmeta.service import UtilMeta

        try:
            self.module = sys.modules[module_name]
        except KeyError:
            if not readonly:
                raise ValueError(f"UtilMeta conf.Config first param must be __name__ "
                                 f"to get the correct setting module, got {module_name}")

        self.module_name = module_name
        self.localhost = localhost
        # ------------
        # self.pid = None
        # self.utils = []
        # self.mounts = []
        # -------------

        settings = {}
        if multi(host):
            host = Host(allows=[host], product=host[0] if host else LOCAL)
        elif isinstance(host, str):
            host = Host(product=host)
        assert isinstance(host, Host), TypeError(f"Config host must be str/list or Host object, got {host}")
        host.production = production
        assert isinstance(http, Http), TypeError(f"Config host must be Http object, got {http}")
        assert isinstance(preference, Preference), f'Config.preference must be a Preference object, got {preference}'
        # self.version_id = None
        self.host_config = host
        self.http_config = http

        self.resolved = bool(name)
        self.name = name or ''
        self.description = description
        self.version = version
        self.production = bool(production)
        self.settings_module = module_name
        self.root_url = root_url.strip('/')
        self.root_api = root_api

        if cluster and cluster.proxy_service and cluster.expose:
            _url = self.name if cluster.single_endpoint else ''
            if self.root_url != _url:
                raise ValueError(f'Config: exposing your service API to proxy'
                                 f' require your root_url adjusted to {repr(_url)}')

        if alert:
            assert monitor, f'Conifg alert need to enable monitor settings'

        self.alert: Alert = alert
        self.monitor: Monitor = monitor
        self.ops: Operations = ops
        self.log: Log = log
        self.time: Time = time
        self.databases: Dict[str, Database] = dict(databases or {})
        self.caches: Dict[str, Cache] = dict(caches or {})
        self.cluster: Cluster = cluster
        self.dist: Dist = dist
        self.deploy: Deploy = deploy
        self.mail: Mail = mail
        self.auth: Auth = auth
        self.csrf: Csrf = csrf
        self.session: Session = session
        self.preference: Preference = preference
        self.auto_cache: AutoCache = auto_cache
        self.middlewares = list(middlewares or DEFAULT_MIDDLEWARES)
        self.requirements = requirements
        self.routers = list(routers)
        self.utilmeta: Optional['UtilMeta'] = None
        self.service = None
        # self.apps = apps

        if readonly:
            return

        if root_api or task:
            assert name.isidentifier(), f'UtilMeta service name must be a valid identifies name, got {name}'

            config_dir = os.path.abspath(self.module.__file__)
            self.service = MetaManagement(cwd=config_dir).service
            # parse meta.ini and get current service from Meta
            assert self.service, f'UtilMeta meta.ini should consist to the project directory'
            self.service.host = self.host_config
            self.service.root_url = self.root_url
            self.service.production = self.production
            self.service.config = self
            deploy.service = self.service
            settings.update(deploy.gen())
            if auth.session_auth:
                assert session, f'Auth(auth_strategy="SESSION") need to enable session config'

            if task:
                task.service = self.service
        else:
            assert module_name == 'utilmeta.conf', f'UtilMeta config should set root_api, got {root_api}'

        self.app = App(self.service_dir, apps_dir=apps_dir, apps=apps)
        # installed_apps = [DEFAULT_APPS['content']]
        # if apps_dir:
        #     self.apps_path = os.path.join(self.service_dir, apps_dir)
        #     assert os.path.exists(self.apps_path), \
        #         ValueError(f"Config apps_path: {self.apps_path} not exists")
        #     mod = apps_dir.strip('/').replace('/', '.')
        #     app_labels = [p for p in next(os.walk(self.apps_path))[1] if '__' not in p]
        #     installed_apps += [f'{mod}.{app}' for app in app_labels]
        # else:
        #     installed_apps += list(apps)
        # self.apps = installed_apps

        if auto_cache:
            if auto_cache.key_prefix is ...:
                auto_cache.key_prefix = self.cache_prefix
            auto_cache.gen(self.caches)
        self.task = task
        if task:
            assert isinstance(task, Task)
        if log:
            assert isinstance(log, Log)
        if mail:
            assert isinstance(mail, Mail)
            settings.update(mail.gen())

        if monitor:
            assert isinstance(monitor, Monitor)
            if monitor.worker_monitor_interval:
                assert monitor.worker_monitor_interval > task.min_task_interval,\
                    f'Invalid Monitor worker_monitor_interval: {monitor.worker_monitor_interval}' \
                    f', must > {task.min_task_interval}'

        if dist:
            assert isinstance(dist, Dist)
            if dist.db_alias not in self.databases:
                raise ValueError(f'Dist db alias: [{repr(dist.db_alias)}]'
                                 f' not configured in databases: {list(self.databases.keys())}')
            if dist.cache_alias not in self.caches:
                raise ValueError(f'Dist cache alias: [{repr(dist.cache_alias)}]'
                                 f'not configured in caches: {list(self.caches.keys())}')
            self.app.append('utilmeta.dist')

        if ops:
            assert isinstance(ops, Operations)
            ops_db = self.databases.get(ops.db_alias)
            ops_cache = self.caches.get(ops.cache_alias)
            if not ops_db:
                raise ValueError(f'Operations db alias: [{repr(ops.db_alias)}]'
                                 f' not configured in databases: {list(self.databases.keys())}')
            if not ops_cache:
                raise ValueError(f'Operations cache alias: [{repr(ops.cache_alias)}] '
                                 f'not configured in caches: {list(self.caches.keys())}')
            if ops_cache.backend == ops_cache.LOCMEM:
                raise ValueError(f'Operations cache must support multiple processes, which LocMemCache cannot')

            if ops.health_check_interval:
                if cluster:
                    assert ops.health_check_interval - cluster.health_check_timeout > task.min_interval, \
                        f'Cluster health_check_timeout ({cluster.health_check_timeout})' \
                        f' should << health_check_interval ({ops.health_check_interval})'
                assert ops.health_check_interval - deploy.health_check_timeout > task.min_interval, \
                    f'Deploy health_check_timeout ({deploy.health_check_timeout})' \
                    f' should << health_check_interval ({ops.health_check_interval})'

            assert isinstance(task, Task), f'Operations need to enable task system, use task=conf.Task(...)'
            # if not ops_cache.is_redis:
            #     if log and log.cache_storage:
            #         if not monitor:
            #             raise ValueError(f'Log with non-redis ops cache backend need monitor'
            #                              f' enabled to save cached logs')
            #         if log.cache_save_interval:
            #             warnings.warn(f'Log with non-redis ops cache backend will reuse '
            #                           f'the worker_monitor_interval at monitor to save pre-process '
            #                           f'logs instead of Log.cache_save_interval')
            # elif log and log.cache_local_memory:
            #     warnings.warn(f'Log with redis cache backend use redis list as logs cache instead of local memory')
            if self.is_proxy:
                assert ops.token, f'Proxy service should define a token for operations'

            self.databases[ops.db_alias].apps = ['ops']
            self.app.append('utilmeta.ops')
            # from utilmeta.ops import router
            # router.Router = router.db_router(ops.db_alias)
            # custom the user specified operation database
            # if is master config, ops.db_alias = None will not allow the migrations to migrate
            Util._secret_names = ops.secret_names
        else:
            if 'utilmeta.ops' in self.app:
                raise TypeError('Operations app added while ops config not specified')
            if monitor:
                raise TypeError('Monitor support need to enable ops=Operations(...) in your config first')
            if cluster:
                raise TypeError('Cluster support need to enable ops=Operations(...) in your config first')
            if dist:
                raise TypeError('Dist support need to enable ops=Operations(...) in your config first')
            if log:
                raise TypeError('Log support need to enable ops=Operations(...) in your config first')

        if self.databases:
            db_config, router = Database.gen(self.databases, self.service.runtime_root or self.service.path)
            settings.update({'DATABASES': db_config})
            if router:
                setattr(self.module, Key.ROUTER, router)
                self.routers.append(f'{self.settings_module}.{Key.ROUTER}')

        if self.cluster:
            if self.cluster.proxy_service:
                if self.cluster.proxy_service.public_host:
                    self.host_config.allows.append(self.cluster.proxy_service.public_host)

            if self.cluster.proxy_config:
                if self.cluster.proxy_config.native is None:
                    self.cluster.proxy_config.native = not self.production
                for gateway in self.cluster.proxy_config.gateways:
                    gateway.deploy = self.deploy
                    gateway.gen()

                if not self.cluster.proxy_config.native:
                    if not self.deploy.web_server.UPSTREAM_PROXY_SUPPORT:
                        raise TypeError(f'configured web-server: {self.deploy.web_server.__class__.__name__} '
                                        f'not support upstream proxy servers, please change a web server or '
                                        f'change your proxy strategy')

                # if self.cluster.proxy_config.private_host:
                #     self.host_config.allows.append(self.cluster.proxy_config.private_host)
                # if isinstance(self.deploy.web_server, Nginx):
                #     assert not self.deploy.web_server.default_server, \
                #         f'Cluster proxy with private host: ' \
                #         f'{repr(self.cluster.proxy_config.private_host)} cannot enable default_server'

            if self.auth.auth_service:
                if self.auth.auth_service not in self.cluster.internals:
                    raise ValueError(f'Auth auth_service: <{self.auth.auth_service}> '
                                     f'must in cluster internal services: {list(self.cluster.internals)}')
                if self.auth.session_auth:
                    if not self.session.from_service:
                        self.session.from_service = self.auth.auth_service

            self.cluster.unique_name = self.name
            ops_cache = caches.get(self.ops.cache_alias)
            service_cache = caches.get(self.cluster.service_cache_alias)
            if not service_cache:
                raise ValueError(f'Cluster service_cache: [{repr(self.cluster.service_cache_alias)}] '
                                 f'not configured in caches: {list(self.caches.keys())}')
            if ops_cache.backend not in (Cache.REDIS_CLUSTER, Cache.MEMCACHED_CLUSTER):
                raise TypeError(f'Operations cache with cluster enabled should use '
                                f'RedisClusterCache (conf.Cache.REDIS_CLUSTER) or\n'
                                f'MemcachedClusterCache (conf.Cache.MEMCACHED_CLUSTER) as backend to work as expected')
            if service_cache.backend not in (Cache.REDIS_CLUSTER, Cache.MEMCACHED_CLUSTER):
                raise TypeError(f'Cluster service_cache should use RedisClusterCache (conf.Cache.REDIS_CLUSTER) or\n'
                                f'MemcachedClusterCache (conf.Cache.MEMCACHED_CLUSTER) as backend to work as expected')

        if self.session:
            if self.session.use_cache:
                cache = self.caches.get(self.session.cache_alias)
                if isinstance(cache, Cache):
                    if self.session.cluster_scope and cache.clustered:
                        cache.expose()
                else:
                    if not self.session.from_service:
                        raise ValueError(f'Session use Cache as backend. but specified alias: '
                                         f'<{self.session.cache_alias}> does not defined in caches')
                    if not self.session.clustered:
                        raise ValueError(f'Session from other service should use'
                                         f' CLUSTER_CACHE or CLUSTER_CACHE_DB as backend, got {self.session.engine}')

            elif self.session.use_file:
                if self.session.file_path:
                    if not os.path.isabs(self.session.file_path):
                        self.session.file_path = os.path.join(self.service.base, self.session.file_path)
                else:
                    self.session.file_path = self.service.runtime_root

            elif self.session.use_django_db:
                self.app.append(DEFAULT_APPS['session'])

            if self.auth and self.auth.user_model:
                self.session.set_default_user(self.auth.UserModel)

            if self.session.public_ip_only is None:
                self.session.public_ip_only = bool(self.is_public)

            assert isinstance(self.session, Session)
            self.session.cookie.set_domain(self.public_host)
            settings.update(self.session.gen())

        # generate after session
        if self.caches:
            settings.update({'CACHES': Cache.gen(self.caches, os.path.join(
                self.service.runtime_root or self.service.path, f'{self.service_name}.cache'))})

            # for key, cache in self.caches.items():
            #     if cache.is_database:
            #         self.app.append('django_cache')
            #         break

        csrf.cookie.set_domain(self.public_host)
        if self.deploy.https and self.deploy.https.secure_cookies:
            csrf.cookie.secure = True
            if session:
                session.cookie.secure = True

        if deploy.check_deployed:
            assert self.root_url, f'Deploy with check_deployed=True must have explicit root_url'

        assert isinstance(time, Time)
        settings.update(time.gen())
        assert isinstance(csrf, Csrf)
        settings.update(csrf.gen())
        assert isinstance(auth, Auth)
        settings.update(auth.gen())
        settings.update(self.app.gen())
        if self.production:
            settings.update({
                'LOGGING': {
                    'version': 1,
                    'disable_existing_loggers': True,
                }
            })

        from utilmeta.util.common import ImmutableDict
        settings = ImmutableDict({
            'DEBUG': not production,
            'SECRET_KEY': gen_key(),
            'BASE_DIR': self.project_dir,
            'ROOT_URLCONF': self.settings_module,
            'MIDDLEWARE': self.middlewares,
            'ALLOWED_HOSTS': self.host_config.gen(),
            'DATABASE_ROUTERS': self.routers,
            'APPEND_SLASH': False,
            'DEFAULT_AUTO_FIELD': 'django.db.models.AutoField',
            **settings
        })

        self._settings = settings
        for attr, value in settings.items():
            setattr(self.module, attr, value)

        self.init_time = datetime.now()
        self._setup_time = None     # this is a process level setup flag

    def check_requires(self, background: bool = False):
        check_requirement('django')
        check_requirement('psutil')
        if self.log and self.log.parse_user_agent or \
                self.session and self.session.human_ua_only and self.session.use_db:
            check_requirement('user_agents')

        if self.auth and self.auth.jwt_auth:
            check_requirement('jwt')

        if self.caches:
            for cache in self.caches.values():
                if cache.is_redis:
                    check_requirement('django_redis')
                    break
                if cache.is_pylibmc:
                    check_requirement('pylibmc')

        green = False
        if background:
            if self.task.concurrent_cls_string == self.task.GEVENT_POOL:
                check_requirement('gevent')
                green = True

        elif self.production:
            if not self.deploy.wsgi_server.serving:
                if isinstance(self.deploy.wsgi_server, UWSGI):
                    # new version of uwsgi will raise ModuleNotFound when import but still installed
                    print('use uWSGI as wsgi server, checking requirement')
                    if os.system('uwsgi --version'):
                        check_requirement('uwsgi', check=False)
                if isinstance(self.deploy.wsgi_server, Gunicorn):
                    check_requirement('gunicorn')
                self.deploy.check_worker_class()
                green = self.deploy.worker_class == UWSGI.GEVENT

        if self.databases:
            for db in self.databases.values():
                if db.type == DB.PostgreSQL:
                    check_requirement('psycopg2')
                    if green:
                        check_requirement('psycogreen')

        web_servers = [self.deploy.web_server]
        if self.cluster and self.cluster.is_proxy and self.cluster.proxy_config.gateways:
            web_servers.extend(self.cluster.proxy_config.gateways)
        for server in web_servers:
            if server.ssh_host:
                check_requirement('paramiko')
                break

        for requirement in self.requirements:
            check_requirement(requirement)

    def get_db(self, app_label):
        for alias, db in self.databases.items():
            if app_label in db.apps:
                return db
        return self.databases['default']

    def sync_caches(self, retrieve_only: bool = False):
        if not any([cache.clustered for cache in self.caches.values()]):
            return
        from utilmeta.util.cache.cluster import globally_retrieve_instances, globally_sync_to_db
        globally_retrieve_instances()
        if retrieve_only:
            # Service Initialized or worker routine cycle, load instances from database
            return
        # master routine cycle, collect instance stats data and sync to database
        globally_sync_to_db()

    def check_db_compat(self):
        for db in self.databases.values():
            if db.pooled:
                db.load_pool_manager()
                # load db, for that when loading API there is likely to introduce queries
        from utilmeta import conf
        pooled_backend = None
        if conf.BACKGROUND:
            if self.task.concurrent_cls_string == self.task.GEVENT_POOL:
                pooled_backend = 'gevent'
        else:
            if self.deploy.worker_class == UWSGI.GEVENT:
                pooled_backend = 'gevent'

        if pooled_backend:
            for db in self.databases.values():
                if db.pooled and db.pooled_green_backend != pooled_backend:
                    raise TypeError(f'Pooled database in {pooled_backend} mode should use {pooled_backend} pool, '
                                    f'such as {repr(db.POOLED_GEVENT_POSTGRESQL)} for gevent')

    def load(self, background: bool = False):
        from utilmeta.util.common import import_util
        self.check_db_compat()
        self.auth.load_models(admin=bool(self.ops))
        if self.cluster:
            self.cluster.load()
        # load root API
        root = import_util(self.root_api)
        self.auth.check()
        if self.session:
            self.session.check()
        self.check_requires(background=background)
        if self.ops:
            # check if operations api are loaded
            if self.ops.api_route:
                root.mount(self.ops.api_route, self.ops.api_cls)

            elif not getattr(root, Attr.SPEC, False):
                raise TypeError('config enabled ops but OperationsAPI not loaded, you should import '
                                'utilmeta.ops.api.OperationsAPI and mount to your RootAPI router')
            from utilmeta.ops.tasks import load_tasks
            load_tasks()
            if self.monitor:
                self.monitor.load_models()
        # check requires after root api loaded (cause new requirements may added during loading)
        self.app.assign_all()
        setattr(self.module, Env.ROOT_API, root)
        self._setup_time = time_now()
        return root

    @property
    def public_host(self):
        if self.cluster and self.cluster.proxy_service:
            if self.production:
                if self.cluster.proxy_service.public_host:
                    return self.cluster.proxy_service.public_host
            return self.cluster.proxy_service.ops_api
        if self.production:
            return self.host_config.production_host
        return self.host_config.development_host

    @property
    def app_labels(self):
        return self.app.app_labels()

    @property
    def debug(self):
        return not self.production

    @property
    def project_dir(self):
        return self.service.base if self.service else ''

    @property
    def project_name(self):
        return os.path.basename(self.project_dir)

    @property
    def service_name(self):
        return self.name

    @property
    def service_dir(self):
        return self.service.path if self.service else ''

    @property
    def service_mark(self):
        return f'{self.project_name}:{self.service_name}'

    @property
    def cache_prefix(self):
        return self.service_mark

    @property
    def scheme(self):
        if not self.production:
            return Scheme.HTTP
        if self.deploy.https and self.deploy.https.production_only:
            return Scheme.HTTPS if self.production else Scheme.HTTP
        return self.deploy.scheme

    @property
    def public_scheme(self):
        if not self.production:
            return Scheme.HTTP
        if self.cluster:
            if self.cluster.proxy_config and self.cluster.proxy_config.gateways:
                for gateway in self.cluster.proxy_config.gateways:
                    if gateway.https:
                        return Scheme.HTTPS
                    return Scheme.HTTP
            if self.cluster.proxy_service:
                if self.production:
                    return self.cluster.proxy_service.public_scheme or Scheme.HTTP
                else:
                    from urllib.parse import urlparse
                    return urlparse(self.cluster.proxy_service.ops_api).scheme
        return self.scheme

    @property
    def ops_api(self):
        return url_join(self.base_url, self.ops.route)

    @property
    def public_origin(self):
        return f'{self.public_scheme}{SCHEME}{get_netloc(self.public_host)}'

    @property
    def public_base_url(self):
        return url_join(self.public_origin, self.root_url)

    @property
    def public_ops_api(self):
        return url_join(self.public_base_url, self.ops.route)

    @property
    def ops_url(self):
        return url_join(self.root_url, self.ops.route, with_scheme=False, prepend_slash=True)
    
    @property
    def is_public(self):
        from ipaddress import ip_address
        try:
            return not ip_address(get_ip(self.public_base_url)).is_private
        except ValueError:
            return True
        
    @cached_property
    def public_ip(self):
        import socket
        try:
            return get_ip(self.host)
        except socket.gaierror:
            return '127.0.0.1'

    @cached_property
    def private_ip(self):
        if self.localhost:
            return LOCAL_IP
        return get_server_ip()

    @property
    def host(self):
        return self.host_config.host

    @property
    def local(self):
        return self.host_config.local

    @property
    def origin(self):
        # if self.cluster and self.cluster.register_required:
        #     return get_origin(self.cluster.proxy_service.ops_api)
        return f'{self.scheme}{SCHEME}{self.host}'

    @property
    def base_url(self):
        if self.cluster:
            return f'{self.origin}/{self.root_url}/' if self.root_url else f'{self.origin}/'
        return f'http://{LOCAL_IP}/{self.root_url}/'

    @property
    def root_pattern(self):
        return f'^{self.root_url}/(.*)' if self.root_url else '(.*)'

    @property
    def is_proxy(self):
        return not self.cluster or self.cluster.is_proxy

    @property
    def worker_cycle_required(self):
        if self.monitor or self.log:
            return True
        if self.cluster and self.cluster.register_required:
            return True
        return False

    @property
    def master_cycle_required(self):
        return self.monitor and self.monitor.master_worker_monitor

    @property
    def cluster_manager(self):
        if self.cluster:
            return self.cluster.manager
        from utilmeta.ops.cluster import ClusterManager
        return ClusterManager(self.cluster)

    @property
    def web_servers(self):
        servers = []
        if self.deploy.web_server:
            servers.append(self.deploy.web_server)
        if self.cluster and self.cluster.proxy_config and self.cluster.proxy_config.gateways:
            servers += self.cluster.proxy_config.gateways
        return servers

    @cached_property
    def version_id(self):
        from utilmeta.ops.models.log import VersionLog
        version = VersionLog.current()
        if not version:
            raise AttributeError('Version not loaded')
        return version.pk

    @property
    def native_proxy(self):
        try:
            return self.cluster.proxy_config.native
        except AttributeError:
            return False

    @property
    def setup_time(self):
        return self._setup_time
