from typing import List, Union, Callable, Optional, TYPE_CHECKING
from utilmeta.util.base import Util
from datetime import timedelta
from utilmeta.util.common import import_util, get_interval, Key, \
    write_to, remove_file, DB, distinct_add
import os
from django.utils.functional import cached_property

if TYPE_CHECKING:
    from utilmeta.bin.commands.base import Service


class Task(Util):
    MAX_WORKERS = min(32, (os.cpu_count() or 1) * 2)
    INIT_WORKERS = (os.cpu_count() or 1) + 1
    MAX_EVENT_WORKERS = min(64, max((os.cpu_count() or 1) + 4, os.cpu_count() * 5))

    SPAWN = 'spawn'
    FORK = 'fork'
    FORKSERVER = 'forkserver'

    MIN_TASKS = 'MIN_TASKS'
    MIN_EXECUTIONS = 'MIN_EXECUTIONS'
    MIN_MEMORY = 'MIN_MEMORY'
    MIN_LIFETIME = 'MIN_LIFETIME'

    FIRST = 'FIRST'
    LAST = 'LAST'
    ROTATE = 'ROTATE'
    HASH = 'HASH'
    LRU = 'LRU'
    LFU = 'LFU'

    REDIS = 'redis'
    # -------
    # GEVENT_JOB = 'utilmeta.util.task.backends.gevent.GeventJob'
    GEVENT_POOL = 'utilmeta.util.task.backends.gevent.GeventPool'
    BLOCKING_POOL = 'utilmeta.util.task.backends.blocking.BlockingPool'
    # THREAD_JOB = 'utilmeta.util.task.backends.thread.ThreadJob'
    THREAD_POOL = 'utilmeta.util.task.backends.thread.ThreadPool'

    ASSIGN_MANAGER = 'utilmeta.util.task.manager.assign.AssignTaskManager'
    QUEUE_MANAGER = 'utilmeta.util.task.manager.queue.QueueTaskManager'

    def __init__(self,
                 main_cycle_interval: Union[int, float, timedelta] = 60,
                 worker_cycle_interval: Union[int, float, timedelta] = 20,
                 min_interval: Union[int, float, timedelta] = 3,

                 instance_disconnect_interval: Union[int, float, timedelta] = 120,

                 min_worker_lifetime: Union[int, float, timedelta] = timedelta(minutes=10),
                 max_worker_lifetime: Union[int, float, timedelta] = timedelta(hours=1),
                 max_worker_lifetime_delta: Union[int, float, timedelta] = timedelta(minutes=10),
                 max_worker_memory: Union[int, float] = None,
                 max_worker_executions: int = None,
                 max_worker_spawn_step: int = None,
                 max_instance_executions: int = None,
                 min_instance_lifetime: timedelta = None,
                 max_instance_lifetime: timedelta = None,
                 max_instance_lifetime_delta: timedelta = None,
                 max_instance_memory: Union[int, float] = None,

                 process_start_method: str = SPAWN,
                 instance_restart_window: Union[int, timedelta] = 120,
                 instance_max_consecutive_restarts: int = 5,
                 instance_memory_exceed_force_restart: bool = True,

                 master: bool = False,
                 cache_executions: bool = False,

                 manager_cls: str = ASSIGN_MANAGER,

                 manager_params: dict = None,
                 worker_graceful_timeout: Union[int, float, timedelta] = timedelta(minutes=5),
                 # event_omit_recover_default_strategy: str = WORKER_REPLAY,
                 fixed_task_start_time: bool = False,

                 concurrent_cls: str = THREAD_POOL,

                 task_reassign_default_strategy: str = MIN_MEMORY,
                 event_dist_default_strategy: str = ROTATE,

                 event_abandon_default_window: Union[int, float, timedelta] = None,
                 # worker_cycle_interval: Union[int, float, timedelta],
                 accept_external_settings: bool = True,
                 accept_external_arrange: bool = True,
                 accept_external_scripts: bool = True,
                 # cycle_interval: Union[int, timedelta] = timedelta(minutes=1),

                 preload_events: int = 3,
                 preserve_events: int = 10,     # successful events preserve times
                 max_preserve_events: int = 100,
                 volatile_event_maintain: timedelta = timedelta(hours=1),
                 # volatile events
                 event_maintain: timedelta = timedelta(days=7),

                 # all events, even for failed and abandoned
                 task_default_max_concurrent_jobs: int = None,
                 task_default_enable_log: bool = True,
                 # default_interval_delta_ratio: Union[int, float, timedelta] = 5,
                 default_interval_delta_ratio: float = 0,

                 max_workers: int = MAX_WORKERS,
                 init_workers: int = INIT_WORKERS,
                 min_workers: int = 2,

                 console_log_execution: bool = True,
                 redirect_output_stream: bool = False,

                 max_worker_tasks: int = None,
                 min_worker_tasks: int = None,

                 task_daemon_thread: bool = True,
                 system_daemon: bool = True,
                 root_user: bool = True,
                 default_execution_timeout: timedelta = timedelta(minutes=10),
                 max_execution_timeout: timedelta = timedelta(hours=24),
                 ):

        super().__init__(locals())

        self.max_workers = max_workers
        assert min_workers >= 2
        assert init_workers >= min_workers
        assert max_workers >= init_workers

        self.init_workers = init_workers
        self.min_workers = min_workers
        self.manager_cls_string = manager_cls
        self.manager_params = manager_params or {}
        self.master = master
        self.cache_executions = cache_executions

        self.max_worker_tasks = max_worker_tasks
        self.min_worker_tasks = min_worker_tasks or 0

        self.task_default_max_concurrent_jobs = task_default_max_concurrent_jobs

        self.preload_events = preload_events
        self.preserve_events = preserve_events
        self.max_preserve_events = max_preserve_events

        self.accept_external_settings = accept_external_settings
        self.accept_external_arrange = accept_external_arrange
        self.accept_external_scripts = accept_external_scripts

        self.root_user = root_user
        self.volatile_event_maintain = get_interval(volatile_event_maintain)
        self.event_maintain = get_interval(event_maintain, ge=self.volatile_event_maintain)
        # self.default_interval_jitter_ratio = default_interval_jitter_ratio
        self.default_interval_delta_ratio = default_interval_delta_ratio
        self.system_daemon = system_daemon
        self.redirect_output_stream = redirect_output_stream
        # assert isinstance(default_timeout, timedelta)

        self.min_worker_lifetime = get_interval(min_worker_lifetime, le=max_worker_lifetime, null=True)
        self.min_interval = get_interval(min_interval, ge=1)
        self.main_cycle_interval = get_interval(main_cycle_interval, ge=self.min_interval)
        self.worker_cycle_interval = get_interval(worker_cycle_interval, ge=self.min_interval)

        self.instance_disconnect_interval = get_interval(
            instance_disconnect_interval, ge=self.main_cycle_interval + self.min_interval)
        self.console_log_execution = console_log_execution
        self.worker_graceful_timeout = get_interval(worker_graceful_timeout)

        self.default_execution_timeout = get_interval(
            default_execution_timeout, ge=self.worker_cycle_interval * 2
        )
        self.max_execution_timeout = get_interval(max_execution_timeout)
        self.task_daemon_thread = task_daemon_thread
        self.event_abandon_default_window = get_interval(event_abandon_default_window, null=True)
        self.process_start_method = process_start_method
        # global _perpetual_executor
        # _perpetual_executor = event_executor_cls(max_event_workers)
        self._service: Optional['Service'] = None

        self.concurrent_cls_string = concurrent_cls

        self._task_map = {}
        self._task_classes = set()
        self._task_groups = set()
        self._info = {}

        self.event_dist_default_strategy = event_dist_default_strategy
        self.task_reassign_default_strategy = task_reassign_default_strategy
        self.task_default_enable_log = task_default_enable_log

        self.max_worker_lifetime = get_interval(max_worker_lifetime, null=True)
        self.max_worker_lifetime_delta = get_interval(max_worker_lifetime_delta, null=True)

        self.max_worker_memory_percent = None
        self.max_worker_memory_bytes = None
        if max_worker_memory:
            if max_worker_memory > 1:
                self.max_worker_memory_bytes = max_worker_memory
            elif max_worker_memory > 0:
                self.max_worker_memory_percent = max_worker_memory * 100
        self.max_worker_executions = max_worker_executions

        self.instance_max_consecutive_restarts = instance_max_consecutive_restarts
        self.instance_memory_exceed_force_restart = instance_memory_exceed_force_restart
        self.max_instance_executions = max_instance_executions
        self.max_instance_lifetime = get_interval(max_instance_lifetime, null=True)
        self.min_instance_lifetime = get_interval(min_instance_lifetime, null=True)
        self.max_instance_lifetime_delta = get_interval(max_instance_lifetime_delta, null=True)
        self.max_instance_memory_percent = None
        self.max_instance_memory_bytes = None
        self.max_worker_spawn_step = max_worker_spawn_step
        self.fixed_task_start_time = fixed_task_start_time

        # self.event_omit_recover_default_strategy = event_omit_recover_default_strategy
        self.instance_restart_window = get_interval(instance_restart_window)
        if max_instance_memory:
            if max_instance_memory > 1:
                self.max_instance_memory_bytes = max_instance_memory
            elif max_instance_memory > 0:
                self.max_instance_memory_percent = max_instance_memory * 100

        self._manager = None

    @property
    def is_green(self):
        return self.concurrent_cls_string in [self.GEVENT_POOL]

    def get_patches(self) -> List[str]:
        from utilmeta.conf import config
        patches = []
        if self.concurrent_cls_string == self.GEVENT_POOL:
            distinct_add(patches, ['gevent'])
            for db in config.databases.values():
                if db.type == DB.PostgreSQL:
                    distinct_add(patches, ['gevent_postgresql'])
        return patches

    def get_instance_lifetime_delta(self) -> float:
        if not self.max_instance_lifetime_delta:
            return 0
        import random
        return (random.random() * 2 - 1) * self.max_instance_lifetime_delta

    def get_worker_lifetime_delta(self) -> float:
        if not self.max_worker_lifetime_delta:
            return 0
        import random
        return (random.random() * 2 - 1) * self.max_worker_lifetime_delta

    @property
    def service(self):
        return self._service

    @service.setter
    def service(self, srv: 'Service'):
        from utilmeta.bin.commands.base import Service
        if not isinstance(srv, Service):
            return
        self._service = srv

    @property
    def instance_id(self):
        instance_id = self._info.get(Key.INSTANCE)
        if instance_id:
            return instance_id
        if not self.service:
            raise ValueError(f'Service not loaded')
        id_file = '%s.task.id' % self.service.config.service_name
        file = os.path.join(self.service.runtime_root, id_file)
        inst_id = None
        if os.path.exists(file):
            inst_id = open(file, 'r').read().replace('\n', '').strip()
            if len(inst_id) != 6:
                remove_file(file)
                inst_id = None
        if not inst_id:
            from utilmeta.ops.models.common import id_generator
            inst_id = id_generator()
            write_to(file, content=inst_id)
        self._info[Key.INSTANCE] = inst_id
        return inst_id

    @property
    def min_task_interval(self):
        return self.worker_cycle_interval + self.min_interval

    @property
    def min_timedelta(self):
        return timedelta(seconds=self.min_interval)

    def get_job_cls(self, cls_string: str = None):
        from utilmeta.util.task.backends.base import BaseJob
        if not cls_string:
            return self.get_concurrent_cls().DEFAULT_JOB_CLS
        cls = import_util(cls_string)
        if not issubclass(cls, BaseJob):
            raise TypeError(f'Invalid job class: {cls}')
        return cls

    def get_concurrent_cls(self, cls_string: str = None):
        from utilmeta.util.task.backends.base import BasePool
        cls = import_util(cls_string or self.concurrent_cls_string)
        if not issubclass(cls, BasePool):
            raise TypeError(f'Invalid pool class: {cls}')
        return cls

    def perpetual_executor(self):
        """
        a common reusable executor for all the worker scope
        all tasks (tasks in API, logs save, omitted tasks)
        prevent creating endless threads (which cost system resources)
        """
        return self.get_concurrent_cls()(perpetual=True)

    def concurrent_executor(self, concurrent_cls: str = None, timeout: float = None, max_workers: int = None,
                            silent_timeout: bool = False, on_complete: Callable = None):
        return self.get_concurrent_cls(concurrent_cls)(
            max_workers=max_workers,
            timeout=timeout or self.default_execution_timeout,
            silent_timeout=silent_timeout,
            on_complete=on_complete,
        )

    def load_instance(self, task):
        if isinstance(task, str):
            if task in self._task_map:
                return self._task_map[task]
            return None

        from utilmeta.ops.models.task import TaskSettings
        from utilmeta.core.task import Task
        if not isinstance(task, TaskSettings):
            raise TypeError(f'conf.Task.load_instance task a Task object, got {task}')
        if task.name in self._task_map:
            return self._task_map[task.name]
        task_cls = import_util(task.base.ref)
        if not issubclass(task_cls, Task):
            raise TypeError(f'Invalid task class: {task_cls}')
        inst = task_cls.deserialize(task)
        self.add(inst)
        return inst

    def run(self, **kwargs):
        kwargs.update(self.manager_params)
        return self.manager_cls(**kwargs).run()

    def check_limit(self):
        if not self.max_worker_tasks:
            return
        max_tasks = self.max_workers * self.max_worker_tasks
        if len(self._task_map) >= max_tasks:
            raise ValueError(f'system tasks will exceed the max_workers * max_worker_tasks limit: {max_tasks}')
        if len(self._task_groups) >= self.max_workers:
            raise ValueError(f'system task groups will exceed the max_workers limit: {self.max_workers}')

    def add_cls(self, *task_cls):
        from utilmeta.core.task import Task
        for cls in task_cls:
            assert issubclass(cls, Task), f'Invalid task class, must be subclass of Task, got {cls}'
        self._task_classes.update(task_cls)

    def add(self, *tasks):
        from utilmeta.core.task import Task
        for task in tasks:
            if not isinstance(task, Task):
                raise TypeError(f'Task.add should add utilmeta.core.task.Task object, got {task}')
            if not task.name:
                raise ValueError(f'Task name not assigned')
            if task.abstract:
                raise TypeError(f'Abstract task cannot add to running list')
            dup = self._task_map.get(task.name)
            if dup and dup != task:
                raise ValueError(f'Duplicate task name: {repr(task.name)} at tasks: {task, dup}')
            self.check_limit()
            self._task_map[task.name] = task
            self._task_groups.add(task.group)

    @property
    def names(self) -> List[str]:
        return list(self._task_map.keys())

    def get(self, name: str):
        return self._task_map.get(name)

    def get_task_classes(self):
        return self._task_classes

    def get_tasks(self):
        return list(self._task_map.values())

    @cached_property
    def manager_cls(self):
        from utilmeta.util.task.manager.base import BaseTaskManager
        if not self.manager_cls_string:
            raise ValueError(f'conf.Task.manager_cls must be specified')
        cls = import_util(self.manager_cls_string)
        if not issubclass(cls, BaseTaskManager):
            raise TypeError(f'Log.manager_cls must inherit {BaseTaskManager}, got {cls}')
        return cls

    @property
    def manager(self):
        if self._manager:
            return self._manager
        manager = self.manager_cls(*self.manager_params)
        try:
            self._manager = manager
        except AttributeError:
            pass
        return manager
