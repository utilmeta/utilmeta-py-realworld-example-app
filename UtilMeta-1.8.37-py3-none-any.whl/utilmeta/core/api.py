import json
import inspect
from io import BytesIO
from functools import update_wrapper
from typing import Union, Dict, Tuple, Optional, Type, List

from django.http.response import HttpResponseBase
from django.utils.decorators import classonlymethod

from utilmeta.util.base import Util
from utilmeta.util.response import Response
from utilmeta.util.media import Media, File
from utilmeta.util.error import Error
from utilmeta.util.message import Message
from utilmeta.util.request import Request
from utilmeta.util.cache import Cache
from utilmeta.util.queue import Queue
from utilmeta.core.sdk import SDK

from utilmeta.util.common import (repeat, Header, MetaHeader, Attr, pop, ignore_errors, get_request_ip,
                                  constant, exc, Key, RequestType, SEG, gen_meta, param_type, copy_value, get_doc,
                                  duplicate, parse_query_dict, load_form_data, allow_cors, multi, pop_null,
                                  ReqType, http_methods, utc_ms_ts, gen_file_name, form_content,
                                  stream_content, ImmutableDict, UnitAttr, COMMON_METHODS)

from .module import ModuleMeta, Module
from .unit import Unit
from functools import partial
from utilmeta.conf import config
from utilmeta.messages import message

RESOLVER_TUPLE_TYPE = Tuple[Union[Type['API'], Type['Module'], Unit],
                            List[Unit], List[Unit], Dict[Type[Exception], Unit]]
RESOLVER_TYPE = Dict[str, Union[RESOLVER_TUPLE_TYPE, Dict[str, RESOLVER_TUPLE_TYPE]]]

__all__ = ['API', 'APIMeta']


def load(request: ReqType, path, *args, **kwargs):
    """
        In production mode, GET/DELETE 's request.content_type is None, different from
        which in develop mode (text/plain)
    """
    # --------- SET LOG ---------
    # set Logger init_time as request time
    from utilmeta.util.log import Logger
    request.log = Logger(root=True)     # root request context logger

    # --------- LOAD PATH -----------------------------
    request.PATH = path
    request.args = args
    request.kwargs = kwargs
    request.recv_ts = utc_ms_ts()

    # --------- LOAD DATA ------------------------------
    request.QUERY = parse_query_dict(request.GET)
    request.BODY = None
    request.IP = get_request_ip(request.META)

    try:
        content_type = request.content_type or RequestType.PLAIN
        content_length = int(request.headers.get(Header.LENGTH) or 0)
        if content_type == RequestType.JSON:
            if not content_length:
                # Empty content
                request.BODY = None
            else:
                request.BODY = json.loads(request.body, cls=config.preference.json_decoder_cls)
        elif content_type == RequestType.XML:
            from xml.etree.ElementTree import XMLParser
            parser = XMLParser()
            parser.feed(request.body)
            request.BODY = parser.close()
        elif stream_content(content_type):
            request.BODY = File(
                file=BytesIO(request.body),
                name=gen_file_name(request.content_type)
            )
        elif form_content(content_type):
            load_form_data(request)
            request.BODY = parse_query_dict(request.POST)
            request.BODY.update(request.FILES)
        else:
            request.BODY = request.body.decode()
    except Exception as e:
        raise exc.UnprocessableEntity(str(e))
    # make a copy: lowercase is parsable and mutable,
    # uppercase will be a immutable property of Request instance
    # request.body is readonly, so use a alias "data"
    request.query = dict(request.QUERY)
    request.data = copy_value(request.BODY)
    return request


class APIMeta(type, Util):
    _util_slots = ['module', 'message', 'media', 'cache', 'request', 'response']

    def __init__(cls, name: str, bases: tuple, attrs: dict, **kwargs):
        type.__init__(cls, name, bases, attrs)
        Util.__init__(cls, locals())

        if not bases:
            return
        try:
            del cls.__locked__
        except AttributeError:
            pass

        attrs = dict(attrs)
        cls._router = pop(attrs, 'router', pop(attrs, 'Router')) or {}
        cls.module: Type[Module] = pop(attrs, 'module')
        cls.message: Type[Message] = pop(attrs, 'message')
        cls.media: Media = pop(attrs, 'media')
        cls.cache: Cache = pop(attrs, 'cache')
        cls.request: Request = pop(attrs, 'request', Request())
        cls.response: Response = pop(attrs, 'response', Response(override=False))

        name_hint = message.api_name_hint
        if hasattr(cls._router, Attr.DICT):
            cls._router = dict(cls._router.__dict__)
        elif not isinstance(cls._router, dict):
            raise TypeError(f"API router must be a dict or class hold router properties,"
                            f" got {cls._router},\n {name_hint}")
        if cls.module and not issubclass(cls.module, Module):
            raise TypeError(f"API module must be subclass of Module, got {cls.module},\n {name_hint}")
        if cls.message:
            cls.message.check()
            if not issubclass(cls.message, Message):
                raise TypeError(f'API message must be subclass of Message, got {cls.message},\n {name_hint}')
        if cls.media:
            if not isinstance(cls.media, Media):
                raise TypeError(f"API media must be instance of Media, got {cls.media},\n{name_hint}")
        if cls.cache:
            if not isinstance(cls.cache, Cache):
                raise TypeError(f"API cache must be instance of Cache, got {cls.cache},\n{name_hint}")
        if not isinstance(cls.request, Request):
            raise TypeError(f"API request must be instance of Request, got {cls.request},\n{name_hint}")
        if not isinstance(cls.response, Response):
            raise TypeError(f"API response must be instance of Response, got {cls.response},\n{name_hint}")

        if not config.utilmeta:
            raise RuntimeError('Service not initialized')

        if bases:
            namespace_conflict = set(attrs).intersection({'id', 'api', 'serve'})
            assert not namespace_conflict, \
                f'API property or function names: {namespace_conflict} conflict to API inner property'

        cls._core_units: RESOLVER_TUPLE_TYPE = cls.module, [], [], {}
        cls._core_routes = set()
        cls._dynamic_methods = set()
        cls._allowed_methods = set()

        cls._resolver: RESOLVER_TYPE = cls.resolve(attrs)
        cls._proxy: Dict[str, SDK] = {}
        cls._root = False

        for slot in cls._util_slots:
            util = getattr(cls, slot, None)
            if isinstance(util, Util) and not inspect.isclass(util):
                path = f'{cls.__declare_path__}.{slot}'
                if util.__declare_path__:
                    if util.__declare_path__ != path:
                        import warnings
                        warnings.warn(f'same util: {util} mount to different '
                                      f'path: {repr(path)}, {repr(util.__declare_path__)}')
                else:
                    util.__declare_path__ = path

        cls._register = kwargs.get('register')
        if cls._register:
            cls.register()

    def register(cls):
        config.app.register(cls.__declare_path__, cls=cls)

    def resolve(cls, attrs: dict):
        resolver = {}

        mounts = []
        units = []
        modules = [cls.module] if cls.module else []
        apis = []

        def find(tar, k, h):
            if isinstance(h, Unit):
                if callable(tar):
                    return h.f is tar
                if isinstance(tar, str):
                    return tar in (h.name, k)
                return False
            return tar in (k, h)

        def hook(*targets, place=0, excludes: list = (),
                 append: Union[APIMeta, ModuleMeta, Unit, Dict[Type[Exception], Unit]]):
            if not append:
                return

            if isinstance(append, Unit):
                units.append(append)
            if isinstance(append, dict):
                units.extend([v for v in append.values() if isinstance(v, Unit)])
            if inspect.isclass(append):
                if issubclass(append, Module):
                    modules.append(append)
                if issubclass(append, API):
                    apis.append(append)

            if place == 0:
                for t in targets:
                    _units = append, [], [], {}
                    # [handler, before_hook, after_hook, error_hooks]
                    _values = resolver.get(t)
                    if isinstance(_values, dict):
                        if not isinstance(append, Unit):
                            raise TypeError
                        if append.method in _values:
                            raise TypeError

                        _values.update({append.method: _units})
                    elif isinstance(_values, tuple):
                        handler = _values[0]
                        if isinstance(handler, Unit) and isinstance(append, Unit):
                            if handler.method == append.method or t in http_methods:
                                raise TypeError
                            resolver[t] = {handler.method: _values, append.method: _units}
                        else:
                            raise TypeError
                    else:
                        resolver[t] = _units
                return

            targets = set(targets).difference(excludes)

            for tar in targets:
                if tar and tar is cls.module:
                    h, b, a, e = cls._core_units
                    if place == 1:
                        b.append(append)
                    elif place == 2:
                        a.append(append)
                    elif place == 3:
                        e.update(append)
                    cls._core_units = h, b, a, e
                    continue

                _find = False
                for k in list(resolver):
                    _values = resolver[k]
                    if isinstance(_values, dict):
                        for _m in list(_values):
                            h, b, a, e = _values[_m]
                            if find(tar, k, h):
                                if place == 1:
                                    b.append(append)
                                elif place == 2:
                                    a.append(append)
                                elif place == 3:
                                    e.update(append)
                                _values[_m] = h, b, a, e
                                _find = True
                    else:
                        h, b, a, e = _values
                        if find(tar, k, h):
                            if place == 1:
                                b.append(append)
                            elif place == 2:
                                a.append(append)
                            elif place == 3:
                                e.update(append)
                            resolver[k] = h, b, a, e
                            _find = True

                assert _find, ValueError(f"{cls} @api.<hook> got unexpected unit: {tar}, use"
                                         f" the reference or name of your target hook API/Module/Unit")

        core_dynamic = False
        if cls.module:
            # API resolve: routes
            # not found ->
            # if core module enable path_param, then API cannot define dynamic method in module's core method
            for method, values in cls.module.resolver.items():
                option = cls.module.get_option(method)
                if method in COMMON_METHODS:
                    if option.path_param_field:
                        core_dynamic = True
                        cls._dynamic_methods.add(method)
                    cls._allowed_methods.add(method)
                else:
                    if not option.path_param_field:
                        cls._core_routes.add(method)
                # hook(method, append=cls.module)
                # not hook module for every method
                # despite of combined module, all the method will resolve to module itself
                # leave module to do the inner dispatch

        for key, val in cls._router.items():
            lo_key = key.lower()
            if key.startswith(SEG) and key.endswith(SEG):
                continue
            elif isinstance(val, (APIMeta, ModuleMeta)):
                assert lo_key not in constant.METHODS, f"API <HTTP_METHOD_NAME>:{repr(lo_key)} unit must be a callable"
                hook(key, append=val)
                mounts.append(key)
            else:
                raise AttributeError(f'API Meta attrs is for mount, must be subclass of API/Module, got {val}')

        for key, val in attrs.items():
            lo_key = key.lower()
            if key.startswith(SEG) and key.endswith(SEG):
                continue
            elif isinstance(val, (APIMeta, ModuleMeta)):
                assert lo_key not in constant.METHODS, f"API <HTTP_METHOD_NAME>:{repr(lo_key)} unit must be a callable"
                hook(key, append=val)
                mounts.append(key)
                continue

            if inspect.isfunction(val):
                val = Unit.from_func(val)

            if isinstance(val, Unit):
                if not val.method:
                    # inner api method
                    continue
                hook(val.alias or key, append=val)
                setattr(cls, key, val)
                if lo_key in constant.METHODS:
                    if val.path:
                        if core_dynamic:
                            raise ValueError(f'{cls} core module: {cls.module}\ndeclared path_param and '
                                             f'make it dynamic in this route, API cannot '
                                             f'declare dynamic method: {repr(lo_key)} now')

                        if lo_key in cls._dynamic_methods:
                            raise ValueError(f'{cls} cannot define dynamic method: {repr(lo_key)} '
                                             f'within core module path_param enabled methods')

                        cls._dynamic_methods.add(lo_key)
                    cls._allowed_methods.add(lo_key)

                else:
                    mounts.append(key)
                continue

            assert lo_key not in constant.METHODS, \
                f'API attrs named in HTTP Method ({lo_key}) must be a instance function, got {val}'

        # traversal attrs twice, first time extract all main METHODS (Unit)
        # in second time extract all method hooks

        def get_keys(_keys):
            if not _keys:
                return []
            if not multi(_keys):
                return []
            if '*' in _keys:
                _keys = list(resolver)
                if cls.module:
                    _keys.append(cls.module)
                return _keys
            return _keys

        for key, val in attrs.items():
            if key in resolver:
                continue
            if not callable(val):
                continue
            pn = len(inspect.signature(val).parameters)
            _b = get_keys(getattr(val, UnitAttr.before_hook, None))
            _a = get_keys(getattr(val, UnitAttr.after_hook, None))
            _e = get_keys(getattr(val, UnitAttr.error_hook, None))
            _exc = get_keys(getattr(val, UnitAttr.excludes, None))

            if _b:
                unit = Unit.from_func(val)
                unit.valid_before()
                units.append(unit)
                setattr(cls, key, unit)
                hook(*_b, place=1, append=unit, excludes=_exc)

            elif _a:
                hints = param_type(val)
                assert pn == 2, f'API after hook: <{key}> should have 2 params, got {pn}, ' \
                    f'function declaration should like [def f(self, resp: Response.http):]'
                if hints:
                    hint = list(hints.values())[0]
                    assert issubclass(hint, HttpResponseBase), \
                        f'API after hook: <{key}> type hint for response must be subclass of HttpResponseBase, ' \
                        f'got {hint} \nyou can simply use Response.http (HttpResponse), Response.json (JsonResponse)'\
                        f', \nResponse.file (FileResponse) or Response.base (HttpResponseBase) for suitable hint'
                unit = Unit.from_func(val)
                units.append(unit)
                setattr(cls, key, unit)
                hook(*_a, place=2, append=Unit.from_func(val), excludes=_exc)

            elif _e:
                hints = param_type(val)
                assert 1 <= pn <= 2, f'API handle hook: <{key}> should have 1~2 params, got {pn}' \
                                     f'function declaration should like [def f(self, e: Error):]'
                if hints:
                    hint = list(hints.values())[0]
                    assert hint is Error, \
                        f'API handle hook: <{key}> type hint for error must be Error, got {hint}'

                errors = getattr(val, UnitAttr.errors)
                status = max([config.http_config.error_status.get(error, 500) for error in errors])
                setattr(val, Attr.STATUS, status)

                unit = Unit.from_func(val)
                units.append(unit)
                setattr(cls, key, unit)
                error_hooks = {error: unit for error in errors}
                hook(*_e, place=3, append=error_hooks, excludes=_exc)

        dup = set(attrs).intersection(cls._router).intersection(resolver)
        assert not dup, f'API Meta class mounted conflict to the API class method: {dup}, please change the names'
        assert not repeat(mounts), \
            ValueError(f"API detected duplicated mount unit, {duplicate(mounts)}")

        for mod in modules:
            if mod.abstract:
                assert mod.subs, f"abstract Module: {mod} must have child Module to assign, then can mount to API"
            assert not mod.related, f"related Module is only for inner related purpose, not support for API mount"
            # if mod.mount_api and cls is not mod.mount_api:
            #     raise ValueError(f'Module: {mod} mount to different api: {mod.mount_api}, {cls}')
            # mod.mount_api = cls

        for util in [*apis, *modules]:
            if getattr(util, Key.PRIVATE, False):
                raise TypeError(f'{util} is private and cannot expose at {cls}')

        for util in apis:
            if getattr(util, Attr.SPEC, False):
                setattr(cls, Attr.SPEC, True)

        for unit in units:
            unit.parent = cls

            getattr(unit, '_make_path')(f'{cls.__declare_path__}.{unit.name}')
            if not unit.cache and cls.cache:
                unit.cache = cls.cache

        return resolver

    def __setattr__(cls, key, value):
        if cls.__dict__.get(Attr.LOCK):
            raise AttributeError(f'{cls.__name__}(API) is readonly and'
                                 f' cannot be set attribute ({key} -> {repr(value)}) during runtime')
        return super().__setattr__(key, value)

    def __delattr__(cls, item):
        if cls.__dict__.get(Attr.LOCK):
            raise AttributeError(f'{cls.__name__}(API) is readonly and'
                                 f' cannot be delete attribute ({item}) during runtime')
        return super().__delattr__(item)

    @property
    def id(cls):
        return getattr(cls, Key.ID, None)

    @property
    def root(cls) -> bool:
        return cls._root

    @property
    def routes(cls):
        return list(cls._resolver)

    # @property
    # def resolver(cls):
    #     return cls._resolver

    def make_root(cls):
        if cls._root:
            # already a root
            return
        methods = set(cls._resolver).intersection(http_methods)
        if methods:
            raise ValueError(f'UtilMeta root_api: {cls} root methods is reserved, '
                             f'mounted {methods} should be remove or rename')
        cls._root = True

    def load_proxy(cls):
        """
        This is called whether proxy_config.native is True or not
        if native=True, this proxy is for conflict detection and load balance (real proxy)
        elsewhere this proxy is only for conflict detection
        :return:
        """
        if not config.cluster or not config.cluster.is_proxy:
            return
        from utilmeta.ops.models.service import Service
        for service in Service.objects.filter(expose=True).exclude(name=config.name):
            service: Service
            if service.single_endpoint:
                srv = cls._proxy.get(str(service.name))
                if srv:
                    if srv.__service__ != service.name:
                        raise ValueError(f'Conflict single_endpoint service name:'
                                         f' {service.name} with {srv.__service__}')
                else:
                    cls._proxy[service.name] = SDK(service=service.name)
            else:
                conflicts = {}
                for route in set(cls._proxy).intersection(service.root_routes):
                    srv = cls._proxy.get(route)
                    if srv and srv.__service__ != service.name:
                        conflicts[route] = srv.__service__
                if conflicts:
                    raise ValueError(f'Conflict service: <{service.name}> conflict'
                                     f' services (<route>: <service-name>): {conflicts}')
                for route in service.root_routes:
                    cls._proxy.setdefault(route, SDK(service=service.name))
        inter = set(cls._proxy).intersection(cls._resolver)
        if not config.root_url:
            # proxy use empty root url, means that other static url is will check conflict as well
            inter.update(set(cls._proxy).intersection(config.deploy.root_routes))
        if inter:
            raise ValueError(f'Conflict services mount routes with proxy resolver: {inter}')

    def mount(cls, route: str, util: Union['APIMeta', 'ModuleMeta', Unit],
              before_hooks: List[Unit] = None, after_hooks: List[Unit] = None,
              error_hooks: Dict[Type[Exception], Unit] = None):
        # mount a util on route if that route is available on this API
        # often used for third-party api injection to the standard API (like operations API)
        if route in cls._resolver:
            values = cls._resolver[route]
            if isinstance(values, tuple) and values[0] is util:
                pass
            else:
                raise ValueError(f'API route to be mounted: {repr(route)} is conflict to another api route')
        if not multi(before_hooks):
            before_hooks = ()
        if not multi(after_hooks):
            after_hooks = ()
        if not isinstance(error_hooks, dict):
            error_hooks = {}
        cls._resolver[route] = (util, before_hooks, after_hooks, error_hooks)

    def generate(cls,  path: str = '', ignore: bool = False,
                 root: bool = False,
                 before_hooks: list = (),
                 after_hooks: list = (),
                 error_hooks: dict = None,
                 ):
        from utilmeta.core.sdk import APISchema

        def join(b: str, p: str):
            if p in http_methods:
                return b
            elif not b:
                return p
            if p.startswith('@'):
                # for module: post query
                return f'{b}{p}'
            return f'{b}/{p}'

        def merge_util(_base: Util, _util: Util):
            _kwargs = _util.__spec_kwargs__ if \
                _util._original_kwargs is None else _util._original_kwargs
            new = _base._merge(_util)
            new._original_kwargs = _kwargs
            return new

        routes = {}
        model = None
        document = get_doc(cls)
        error_hooks = error_hooks or {}

        if cls.module:
            module, bef, aft, err = cls._core_units
            _err = dict(error_hooks)
            if err:
                _err.update(err)
            core: APISchema = module.generate(
                before_hooks=[*before_hooks, *bef],
                after_hooks=[*aft, *after_hooks],
                error_hooks=_err,
                path=path,
                ignore=ignore,
                response=cls.response
            )
            routes.update(core.routes)
            model = core.model
            if not document:
                document = core.document

        for key, values in cls._resolver.items():
            _path = join(path, key)

            if isinstance(values, dict):
                temp = {}
                for k, (util, befores, afters, errors) in values.items():
                    _err = dict(error_hooks)
                    if errors:
                        _err.update(errors)

                    if isinstance(util, Unit):
                        if not util.public:
                            continue
                        util.request = merge_util(cls.request, util.request)
                        for _u in (util, *afters, *errors.values()):
                            if _u and _u.response:
                                _u.response = merge_util(cls.response, _u.response)
                        temp[k] = util.generate(
                            before_hooks=[*before_hooks, *befores],
                            after_hooks=[*afters, *after_hooks],
                            error_hooks=_err,
                            path=_path,
                            ignore=ignore
                        )
                    else:
                        raise TypeError(f'Invalid API resolver unit: {util}')
                if temp:
                    routes[key] = temp
            else:
                util, befores, afters, errors = values
                _bef = [*before_hooks, *befores]
                _aft = [*afters, *after_hooks]
                _err = dict(error_hooks)
                if errors:
                    _err.update(errors)

                if isinstance(util, (APIMeta, Unit)):
                    for _u in (util, *afters, *errors.values()):
                        if _u and _u.response:
                            # response behaviour in API: override if not __defaulted
                            _u.response = merge_util(cls.response, _u.response)

                if isinstance(util, APIMeta):
                    util.request = merge_util(cls.request, util.request)
                    temp = util.generate(
                        before_hooks=_bef,
                        after_hooks=_aft,
                        error_hooks=_err,
                        path=_path,
                        ignore=ignore or getattr(util, Attr.IGNORE_GENERATE, False)
                    )
                    if getattr(util, Attr.SPEC, False) and config.ops:
                        config.ops._route = _path
                    if not getattr(util, Attr.IGNORE_GENERATE, False):
                        routes[key] = temp

                elif isinstance(util, ModuleMeta):
                    routes[key] = util.generate(
                        before_hooks=_bef,
                        after_hooks=_aft,
                        error_hooks=_err,
                        path=_path,
                        ignore=ignore,
                        response=cls.response
                    )

                elif isinstance(util, Unit):
                    if not util.public:
                        continue
                    util.request = merge_util(cls.request, util.request)
                    routes[key] = util.generate(
                        before_hooks=_bef,
                        after_hooks=_aft,
                        error_hooks=_err,
                        path=_path,
                        ignore=ignore
                    )
                else:
                    raise TypeError(f'Invalid API resolver unit: {util}')

        if not isinstance(cls._resolver, ImmutableDict):
            cls._resolver = ImmutableDict(cls._resolver)  # frozen resolver so it cannot be change during runtime

        return pop_null(APISchema(
            path=path,
            model=model,
            document=document,
            request=cls.request.get_params_schema(auth_config=config.auth.auth_config if root else None),
            response=cls.response.get_params_schema(),
            routes=routes
        ))

    def process_response(cls, req: Request, resp: HttpResponseBase):
        resp = resp or cls.response(status=500)
        if not req:
            return resp
        try:
            logged = bool(resp.get(MetaHeader.LOG))
            if req.source_instance:
                resp.setdefault(MetaHeader.RECV_TIMESTAMP, req.recv_ts)
                log_id = req.log.wait_for_id()
                if log_id:
                    resp.setdefault(MetaHeader.LOG, log_id)
                resp.setdefault(MetaHeader.SERVICE_NAME, config.name)
                resp.setdefault(MetaHeader.INSTANCE, config.deploy.instance_id)
            if req.accept_version and req.accept_version.resolved:
                # version resolved in current service
                resp.setdefault(MetaHeader.SERVER_VERSION, str(config.version))
            if req.head:
                resp.content = ''
        except Exception as e:
            logged = False
            resp = cls.response(status=500, message=str(e))
        if not logged:
            # if a query is rerouted and logged, do not re-log redundantly
            req.log.save_api(req, resp)
        try:
            if req.access_control_required:
                allow_cors(
                    resp, origin=req.origin,
                    methods=req.allow_methods,
                    headers=req.allow_headers
                )
        except constant.COMMON_ERRORS:
            pass
        return resp


class API(metaclass=APIMeta):
    router: dict = None
    module: Type[Module] = None
    message: Type[Message] = None
    media: Optional[Media] = None
    cache: Optional[Cache] = None
    queue: Optional[Queue] = None
    request = Request()
    response = Response(override=False)

    def __init_subclass__(cls, register: bool = False, private: bool = False):
        cls._register = register
        cls._private = private

    def __init__(self, request: Union[ReqType, Request]):
        self.request: Request = self.__class__.request(request)
        if self.__class__.cache:
            self.cache = self.__class__.cache.make_cache(self.request)
        if self.__class__.message:
            self.message: Message = self.__class__.message.__gen__(request)
        for key, val in self.__class__.__dict__.items():
            if isinstance(val, Unit):
                setattr(self, key, partial(val, self))

    @classonlymethod
    def api(cls):
        def f(request: ReqType, *args, **kwargs):
            req = None
            try:
                req = Request().apply(request)
                # when the operation failed in load, add the cors headers
                root = cls(load(request, *args, **kwargs))
                req = root.request
                resp = root()
            except Exception as e:
                error = Error()
                status = error.log(req.log, console=True) if req else 500
                headers = e.append_headers if isinstance(e, exc.HttpError) else {}
                state = getattr(e, 'state', 0)
                resp = cls.response(status=status, message=str(e), state=state, headers=headers)
            return cls.process_response(req, resp)
        update_wrapper(f, cls, updated=())
        f.csrf_exempt = True  # noqa
        # as this f() of RootAPI is the only callable return to set url
        # csrf_exempt must set to True or every result without token will be blocked
        return f

    @classonlymethod
    def serve(cls, api: 'API') -> HttpResponseBase:
        return cls(api.request)()

    def __call__(self) -> HttpResponseBase:
        if self.request.routes:
            unit = self.request.routes[0]
            if self.__class__.root:
                if config.native_proxy:
                    invoke = self._proxy.get(unit) or self.request.reroute_target
                    # get invoke template for proxy service or mismatched version reroute
                    if invoke:
                        # proxy request
                        return self.response(invoke.__proxy__(self.request))
                # --------- LOAD USER ------------------------------
                # do not load for proxy and version reroute
                self.request.load()
            if unit not in self._resolver:
                # may be path param
                # 1, module path param
                # 2, API dynamic method (core method with path param)
                # 3. in module resolver
                # 4, invalid route
                if self.request.method in self._dynamic_methods:
                    # if dynamic method is in core module, unit will not found in resolver
                    # so request goes into module
                    unit = self.request.method
                elif unit in self._core_routes:
                    # module have GET/PUT dynamic method and define POST
                    pass
                else:
                    raise exc.NotFound(path=self.request.path)
            else:
                self.request.routes.pop(0)
        else:
            self.request.allow_methods = self._allowed_methods
            if self.request.method not in self.request.allow_methods:
                raise exc.MethodNotAllowed(
                    method=self.request.method,
                    allows=self.request.allow_methods
                )
            unit = self.request.method

        values = self._resolver.get(unit)
        if not values:
            if self.module:
                # resolve to module
                units = self._core_units
            else:
                raise exc.NotFound(path=self.request.path)

        elif isinstance(values, tuple):
            units: RESOLVER_TUPLE_TYPE = values
            handler, before_hooks, after_hooks, error_hooks = values
        else:
            self.request.allow_methods = list(values)
            if self.request.method not in values:
                raise exc.MethodNotAllowed(
                    method=self.request.method,
                    allows=self.request.allow_methods
                )
            units: RESOLVER_TUPLE_TYPE = values[self.request.method]

        handler, before_hooks, after_hooks, error_hooks = units

        @ignore_errors
        def record_error():
            self.request.record_error()
            if isinstance(handler, (APIMeta, Unit)):
                handler.request.record_error()

        try:
            if not self.request.options:
                for hook in before_hooks:
                    hook(self, **hook.parser.parse_query(gen_meta(
                        headers=self.request.headers,
                        cookie=self.request.COOKIES
                    )))
            result = handler.serve(self)
            for hook in after_hooks:
                result = hook(self, result) or result

        except Exception as e:
            error = Error(e)
            hook = error.get_hook(error_hooks)
            record_error()
            if not hook:
                raise error.throw()
            error.log(self.request.log)
            result = hook(self, error)

        response = self.response(result)

        # ---- record and process response
        if response.status_code >= 400:
            record_error()
        if self.cache:
            response = Response.set_headers(response, **self.cache.headers)
        if self.message and Header.CONTENT_LANGUAGE not in response:
            response.setdefault(Header.CONTENT_LANGUAGE, self.message.content_language)
        return response

    def options(self):
        return self.request.options_response()
