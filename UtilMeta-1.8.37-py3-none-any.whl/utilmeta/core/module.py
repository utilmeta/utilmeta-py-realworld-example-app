from typing import Optional, Union, List, Type, Dict, Any, Tuple

from django.utils.decorators import classonlymethod
from django.db.models.query import QuerySet, Q, Case, When
from django.db.models import ManyToOneRel
from django.core.exceptions import FieldDoesNotExist, FieldError
from django.db.models.base import ModelBase, Model
from django.db.models.expressions import BaseExpression, Combinable

from .schema import Schema, SchemaMeta

from utilmeta.util.base import Util
from utilmeta.util.rule import Rule
from utilmeta.util.field import Field
from utilmeta.util.method import Method
from utilmeta.util.bulk import Bulk
from utilmeta.util.auth import Auth
from utilmeta.util.error import Error
from utilmeta.util.page import Page
from utilmeta.util.filter import Filter
from utilmeta.util.operator import Operator
from utilmeta.util.option import Option
from utilmeta.util.request import Request
from utilmeta.util.response import Response
from utilmeta.util.cache import Cache

from utilmeta.util.common import pop, COMMON_TYPES, COMMON_ERRORS, \
    exp, order_list, get_pk, Logic, model_tag, ImmutableDict, \
    distinct, add_field_id, FilterNote, many_to, one_to, \
    get_fields, get_field, del_field_id, convert_data_frame, \
    Attr, SEG, handle_parse, Key, PK, ID, make_dict_by, pop_null,  \
    multi, COMMON_METHODS, get_doc, \
    UnitAttr, METHOD_IDEMPOTENCY, exc

from utilmeta.util.query import MetaQuerySet, MetaManager
from utilmeta.util.parser.mod import ModuleParser
from utilmeta.util.common import CommonMethod as M
from utilmeta.conf import config
from .unit import Unit
from functools import partial
import inspect
from datetime import timedelta

RESOLVER_TUPLE_TYPE = Tuple[Union[Type['Module'], Unit], List[Unit], List[Unit], Dict[Type[Exception], Unit]]
RESOLVER_TYPE = Dict[str, Union[RESOLVER_TUPLE_TYPE, Dict[str, RESOLVER_TUPLE_TYPE]]]

__all__ = ['Module', 'ModuleMeta']


class ModuleMeta(type, Util):
    _util_slots = ['model', 'query', 'option', 'method', 'schema']

    def __setattr__(cls, key, value):
        if cls.__dict__.get(Attr.LOCK):
            raise AttributeError(f'{cls.__name__}(Module) is readonly and'
                                 f' cannot be set attribute ({key} -> {repr(value)}) during runtime')
        return super().__setattr__(key, value)

    def __delattr__(cls, item):
        if cls.__dict__.get(Attr.LOCK):
            raise AttributeError(f'{cls.__name__}(Module) is readonly and'
                                 f' cannot be delete attribute ({item}) during runtime')
        return super().__delattr__(item)

    def __init__(cls, name: str, bases: tuple, attrs: dict, **kwargs):
        type.__init__(cls, name, bases, attrs)
        Util.__init__(cls, locals())

        if not bases:
            # cls.__locked__ = True
            return
        try:
            del cls.__locked__
        except AttributeError:
            pass

        # cls.id = config.utilmeta.assign(cls)
        cls.mixin = kwargs.get('mixin', False)
        cls.mixins: List[Type['Module']] = []

        cls.model: Type[Model] = attrs.get('model')
        cls.query: Type[Schema] = attrs.get('query')

        cls.related = attrs.get(Attr.RELATED, False)
        cls.proxy = None

        cls.base = None     # take effect when combined=False
        cls.modules = []    # take effect when combined=True

        combined = False
        model = None
        for base in bases:
            if issubclass(base, Module):
                if cls.mixin:
                    cls.mixins.append(base)
                    continue

                cls.modules.append(base)
                if cls.base:
                    combined = True
                    cls.base = None
                else:
                    cls.base = base
                if model:
                    assert base.model is model, \
                        f'Module with multiple bases (combined module) should have consistent model, ' \
                        f'got {base.model}, {model}'
                else:
                    model = base.model

        # abstract = False
        if not isinstance(cls.model, ModelBase):
            if model and combined:
                cls.model = model
                combined = True     # view this as combined trivial case (not inherit)
            else:
                # abstract = True
                raise TypeError(f"Module model must be a subclass of Model, got {cls.model}")
        else:
            if combined and model and cls.model != model:
                raise ValueError(f'Module with multiple bases (combined module) should have consistent model, '
                                 f'got {cls.model}, {model}')

        cls.inherited = cls.base and cls.base.model
        cls.combined = combined
        if cls.combined or cls.mixins:
            # do not use inherited properties
            cls.schema: Type[Schema] = attrs.get('schema', cls.default_schema)
            cls.method: Method = attrs.get('method', Method())
            cls.option: Option = attrs.get('option', Option())
        else:
            cls.schema = cls.schema or cls.default_schema
            cls.modules = []

        if not config.utilmeta:
            raise RuntimeError('Service not initialized')

        # schema can be inherit from the base module, as long as base module has declared
        assert issubclass(cls.schema, Schema), \
            TypeError(f"Module schema must be subclass of Schema, got {cls.schema}")
        assert isinstance(cls.option, Option), \
            TypeError(f"Module option must be an instance of Option, got[{cls.option}]")
        assert isinstance(cls.method, Method), \
            TypeError(f"Module method must be an instance of Method, got[{cls.method}]")

        if cls.model is config.auth.AuthModel:
            raise ValueError(f'Auth model: {cls.model} contains secret data which cannot be Modular')

        cls.meta = getattr(cls.model, '_meta')
        cls.abstract = cls.meta.abstract
        manager = MetaManager()
        manager.model = cls.model
        setattr(cls.meta, 'base_manager', manager)

        cls.pk_name = get_pk(cls.model, root=True).name
        # attrs pass through parent and child, when need to be extract & modify, it need to copy
        # assign attr before merge, because merge util will copy the parent's method
        # to child's method
        if cls.inherited:  # base item has model indicate that it's not Module(base class)
            method: Method = cls.base.method._merge(cls.method)
            option: Option = cls.base.option._merge(cls.option)
            cls.method = method
            cls.option = option
            cls.base.add_submodule(cls)
        else:
            try:
                cls.method = cls.method.__copy__()
            except RecursionError:
                pass

        cls.subs = set()
        cls.query_pk_name = cls.pk_name if cls.pk_name in cls.schema.__template__ else ID
        cls.keys = set(cls.schema.__keys__).union({cls.query_pk_name})
        cls.bare_routes = set()

        cls.option.model = cls.method.model = cls.model
        if cls.query:
            cls.option.apply_query(query=cls.query)

        cls.apply_mixins()
        # check mixins before option check, cause mixins may bring filters to option

        cls.option.check(*cls.keys)
        cls.method.check()

        if cls.combined:
            cls.methods = []
            cls.paging = {}
            cls.batch = {}
            # cls.permission = {}
            for mod in cls.modules:
                cls.methods.extend(mod.methods)
                cls.paging.update(mod.paging)
                cls.batch.update(mod.batch)
                # cls.permission.update(mod.permission)
        else:
            cls.methods = cls.method.methods
            cls.paging = cls.method.paging
            cls.batch = cls.method.batch
            # cls.permission = cls.method.auth

        for mixin in cls.mixins:
            assert isinstance(mixin, ModuleMeta), f'Invalid Module mixin: {mixin}, must be subclass of Module'
            not_support = set(cls.methods).difference(mixin.methods)
            if not_support:
                raise ValueError(f'{cls} mixin: {mixin} does not support {not_support} methods in Module')

        if cls.proxy is None:
            cls.proxy = cls.method.proxy
        cls.proxy = bool(cls.proxy)

        # schema query generate must after the attribute inherit of Option property
        cls.schema_generator = cls.option.schema_generator_cls(
            schema=cls.schema,
            model=cls.model
        )
        cls.schema_query = staticmethod(cls.schema_generator.query(
            optional=cls.option.optional,
            with_rules=cls.option.filter_with_rules,
            split_relates=cls.option.split_many_relation_query
        ))

        cls.read_alias, cls.write_alias = cls.schema_generator.separate_alias()
        cls.operators: Dict[str, Operator] = {}
        cls.cache = Cache(client_cache=cls.option.client_cache) if config.auto_cache else None
        cls.related_modules: Dict[str, Union[Type[Module], ModuleMeta]] = cls.gen_related_modules()
        cls.field_keys = Field.all_fields(cls.model, redundant=True, many=True)
        # cls.mount_api = None

        cls._route_reverse = {}
        cls._extra_params = cls.option.path_params
        cls._route_modules = {}
        cls._resolver: RESOLVER_TYPE = cls.resolve(attrs=attrs)

        cls.option.check_methods(*cls.methods)
        cls.assign_config = cls.option.assign
        cls._register = kwargs.get('register')
        cls._private = kwargs.get('private')
        if cls._register:
            cls.register()

        if cls.related:
            return

        for slot in cls._util_slots:
            util = attrs.get(slot)
            if isinstance(util, Util) and not inspect.isclass(util):
                path = f'{cls.__declare_path__}.{slot}'
                if util.__declare_path__:
                    if util.__declare_path__ != path:
                        pass
                        # import warnings
                        # warnings.warn(f'same util: {util} mount to different '
                        #               f'path: {repr(path)}, {repr(util.__declare_path__)}')
                else:
                    util.__declare_path__ = path

    def generate(cls,
                 path: str = '',
                 ignore: bool = False,
                 response: Response = None,
                 before_hooks: list = (),
                 after_hooks: list = (),
                 error_hooks: dict = None,
                 ):
        from utilmeta.core.sdk import APISchema

        def merge_util(_base: Util, _util: Util):
            _kwargs = _util.__spec_kwargs__ if \
                _util._original_kwargs is None else _util._original_kwargs
            new = _base._merge(_util)
            new._original_kwargs = _kwargs
            return new

        def join(b: str, p: str, param: str = None):
            if param:
                b = '%s/{%s}' % (b, param)
            if p in COMMON_METHODS:
                return b
            elif not b:
                return p
            if p.startswith('@'):
                # for module: post query
                return f'{b}{p}'
            return f'{b}/{p}'

        error_hooks = error_hooks or {}
        routes = {}
        for key, values in cls._resolver.items():
            if isinstance(values, dict):
                temp = {}
                for k, (unit, bf, af, er) in values.items():
                    _err = dict(error_hooks)
                    if er:
                        _err.update(er)

                    if response:
                        for _u in (unit, *af, *er.values()):
                            if _u and _u.response:
                                # response behaviour in API: override if not __defaulted
                                _u.response = merge_util(response, _u.response)

                    parser: ModuleParser = unit.parser
                    _path = join(path, key, parser.option.path_param_field)
                    res = unit.generate(
                        before_hooks=[*before_hooks, *bf],
                        after_hooks=[*af, *after_hooks],
                        error_hooks=er,
                        auth=parser.auth,
                        path=_path,
                        ignore=ignore,
                        prepend=parser.option.path_param_field,
                        model=cls.model
                    )
                    temp[k] = res
                if temp:
                    routes[key] = temp
            else:
                h, bf, af, er = values
                _bef = [*before_hooks, *bf]
                _aft = [*af, *after_hooks]
                _err = dict(error_hooks)
                if er:
                    _err.update(er)

                if isinstance(h, ModuleMeta) and key not in COMMON_METHODS:
                    # mount module
                    _path = join(path, key, cls.option.path_param_field)
                    temp = h.generate(
                        before_hooks=_bef,
                        after_hooks=_aft,
                        error_hooks=_err,
                        path=_path,
                        ignore=ignore,
                        response=response
                    )
                    routes[key] = pop_null(APISchema(
                        model=model_tag(h.model),
                        path=_path,
                        routes=temp.routes,
                        document=get_doc(h),
                        prepend=cls.option.path_param_field,
                        params={cls.option.path_param_field: cls.option.path_param_rule.dict}
                    ))
                    continue

                unit = cls.get_unit(key)  # maybe combined module

                if response:
                    for _u in (unit, *af, *er.values()):
                        if _u and _u.response:
                            # response behaviour in API: override if not __defaulted
                            _u.response = merge_util(response, _u.response)

                # do not merge request for Module, Module may mount to different API
                # Request defined on Method will be standalone
                parser: ModuleParser = unit.parser
                _path = join(path, key, parser.option.path_param_field)
                res = unit.generate(
                    before_hooks=_bef,
                    after_hooks=_aft,
                    error_hooks=_err,
                    ignore=ignore,
                    auth=parser.auth,
                    prepend=parser.option.path_param_field,
                    model=cls.model,
                    path=_path
                )
                routes[key] = res

        if not isinstance(cls._resolver, ImmutableDict):
            cls._resolver = ImmutableDict(cls._resolver)

        for sub in cls.get_modules():
            sub.generate(
                path=path,
                ignore=ignore,
                response=response,
                before_hooks=before_hooks,
                after_hooks=after_hooks,
                error_hooks=error_hooks
            )

        return pop_null(APISchema(
            path=path,
            model=model_tag(cls.model),
            routes=routes,
            document=get_doc(cls),
        ))

    @property
    def resolver(cls):
        return cls._resolver

    def read_field_unit(cls, field: Field) -> Unit:
        def get(self: Module):
            return field.read_value(request=self.request, queryset=self.queryset, one=self.one)

        return Unit(
            get,
            parser_cls=cls.option.module_parser_cls_string,
            parser_kwargs=dict(
                cls=cls,
                method=M.GET,
                route=field.name
            )
        )

    def write_field_unit(cls, field: Field) -> Unit:
        def put(self: Module, data: field.rule = Request.Body):
            return field.write_value(request=self.request, queryset=self.queryset, data=data)

        return Unit(
            put,
            parser_cls=cls.option.module_parser_cls_string,
            parser_kwargs=dict(
                cls=cls,
                method=M.PUT,
                route=field.name
            )
        )

    def resolve(cls, attrs: dict):
        resolver = {}
        units = []

        def mount(_r, _m):
            if _r in resolver:
                if resolver[_r][0] != _m:
                    raise ValueError(f'{cls} conflict routes on {repr(_r)}: {resolver[_r][0]}, {_m}')
                return
            resolver[_r] = (_m, [], [], {})

        for mod in cls.modules:
            for route in mod._resolver:
                mount(route, mod)
            cls.bare_routes.update(mod.bare_routes)

        def get_kwargs(_m: str = None, _r: str = None, _e: List[str] = None,
                       _p: str = None, _b: List[str] = None, _a: List[str] = None):
            return dict(
                parser_cls=_p or cls.option.module_parser_cls_string,
                parser_kwargs=dict(
                    cls=cls,
                    method=_m,
                    route=_r,
                    before=_b,
                    after=_a,
                    error=_e
                )
            )

        for m in cls.methods:
            if m in resolver:
                continue

            option: Unit = cls.method.option.get(m)
            func = getattr(cls, m)

            if isinstance(func, Unit):
                # parent module is initialized before
                func = func.f

            if inspect.ismethod(func):
                raise TypeError(f'Module method function should be instances method, not classmethod, got {func}')
            if option and isinstance(option.idempotent, bool):
                # use dev defined property if specified
                idempotent = option.idempotent
            elif m == M.PATCH:
                idempotent = not cls.operators
            else:
                idempotent = METHOD_IDEMPOTENCY.get(m)

            if getattr(func, UnitAttr.method, None) or not option:
                unit = Unit.from_func(func, **get_kwargs(m))
            else:
                unit = Unit(
                    func,
                    method=m,
                    # transaction=option.transaction_using,
                    # transaction is used in module to cross before / handle / after contexts
                    timeout=option.timeout,
                    request=option.request,
                    response=option.response,
                    cache=option.cache,
                    public=option.public,
                    max_retries=option.max_retries,
                    idempotent=idempotent,
                    wrapper=option.wrapper,
                    **get_kwargs(m),
                )

            if m in cls.method.batch:
                unit.parser.options.bulk_dict = True

            setattr(cls, m, unit)
            units.append(unit)
            mount(m, unit)

        def find(tar, k, h):
            if isinstance(tar, Field) and tar.name == k:
                return True

            if isinstance(h, Unit):
                if callable(tar):
                    return h.f is tar
                if isinstance(tar, str):
                    return tar in (h.name, k)
                return False

            return False

        def hook(*targets, place=0, excludes: list = (), append):
            targets = set(targets).difference(excludes)
            dif = set(targets).difference(resolver)
            if dif:
                ValueError(f"Module method {dif} must define in Module's methods")

            for tar in targets:
                _find = False
                for k in list(resolver):
                    _values = resolver[k]
                    if isinstance(_values, dict):
                        for _m in list(_values):
                            h, b, a, e = _values[_m]
                            if find(tar, k, h):
                                if place == 1:
                                    b.append(append)
                                elif place == 2:
                                    a.append(append)
                                elif place == 3:
                                    e.update(append)
                                _values[_m] = h, b, a, e
                                _find = True
                    else:
                        h, b, a, e = _values
                        if find(tar, k, h):
                            if place == 1:
                                b.append(append)
                            elif place == 2:
                                a.append(append)
                            elif place == 3:
                                e.update(append)
                            resolver[k] = h, b, a, e
                            _find = True
                assert _find, ValueError(f"@api.<hook>{targets} got unexpected unit: {tar}, use"
                                         f" the reference or name of your target hook API/Module/Unit")

        def get_keys(_keys):
            if not _keys:
                return []
            if not multi(_keys):
                return []
            if '*' in _keys:
                return list(resolver)
            _res = []
            for _k in _keys:
                if isinstance(_k, str):
                    _res.append(_k)
                elif isinstance(_k, Field):
                    _res.append(_k.attname or _k.name)
                elif hasattr(_k, Attr.NAME):
                    _res.append(getattr(_k, Attr.NAME))
                else:
                    _res.append(str(_k))
            return _res

        routes = {}
        for key, val in attrs.items():
            if not callable(val):
                continue
            if key in COMMON_METHODS:
                continue
            if not inspect.ismethod(val) and not inspect.isfunction(val):
                continue
            method = getattr(val, UnitAttr.method, None)
            if not method:
                continue
            unit = Unit.from_func(val, **get_kwargs(method, key))
            units.append(unit)
            setattr(cls, key, unit)

            route = unit.alias or key
            parser: ModuleParser = unit.parser
            if not parser.option.path_param_field:
                cls.bare_routes.add(route)

            _units = (unit, [], [], {})
            if route in routes:
                routes[route][method] = _units
            else:
                routes[route] = {method: _units}

        for key, field in cls.schema.__data__.items():
            if not isinstance(field, Field):
                continue
            if not field.field:
                continue
            if not field.mount:
                continue
            if field.with_module:
                def _setter(_m: Type[Module], _k=key, _name=field.remote_name):
                    # need to set key to func local param so that it will not be override in next circulation
                    cls.set_route_module(_k, _m, remote_name=_name)
                    mount(_k, _m)

                if field.module:
                    _setter(field.module)
                elif field.module_str:
                    field.append_module_setter(_setter)

                if field.remote_name:
                    cls._route_reverse[key] = field.remote_name
                continue
            methods = {}
            if not field.writeonly:
                get = cls.read_field_unit(field)
                units.append(get)
                methods[M.GET] = get, [], [], {}
            if not field.readonly:
                put = cls.write_field_unit(field)
                units.append(put)
                methods[M.PUT] = put, [], [], {}
            if key in routes:
                raise ValueError(f'{cls} sub-route {key} conflict with mounted field')
            routes[key] = methods

        for key, values in routes.items():
            param_field = set()
            for method, (unit, *_) in values.items():
                param_field.add(unit.parser.option.path_param_field)
            if len(param_field) > 1:
                raise ValueError(f'{cls} conflict path_param_field: {param_field} on same route: {key}')

            if len(values) == 1:
                values = values[list(values)[0]]
            if key in resolver:
                raise ValueError(f'{cls} conflict routes on {repr(key)}')
            resolver[key] = values

        for key, val in attrs.items():
            if not callable(val):
                continue
            if key in resolver:
                continue
            if not inspect.isfunction(val) and not inspect.ismethod(val):
                continue

            bf = get_keys(getattr(val, UnitAttr.before_hook, None))
            af = get_keys(getattr(val, UnitAttr.after_hook, None))
            er = get_keys(getattr(val, UnitAttr.error_hook, None))
            _exc = get_keys(getattr(val, UnitAttr.excludes, []))

            if bf:
                unit = Unit.from_func(val, **get_kwargs(_b=bf))
                units.append(unit)
                setattr(cls, key, unit)
                hook(*bf, place=1, append=unit, excludes=_exc)
            elif af:
                unit = Unit.from_func(val, **get_kwargs(_a=af))
                units.append(unit)
                setattr(cls, key, unit)
                hook(*af, place=2, append=unit, excludes=_exc)
            elif er:
                errors = getattr(val, UnitAttr.errors)
                unit = Unit.from_func(val, **get_kwargs(_e=er))
                units.append(unit)
                setattr(cls, key, unit)
                hook(*er, place=3, append={error: unit for error in errors}, excludes=_exc)

        for unit in units:
            unit.parent = cls
            getattr(unit, '_make_path')(f'{cls.__declare_path__}.{unit.name}')

        if cls.option.post_query or cls.option.client_cache:
            # from .unit import Unit
            # this unit is abstract, only for API template
            if M.GET not in cls.methods:
                raise ValueError('Option post_query / client_cache require to open get method to apply query')

            get, befores, afters, errors = resolver[M.GET]
            if isinstance(get, Unit):
                if cls.option.post_query:
                    u = get.__copy__()
                    u.parent = cls
                    u.__declare_path__ = get.__declare_path__
                    u.method = M.POST
                    u.parser.query = {}
                    u.parser.body = u.parser.query
                    resolver[cls.option.post_query_route] = u, befores, afters, errors

                if cls.option.client_cache:
                    inner = get.inner and not afters
                    if not inner:
                        # the result is not absolutely controlled by Module layer
                        # and have developer-defined logic, so the result must be cache in form of etag
                        get.parser.option.etag_cache = True

        return resolver

    def update_route_params(cls, params: dict):
        for unit in cls.get_units():
            parser: ModuleParser = unit.parser
            parser.kwargs.update(params)
        for key, module in cls._route_modules.items():
            for unit in module.get_units():
                parser: ModuleParser = unit.parser
                parser.kwargs.update(params)
        # only force to update new params
        cls._extra_params.update(params)

    def set_route_module(cls, key: str, module: 'ModuleMeta', remote_name):
        cls._route_modules[key] = module
        if cls.option.path_param_field:
            # if module is mount after path param
            # like /api/article/:slug/comments/id
            # then it's
            module.update_route_params(cls._extra_params)

            if remote_name:
                for unit in module.get_units():
                    parser: ModuleParser = unit.parser
                    for _n in (remote_name,
                               add_field_id(remote_name),
                               module.read_alias(remote_name)
                               ):
                        pop(parser.query, _n, pop(parser.body, _n))

    def register(cls):
        config.app.register(cls.__declare_path__, cls=cls)

    def get_units(cls) -> List[Unit]:
        units = []
        for key, values in cls._resolver.items():
            if isinstance(values, dict):
                for k, (u, *_) in values.items():
                    units.append(u)
            else:
                unit = values[0]
                if isinstance(unit, Unit):
                    units.append(unit)
                elif key not in COMMON_METHODS:
                    continue
                else:
                    unit = unit.get_unit(key)
                    if unit:
                        units.append(unit)
        return units

    def get_modules(cls):
        modules = []
        if cls.subs:
            modules.extend(cls.subs)
        if cls.mixins:
            modules.extend(cls.mixins)
        if cls.modules:
            modules.extend(cls.modules)
        return modules

    @property
    def id(cls):
        return getattr(cls, Key.ID, None)

    def add_submodule(cls, sub: 'ModuleMeta'):
        cls.assign_config.inject(sub)
        cls.subs.add(sub)
        for m in cls.methods:
            unit = cls.get_unit(m)
            if not unit:
                continue
            unit.parser.query_options.allow_excess = True
            unit.parser.query_options.excess_preserve = True
            # preserve query filters for base class

    @property
    def default_schema(cls) -> SchemaMeta:
        from utilmeta.fields import PasswordField
        annotates = {}
        for field in get_fields(cls.model, many=False):
            if isinstance(field, PasswordField):
                # forbid to serialize PasswordField
                continue
            annotates[field.name] = Field.get_rule(field)
        return SchemaMeta(cls.__name__ + 'Schema', (Schema,), {Attr.ANNOTATES: annotates})

    @property
    def read_template(cls) -> dict:
        unit = cls.get_unit(M.GET)
        if not unit:
            return {}
        return SchemaMeta.__retrieve__(unit.response.schema, _dict=True) or {}

    def gen_related_modules(cls):
        data = {}
        for key, unit in cls.schema.__template__.items():
            item = cls.schema.__data__.get(key)
            name = key
            base_methods = {M.PUT, M.PATCH, M.POST}
            if isinstance(item, Field):
                if item.name:
                    name = item.name
                # POST need relate module too and will ignore readonly
                if not item.relate_creation:
                    base_methods.remove(M.POST)
                if item.readonly:
                    base_methods.remove(M.PUT)
                    base_methods.remove(M.PATCH)

            write_methods = base_methods.intersection(cls.methods)
            if not write_methods:
                continue
            t = SchemaMeta.__retrieve__(unit, schema=True)
            if not t:
                continue
            try:
                field = get_field(cls.model, name)
            except FieldDoesNotExist:
                continue
            if not isinstance(field, ManyToOneRel):
                continue

            method_bulk = {
                M.PUT: Bulk(replace=True),
                M.POST: Bulk(post=True),
                M.PATCH: Bulk()
            }
            if isinstance(item, Field) and item.with_module:
                def setter(m, n=name):
                    # must pass name as setter's params, or will cause wrong update
                    # (name point to outer variable that change during the loop)
                    data[n] = m
                    for mt in write_methods.intersection(m.methods):
                        if mt not in m.batch:
                            raise ValueError(f'Field module: {m} write method: >{mt}> should define \n'
                                             f'a Bulk object in method config to support relate modify/create, '
                                             f'like {repr(method_bulk[mt])}')
                if item.module:
                    setter(item.module)
                elif item.module_str:
                    item.append_module_setter(setter)
                continue

            if isinstance(t, tuple):
                raise ValueError(f'Union schemas relates: <{name}> should provide Field(module=<Module Name>) '
                                 f'which module is inherit by different subclasses. got {t}')

            remote = add_field_id(field.remote_field.name)
            updates = {} if remote in t else {remote: Rule.optional(Field.get_type(field.remote_field))}
            attrs = {
                Attr.RELATED: True,
                'model': field.related_model,
                'schema': t.__reproduce__(updates=updates),
                'method': Method(**{method: bulk for method, bulk in method_bulk.items() if method in write_methods})
            }
            class_name = field.related_model.__name__ + 'Module'
            data[name] = ModuleMeta(class_name, (Module,), attrs)
        return data

    def get_unit(cls, method: str, route: str = None):
        method = str(method).lower()
        key = method
        if route:
            key = route
        try:
            values = cls._resolver[key]
            if isinstance(values, dict):
                unit = values[method][0]
            else:
                unit = values[0]
        except (KeyError, IndexError):
            return None
        if not isinstance(unit, Unit):
            if unit in cls.modules:
                return unit.get_unit(method, route=route)
            return unit
        return unit

    def get_option(cls, method: str) -> Option:
        if not cls.modules:
            return cls.option
        utils = cls._resolver.get(method)
        if not utils:
            return cls.option
        util = utils[0]
        if isinstance(util, ModuleMeta):
            return util.get_option(method)
        return cls.option

    @property
    def read_option(cls):
        return cls.get_option(M.GET)

    def apply_mixins(cls):
        """
        1. check all mixins does not have conflict fields in schema
            (except for pointer to the base model and pk)
        2. check all mixins filters does not conflict
        :return:
        """
        if not cls.mixins:
            return
        # cls.option.client_option.extend_order_range(*[mixin.model for mixin in cls.mixins])
        cls.schema.__options__.excess_preserve = cls.schema.__options__.allow_excess = True
        for mixin in cls.mixins:
            # main request passed to mixin is highly possible out of mixin's scope
            mixin.option.ignore_invalid_params = True
            for key, (unit, a, b, e) in mixin._resolver.items():
                unit.parser.query_options.allow_excess = True
            cls.keys.update(mixin.keys)

        union_fields = set(cls.schema_generator.gen(get=True))
        union_filters = set(cls.option.filters)
        for mixin in cls.mixins:
            get = mixin.get_unit(M.GET)
            if not get:
                continue
            pk = get_pk(mixin.model, root=True)
            if pk.related_model is not cls.model:
                raise TypeError(f'{cls} mixin: {mixin} model primary_key'
                                f' should point to {cls.model}, got {pk.related_model}')
            reverse_field = pk.remote_field.name
            excludes = [pk.name, add_field_id(pk.name), 'id', 'pk']
            filters = set(mixin.option.filters).difference(excludes)

            if not cls.option.ignore_mixin_conflicts:
                fields = set(mixin.read_template).difference(excludes)
                inter = union_fields.intersection(fields)
                if inter:
                    raise ValueError(f'{cls} mixins has conflict fields: {inter} with {mixin}, alter the schemas or '
                                     f'turn Option(ignore_mixin_conflicts=True) if you want to ignore this conflict')
                union_fields.update(fields)
                inter = union_filters.intersection(filters)
                if inter:
                    raise ValueError(f'{cls} mixins has conflict filters: {inter} with {mixin}, alter the filters or '
                                     f'turn Option(ignore_mixin_conflicts=True) if you want to ignore this conflict')

            union_filters.update(filters)
            for key, values in mixin.option.filter_dict.items():
                cls.option.filter_dict[key] = [val.apply_mixin(reverse_field=reverse_field)
                                               for val in values if val.field]


class Module(metaclass=ModuleMeta):
    model: Type[Model] = None
    query: Type[Schema] = None
    schema: Type[Schema] = None
    option = Option()
    method = Method(get=Auth())

    def __init_subclass__(cls, register: bool = False, private: bool = False, mixin: bool = False):
        cls._register = register
        cls._private = private
        cls._mixin = mixin

    def __init__(self, request: Request = None, *,
                 id: Union[int, str] = None, pk_list: list = None,
                 instance: Model = None,
                 queryset: Union[QuerySet, list] = None,
                 method: str = None,
                 query: dict = None,    # query params dict
                 filters: dict = None,
                 route: str = None,
                 data: Union[dict, list] = None,
                 auth: bool = True, unlimited: bool = False,
                 assign: bool = None, one: bool = False, db: str = None):

        # initialize data
        # self.i: models.Model = instance
        # self.q: QuerySet = queryset
        self._original_kwargs = {key: val for key, val in locals().items() if key != 'self' and val is not None}
        self._module = self                 # directly assigned module
        self._modules: List[Module] = []    # assigned submodules
        self._mixins: List[Module] = []     # mixin modules

        # Cache value init ------------------
        self._pk = None
        self._orders: list
        self._i: Model    # cache of instance if instance is provide, using ... to represent undefined
        self._exist: bool     # cache of exist if instance is provide
        self._count: int    # cache of count
        self._pk_domain = None
        self._q: MetaQuerySet = self.none()
        self._altered = unlimited
        self._schema_data = None

        self.refresh()

        self.one = one   # return a list of data or one dict/field
        self.query_count = None
        self.query_temp = None
        self.message = ''
        self.referring = False
        # Data initialize ----------------------
        self.args = ()
        self.kwargs = {}

        if query:
            if not isinstance(query, dict):
                raise TypeError(f'Invalid query: {query}, must be dict object')

        if request:
            if not isinstance(request, Request):
                raise TypeError(f'Invalid request: {request}, must be Request object')
            if data is not None or query is not None or method is not None:
                # custom request
                request = Request.custom(
                    method=method or request.method,
                    query=query if query is not None else request.query,
                    data=data if data is not None else request.data,
                    # when data is explicitly set from upper-layer, one should accept if even if it's empty
                    # because original data and target module may not correspond, will cause wrong result
                    user_id=request.user_id,
                    admin=request.admin,
                    headers=request.headers
                )
            self.request = request
            # self.query: Dict[str, Any] = self.request.query
            # self.data: Union[dict, list] = self.request.data  # request data (after parse)
        else:
            # self.query = query
            # self.data = data
            if not method:
                method = M.POST if data else M.GET
            self.request = Request.custom(method, query=query, data=data)

        self.m = self.request.method
        self.cache = self.__class__.cache.make_cache(self.request) if self.__class__.cache else None
        self.data = self.request.data
        self.response = Response()
        # API service initialize ----------------------
        # assign back to the request in the case that request not
        # from API still hold empty values that affect the sub Module

        self.status = 200
        self.state = 1
        self.non_result = False

        # Db query initialize ----------------------
        # the runtime (per query) fields optimize
        self.only_fields = None
        self.deter_fields = ()
        # self.subs: Dict[str, Type[Module]]
        self.path_param = None
        self.path_query = None
        self.validated = False
        self.do_auth = bool(auth)
        self.sole_field = None
        self.extra_filters = filters
        self.query: dict = self.request.query
        self.filters: dict = {}
        self.response = Response()
        self.auth = None
        self.parser = None
        self.page = None
        self.bulk = None
        self.using = None
        self.assignable = None
        self.dataframe_depth = None
        self.relative_key = None
        self.do_distinct = None
        _routes = list(self.request.routes)
        self.route = route or (self.request.routes.pop(0) if self.request.routes else None)
        self.unit = None

        if self.request.options:
            return

        if self.route:
            # if combined modules have path_param
            # M1: path=T get/delete f1
            # M2: path=F post/patch f2 f3
            # 1. match bare_routes: f2, f3 (when in combined case, the bare route cannot be pop for next parse)
            # 2. get method option (default to cls.option) to check if path param exists
            # 3. if path param exists, parse and assign route to next
            if self.route not in self.bare_routes:
                # if request still have routes, means that it may be an module after path param
                option = self.option if self.request.routes else self.__class__.get_option(self.m)

                if option.path_param_field:
                    # self.option means self.__class__.option since self.option is never assigned
                    # this option is only for path param options to generate route for the further unit
                    try:
                        self.path_param = option.path_param_rule(self.route)
                    except COMMON_ERRORS as e:
                        raise exc.BadRequest(e)
                    self.path_query = {option.path_param_field: self.path_param}
                    self.one = True
                    if self.request.routes:
                        self.route = self.request.routes.pop(0)
                    else:
                        self.route = None
                else:
                    raise exc.NotFound(path=self.request.path)
        else:
            if self.option.path_param_required:
                raise exc.NotFound(path=self.request.path)

        self.unit: Unit = self.__class__.get_unit(self.m, route=self.route)

        if self.request.from_api:
            if not self.unit:
                if self.route:
                    raise exc.NotFound(path=self.request.path)
                if method:
                    raise exc.MethodNotAllowed(allows=self.methods, method=self.m)

            elif not isinstance(self.unit, Unit):
                # mount to further module
                self.unit = None
                self.parser = None
                return
            else:
                if self.unit.parent is not self.__class__:
                    # assign to combined module, assign the routes
                    self.request.routes = _routes
                    return

        if isinstance(self.unit, Unit):
            self.response = self.unit.response
            self.parser: ModuleParser = self.unit.parser
            self.option = self.parser.option
            self.page = self.parser.page
            self.auth = self.parser.auth
            self.bulk = self.parser.bulk

        if not isinstance(self.data, list):
            self.bulk = None

        self.using = db or self.option.get_using_db(request=self.request)
        self.assignable = assign is not False and self.assign_config     # avoid infinite recursive for rest_list
        self.dataframe_depth = self.option.data_frame
        self.relative_key = self.option.relative_key

        if self.abstract:
            # deal with the abstract Module
            return
        # if self.bypass:
        #     # do not return from code-defined combined module
        #     return

        # -------- GENERATE QUERYSET-------------------------------------------------
        if self.parser:
            try:
                self.query: dict = self.parser.parse_query(
                    self.request.query,
                    options=Schema.Options(allow_excess=True) if assign else None
                    # options=None if self.request.from_api else Schema.Options()
                )
                if self.parser.query_schema:
                    self.query: dict = self.parser.query_schema(**self.query)
            except exc.BadRequest as e:
                if self.request.from_api:
                    raise Error(e).throw()

        self._clean_query()
        # self.query = self._get_params()
        self.filters = self._get_filters()
        id = id or self.get_param_pk()

        # no matter what params, process should be generate_queryset -> process queryset
        # cause if both id / instance  and filters are specified, if filters are ignore
        # the id / instance may not want to include in the result
        if id:
            queryset = self.base_queryset().filter(pk=id)
            self._pk = id
            self.one = True
        elif pk_list is not None:
            if not pk_list:
                queryset = self.none()
            else:
                assert distinct(pk_list), \
                    f"Module pk_list must be a list of exist distinct instances pk, got {distinct(pk_list)}"
                pk_list = self.none().parse_pk_list(pk_list)
                queryset = self.base_queryset().filter(pk__in=pk_list)

            self._orders = pk_list
            self._count = len(pk_list)
            self._exist = bool(pk_list)

        elif instance:
            if not isinstance(instance, self.model):
                raise ValueError(f"Module init instance must be the module's "
                                 f"model's instance, got {instance.__class__}")
            self._pk = instance.pk
            queryset = self.base_queryset().filter(pk=self.pk)
            self._i = instance
            self.one = True
            self._count = 1
            self._orders = [self.pk]
            self._exist = True
        elif self.adding:
            if not self.bulk:
                self.one = True
            queryset = self.none()
        else:
            do_distinct = False
            if multi(queryset):  # a list/set/tuple of Model Object, must convert to QuerySet
                pk_list = distinct([inst.pk for inst in queryset])
                self._orders = list(pk_list)
                self._count = len(pk_list)
                self._exist = bool(pk_list)
                queryset = self.base_queryset().filter(pk__in=pk_list)
            elif isinstance(queryset, MetaQuerySet):
                if self.model != queryset.model:
                    raise TypeError(f'Invalid queryset model: {queryset.model}'
                                    f' for {self.__class__} with {self.model} as model')
                if not queryset.query.is_sliced:
                    do_distinct = True
            elif isinstance(queryset, QuerySet):
                if self.model != queryset.model:
                    raise TypeError(f'Invalid queryset model: {queryset.model}'
                                    f' for {self.__class__} with {self.model} as model')
                queryset = self.option.module_queryset_cls(model=queryset.model, query=queryset.query)
                do_distinct = True
            elif self.page and self.page.all and not self.filters:
                queryset = self.base_queryset()

            if not self.reading:
                # other methods with distinct may cause unexpected error
                # eg. TypeError: Cannot call delete() after .distinct().
                do_distinct = False
            if not isinstance(queryset, QuerySet):
                queryset = self.base_queryset()
            self.do_distinct = do_distinct

        if self.option.annotates:
            queryset = queryset.annotate(**self.option.annotates)

        if self.path_query:
            if not self.option.ignore_invalid_params and self.filters:
                raise ValueError(f'Invalid query parameters: {list(self.filters)} for path param request')
            queryset = queryset.filter(**self.path_query)
        else:
            queryset = self.apply_filters(queryset)

        if isinstance(filters, dict) and filters:
            queryset = queryset.filter(**filters)

        if not isinstance(queryset, MetaQuerySet):
            queryset = self.none()

        if not queryset.ordered and not self.one:
            # when ordered by developer somewhere else util will override the order
            # the order override:  upper specify order -> client order(param @order) -> Option order -> Model order
            orders = self._get_orders()
            if not queryset.query.is_sliced and self.option.order_not_null:
                not_null_query = {}
                for order in orders:
                    field = order.lstrip('-')
                    opt = self.option.order_dict.get(field)
                    if opt and not opt.notnull:
                        continue
                    not_null_query[field + '__isnull'] = False
                try:
                    queryset = queryset.filter(**not_null_query)
                except FieldError as e:
                    raise exc.BadRequest(e)
            queryset = queryset.order_by(*orders)

        assert queryset.model == self.model, \
            ValueError(f"Module init queryset must be the module's "
                       f"model's QuerySet, got {queryset.model}")
        self._q: MetaQuerySet = queryset.using(self.using)
        self._q.relate_request_maker = self._make_relate_request
        # from utilmeta.core.unit import Unit

        for key, val in self.__class__.__dict__.items():
            if isinstance(val, Unit):
                setattr(self, key, partial(val, self))

    # def generate_queryset(self, id, pk_list, instance):
    #     pass

    @property
    def i(self) -> Union[Model, Any]:
        if self._i is ...:
            if self.pk:
                self._i = self.q.fetch(self.pk)
            else:
                self._i = self.q.first()
            if self._i:
                self._pk = self._i.pk
            self._exist = bool(self._i)
        return self._i

    @i.setter
    def i(self, i):
        if isinstance(i, Model):
            self._i = i
            self._pk = i.pk
            self.q = self.base_queryset().filter(pk=i.pk)

    @property
    def q(self):
        try:
            return self._q
        except AttributeError:
            return self.none()

    @q.setter
    def q(self, v):
        if isinstance(v, MetaQuerySet):
            self._q = v
        elif isinstance(v, QuerySet):
            self._q = MetaQuerySet(model=v.model, query=v.query)
        else:
            return
        self.refresh()

    @property
    def instance(self) -> Union[Model, Any]:
        return self.i

    @instance.setter
    def instance(self, i):
        self.i = i

    @property
    def object(self) -> Union[Schema, Any]:
        if not self.one:
            return None
        values = self.serialize()
        if not values:
            return None
        return values[0]

    @property
    def queryset(self) -> MetaQuerySet:
        return self.q

    @queryset.setter
    def queryset(self, q):
        self.q = q

    @property
    def log(self):
        return self.request.log

    @property
    def user_id(self):
        return self.request.user_id

    # DOING -------------------------
    @property
    def adding(self) -> bool:
        return not self.route and self.m == M.POST

    @property
    def altering(self) -> bool:
        return not self.route and self.m in (M.PUT, M.PATCH)

    @property
    def replacing(self) -> bool:
        return not self.route and self.m == M.PUT

    @property
    def writing(self) -> bool:
        return not self.route and self.adding or self.altering

    @property
    def reading(self) -> bool:
        return not self.route and self.m == M.GET

    @property
    def deleting(self) -> bool:
        return not self.route and self.m == M.DELETE

    @property
    def bypass(self) -> bool:
        return self.combined and self.m not in self.methods
    # DOING -------------------------

    @property
    def query_count_required(self):
        if self.page:
            return True
        if self.response:
            return bool(self.response.count_key)
        return False

    @property
    def extra_query(self):
        base_extra = {}
        if self.path_query:
            base_extra.update(self.path_query)
        if self.extra_filters:
            base_extra.update(self.extra_filters)
        return base_extra

    def _clean_query(self):
        for filters in self.option.filter_dict.values():
            for filter in filters:
                if filter.custom:
                    continue
                key = filter.first_key
                if not filter.public:
                    as_val = pop(self.query, key)
                    if as_val is not None:
                        if as_val != filter.set_as:
                            raise exc.BadRequest(f'Invalid Filter field: <{key}> value: {repr(as_val)}')

    def _get_filters(self) -> dict:
        result = {k: v for k, v in self.query.items() if k in self.option.filters or k == self.pk_name}
        for filters in self.option.filter_dict.values():
            for filter in filters:
                key = filter.first_key
                if filter.auto_user_id:
                    if key not in result and self.user_id:
                        result[key] = self.user_id
                    continue
                if filter.default is not ... and key not in result:
                    result[key] = filter.default
                val = filter.get_value(self)
                if val is not ...:
                    result[key] = val
        return result

    @handle_parse
    def parse_params(self):

        self.non_result = self.option.client_option.template in self.query \
                         and not self.query[self.option.client_option.template]
        if self.non_result:
            if self.query_count_required and self.query_count is None:
                self.query_count = self.q.count()
        _template = self.query.get(self.option.client_option.template)
        _exclude = self.query.get(self.option.client_option.exclude)
        _field = self.query.get(self.option.client_option.field)
        _dataframe = self.query.get(self.option.client_option.dataframe)
        _relative_key = self.query.get(self.option.client_option.key)

        params = [_template, _exclude, _field]
        if params.count(None) < len(params) - 1:
            raise ValueError('Module client option @field/@exclude/@template only allow to specify one param')
        self.query_temp = dict(_template or {})
        self.sole_field = _field
        self.deter(list(_exclude or []))
        self.only(_field)
        if _dataframe is not None:
            self.dataframe_depth = int(_dataframe)
        if _relative_key:
            self.relative_key = _relative_key

    def get_expect_fields(self):
        if self.query_temp:
            return set(self.query_temp).union({self.query_pk_name})
        if self.only_fields:
            return set(self.only_fields).union({self.query_pk_name})
        keys = self.keys
        if self.deter_fields:
            return set(keys).difference(self.deter_fields).union({self.query_pk_name})
        return keys

    def process_data(self):
        if not self.data or not self.writing:
            return
        # convert schema data (attname) to dict (field-name)
        data = self.write_alias(
            [dict(d) for d in self.data]
            if multi(self.data) else dict(self.data)
        )

        # PROCESS ORDER OPTION --------------------------------
        if self.option.order_option:
            field = self.option.order_option.field
            key = self.option.order_option.model_order_key
            start = self.option.order_option.model_order_start

            if self.adding:
                if isinstance(data, list):
                    key_counts = {}
                    for d in data:
                        val = d.get(key)
                        if val not in key_counts:
                            key_counts[val] = 1
                        else:
                            key_counts[val] += 1
                        query = self.base_queryset().filter(**{key: val}) if key else self.base_queryset()
                        max_order = query.aggregate(max=exp.Max(field))['max']
                        if isinstance(max_order, int):
                            start = max_order
                        d[field] = start + key_counts[val]
                else:
                    query = self.base_queryset().filter(**{key: data.get(key)}) if key else self.base_queryset()
                    max_order = query.aggregate(max=exp.Max(field))['max']
                    if isinstance(max_order, int):
                        start = max_order + 1
                    data[field] = start
            else:
                if isinstance(data, list):
                    pk_list = [str(d.get('pk', d.get(self.pk_name))) for d in data]
                    values = []
                    append = []
                    for d in data:
                        d: dict
                        val = d.get(field)
                        if val is None:
                            continue
                        if val in values:
                            raise ValueError(f'Module order field value duplicate at {val}')
                        values.append(val)
                        pk = d.get('pk', d.get(self.pk_name))
                        # the case/when will be implement in Bulk
                        target = self.fetch(pk)
                        query = self.base_queryset().filter(
                            **{key: getattr(target, key)}) if key else self.base_queryset()
                        inst = query.filter(**{field: val}).first()
                        if not inst:
                            raise ValueError(f'Module modify order field to a not exist value: {val}')
                        elif target:
                            if str(inst.pk) not in pk_list:
                                append.append({'pk': inst.pk, field: getattr(target, field)})
                    data.extend(append)
                elif field in data:
                    if self.count != 1:
                        raise ValueError(f'Module order field cannot be batch update')
                    value = data[field]
                    query = self.base_queryset().filter(**{key: getattr(self.i, key)}) if key else self.base_queryset()
                    inst = query.filter(**{field: value}).first()
                    if inst:
                        # exchange values
                        case = Case(When(pk=self.pk, then=getattr(inst, field)),
                                    When(pk=inst.pk, then=getattr(self.i, field)))
                        self.base_queryset().filter(pk__in=[self.pk, inst.pk]).update(**{field: case})
                    else:
                        raise ValueError(f'Module modify order field to a not exist value: {value}')

        if self.adding and self.option.valid_integrity:
            if isinstance(data, dict):
                unique_data = {key: data[key] for key in self.option.unique_fields if key in data}
            elif isinstance(data, list):
                unique_data = {key + '__in': [d[key] for d in data if key in d]
                               for key in self.option.unique_fields}
            else:
                unique_data = {}
            if unique_data:
                if self.find(**unique_data).exists():
                    raise exc.BadRequest(f'duplicate key detected in {unique_data}')

        self.data = [self._process_dict(d) for d in data] \
            if multi(data) else self._process_dict(data)

    def _process_dict(self, data: dict):
        if not isinstance(data, dict):
            raise TypeError(f'Module process data must be dict object, got {data}')
        if self.operators:
            adds, rems = Operator.process(data=data, options=self.operators)
            # directly add / remove will not
            self.q.add_relates(adds, query_scope=True)
            self.q.remove_relates(rems, query_scope=True)
        if self.adding or self.replacing:
            self.option.assign_user_id(data, self.user_id)      # assign user_id to auto_user_field
        result = {}
        from utilmeta.fields import DurationField
        for key, val in data.items():
            if key not in self.field_keys:
                # maybe arguments that used in self-define hooks, just ignore
                continue
            field = get_field(self.model, key)
            if one_to(field):
                # depend on the complexity of fk map  <field>: <id> / <field>_id: <id> / <field>: obj / <field>_id: obj
                key = del_field_id(key) if isinstance(val, Model) else add_field_id(key)
            elif isinstance(field, DurationField) and isinstance(val, (int, float)):
                val = timedelta(seconds=val)
            elif not isinstance(val, COMMON_TYPES):
                # fk_field can map to Model instance, other field can use exp.F to apply operators
                # but other than that beyond COMMON_TYPES is illegal
                if not isinstance(val, (BaseExpression, Combinable)):
                    val = str(val)
            elif multi(val):
                # convert tuple/set to list
                val = list(val)
            result[key] = val

        for key, val in self.schema.__data__.items():
            if isinstance(val, Field):
                if self.altering:
                    if val.write_auth:
                        # keys include operator keys like price-, stock+
                        if set(val.keys).intersection(result):
                            try:
                                reserve = val.write_auth(request=self.request, resource=self.q)
                            except exc.PermissionDenied as e:
                                if not val.forbid_silently:
                                    raise e
                                reserve = False
                            if not reserve:
                                for k in val.keys:
                                    pop(result, k)

        return result

    @handle_parse
    def validate(self,  force: bool = False):
        if not force and self.validated:
            return
        if self.do_auth and self.auth:
            self.auth(request=self.request, resource=self.q, data=self.data)
        self.validated = True

    def refresh(self):
        self._pk = None
        self._orders = None
        self._i = ...  # cache of instance if instance is provide, using ... to represent undefined
        self._exist = None  # cache of exist if instance is provide
        self._count = None  # cache of count

    def _get_mixins(self):
        if not self.mixins:
            return []
        mixins = []
        for key, filters in self.option.filter_dict.items():
            for fil in filters:
                if not fil.mixins or fil.custom:
                    continue
                value = self.filters.get(fil.first_key)
                if value is None:
                    continue
                for val, mixin in fil.mixins.items():
                    if val == value:
                        if mixin in self.mixins and mixin not in mixins:
                            mixins.append(mixin)
        return mixins

    def _get_orders(self):
        order_params = self.query.get(self.option.client_option.order)
        if not order_params:
            return self.option.get_base_order(request=self.request)
        if not self.option.order_dict:
            return order_params
        orders = []
        for order in order_params:
            order: str
            field = order.lstrip('-')
            desc = '-' if order.startswith('-') else ''
            for key, val in self.option.order_dict.items():
                if key == field:
                    orders.append(desc + val.field_name)
                    break
        return orders

    @handle_parse
    def assign(self):
        """
        Assign base module to
        Create:

        Modify:
            Bulk Data:
                1* directly using ID
            Sole Data:
                1* check filters, if sub.option.assign_from is a subset of filters, assign that sub module
                2* use id to split queryset

        Serialize:
            1* check filters, if sub.option.assign_from is a subset of filters, assign that sub module
            2*
        """
        if self.request.options:
            # do not assign
            return self

        if self.mixins:
            # assign mixin modules
            # based on the filters, it predict that queryset is a mix of above mixin_classes
            if self.adding:
                pass
            elif self.one:
                mixins = []
                for mixin_cls in self.mixins:
                    mixin = mixin_cls(self.request, id=self.pk, auth=self.do_auth, assign=True)
                    if mixin.exist:
                        mixins.append(mixin)
                self._mixins = mixins
            else:
                mixins = []
                for mixin in self._get_mixins():
                    mixins.append(mixin(self.request, auth=self.do_auth, assign=True))
                self._mixins = mixins

        if not self.subs or not self.assignable:
            return self

        if self.bulk:
            if self.bulk.post or self.bulk.replace:
                mod_values = {}
                for d in self.data:
                    if not isinstance(d, dict):
                        continue
                    sub_mod = self.assign_config.get_by(d)
                    if sub_mod in mod_values:
                        mod_values[sub_mod].append(d)
                    else:
                        mod_values[sub_mod] = [d]
                for sub_mod, values in mod_values.items():
                    self._modules.append(sub_mod(request=self.request, data=values, auth=self.do_auth, assign=True))

            else:
                pk_values = {d.get(self.query_pk_name): d for d in self.data}
                for s in self.subs:
                    q = s.filter(pk__in=set(pk_values)).using(self.using)
                    pks = q.pk_list
                    if not pks:
                        continue
                    values = [pk_values[pk] for pk in pks]
                    self._modules.append(s(request=self.request, data=values, auth=self.do_auth, assign=True))

        elif self.one:
            sub_mod = None
            id = None
            if self.adding:
                if isinstance(self.data, dict):
                    sub_mod = self.assign_config.get_by(self.data)
            elif self.abstract or self.assign_config.by_pk:
                for sub in self.subs:
                    if sub.filter(pk=self.pk).exists():
                        sub_mod = sub
                        id = self.pk
                        break
            else:
                id = self.pk
                sub_mod = self.assign_config.from_inst(inst=self.i)
            if sub_mod:
                self._module = sub_mod(request=self.request, id=id, auth=self.do_auth, assign=True).assign()

        elif self.exist:
            sub_mod = self.assign_config.get_by(self.query)
            if sub_mod:
                self._module = sub_mod(request=self.request, auth=self.do_auth, assign=True).assign()
            else:
                pk_list = self.orders
                include_list = []
                for sub in self.subs:
                    sub: Type[Module]
                    q: MetaQuerySet = sub.filter(pk__in=pk_list).using(self.using)
                    pks = q.pk_list
                    if len(pks):
                        include_list += pks
                        self._modules.append(sub(pk_list=pks, request=self.request, auth=self.do_auth, assign=True))
                rest_list = list(set(pk_list).difference(include_list))
                if rest_list:
                    self._modules.append(self.__class__(
                        pk_list=rest_list, request=self.request, assign=False, auth=self.do_auth))

        mod: Module = self
        while mod._module != mod:
            mod = mod._module
        mod._modules = [m.assign() for m in self._modules]
        mod._mixins = [m.assign() for m in self._mixins]

        for m in [mod, *mod._modules, *mod._mixins]:
            if m and inspect.isclass(m) and issubclass(m, Module):
                m.response = self.response
        return mod

    @property
    def user(self) -> Union[Model, Any]:
        return self.request.user

    @property
    def pk(self):
        return self._pk

    @property
    def pk_domain(self):
        if self._pk_domain is None:
            self._pk_domain = self.base_queryset().pk_list
        return self._pk_domain

    @pk_domain.setter
    def pk_domain(self, domain):
        if self._module:
            self._module._pk_domain = domain
        if self._modules:
            for mod in self._modules:
                mod._pk_domain = domain
        self._pk_domain = domain

    @property
    def orders(self) -> list:
        if self._orders is None:
            if not self._altered:
                self.apply_alter()
            self._orders = self.q.pk_list
        return self._orders

    @orders.setter
    def orders(self, orders):
        if not self.abstract:
            self.q = self.base_queryset().filter(pk__in=orders)
            self.q.pk_list = orders
        # set orders after set QuerySet, or refresh() will be triggered
        self._orders = orders

    @property
    def exist(self) -> bool:
        if self._exist is None:
            self._exist = bool(self._orders) \
                if self._orders is not None else bool(self._i) if self._i is not ... else\
                self.q.exists()
        return self._exist

    @property
    def empty(self) -> bool:
        return not self.base_queryset().using(self.using).exists()

    @property
    def total(self) -> int:
        return self.base_queryset().using(self.using).count()

    @property
    def count(self) -> int:
        if self._count is None:
            self._count = len(self._orders) \
                if self._orders is not None else self.q.count()
        return self._count

    @property
    def manager(self) -> MetaQuerySet:
        return self.base_queryset().using(self.using)

    @classmethod
    def all(cls) -> MetaQuerySet:
        return MetaQuerySet(model=cls.model).filter(cls.option.get_base_filter())

    def base_queryset(self) -> MetaQuerySet:
        return self.option.module_queryset_cls(model=self.model).filter(self.option.get_base_filter(self.request))

    @classmethod
    def none(cls) -> MetaQuerySet:
        return cls.all().none()

    @classmethod
    def fetch(cls, pk=None, **kwargs) -> Union[Model, Any]:
        if pk is None:
            pks = cls.filter(**kwargs).pk_list
            if not pks:
                return None
            pk = pks[0]
        return MetaQuerySet(model=cls.model).fetch(pk)

    @classmethod
    def reveal(cls, pk=None, **kwargs) -> Union[Schema, Any]:
        if pk is None:
            pks = cls.filter(**kwargs).pk_list
            if not pks:
                return None
            pk = pks[0]
        values = cls(id=pk).serialize()
        return values[0] if values else None

    @classmethod
    def add(cls, **kwargs):
        return cls.model.objects.create(**kwargs)

    @classmethod
    def exists(cls, *args, **kwargs) -> bool:
        return cls.filter(*args, **kwargs).exists()

    @classmethod
    def find(cls, **kwargs) -> MetaQuerySet:
        q = Q()
        for key, val in kwargs.items():
            q |= Q(**{key: val})
        return cls.filter(q)

    @classmethod
    def filter(cls, *args, **kwargs) -> MetaQuerySet:
        return cls.all().filter(*args, **kwargs)

    def update(self, **kwargs):
        if self.q.query.is_sliced:
            # reconstruct query
            self.orders = self.q.pk_list
        return self.q.update(**kwargs)

    @classmethod
    def execute(cls, *args, **kwargs):
        return cls.all().raw(*args, **kwargs)

    def only(self, fields):
        """
        it act like the QuerySet's only API, but it's Module level
        the further serialization won't serialize the fields, which not only can be model_fields,
        but also can be proxies, relates, it's a wise way to reduce I/O cost at runtime

        also remind, no matter only() or deter(), it's the client's require to reduce the the result,
        so the fields here is aliased, need to be decode if necessary
        """
        if not fields:
            return
        self.only_fields = set(fields if multi(fields) else (fields, )).intersection(self.keys)

    def deter(self, fields):
        if not fields:
            return
        self.deter_fields = set(fields if multi(fields) else (fields, )).intersection(self.keys)

    @handle_parse
    def apply_filters(self, base: MetaQuerySet) -> MetaQuerySet:
        filters = self.filters
        or_only = list(filters.keys()) == [Logic.OR]
        con = Q.OR if or_only else Q.AND
        nested_data: dict = pop(filters, Logic.OR) if or_only else dict(filters)
        orders = []

        def recursive(data, c=Q.AND) -> Q:
            q = Q()
            if isinstance(data, list):
                _c = Q.OR if c == Q.AND else Q.AND
                for val in data:
                    _q = resolve(val, c=_c)
                    if c == Q.AND:
                        q &= _q
                    else:
                        q |= _q
            elif isinstance(data, dict):
                _q = resolve(data, c=c)
                if c == Q.AND:
                    q &= _q
                else:
                    q |= _q
            return q

        def resolve(conditions: dict, c=Q.AND) -> Q:
            range_dict = {}
            q = Q()
            for key, val in conditions.items():
                connect = None
                if key == Logic.OR:
                    connect = Q.OR
                elif key == Logic.AND:
                    connect = Q.AND
                if multi(val):
                    # convert other multi type (set/tuple/dict_keys/dict_values) to list
                    # db backend may not support other type
                    val = list(val)
                if connect:
                    _q = recursive(val, c=connect)
                    if c == Q.AND:
                        q &= _q
                    else:
                        q |= _q
                    continue

                _q = Q()
                query = {}
                field, opt, exclude, _in = Filter.extract(key)
                fil = self.option.get_filter(key)
                if not fil or fil.custom:
                    continue
                if fil.sole:
                    opt = fil.options[0]
                field = fil.field_name
                if fil.value_exp:
                    val = fil.value_exp(val)
                if fil.query_exp:
                    __q = fil.query_exp(val)
                    if isinstance(__q, Q):
                        _q = __q
                elif opt == FilterNote.lte:
                    if field in range_dict:
                        ano = range_dict.pop(field)
                        if ano == val:
                            query = {field: val}
                        elif ano > val:
                            raise ValueError(f'Module query for "{field}" gte: {ano} is larger than lte: {val}')
                        else:
                            query = {field + SEG + "range": (ano, val)}
                    elif field + FilterNote.gte in filters:
                        range_dict[field] = val
                        continue
                elif opt == FilterNote.gte:
                    if field in range_dict:
                        ano = range_dict.pop(field)
                        if ano == val:
                            query = {field: val}
                        elif ano < val:
                            raise ValueError(f'Module query for "{field}" gte: {val} is larger than lte: {ano}')
                        else:
                            query = {field + SEG + "range": (val, ano)}
                    elif field + FilterNote.lte in filters:
                        range_dict[field] = val
                        continue

                if not query and not _q:
                    option = FilterNote.get_option(opt)
                    lookup = f'{field}{SEG}{option}' if option else field
                    if _in:
                        if opt:  # opt is not '' (which is exact in option)
                            for v in val:
                                _q |= Q(**{lookup: v})
                        else:
                            query = {field + SEG + 'in': val}
                            if fil.list_order:
                                orders.append(Case(*[When(**{field: v, 'then': pos}) for pos, v in enumerate(val)]))
                    else:
                        query = {lookup: val}

                if not _q:
                    _q = Q(**query)
                if exclude:
                    _q = ~_q
                if c == Q.AND:
                    q &= _q
                else:
                    q |= _q
            return q

        __q__ = recursive(nested_data, c=con)
        if not isinstance(base, QuerySet):
            return self.base_queryset().filter(__q__).order_by(*orders) if __q__ else self.none()
        return base.filter(__q__).order_by(*orders) if __q__ else base

    def get_param_pk(self):
        if not isinstance(self.filters, dict):
            return None
        # use filters instead of query is because filters can have auth_user_id
        if self.path_param and self.option.path_param_pk:
            return self.path_param
        pk = self.filters.get('id', self.filters.get(self.pk_name))
        if not pk and isinstance(self.data, dict):
            pk = self.data.get('id', self.data.get(self.pk_name))
        if self.request.method == Method.POST:
            if pk:
                raise ValueError('primary_key indicate is not support for POST method')
        return pk

    def apply_alter(self, limit: int = None, offset: int = None,
                    page: int = None, rows: int = None,
                    write: bool = False,
                    attr_only: bool = False):
        """
        There might be queryset alter in before hook, if the page/max slice
        is applied before, the filter (like self.q = self.q.filter(...)) could not be applied
        for the reason that <Cannot filter a query once a slice has been taken.>
        so apply the page/max slice after before_hook and before query executed

        For abstract Module, request params to alter queryset (@page / @limit)
        is not applied because there is no db to run query
        alter will apply here to _order attribute and affect when serialize (in order_list method)
        """

        if attr_only:
            self._altered = True
            return

        if self.option.split_many_relation_query:
            self.q.split_many_relations = True

        if self._altered:
            return

        if self.q.query.is_sliced:
            return

        if not self.q.query.distinct and self.do_distinct:
            # distinct only allow at reading
            self.q = self.q.distinct(*self.option.distinct_by)
            # distinct in case that complex query in before hook will generate duplicate result

        self._altered = True
        _limit = self.query.get(self.option.client_option.limit) if limit is None else limit
        _offset = self.query.get(self.option.client_option.offset) if offset is None else offset
        _page = self.query.get(self.option.client_option.page) if page is None else page
        _rows = self.query.get(self.option.client_option.rows) if rows is None else rows

        if {_limit, _offset, _page} == {None}:
            return

        pager = self.page or Page()
        if self.abstract:
            if self.query_count is None:
                self.query_count = len(self._orders)

            if _page:
                self.orders = pager(self._orders, _rows, _page)
            elif _offset:
                self.orders = pager.offset(self._orders, _offset, _limit)
            elif _limit:
                self.orders = self._orders[:_limit]
            return
        # apply @page / @limit to multiple sub _modules and abstract Module'
        if self.query_count is None:
            self.query_count = self.q.count()

        if _page:
            self.q = pager(self.q, _rows, _page)
        elif _offset:
            self.q = pager.offset(self.q, _offset, _limit)
        elif _limit:
            self.q = self.q[:_limit]

        if write:
            # update METHODS not support slice
            # so alter the queryset to directly filter pk
            self.orders = self.q.pk_list

    @classmethod
    @handle_parse
    def modular(cls, request: Request):
        if cls.combined:
            return cls(request=request)
        if cls.abstract:
            module = cls(request=request)
            pk_list = []
            modules = []
            if not cls.subs:
                raise NotImplementedError(f"Abstract Module {cls} without inherit")
            for sub in cls.subs:
                sub: cls
                mod = sub.modular(request)
                if mod.exist:
                    pk_list += mod.orders
                    modules.append(mod)
            pk_list = distinct(pk_list)
            # set _orders for serialize order_list
            module._orders = pk_list
            module._modules = modules
            module.apply_alter()
            # not assign here for abstract Module
            return module
        return cls(request=request, queryset=cls.filter(cls.option.get_base_filter(request))).assign()

    def options(self):
        return self.request.options_response()

    @classonlymethod
    def serve(cls, api) -> Response.base:
        from utilmeta.core.api import API
        api: API
        request = cls.option.process_request(api.request)
        if api.module is not cls:
            request.allow_methods = cls.methods
        # module initialize -----------
        module = cls.modular(request)
        if request.options:
            return module.options()
        module.response = api.response
        # get dispatched result --------
        result = module()
        # ------------------------------
        return module.response(
            result=result,
            message=module.message,
            status=module.status,
            state=module.state,
            count=module.query_count,
            headers=module.cache.headers if module.cache else None
        )

    def not_modified(self):
        """
        For get: valid if-modified-since header to generate a not-modified response
        For put/patch: valid the if-match condition header if option.valid_match
        """
        if not self.cache:
            return False
        if self.m in (M.POST, M.DELETE):
            return False
        if self.reading:
            if not self.option.client_cache:
                return False
            self.cache.counter.requests += 1
            if self.option.etag_cache:
                # valid etag instead of last-modified
                return False
        elif not self.option.valid_match:
            return False

        from .schema import SchemaMeta
        from utilmeta.util.common import ignore_errors

        @ignore_errors(default=dict)
        def get_field_domain(domain: dict, schema=self.schema, model=self.model):
            relate_domain = {}
            for key, val in domain.items():
                field: Field = getattr(schema, key, None)
                if not isinstance(field, Field):
                    continue
                name = field.name
                if not name:
                    continue
                dom = relate_domain
                try:
                    mod = get_field(model, name, cascade=True).related_model
                except FieldDoesNotExist:
                    mod = None
                if SEG not in name and not mod:
                    continue
                *lookups, target = name.split(SEG)
                for s in lookups:
                    dom.setdefault(s, {})
                    dom = dom[s]
                if mod:
                    temp = SchemaMeta.__retrieve__(schema.__template__.get(key), schema=True)
                    if isinstance(temp, tuple):
                        # handled by multi-inherit modules, leave None on the domain
                        dom[target] = {}
                        for t in temp:
                            dom[target].update(get_field_domain(domain=val, model=mod, schema=t))
                    elif temp and val:
                        dom[target] = get_field_domain(domain=val, model=mod, schema=temp)
                    else:
                        dom.setdefault(target, None)
            return relate_domain

        field_domain = get_field_domain(self.query_domain or self.schema.__scope__) if self.reading else {}
        self.cache.last_modified = self.q.last_modified(domain=field_domain, seq=not self.pk)
        not_modified = self.cache.not_modified
        if self.reading:
            if not_modified:
                self.cache.counter.not_mods += 1
                self.status = 304
        else:
            self.cache.check_precondition()
            if not not_modified:
                raise exc.PreconditionFailed()
        return not_modified
        # if put/patch and not_modified, return None instead to continue modify
        # (return True in case of get will directly return a 304 response)

    @handle_parse
    def _gen_schema_data(self) -> Optional[Union[List[dict], dict]]:
        if self._schema_data is not None:
            return self._schema_data
        if not self.parser:
            return self.data
        if not isinstance(self.data, (list, dict)):
            return None

        processed_data = self.data
        # schema = self.request_schemas.get(self.m)
        schema = self.parser.data_schema
        if not schema:
            from .schema import ArbitrarySchema
            try:
                data = self.schema(processed_data)
            except COMMON_ERRORS:
                data = ArbitrarySchema(processed_data)
        elif isinstance(processed_data, list):
            data = [schema(**d) for d in processed_data]
            if self.m not in self.batch:
                data = data[0]
        else:
            data = schema(**processed_data)
            if self.m in self.batch:
                data = [data]

        self._schema_data = data
        return data

    def _apply_transaction(self):
        from django.db.transaction import atomic

        class _AtomicContext:
            def __init__(self, *aliases: str):
                self.contexts = [atomic(using=alias) for alias in aliases]

            def __enter__(self):
                for context in self.contexts:
                    context.__enter__()

            def __exit__(self, exc_type, exc_val, exc_tb):
                for context in self.contexts:
                    context.__exit__(exc_type, exc_val, exc_tb)

        return _AtomicContext(*self.method.get_transaction_using(self.m))

    def make_kwargs(self, kwargs: dict, parser: ModuleParser, result=None, error=None):
        if not isinstance(kwargs, dict):
            kwargs = {}
        if parser.instance_key:
            if not self.one or not self.instance:
                raise exc.NotFound
            kwargs[parser.instance_key] = self.instance
        if parser.body_key:
            kwargs[parser.body_key] = self.data
        if parser.query_key:
            kwargs[parser.query_key] = self.query
        if parser.result_key:
            kwargs[parser.result_key] = result
        if parser.error_key:
            kwargs[parser.error_key] = error
        return kwargs

    def __call__(self):
        key = self.route or self.m
        if key not in self._resolver:
            if self.route:
                return exc.NotFound(path=self.request.path)
            else:
                raise exc.MethodNotAllowed(method=self.m, allows=self.methods)

        values = self._resolver[key]
        if isinstance(values, tuple):
            units: RESOLVER_TUPLE_TYPE = values
        else:
            self.request.allow_methods = list(values)
            if self.m not in values:
                raise exc.MethodNotAllowed(
                    method=self.m,
                    allows=self.request.allow_methods
                )
            units: RESOLVER_TUPLE_TYPE = values[self.m]

        handler, before_hooks, after_hooks, error_hooks = units

        try:
            if self.not_modified():
                self.request.cached = True
                return None

            self.data = self._gen_schema_data()
            main_pk = None
            self.options()
            with self._apply_transaction():
                # cross hook contexts
                for before_hook in before_hooks:
                    args, kwargs = before_hook.parser.parse_request(request=self.request)
                    # convert the request data to Schema to apply the before hook
                    before_hook(self, *args, **self.make_kwargs(kwargs, parser=before_hook.parser))

                if isinstance(handler, Unit):
                    if self.request.from_api or not handler.inner:
                        # only request from API (already wrapped a HttpRequest) need to parse
                        # other related Module don't need parse
                        # (which will cause error since the request Model is not this related Module)
                        # only non-inner (user-defined) METHODS need to parse args/kwargs
                        self.args, self.kwargs = handler.parser.parse_request(request=self.request)

                    self.validate()
                    result = handler(self, *self.args, **self.make_kwargs(self.kwargs, parser=handler.parser))
                    if self.adding:
                        main_pk = self.pk

                else:
                    if handler in self.modules:
                        # module handler
                        module = handler(
                            **self._original_kwargs  # use original kwargs instead of processed data
                        )
                    else:
                        rel = self._route_reverse.get(key)
                        extra = None
                        if rel and self.extra_query:
                            extra = {}
                            for key, val in self.extra_query.items():
                                if key in (ID, PK):
                                    extra[key] = val
                                else:
                                    extra[f'{rel}{SEG}{key}'] = val

                        module = handler(request=self.request, filters=extra)

                    result = module()

                    if self.adding and issubclass(module.model, self.model):
                        main_pk = getattr(module, PK)

                    self.query_count = module.query_count
                    self.status = module.status
                    self.state = module.state
                    self.message = module.message
                    self.response = module.response

                for after_hook in after_hooks:
                    try:
                        kwargs = self.make_kwargs({}, parser=after_hook.parser, result=result)
                    except exc.NotFound:
                        # skip if key spec is not satisfied
                        continue
                    result = after_hook(self, **kwargs) or result

            if self._mixins and not self.deleting:
                if self.reading:
                    pks = [val[self.query_pk_name] for val in result]
                else:
                    pks = self.orders
                removes = []
                for mixin in self._mixins:
                    if self.adding and main_pk:
                        mixin.data[mixin.pk_name] = main_pk
                    mixin._altered = True
                    mixin.q = mixin.filter(pk__in=pks)
                    mix_result = mixin()

                    if self.reading and result:
                        # result_map = {val[self.pk_name]: val for val in result}
                        if isinstance(mix_result, dict):
                            mix_map = {str(mix_result[mixin.query_pk_name]): mix_result}
                        elif isinstance(mix_result, list):
                            mix_map = {str(val[mixin.query_pk_name]): val for val in mix_result}
                        else:
                            continue

                        for i, val in enumerate(result):
                            if i in removes:
                                continue
                            pk = str(val[self.query_pk_name])
                            mix_data = mix_map.get(pk)
                            if not isinstance(mix_data, dict):
                                # incomplete mixin result
                                if self.option.discard_incomplete_mixin:
                                    removes.append(i)
                                continue
                            val.update(mix_data)

                if removes:
                    result = [val for i, val in enumerate(result) if i not in removes]

            result = self.process_result(result)

        except Exception as e:
            error = Error(e)
            hook: Unit = error.get_hook(error_hooks)
            if isinstance(handler, Unit):
                handler.request.record_error()
            if not hook:
                exc_type = type(e)
                if isinstance(e, exc.IntegrityError):
                    exc_type = exc.BadRequest
                raise error.throw(exc_type)
            self.status = error.log(self.log)
            result = hook(self, **self.make_kwargs({}, parser=hook.parser, error=error))
        return result

    def serialize(self) -> List[Union[Schema, Any]]:
        self.parse_params()
        self.apply_alter()
        if self.q.get_cache():
            self.request.cached = True
        if self.non_result:
            return []
        if self._modules:
            result = []
            for module in self._modules:
                module.referring = True
                r = module()
                if isinstance(r, list):
                    result += r
                else:
                    result.append(r)
            if self.abstract:
                # when Module is abstract, the order could not apply to DB query
                # so order it when result is serialized
                # order_list will apply the @page / @limit params to abstract Module
                self.query_count = len(result)
                result.sort(key=self.option.order_function)
            # use original orders to sort abstract module results
            return order_list(result, self.orders, by=self.pk_name)
        return self.schema_query(self.q, request=self.request, domain=self.query_domain)

    def modify(self):
        # self.process()
        self.apply_alter(write=True)
        self.process_data()
        if self._modules:
            for module in self._modules:
                module()
            return
        if not self.data:
            return
        data, relates, updates = self._fetch_relates(self.data)
        if self.bulk:
            if data:
                data: list
                self.q = self.bulk(data, query=True, domain=self.pk_domain, using=self.using)
        elif not isinstance(data, dict):
            raise ValueError(f'Bulk data not allowed in current method: {self.m}')
        else:
            if not self.exist:
                raise exc.NotFound(query=self.filters)
            data: dict
            self.q.update(**data)
        self._update_relation(relates=relates, updates=updates)

    def create(self):
        # self.process()
        self.process_data()
        if self._modules:
            for module in self._modules:
                module()
            return
        if not self.data:
            return
        data, relates, updates = self._fetch_relates(self.data)
        result = None
        if self.bulk:
            if data:
                data: list
                self.q = self.bulk(data, query=True, using=self.using)
                result = self.q.pk_list
        elif not isinstance(data, dict):
            raise ValueError(f'Bulk data not allowed in current method: {self.m}')
        else:
            data: dict
            instance = self.manager.create(**data)
            self._i = instance
            result = instance.pk
            self.q = self.base_queryset().filter(pk=instance.pk)
        self._update_relation(relates=relates, updates=updates)
        return result

    def _clear_data(self):
        if self.option.order_option and self.option.order_option.model_order_strict:
            key = self.option.order_option.model_order_key
            field = self.option.order_option.field
            start = self.option.order_option.model_order_start
            query = self.base_queryset().exclude(pk__in=self.orders)
            if key:
                keys = list(self.q.values_list(key, flat=True))
                for val in keys:
                    q = query.filter(**{key: val})
                    when_list = [When(pk=pk, then=start + pos) for pos, pk
                                 in enumerate(list(q.order_by(field).values_list('pk', flat=True)))]
                    q.update(**{field: Case(*when_list)})
            else:
                when_list = [When(pk=pk, then=start + pos) for pos, pk
                             in enumerate(list(self.base_queryset().exclude(pk__in=self.orders)
                                               .order_by(field).values_list('pk', flat=True)))]
                query.update(**{field: Case(*when_list)})

    def remove(self):
        self.apply_alter()
        if not self.exists():
            raise exc.NotFound(query=self.filters)
        self._clear_data()
        self.q.delete()
        self.q = self.none()

    @property
    @handle_parse
    def query_domain(self) -> Optional[dict]:
        domain = self.schema.__scope__
        pops = []
        for f in tuple(domain.keys()):
            if self.only_fields and f not in self.only_fields:
                pops.append(domain.pop(f))
                continue
            if self.deter_fields and f in self.deter_fields:
                pops.append(domain.pop(f))
                continue
            field = self.schema.__data__.get(f)
            if isinstance(field, Field):
                if field.read_auth:
                    try:
                        field.read_auth(request=self.request, resource=self.q)
                    except exc.PermissionDenied:
                        pops.append(domain.pop(f))

        if self.query_temp:
            def reduce_dict(data: dict, temp: dict):
                if not temp:
                    return
                for k in tuple(data.keys()):
                    if k not in temp:
                        data.pop(k)
                        continue
                    item, unit = data[k], temp[k]
                    if isinstance(item, dict) and isinstance(unit, dict):
                        reduce_dict(item, unit)
                        continue

            reduce_dict(domain, self.query_temp)
        elif not pops:
            return None
        if self.relative_key:
            # relative key should always in domain if specified
            domain.setdefault(self.relative_key, None)
        return self.write_alias(domain)

    # def handle_page_cases(self):
    #     """
    #     paging results need to handle cases in relation pages
    #     such as query follows of a account with paging
    #     usually request like
    #      GET /api/account?id=1&@field=follows&follows@page=1&follows@rows=20
    #     as for only one dict result is returned (?id) and only one field is returned
    #     so follows@... can be simplify like  GET /api/account/1/follows?@page=1&@rows=20
    #     if the many-to relation is only paged (not filtered or ordered in query)
    #     this will be a trivial case that can be paged in cache using list slice and lrange in redis
    #     which will save lot of performance when relations scale is ex-large
    #     """
    #     pass

    def _make_relate_request(self, field: str) -> Request:
        params = {}
        field = self.read_alias(field)    # get aliased key
        for key, val in self.query.items():
            if key.startswith(field + '@'):
                params[key[len(field):]] = val
                # field key should contains "@"
            elif key.startswith(field + '.'):
                params[key[len(field) + 1:]] = val
        _template: dict = self.query.get(self.option.client_option.template, {}).get(field)
        if isinstance(_template, dict):
            params[self.option.client_option.template] = _template
        return Request.custom(
            method=M.GET, query=params,
            headers=self.request.headers,
            user_id=self.user_id,
            admin=self.request.admin
        )

    def _update_relation(self, relates: Union[list, dict], updates: Union[list, dict]):
        """
        1. update all ManyToMany relates for each object
        2. Integrate all intermediate data to a ( model -> [data] ) mapping,
        and bulk create/update them at once to reduce the database queries
        """
        if not relates and not updates:
            return
        related_updates = {}
        updated_relates = {}
        cache = self.q.get_cache()
        for i, obj in enumerate(self.q):
            rel: Dict[str, List[dict]] = relates if isinstance(relates, dict) else relates[i]
            upt: Dict[str, List[dict]] = updates if isinstance(updates, dict) else updates[i]

            for key, val in upt.items():
                field = get_field(self.model, key)
                module_class = self.related_modules.get(key)
                if not module_class:
                    continue
                for v in val:
                    v[add_field_id(field.remote_field.name)] \
                        = v[del_field_id(field.remote_field.name)] = obj.pk
                if self.replacing:
                    # if bulk is replace, the data is independent with others and need to
                    # define a domain for each data
                    # elsewhere the data can be merged and execute at once
                    module: Module = module_class(self.request, data=val, query={}).assign()
                    # set query to {} to prevent unexpected ExcessError
                    module.pk_domain = cache.get_relates(pk=obj.pk, field=key) \
                        if cache else list(getattr(obj, key).values_list('pk', flat=True))
                    if val:
                        module()
                    else:
                        # replace and no values means delete
                        module.filter(pk__in=module.pk_domain).delete()
                elif not val:
                    # when not replacing, no values simply means do nothing
                    continue
                else:
                    if module_class not in related_updates:
                        related_updates[module_class] = val
                    else:
                        related_updates[module_class] += val

            for key, val in rel.items():
                if key in updated_relates:
                    updated_relates[key][obj] = val
                else:
                    updated_relates[key] = {obj: val}

        for module_class, data in related_updates.items():
            module_class(self.request, data=data, query={})()

        self.q.set_relates(updated_relates)

    @handle_parse
    def _fetch_relates(self, data):
        values = {}
        relates = {}
        updates = {}
        if isinstance(data, list):
            values = []
            relates = []
            updates = []
            for d in data:
                v, r, c = self._fetch_relates(d)
                values.append(v)
                relates.append(r)
                updates.append(c)
        elif isinstance(data, dict):
            for key, val in data.items():
                try:
                    field = get_field(self.model, key)
                except FieldDoesNotExist:
                    continue
                if one_to(field):
                    if not isinstance(val, dict):
                        # probably be fk value
                        values[add_field_id(key)] = val
                    else:
                        # maybe key: <object>
                        fk_value = val.get(PK, val.get(ID))
                        if fk_value is not None:
                            # only set values when fk is presented
                            values[add_field_id(key)] = fk_value
                elif isinstance(field, ManyToOneRel):
                    if isinstance(val, list):
                        updates[key] = val
                elif many_to(field):
                    if not isinstance(val, list):
                        val = [val]
                    relates[key] = val
                else:
                    values[key] = val

            if self.extra_query:
                # from prepend routes
                extra = {}
                for key, val in self.extra_query.items():
                    key: str
                    name, *lookups = key.split(SEG)
                    if name in values:
                        continue
                    try:
                        field = get_field(self.model, name)
                    except FieldDoesNotExist:
                        continue
                    if one_to(field) and add_field_id(name) in values:
                        continue
                    if not field.related_model:
                        if lookups:
                            continue
                        values[name] = val
                        continue
                    if not one_to(field):
                        continue
                    if not lookups:
                        # pk
                        values[add_field_id(name)] = val
                        continue

                    lookup = SEG.join(lookups)
                    if field in extra:
                        extra[field].update({lookup: val})
                    else:
                        extra[field] = {lookup: val}

                for field, query in extra.items():
                    if field.name in values or add_field_id(field.name) in values:
                        continue

                    inst = MetaQuerySet(model=field.related_model).filter(**query).first()

                    if inst:
                        values[field.name] = inst

        return values, relates, updates

    # -- METHODS
    def get(self, *_, **__):
        return self.serialize()

    def post(self, *_, **__):
        return self.create()

    def put(self, *_, **__):
        return self.modify()

    def patch(self, *_, **__):
        return self.modify()

    def delete(self, *_, **__):
        return self.remove()

    setattr(get, Attr.INNER, True)
    setattr(post, Attr.INNER, True)
    setattr(put, Attr.INNER, True)
    setattr(patch, Attr.INNER, True)
    setattr(delete, Attr.INNER, True)

    def process_result(self, result):
        if not self.reading or self.bypass or self.referring or not self.unit:   # bypass if used in a parent module
            return result
        if self.non_result:
            return None
        _field: str = self.sole_field
        if self.one:
            if not result:
                self.query_count = 0
                raise exc.NotFound(query=self.filters)
            if multi(result):
                result = result[0]
                self.query_count = 1
            if isinstance(result, dict) and _field:
                result = result.get(_field)
        elif multi(result):
            if self.query_count is None:
                self.query_count = len(result)

            if self.option.order_by_result or self.q.order_required:
                result.sort(key=self.option.order_function)

            def process_result(res):
                if _field:
                    field_values = []
                    for r in res:
                        if isinstance(r, dict):
                            field_values.append(r.get(_field))
                    return field_values
                elif self.dataframe_depth:
                    return convert_data_frame(res, depth=self.dataframe_depth, keys=list(self.get_expect_fields()))
                return res

            if self.relative_key:
                result = {key: process_result(val) for key, val
                          in make_dict_by(result, key=self.relative_key).items()}
            else:
                result = process_result(result)

        if self.cache and self.option.etag_cache:
            self.cache.etag = result
            # request.cache.etag.setter will add etag() transform to result
            # whether or not request has If-None-Match headers
            # calculate etag add to response headers

            if self.cache.not_modified:
                self.cache.counter.not_mods += 1
                self.status = 304
                return None
        return result
