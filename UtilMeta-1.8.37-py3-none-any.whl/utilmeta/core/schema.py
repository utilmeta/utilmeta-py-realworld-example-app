import inspect
from django.db.models.expressions import BaseExpression
from utilmeta.util.rule import Rule, Bound, BaseParam
from utilmeta.util.field import Field
from utilmeta.util.base import Util
from utilmeta.util.parser import Alias, Options, AbsenceError, ExcessError
from utilmeta.util.common import COMMON_TYPES, SEG, multi, COMMON_ERRORS, distinct, Attr
from typing import TypeVar, List, Union, Dict, Any, Type
from functools import wraps

T = TypeVar('T')
__all__ = ['Schema', 'SchemaMeta', 'ArbitrarySchema']


class SchemaMeta(type, Util):
    def __setattr__(cls, key, value):
        if cls.__dict__.get(Attr.LOCK):
            raise AttributeError(f'{cls.__name__}(Schema) is readonly and'
                                 f' cannot be set attribute ({key} -> {repr(value)}) during runtime')
        return super().__setattr__(key, value)

    def __delattr__(cls, item):
        if cls.__dict__.get(Attr.LOCK):
            raise AttributeError(f'{cls.__name__}(Schema) is readonly and'
                                 f' cannot be delete attribute ({item}) during runtime')
        return super().__delattr__(item)

    @classmethod
    def __retrieve__(mcs, t, data=False, schema=False, _dict=False) \
            -> Union[dict, Type['Schema'], 'Schema', 'SchemaMeta', tuple, None]:
        from utilmeta.conf import config
        if hasattr(t, Attr.ORIGIN):
            t = config.preference.base_parser_cls.parse_type(t)
        if _dict:
            if isinstance(t, dict):
                return t
        if schema:
            if isinstance(t, Schema):
                return t
        if isinstance(t, mcs):
            if schema:
                return t
            return t.__data__ if data else t.__template__
        elif isinstance(t, list):
            if t:
                return mcs.__retrieve__(t[0], data, schema, _dict)
        elif isinstance(t, tuple):
            schemas = []
            for item in t:
                r = mcs.__retrieve__(item, data, schema, _dict)
                if r:
                    schemas.append(r)
            if len(schemas) == 1:
                return schemas[0]
            return tuple(schemas) or None
        elif isinstance(t, Rule):
            if Bound.template in t:
                return mcs.__retrieve__(t[Bound.template], data, schema, _dict)
            if Bound.type_union in t:
                return mcs.__retrieve__(t[Bound.type_union], data, schema, _dict)
        elif schema:
            return None
        elif isinstance(t, dict):
            return dict(t)
        return None

    def __reproduce__(cls, optional=False, from_query: bool = False,
                      name: str = None, for_read: bool = False, with_properties: bool = True,
                      template: dict = None, assign_template: bool = False, no_default: bool = False,
                      with_rules: bool = True, options: Options = None, updates: dict = None) -> 'SchemaMeta':
        def parse_attrs(data):
            if isinstance(data, SchemaMeta):
                return data.__reproduce__(optional=optional, with_rules=with_rules, no_default=no_default,
                                          options=options, from_query=from_query)
            if multi(data):
                return type(data)([parse_attrs(val) for val in data])
            if isinstance(data, Rule):
                kwargs = data.rules
                if Bound.template in kwargs:
                    kwargs[Bound.template] = parse_attrs(kwargs[Bound.template])
                if Bound.type_union in kwargs:
                    kwargs[Bound.type_union] = parse_attrs(kwargs[Bound.type_union])
                return Rule(**kwargs)
            return data

        def gen_attrs(data):
            attrs = dict(cls.__methods__)
            exc_keys = []
            for key, val in cls.__data__.items():
                if isinstance(val, Rule):
                    continue
                if from_query:
                    if isinstance(val, Field) and val.writeonly:
                        val = val.copy_for_query()        # writeonly field will be retain=False when query
                elif isinstance(val, property):
                    if not with_properties:
                        continue
                elif key not in data:
                    continue
                if isinstance(val, COMMON_TYPES) or val in COMMON_TYPES or inspect.isfunction(val) and no_default:
                    continue
                if for_read:
                    if isinstance(val, Field):
                        if not val.retain or val.writeonly:
                            exc_keys.append(key)
                            continue
                attrs[key] = val

            if options:
                # should merge class options
                attrs[Attr.OPTIONS] = cls.__options__._merge(options)
            else:
                attrs[Attr.OPTIONS] = cls.__options__.__copy__()
            if not isinstance(data, dict):
                return attrs

            annotates = {}
            for key, val in data.items():
                if key in exc_keys:
                    continue

                val = parse_attrs(val)
                if not with_rules:
                    val = Rule.rid(val)
                attr = key
                if isinstance(val, Rule):
                    if val.attname:
                        attr = val.attname
                if optional:
                    # after rid so that optional can apply
                    val = Rule.optional(val, no_default=no_default)
                annotates[attr] = val

            if updates:
                annotates.update(updates)
            attrs[Attr.ANNOTATES] = annotates
            attrs[Attr.ORIGIN] = getattr(cls, Attr.ORIGIN, None) or cls
            attrs[Attr.LOCK] = False
            return attrs
        schema = SchemaMeta(name or cls.__name__, (Schema,), gen_attrs(template or cls.__template__))
        if template and assign_template:
            schema.__template__ = schema.__parser__.template = template
        return schema

    @property
    def __scope__(cls) -> dict:
        scope = {}
        for key, unit in cls.__template__.items():
            schema = cls.__retrieve__(unit, schema=True)
            if isinstance(schema, tuple):
                scp = {}
                for s in schema:
                    scp.update(s.__scope__)
                scope[key] = scp
            elif schema:
                scope[key] = schema.__scope__
            else:
                scope[key] = None
        return scope

    def __json__(cls) -> dict:
        return Rule.note(cls)

    def __from_dict__(cls: T, schema: dict) -> T:
        attrs = {}
        for key, val in schema.items():
            value = None
            if isinstance(val, dict):
                pass
            elif multi(val):
                pass
            elif val is None:
                value = Rule()
            attrs[key] = value
        return SchemaMeta('_GeneratedSchema', (cls,), attrs)

    def __new__(mcs, name, bases: tuple, attrs: dict, **kwargs):
        if bases == (dict,):
            # cls.__locked__ = True   # lock the base Schema
            return super().__new__(mcs, name, bases, attrs)

        def default_init(*_, **__):
            return Schema.__init__(*_, **__)

        def wrap_init(func):
            """
            A required argument of init function cannot be ommited (require=False, no defaults) in Schema
            """
            @wraps(func)
            def wrapper(self, *_, **__):
                return Schema.__init__(self, *_, **__)
                # try:
                #     data = __
                #     if not __ and len(_) == 1 and isinstance(_[0], dict):
                #         data = _[0]
                #     return Schema
                #     return func(self, **self.__parser__(data))
                # except TypeError as e:
                #     if str(e) == 'super(type, obj): obj must be an instance or subtype of type':
                #         # module reload caused identity unmatched
                #         return Schema.__init__(self, *_, **__)
                #     raise e
            return wrapper

        __init = attrs.get(Attr.INIT)

        if __init:
            attrs[Attr.INIT] = wrap_init(__init)
        else:
            # if a schema class does not define __init__ but it parents defines
            # initialize of the schema class will invoke parents's __init__ before Schema.__init__
            # based on the init params of parents, result will be unpredictable
            # most likely to cause AbsenceError
            # so use default init instead
            attrs[Attr.INIT] = default_init
        return super().__new__(mcs, name, bases, attrs)

    def __init__(cls, name, bases: tuple, attrs: dict, **kwargs):
        type.__init__(cls, name, bases, attrs)
        Util.__init__(cls, locals())

        if bases == (dict,):
            # cls.__locked__ = True   # lock the base Schema
            return
        try:
            del cls.__locked__
        except AttributeError:
            pass

        isolate = bool(kwargs.get('isolate'))
        dependency = {}
        data = {}
        methods = {}

        for base in bases:
            if issubclass(base, Schema):
                data.update(base.__data__)
            if base is Schema:
                continue
            for k, v in base.__dict__.items():
                if inspect.isfunction(v) or inspect.ismethod(v):
                    methods[k] = v

        valid_options = [key for key in Schema.__options__.__dict__
                         if not (key.startswith(SEG) or key.endswith(SEG))]

        from utilmeta.conf import config
        __options__ = attrs.get(Attr.OPTIONS) or config.preference.base_parser_options or getattr(cls, Attr.OPTIONS)
        # get from base

        if inspect.isclass(__options__):
            assert issubclass(__options__, Options), \
                f'Schema __options__ class must inherit from Schema.Options, got {__options__}'
            __options__ = Options(**{key: val for
                                     key, val in __options__.__dict__.items() if key in valid_options})
        elif __options__:
            assert isinstance(__options__, Options), \
                f'Schema __options__ instance must be Schema.Options object, got {__options__}'
            __options__ = __options__.__copy__()

        parser = __options__.class_parser_cls(cls, options=__options__)

        for key, val in attrs.items():
            if key.startswith('_'):
                if isinstance(val, (Rule, Field, BaseExpression)):
                    raise ValueError(f'Schema key: {repr(key)} should not startswith "_" '
                                     f'to make sure property access is not protected, \n'
                                     f'if you need actual field key startswith "_", use Rule(alias={repr(key)})')
                if not hasattr(Schema, key):
                    continue
            if inspect.isfunction(val) or inspect.ismethod(val):
                methods[key] = val
                continue
            if key.startswith('_'):
                continue
            if isinstance(val, property):
                bounds = inspect.getclosurevars(val.fget).unbound
                depends = []
                for b in bounds:
                    if b not in parser.template:
                        continue
                    depends.append(b)
                dependency[key] = depends
            data[key] = val

        for key, unit in parser.template.items():
            name = parser.attr_alias(key)
            if hasattr(dict, name):
                raise AttributeError(f"Schema key: {repr(name)} is an attribute of dict, "
                                     f"please change the name and use Rule(alias={repr(name)})")
            item = data.get(name)
            if inspect.isclass(item) and key == item.__name__:
                continue
            elif isinstance(item, property):
                continue
            if isinstance(item, Field):
                if not item.require:
                    unit = Rule.optional(unit)
                item.attname = name
            else:
                setattr(cls, name, Field.reproduce(attname=name, origin=item,
                                                   rule=unit if isinstance(unit, Rule) else None))

        cls.__methods__ = methods
        cls.__options__ = __options__
        cls.__parser__ = parser
        cls.__template__: Dict[str, Any] = parser.template
        cls.__data__: Dict[str, Any] = data
        cls.__keys__: List[str] = distinct(list(cls.__template__) + list(cls.__data__))
        cls.__dependency__: dict = dependency
        cls.__alias__ = parser.alias
        cls.__attr_alias__ = parser.attr_alias
        cls.__isolate__ = isolate

        if kwargs.get('register'):
            cls.__register__()

        for key, val in cls.__dict__.items():
            if isinstance(val, Util):
                val._make_path(f'{cls.__declare_path__}.{key}')

        # cls.__slots__ = tuple(set(cls.__data__).union(cls.__methods__))

        # Rule alias will replace the key in the dict data, but the attribute
        # stay the same, usually used in case that the key is not a valid variable
        # or key is the property of dict
        #
        # class Example(Schema):
        #    value_list = Rule(alias='values')
        #    page_set = Rule(alias='@page')
        #
        # >>> example = Example({'values': [1,2], '@page': 1})
        # >>> example.value_list
        # >>> [1,2]
        # >>> dict(example)
        # >>> {'values': [1,2], '@page': 1}

    def __register__(cls):
        from utilmeta.conf import config
        config.app.register(cls.__declare_path__, cls=cls)

    def __contains__(self, item):
        return item in self.__template__

    def __getitem__(self, item):
        return self.__data__.__getitem__(item)


class Schema(dict, metaclass=SchemaMeta):
    def __init_subclass__(cls, isolate: bool = False, register: bool = False):
        try:
            cls.__isolate__ = isolate
        except AttributeError:
            pass

    Options = Options

    __origin__ = None
    __options__ = Options()
    __template__: Dict[str, Any] = {}
    __data__: Dict[str, Any] = {}
    __dependency__: Dict[str, Any] = {}
    __alias__ = Alias([])
    __attr_alias__ = Alias([])

    def __validate__(self):
        pass

    def __init__(self, *args, **kwargs):
        super().__setattr__(Attr.NAME, self.__class__.__name__)
        data = args[0] if args else kwargs

        if isinstance(data, Schema):
            data = dict(data)
        elif isinstance(data, dict):
            pass
        elif isinstance(data, (type, object)):
            data = data.__dict__
        else:
            raise TypeError(f'{self.__class__.__name__}: Invalid schema data: {data}')

        super().__init__(self.__parser__(data))

        for name, val in self.__data__.items():
            key = self.__alias__(name)
            if isinstance(val, property):
                if name in self.__parser__.exclude_properties:
                    # exclude properties does not calculate value when initialized
                    continue
                if key in self.__dependency__:
                    if set(self.__dependency__[key]).difference(self):
                        continue
                try:
                    super().__setitem__(key, getattr(self, name))
                except COMMON_ERRORS as e:
                    print(f'{self.__class__.__name__} calculate property: <{name}> failed with error: {e}')
                    continue

        self.__validate__()
        # pop retain=False attribute after self-defined validation
        for name, val in self.__data__.items():
            key = self.__alias__(name)
            if isinstance(val, Field) and not val.retain:
                # only delete item, reserve the attribute
                if key in self:
                    super().__delitem__(key)

    def __str__(self):
        items = []
        for key, val in self.items():
            name = self.__attr_alias__(key)
            items.append(f'{name}={repr(val)}')
        values = ', '.join(items)
        return f'{self.__class__.__name__}({values})'

    def __repr__(self):
        return self.__str__()

    def __parse_value__(self, key, value):
        if isinstance(value, (BaseExpression, property)):
            return ...
        if isinstance(value, BaseParam):
            # in function such as arg: str = Rule(length=3)
            # if arg is not pass the arg param will use default Rule(length=3), check if it's required
            if value.require:
                raise AbsenceError(f'{self.__class__.__name__} data key [{repr(key)}] is required')
            return ...

        if key not in self.__template__:
            if not self.__options__.allow_excess:
                raise ExcessError(f'{self.__class__.__name__} data key [{repr(key)}] excess the template, '
                                  f'which configured not allowed in {self.__name__}')
            if not self.__options__.excess_preserve:
                return ...
        else:
            from utilmeta.conf import config
            value = config.preference.base_parser_cls.parse(data=value, template=self.__template__[key])
        return value

    def __setitem__(self, alias: str, value):
        name = self.__attr_alias__(alias)
        key = self.__alias__(alias)
        attr = self.__data__.get(name)
        value = self.__parse_value__(key=key, value=value)
        if value is ...:
            return
        if not hasattr(Schema, name):
            super().__setattr__(name, value)
        if isinstance(attr, property) and attr.fset:
            value = getattr(self, name)
        super().__setitem__(key, value)

    def __setattr__(self, alias: str, value):
        name = self.__attr_alias__(alias)
        key = self.__alias__(alias)
        attr = self.__data__.get(name)

        if hasattr(Schema, name):
            # do not block up layer setter
            return super().__setattr__(name, value)
            # raise AttributeError(f'Schema attr: {repr(alias)} is readonly')

        value = self.__parse_value__(key=key, value=value)
        if value is ...:
            return
        super().__setattr__(name, value)
        if isinstance(attr, property) and attr.fset:
            value = getattr(self, name)
        super().__setitem__(key, value)

    def __delitem__(self, alias: str):
        name = self.__attr_alias__(alias)
        key = self.__alias__(alias)
        rule = self.__template__.get(key)
        if isinstance(rule, Rule) and not rule.require or self.__options__.schema_allow_delete_required:
            super().__delitem__(key)
            super().__delattr__(name)
        else:
            raise AttributeError(f'{self.__class__.__name__}: Attempt to delete required schema key: {key}')

    def __delattr__(self, alias: str):
        if hasattr(Schema, alias):
            raise AttributeError(f'{self.__class__.__name__} attr: {repr(alias)} is readonly')
        name = self.__attr_alias__(alias)
        key = self.__alias__(alias)
        rule = self.__template__.get(key)
        if isinstance(rule, Rule) and not rule.require or self.__options__.schema_allow_delete_required:
            if key in self:
                super().__delitem__(key)
            try:
                super().__delattr__(name)
            except AttributeError:
                pass
        else:
            raise AttributeError(f'{self.__class__.__name__}: Attempt to delete required schema key: {key}')

    def popitem(self):
        if self.__options__.schema_allow_popitem:
            return super().popitem()
        raise TypeError(f'{self.__class__.__name__}: Attempt to popitem (which is not allowed in schema __options__)')

    def pop(self, alias: str):
        key = self.__alias__(alias)
        rule = self.__template__.get(key)
        if isinstance(rule, Rule) and not rule.require or self.__options__.schema_allow_delete_required:
            return super().pop(key)
        else:
            raise TypeError(f'{self.__class__.__name__}: Attempt to delete required schema key: {key}')

    def update(self, __m=None, **kwargs):
        return super().update(self.__parser__(__m or kwargs))

    def clear(self):
        if self.__options__.schema_allow_clear:
            return super().clear()
        raise TypeError(f'{self.__class__.__name__}: Attempt to clear (which is not allowed in schema __options__)')

    def __get_property__(self, name: str):
        prop = getattr(self.__class__, name)
        if not isinstance(prop, property):
            raise AttributeError(f'Invalid property name: {repr(name)}')
        getter = getattr(prop, 'fget', None)
        if not callable(getter):
            raise AttributeError(f'Invalid property: {repr(name)}')
        return getter(self)

    def ___getattribute__(self, alias: str):
        if alias.startswith(SEG) or alias in self.__methods__ or hasattr(Schema, alias):
            return super().__getattribute__(alias)
        raise AttributeError

    def ___getattr__(self, alias: str):
        """
        If the target attribute did not provided in the data (maybe require=False or retain=False)
        access to that attribute will return the class attribute (eg. Field object)
        which will cause unpredictable error, so here we directly raise the AttributeError
        to remind developer not to access the missing attribute or provide a try-except in upper-layer explicitly
        """
        key = self.__alias__(alias)
        if isinstance(self.__data__.get(alias), property):
            if key in self:
                # see this as the cache of property calculation
                # certain scenarios when property calculate relies on a retain=False field
                # after schema initialization, access to the property will trigger the access of un
                # non-exist field and cause error, so calculate the property and cache the result in dict data
                return super().__getitem__(key)
            return self.__get_property__(alias)
        try:
            return super().__getitem__(key)
        except KeyError:
            raise AttributeError(f'{self.__class__.__name__} object has no attribute <{alias}>, '
                                 f'because [{repr(key)}] is not provided in schema data')

    @classmethod
    def __from__(cls, schema: 'Schema'):
        if schema.__class__ is cls:
            return schema
        return cls(schema)


# for enable type hint (attribute hint)
Schema.__getattr__ = Schema.___getattr__
Schema.__getattribute__ = Schema.___getattribute__


class ArbitrarySchema(Schema):
    __options__ = Options(excess_preserve=True)
        
    def __getattr__(self, alias: str):
        key = self.__alias__(alias)
        if key not in self:
            return ...
        return super().__getitem__(key)
