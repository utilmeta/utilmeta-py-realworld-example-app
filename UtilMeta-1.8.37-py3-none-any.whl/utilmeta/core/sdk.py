from functools import wraps
import inspect
import json
from io import BytesIO
from http.cookies import BaseCookie
from http.client import HTTPMessage, HTTPResponse
from urllib.error import URLError
from utilmeta.util.response import Response
from utilmeta.util.request import Request
from utilmeta.util.rule import Rule
from utilmeta.util.call import Call
from utilmeta.util.base import Util
from utilmeta.util.media import File
from utilmeta.util.log import Logger
from utilmeta.util.error import Error
from utilmeta.types import *
from utilmeta.util.common import METHODS, Header, pop, Attr, camel_case, GeneralType, \
    stream_content, UTF_8, COMMON_ERRORS, url_join, TYPE_NAME, key_normalize, time_now, \
    exc, handle_parse, UnitAttr, function_pass, METHOD_IDEMPOTENCY, SERVER_ERROR_STATUSES,  \
    MetaHeader, RequestType, Key, COMMON_TYPES, HttpError, ServerError, valid_url, Reg, \
    get_python_type, clean_line, represent, import_util, multi, get_interval
from .schema import Schema
from base64 import b64encode

if TYPE_CHECKING:
    from utilmeta.ops.schema.service import ServiceInstanceSchema


class RuleSchema(Schema):
    alias: str = None
    alias_from: List[str] = None
    alias_for: str = None

    attname: str = None
    require: bool = True
    default = None

    type_union: list = None
    dict_type: tuple = Rule(length=2, default=None)
    type: str = None

    template = None

    round: int = None
    value = None
    choices: List[str] = None
    multiple: bool = None
    regex: str = None
    document: str = None
    message: str = None

    null: bool = None
    length: int = None
    max_length: int = None
    min_length: int = None
    gt: Union[int, float, str] = None
    ge: Union[int, float, str] = None
    lt: Union[int, float, str] = None
    le: Union[int, float, str] = None

    def common_repr(self, alias: str = None) -> 'str':
        from utilmeta.util.rule import Bound, Rule
        attrs = []
        if not self.alias and alias:
            self.alias = alias
        for k, v in self.items():
            if k in [Bound.converter, Bound.validator, Bound.type, Bound.dict_type,
                     Bound.alias_for, Bound.alias_from, Bound.attname,
                     Bound.type_union, Bound.template, Bound.default]:
                continue
            if k == Bound.require and v:
                continue
            if v is None:
                continue
            if isinstance(self.__data__.get(k), property):
                continue
            attrs.append(k + '=' + represent(v))
        s = ', '.join(attrs)
        return f'{Rule.__name__}({s})'

    @property
    def common_type(self) -> 'str':
        t = repr(represent(get_python_type(self.type)))
        if self.null:
            t = 'Optional[%s]' % t
        return t


class ResponseParams(Schema):
    result_data_key: str = None
    status_code_key: str = None
    error_message_key: str = None
    total_count_key: str = None
    action_state_key: str = None
    success_action_state: Union[int, str] = None
    failed_action_state: Union[int, str] = None

    def __init__(self, result_data_key: str = None,
                 status_code_key: str = None,
                 error_message_key: str = None,
                 total_count_key: str = None,
                 action_state_key: str = None,
                 success_action_state: Union[int, str] = None,
                 failed_action_state: Union[int, str] = None
                 ):
        super().__init__(locals())

    @property
    def repr(self) -> 'str':
        return f'Response(%s)' % ', '.join(f'{key}={repr(val)}' for key, val in self.items() if val is not None)


class ResponseSchema(Schema):
    name: str = None
    type: str
    status: int
    headers: dict = None
    params: ResponseParams = None
    data = None

    def __init__(self, type: str, status: int, headers: dict = None, data=None,
                 name: str = None, params: ResponseParams = None):
        super().__init__(locals())


class BaseResponse(Schema):
    __params__: Response = None

    result = None
    state = None
    message: str = ''
    success: bool = True
    data = None     # response data, may converted to dict (application/json) or File (stream content) or str (text/*)
    raw: bytes = None   # raw response bytes
    count: int = 0
    status: int = Rule(ge=100, le=600, default=200)
    reason: str = 'ok'
    duration: timedelta = timedelta(seconds=0)
    headers: HTTPMessage = HTTPMessage()
    cookie: BaseCookie = BaseCookie()
    language: str = 'zz'
    length: int = 0
    type: str = 'application/json'
    time: datetime
    name: str = None

    @property
    def duration_ms(self):
        return self.duration.total_seconds() * 1000

    @property
    def error(self):
        if self.success:
            return None
        return HttpError.STATUS_EXCEPTIONS.get(self.status, ServerError)(self.message)

    def valid(self, *_, **__):
        return self.success

    @classmethod
    def get_default(cls, key: str):
        temp = cls.__template__.get(key)
        if isinstance(temp, Rule):
            return temp.default
        return ...


class RequestParams(Schema):
    content_type: str = RequestType.JSON
    allow_origin: List[str] = None
    scheme: str = None
    auth_config: dict = None
    auth_require: dict = None
    max_rps: Union[int, float] = None
    max_times: int = None
    max_errors: int = None
    admin_only: bool = None
    open_time: datetime = None
    close_time: datetime = None

    def __init__(self, content_type: str, allow_origin: List[str] = None, login: bool = None,
                 accept_case_styles: List[str] = None,
                 admin_only: bool = None, scheme: str = None,
                 auth_config: dict = None, auth_require: dict = None,
                 open_time: datetime = None, close_time: datetime = None,
                 max_rps: Union[int, float] = None, max_times: int = None, max_errors: int = None,):
        super().__init__(locals())


class APISchema(Schema):
    path: str
    document: str = None
    request: RequestParams = None
    response: ResponseParams = None
    routes: Dict[str, dict]
    prepend: str = None
    params: dict = None
    model: Optional[str] = None
    responses: List[ResponseSchema] = None

    def __init__(self,
                 path: str,
                 routes: Dict[str, dict],
                 document: str,
                 responses: List[ResponseSchema] = None,
                 request: RequestParams = None,
                 response: ResponseParams = None,
                 prepend: str = None,
                 params: dict = None,
                 model: Optional[str] = None,
                 ):
        super().__init__(locals())


class APIUnitData(APISchema):
    path: str
    method: str
    model: Optional[str] = None     # RESTful API's data model
    routes = None
    response = None     # use responses
    prepend: str = None
    append: str = None
    regex: bool = False
    idempotent: bool = False
    params: dict = {}
    query: dict = {}
    headers: dict = {}
    data: Optional[dict] = None

    def __init__(self, method: str, document: str,
                 request: RequestParams,
                 response: ResponseParams,
                 path: str,
                 append: str,
                 regex: bool,
                 idempotent: bool,
                 params: dict,
                 query: dict,
                 headers: dict,
                 data: Optional[dict],
                 responses: List[ResponseSchema],
                 prepend: str = None,
                 model: Optional[str] = None
                 ):
        Schema.__init__(self, locals())


class DocumentSchema(Schema):
    class MetaData(Schema, isolate=True):
        def __init__(self, utilmeta_version: str, spec_version: str):
            super().__init__(locals())

    meta: MetaData
    api: APISchema
    name: str
    description: str = ''
    version: str
    base_url: str
    schemas: Dict[str, dict] = None         # reusable data schema
    models: Dict[str, dict] = None          # data models defined in the service with <domain>:<name>
    entries: Dict[str, dict] = None         # distributed entry points
    urls: Dict[str, str] = None             # contact / license / tos .etc

    def __init__(self, api: APISchema, name: str,
                 version: str, base_url: str,
                 description: str,
                 meta: MetaData,
                 models: Dict[str, dict] = None,
                 schemas: Dict[str, dict] = None,
                 entries: Dict[str, dict] = None,
                 urls: Dict[str, str] = None
                 ):
        super().__init__(locals())


class SDK(Util):
    response: Response = None

    class UserAgent:
        # ua.ie
        # IE = 'Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US);'
        # ua.msie
        # MSIE = 'Mozilla/5.0 (compatible; MSIE 10.0; Macintosh; Intel Mac OS X 10_7_3; Trident/6.0)'
        # ua['Internet Explorer']
        # Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1;
        # Trident/4.0; GTB7.4; InfoPath.2; SV1; .NET CLR 3.3.69573; WOW64; en-US)
        # ua.opera
        # Opera/9.80 (X11; Linux i686; U; ru) Presto/2.8.131 Version/11.11
        # ua.chrome
        # Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.2 (KHTML, like Gecko) Chrome/22.0.1216.0 Safari/537.2'
        # ua.google
        # Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4) AppleWebKit/537.13
        # (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13
        # ua['google chrome']
        # Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11
        # (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11
        # ua.firefox
        # Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1
        # ua.ff
        # Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:15.0) Gecko/20100101 Firefox/15.0.1
        # ua.safari
        # Mozilla/5.0 (iPad; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26
        # (KHTML, like Gecko) Version/6.0 Mobile/10A5355d Safari/8536.25
        def __init__(self, ua_string: str = None, *, browser: str = None, os: str = None,
                     random: bool = False, rotate: bool = False):
            self.ua_string = ua_string
            self.browser = browser
            self.os = os
            self.random = random
            self.rotate = rotate

        @property
        def headers(self):
            if not self.ua_string:
                return {}
            return {
                Header.USER_AGENT: self.ua_string
            }

    class HTTPAuth:
        def __init__(self, scheme: str, value: str, header: str = Header.AUTHORIZATION):
            self.scheme = scheme
            self.value = value
            self.header = header

        @property
        def headers(self):
            b64 = b64encode(self.value.encode('latin1')).strip().decode()
            return {
                self.header: f'{self.scheme} {b64}'
            }

    class BasicAuth(HTTPAuth):
        def __init__(self, username: str, password: str = '', header: str = Header.AUTHORIZATION):
            super().__init__(scheme='Basic', value=f'{username}:{password}', header=header)

    def __init_subclass__(cls, **kwargs):
        cls.response: Response = kwargs.get('response') or cls.response

    def __init__(self, base_url: Union[str, List[str]] = None,
                 service: str = None,
                 prepend_route: str = None,
                 append_route: str = None,
                 version: Union[str, Request.Version] = None,
                 response: Response = None,
                 logger: Logger = None,
                 max_retries: int = 1,
                 retry_interval: Union[float, int, timedelta] = None,
                 timeout: int = None,
                 base_headers: Dict[str, str] = None,
                 append_slash: bool = None,
                 request_case_style: str = None,
                 response_case_style: str = None,
                 cookies: Dict[str, str] = None,
                 user_agent: UserAgent = None,
                 http_auth: HTTPAuth = None,
                 base_query: dict = None,
                 raise_error: bool = False,
                 valid_response: bool = True):
        super().__init__(locals())
        self._manager = None
        if service:
            from utilmeta.conf import config
            assert config.cluster, \
                f'use SDK service must enable cluster'
            self._manager = config.cluster_manager
        self._base_urls = [base_url] if isinstance(base_url, str) else list(base_url or [])
        self._service = service
        if not isinstance(version, Request.Version):
            version = Request.Version(version)
        self._version = version
        self._valid_response = valid_response
        self._timeout = timeout
        self._prepend_route = prepend_route
        self._append_route = append_route
        self._append_slash = append_slash
        self._raise_error = raise_error
        self._base_headers = dict(base_headers or {})
        if http_auth:
            assert isinstance(http_auth, self.HTTPAuth), \
                TypeError(f'SDK.http_auth must be a SDK.HTTPAuth object. got {http_auth}')
            self._base_headers.update(http_auth.headers)
        if user_agent:
            assert isinstance(user_agent, self.UserAgent), \
                TypeError(f'SDK.user_agent must be a SDK.UserAgent object. got {user_agent}')
            self._base_headers.update(user_agent.headers)
        if cookies:
            assert isinstance(cookies, dict), f'SDK.cookies must be a dict object, got {cookies}'
            self._base_headers[Header.COOKIE] = ';'.join([f'{key}={val}' for key, val in cookies.items()])

        self._cookies = cookies
        self._http_auth = http_auth
        self._user_agent = user_agent
        self._base_query = dict(base_query or {})
        if max_retries:
            assert max_retries >= 1, f'SDK max_retries should be a int >= 1'
        self._max_retries = int(max_retries or 1)
        if retry_interval:
            retry_interval = get_interval(retry_interval)
        self._retry_interval = retry_interval

        if not isinstance(logger, Logger) or not logger.invoke:
            # reject invalid logger
            logger = None
        if logger:
            # root invoke context logger
            logger.root = True
        self._logger = logger
        self._response = response or self.__class__.response

        def gen(sdk, base='', _response=self._response):
            for key, val in sdk.__class__.__dict__.items():
                key: str
                sub = '' if key in METHODS else key
                route = '/'.join([p for p in [base, sub] if p])
                if key.startswith('_'):
                    continue
                if isinstance(val, SDK):
                    if not val._response:
                        val._response = _response
                    gen(val, base=route, _response=val._response)
                elif inspect.isfunction(val):
                    if not getattr(val, UnitAttr.method, None):
                        # common methods
                        continue
                    method = key if key in METHODS else getattr(val, UnitAttr.method, None)
                    # method can be empty to support dynamic self-defined method router inside function
                    setattr(sdk, key, self(val, route=route, method=method, resp_temp=_response))
        gen(self)

    @property
    def __service__(self):
        return self._service

    def __invoke__(self, caller: Callable[[str, 'ServiceInstanceSchema'], HTTPResponse],
                   route: str, idempotent: bool = False, max_retries: int = 1) -> HTTPResponse:
        from utilmeta.conf import config

        if valid_url(route, raise_err=False):
            urls = [(route, None)]
        else:
            if self._service:
                if self._version:
                    # specified version requirement instances
                    instances = self._version.get_instances(self._service)
                else:
                    instances = self._manager.get_instances(self._service, connected=True)
                base_urls = [(inst.base_url, inst) for inst in self._manager.rank_algorithm(instances)]
            else:
                base_urls = [(url, None) for url in self._base_urls]
            urls = [(
                url_join(
                    base_url,
                    self._prepend_route,
                    route,
                    self._append_route,
                    append_slash=self._append_slash
                ), inst) for (base_url, inst) in base_urls]

        if not urls:
            raise exc.NoAvailableInstances(f'No available urls')

        switch_on_statuses = config.cluster.switch_on_statuses if config.cluster else SERVER_ERROR_STATUSES
        switch_on = config.cluster.switch_on if config.cluster else True
        switch_on_timeout = config.cluster.switch_on_timeout if config.cluster else True
        switch_on_idempotent_only = config.cluster.switch_on_idempotent_only if config.cluster else True
        response = None
        errors = []
        for url, inst in urls:
            for i in range(0, getattr(inst, 'max_entries', 1) if inst else max_retries):
                try:
                    if i and self._retry_interval:
                        # do not sleep at the last retry
                        import time
                        time.sleep(self._retry_interval)

                    response = caller(url, inst)
                    if response.status in switch_on_statuses:
                        # An error response
                        raise exc.ServerError(response=response)
                    # success response, break this loop
                    break
                except (TimeoutError, exc.ServerError, URLError) as e:
                    errors.append(e)
                    if switch_on_idempotent_only and not idempotent:
                        # not idempotent api, unsafe to retry
                        response = getattr(e, 'response', None)
                        break

            if not switch_on:
                break
            if switch_on_idempotent_only and not idempotent:
                break
            if response:
                if response.status in switch_on_statuses:
                    continue
            else:
                if switch_on_timeout:
                    continue
                else:
                    break
        if not response:
            msg = ';'.join([str(e) for e in errors]) if errors else 'No response'
            raise TimeoutError(msg)
        if self._raise_error and errors:
            if len(errors) == 1:
                raise Error(errors.pop()).throw()
            raise exc.CombinedError(*errors)
        return response

    def __proxy__(self, request: Request):
        from utilmeta.conf import config
        if not config.cluster or not config.cluster.proxy_config \
                or not config.cluster.proxy_config.native:
            raise exc.NotFound(path=request.path)

        timeout = self._timeout
        request.log.option = request.log.OMIT
        path = request.endpoint_path
        headers = dict(self._base_headers)
        query = dict(self._base_query)
        if self._service:
            service = self._manager.get_service(self._service)
            if service.single_endpoint:
                path = path.lstrip(service.name)
            headers.update({
                MetaHeader.ACTION_TOKEN: self._manager.get_action_token(self._service),
                MetaHeader.INSTANCE: config.deploy.instance_id
            })

        def caller(url, inst):
            headers.update(request.headers)
            query.update(request.query)
            return Call(
                url=url,
                method=request.METHOD,  # use original method
                query=request.query,
                data=request.raw_body,  # send original body to match content_tag
                headers=headers,
                timeout=inst.proxy_timeout if inst else timeout
            ).send()
        return self.__invoke__(
            caller,
            route=path,
            idempotent=METHOD_IDEMPOTENCY.get(request.method),
            max_retries=self._max_retries
        )

    @classmethod
    def _get_response_types(cls, return_type) -> List[Type[BaseResponse]]:
        def _is(t):
            return inspect.isclass(t) and issubclass(t, BaseResponse)

        if _is(return_type):
            return [return_type]

        if multi(return_type):
            types = []
            for tp in return_type:
                if _is(tp):
                    types.append(tp)
            return types
        elif isinstance(return_type, Rule):
            if return_type.type_union:
                return cls._get_response_types(return_type.type_union)
            if return_type.template:
                return cls._get_response_types(return_type.template)
            if return_type.type:
                return cls._get_response_types(return_type.type)
        return []

    def __call__(self, f, route: str, method: str, resp_temp: Response = None):
        # from utilmeta.core.schema import SchemaMeta
        from utilmeta.conf import config
        route = getattr(f, UnitAttr.alias, getattr(f, UnitAttr.route, route))
        # regex = getattr(f, UnitType.regex, False)
        log = bool(self._logger) or getattr(f, UnitAttr.log, False)
        block = getattr(f, UnitAttr.block, True)
        max_retries = getattr(f, UnitAttr.max_retries, self._max_retries)
        parser_cls = getattr(f, UnitAttr.parser_cls, config.preference.request_parser_cls)
        if isinstance(parser_cls, str):
            parser_cls = import_util(parser_cls)

        passed_func = function_pass(f)
        idempotent = getattr(f, UnitAttr.idempotent, None)
        if idempotent is None:
            idempotent = METHOD_IDEMPOTENCY.get(method)

        parser = parser_cls(
            f, from_class=...,
            parse_result=False,
            provide_default=not passed_func,
            path_config=parser_cls.PathConfig(
                path=url_join(self._base_urls[0], route) if self._base_urls else route,
                path_unit=Reg.URL_ALL
            )
        )
        response_types = self._get_response_types(parser.return_type)

        @wraps(f)
        @handle_parse
        def call_func(*args, **kwargs):
            # the __call__ is called when SDK initialized
            # when defining a subclass of SDK, some params maybe alter
            # when subclass initialized or other case, access them when do actual calling
            from_process = pop(kwargs, Key.EXECUTOR_PROCESS_ID)
            from_thread = pop(kwargs, Key.EXECUTOR_THREAD_ID)
            if log:
                self._logger = self._logger or Logger(invoke=True, root=True)
                self._logger.to_service = self._service
                self._logger.from_process = from_process
                self._logger.from_thread = from_thread
            # to record the correct Logger of the service request
            # when using ConcurrentTask to send async requests
            # this local can obtained from the original thread (which handling the request)
            # also, if there is a _origin_thread_id, means this request is not blocking
            timeout = getattr(f, UnitAttr.timeout, None) or self._timeout       # use or cause f.timeout = None
            if not timeout and config.cluster:
                timeout = config.cluster.default_timeout
            headers = dict(self._base_headers)
            query = dict(self._base_query)
            if self._service:
                headers.update({
                    MetaHeader.ACTION_TOKEN: self._manager.get_action_token(self._service),
                    MetaHeader.INSTANCE: config.deploy.instance_id
                })

            def caller(url, inst):
                if log and inst:
                    self._logger.to_instance = inst.id
                return parser.request_call(
                    args, kwargs,
                    base_url=url,
                    base_query=query,
                    base_headers=headers,
                    logger=self._logger, block=block,
                    append_slash=self._append_slash,
                    timeout=inst.proxy_timeout if inst else timeout
                ).send(method=method)

            request_time = time_now()
            if passed_func:
                response = self.__invoke__(caller, route=route, idempotent=idempotent, max_retries=max_retries)
            else:
                response = parser(self, *args, **kwargs)
            if not response_types:
                return response
            resp = self.parse_response(
                response,
                request_time=request_time,
                response_temp=resp_temp,
                response_types=response_types
            )
            if self._raise_error:
                if resp.error:
                    raise resp.error
            return resp

        setattr(call_func, Key.EXECUTOR_THREAD_ID_REQUIRED, True)
        setattr(call_func, Key.EXECUTOR_PROCESS_ID_REQUIRED, True)
        return call_func

    @classmethod
    def parse_response(cls, raw_response: HTTPResponse,
                       response_types: List[Type[BaseResponse]],
                       request_time: datetime,
                       response_temp: Response = None) -> BaseResponse:
        end = time_now()
        duration: timedelta = end - request_time
        if not isinstance(raw_response, HTTPResponse):
            raise TypeError(f'Call unit response should be HTTPResponse object, got {raw_response}, \n'
                            f'you need to return Call(...) at the end of the function')

        status, headers, reason = raw_response.status, raw_response.headers, raw_response.reason
        content_type = headers.get(Header.TYPE, '*/*')
        content_length = headers.get(Header.LENGTH, 0)
        content_language = headers.get(Header.CONTENT_LANGUAGE, 'zz')
        cookie = BaseCookie(headers.get(Header.SET_COOKIE, ''))
        response_name = headers.get(MetaHeader.RESPONSE_NAME)
        bytes_response = raw_response.read()
        raw_response.close()  # close response to prevent from socket file descriptors leak

        types = []
        for resp in response_types:
            if response_name and response_name == resp.get_default('name'):
                types.append(resp)
                continue
            if status == resp.get_default('status'):
                types.append(resp)
                continue
        for resp in response_types:
            if resp not in types:
                types.append(resp)
        if not types:
            types = [BaseResponse]

        data = None
        result = None
        state = None
        count = 0
        message = ''

        for i, response_type in enumerate(types):
            last = i == len(types) - 1

            resp_temp = response_type.__params__ or response_temp or Response()

            if GeneralType.JSON in content_type:
                # content_type
                try:
                    data = json.loads(bytes_response)
                except json.JSONDecodeError as e:
                    if not last:
                        continue

                    message = str(e)
                    state = resp_temp.failed_action_state
                else:
                    result = data
                    if isinstance(data, dict):
                        if resp_temp.result_key:
                            if resp_temp.result_key not in data:
                                # parse failed
                                if not last:
                                    continue
                            result = data.get(resp_temp.result_key)
                        if resp_temp.state_key:
                            state = data.get(resp_temp.state_key)
                        if resp_temp.message_key:
                            message = data.get(resp_temp.message_key)
                        if resp_temp.count_key:
                            count = data.get(resp_temp.count_key)
                        if resp_temp.status_key:
                            status = int(data.get(resp_temp.status_key, status))

            elif stream_content(content_type):
                data = File(file=BytesIO(bytes_response))
            else:
                data = bytes_response.decode(UTF_8, 'ignore')

            if status >= 400:
                success = False
                if state is None:
                    state = resp_temp.failed_action_state
            else:
                success = resp_temp.check_success(data, status=status)

            if not issubclass(response_type, BaseResponse):
                try:
                    from utilmeta.conf import config
                    return config.preference.request_parser_cls.parse(data, response_type)
                except COMMON_ERRORS as e:
                    raise exc.BadResponse(e)
                # fall back to basic string response
            response_data = dict(
                data=data,
                count=count,
                state=state,
                headers=headers,
                reason=reason,
                status=status,
                language=content_language,
                length=content_length,
                type=content_type,
                duration=duration,
                time=request_time,
                raw=bytes_response,
                cookie=cookie,
            )
            try:
                return response_type(
                    success=success,
                    message=message,
                    result=result,
                    **response_data
                )
            except COMMON_ERRORS as e:
                # result schema cannot be guaranteed, so fall back to BaseResponse
                if not last:
                    continue
                if message:
                    message += '; '
                else:
                    message = ''
                message += f'parse response with error: {str(e)}'
                return BaseResponse(
                    result=None,
                    success=False,
                    message=message,
                    **response_data
                )

    @classmethod
    def generate(cls, doc: DocumentSchema) -> str:
        from utilmeta.conf import config
        imports = 'from utilmeta.types import *\n' \
                  'from utilmeta.utils import *\n' \
                  'from utilmeta.core.sdk import BaseResponse'
        api = APISchema(**doc.api)
        root_resp_str = f', response={api.response.repr}' if api.response else ''
        temp_content = f'\nclass APIService(SDK{root_resp_str}):\n\t'
        instance = f'\n{doc.name} = APIService(' + \
                   (f'service={repr(doc.name)}, ' if config.cluster else '') + \
                   f'base_url={repr(doc.base_url)}, ' \
                   f'version={repr(doc.version)})\n'

        def gen_type(val, name: str = None, alias: str = None, isolate: bool = True,
                     by_init: bool = False, namespace: list = None) \
                -> Tuple[str, str, str]:
            content = temp = ''
            namespace = namespace or []  # use universal namespaces
            alias = alias if alias != name else None

            def get_schema_name(n: str = None):
                schema_name = 'DataSchema'
                if isinstance(n, str) and n:
                    if not n.lower().endswith('schema'):
                        schema_name = camel_case(n) + 'Schema'
                flag = ''
                if schema_name in namespace:
                    flag = str(namespace.count(schema_name))
                namespace.append(schema_name)
                return schema_name + flag

            if isinstance(val, (list, set)):
                v = list(val)[0]
                if not name:
                    name = getattr(v, Attr.NAME, None)
                sub_name, temp, content = gen_type(v, name, by_init=by_init, namespace=namespace)
                name = f'{TYPE_NAME[type(val)]}[{sub_name}]'

            elif isinstance(val, tuple):
                subs = []
                names = []
                for i, v in enumerate(val):
                    sub_name, sub_temp, sub_content = gen_type(v, name=name, by_init=by_init, namespace=namespace)
                    subs.append(sub_content)
                    names.append(sub_name)
                name = f'Tuple[{", ".join(names)}]'
                content = "\n\n\n".join(subs)

            elif isinstance(val, dict):
                _ = val.get('@')
                if _ == Rule.__name__:
                    val = RuleSchema(**val)
                    # a rule
                    if val.template:
                        name, _t, content = gen_type(val.template, name=name, by_init=by_init, namespace=namespace)
                    elif val.type_union:
                        types = []
                        appends = []
                        for i, tp in enumerate(val.type_union):
                            _n, _t, _a = gen_type(tp, by_init=by_init, name=name, namespace=namespace)
                            types.append(_n)
                            if _a:
                                appends.append(_a)
                        name = 'Union[%s]' % ', '.join(types)
                        content = '\n'.join(appends)
                    elif val.dict_type:
                        key_type, val_type = val.dict_type
                        key_type = get_python_type(key_type)
                        _n, _t, content = gen_type(val_type, by_init=by_init, name=name, namespace=namespace)
                        if key_type not in COMMON_TYPES:
                            key_type = 'str'
                        name = 'Dict[%s, %s]' % (repr(represent(key_type)), _n)
                    else:
                        name = val.common_type

                    if by_init and not val.require and not alias:
                        default = val.default

                        if default in (list(), set(), dict()):
                            temp = str(Rule(default=type(default)))
                        else:
                            temp = repr(val.default)
                    else:
                        temp = val.common_repr(alias=alias)
                    if temp == str(Rule()):
                        temp = None

                elif _ == File.__name__:
                    val = RuleSchema(**val)
                    name = val.common_type
                    if by_init and not val.require:
                        temp = repr(val.default)
                    else:
                        temp = val.common_repr(alias=alias)
                    if temp == str(File()):
                        temp = None

                elif _ is None:
                    # schema data
                    defaults = []
                    non_defaults = []

                    isolate_str = ', isolate=True' if isolate else ''
                    name = get_schema_name(name)
                    content = f'class {name}(Schema{isolate_str}):\n\t'

                    def _get_key(n: str):
                        if n.startswith('@'):
                            n = n[1:]
                            while n in val:
                                n = '_' + n
                            return n
                        return key_normalize(n)

                    for k, v in val.items():
                        k: str
                        _type = repr('str')
                        _temp = None
                        _append = ''

                        rule = RuleSchema(**v) if isinstance(v, dict) and v.get('@') == Rule.__name__ else None
                        key = rule.attname if rule and rule.attname else _get_key(k)

                        _type, _temp, _append = gen_type(
                            v, name=key, alias=k, namespace=namespace,
                            isolate=False, by_init=by_init
                        )

                        content += '\n\t'.join([line for line in _append.splitlines() if line])
                        if _append:
                            content += '\n\n\t'
                        if not key:
                            continue

                        sub_str = f'{key}: {_type}'
                        if _temp:
                            sub_str += ' = ' + _temp
                            defaults.append(sub_str)
                        else:
                            non_defaults.append(sub_str)

                    if by_init:
                        content += 'def __init__(\n\t\t%s\n\t): super().__init__(locals())' \
                                   % ',\n\t\t'.join(['self', *non_defaults, *defaults])
                    else:
                        content += '\n\t'.join([*non_defaults, *defaults])

            elif isinstance(val, str):
                name = repr(represent(get_python_type(val)))

            return name, temp, content

        def analyze(unit: APIUnitData, name: str):
            path_str = query_str = body_str = headers_str = ''
            schemas = ''
            keys = set()

            def _get_key(_n: str):
                while _n in keys:
                    _n = '_' + _n
                return _n

            if unit.params:
                _name, _temp, _content = gen_type(unit.params, name='Path', by_init=False)
                prepends = []
                annotates = []
                defaults = []
                for line in _content.splitlines()[1:]:
                    line = line[1:]
                    if line.startswith('\t') or line.startswith('class '):
                        prepends.append(line.strip('\t'))
                    elif '=' in line:
                        _line = clean_line(line)
                        if _line:
                            defaults.append(line)
                    else:
                        _line = clean_line(line)
                        if _line:
                            annotates.append(line)
                schemas += '\n\t'.join(prepends)
                path_str = ',\n\t'.join(annotates + defaults)
                keys.update(unit.params)

            if unit.query:
                if keys.intersection(unit.query):
                    query_name = f'{camel_case(name)}Query'
                    _name, _temp, _schema = gen_type(unit.query, name=query_name, by_init=True)
                    if _schema:
                        schemas += _schema + '\n\n\n'
                    query_key = _get_key('query')
                    query_str = f'{query_key}: {_name} = Request.Query'
                else:
                    _name, _temp, _content = gen_type(unit.query, name='Query', by_init=False)
                    prepends = []
                    annotates = []
                    defaults = []
                    for line in _content.splitlines()[1:]:
                        line = line[1:]
                        if line.startswith('\t') or line.startswith('class '):
                            prepends.append(line.strip('\t'))
                        elif '=' in line:
                            _line = clean_line(line)
                            if _line:
                                defaults.append(line)
                        else:
                            _line = clean_line(line)
                            if _line:
                                annotates.append(line)
                    schemas += '\n\t'.join(prepends)
                    query_str = ',\n\t'.join(annotates + defaults)

            if unit.data:
                body_name = f'{camel_case(name)}Body'
                _name, _temp, _schema = gen_type(unit.data, name=body_name, by_init=True)
                if _schema:
                    schemas += _schema + '\n\n\n'
                body_key = _get_key('data')
                body_str = f'{body_key}: {_name} = Request.Body'

            if unit.headers:
                headers_name = f'{camel_case(name)}Headers'
                _name, _temp, _schema = gen_type(unit.headers, name=headers_name, by_init=True)
                if _schema:
                    schemas += _schema + '\n\n\n'
                headers_key = _get_key('headers')
                headers_str = f'{headers_key}: {_name} = Request.Headers'

            args = [v for v in [path_str, query_str, body_str, headers_str] if v]
            return schemas, ',\n\t'.join(args)

        def resolve(routes: dict, base: str = ''):
            cls_contents = []
            instance_content = ''
            schema_content = ''
            call_contents = []

            for key, unit in routes.items():
                if not isinstance(unit, dict):
                    continue
                key = key_normalize(key)
                name = camel_case(base) + camel_case(key)
                _method = unit.get('method')
                _routes = unit.get('routes')

                if _method:
                    # Unit
                    unit = APIUnitData(**unit)
                    method_params = {}
                    method_arg = repr(unit.path) if unit.path != key else ''
                    if unit.append:
                        method_params.update(path=repr(unit.append))
                    if unit.regex:
                        method_params.update(regex=unit.regex)
                    if unit.idempotent is not None:
                        method_params.update(idempotent=unit.idempotent)
                    if method_params and method_arg:
                        method_arg += ', '

                    if method_arg or method_params:
                        method_params_str = f'({method_arg}%s)' % \
                                            ', '.join([f'{k}={v}' for k, v in method_params.items()])
                    else:
                        method_params_str = ''

                    method_str = f'@api.{unit.method}{method_params_str}\n'
                    schema_str, kw_str = analyze(unit, key)

                    resp_names = []
                    resp_contents = []
                    for resp in unit.responses:
                        if not resp.data and not resp.headers and not resp.params:
                            if resp_names:
                                continue
                            else:
                                resp_names.append('BaseResponse')
                            continue

                        prefix = f'{camel_case(key)}'
                        if resp.name:
                            prefix += resp.name.capitalize()

                        resp_name = f'{prefix}Response'
                        resp_cls = f'class {resp_name}(BaseResponse):\n\t'
                        resp_content = ''

                        attr_contents = []

                        if resp.name:
                            attr_contents.append(f'name = {repr(resp.name)}')
                        if resp.type != GeneralType.JSON:
                            attr_contents.append(f'type = {repr(resp.type)}')
                        if resp.status != 200:
                            attr_contents.append(f'status = {resp.status}')

                        if resp.data:
                            _name, _temp, _content = gen_type(
                                resp.data, name=f'{prefix}Result')
                            # result_names.append(_name)
                            resp_content += '\n\t'.join([line for line in _content.splitlines() if line])
                            attr_contents.append(f'result: {_name}')
                        if resp.headers:
                            _name, _temp, _content = gen_type(
                                resp.data, name=f'{prefix}Headers')
                            # header_names.append(_name)
                            resp_content += '\n\t'.join([line for line in _content.splitlines() if line])
                            attr_contents.append(f'headers: {_name}')

                        if resp.params:
                            attr_contents.append(f'__params__ = {resp.params.repr}')

                        if resp_content:
                            resp_cls += resp_content + '\n\t'

                        resp_cls += '\n\t'.join(attr_contents) + '\n'
                        resp_contents.append(resp_cls)
                        resp_names.append(resp_name)

                    if resp_names:
                        schema_str += '\n\n'.join(resp_contents)

                    if len(resp_names) > 1:
                        resp_name = f'Union[%s]' % ', '.join(resp_names)
                    elif len(resp_names) == 1:
                        resp_name = resp_names[0]
                    else:
                        resp_name = 'BaseResponse'

                    schema_content += schema_str
                    call_contents.append(f'{method_str}def {key}(%s) -> {resp_name}: pass\n'
                                         % (f'\n\tself,\n\t{kw_str}\n' if kw_str else 'self'))
                elif _routes is not None:
                    # API or Module
                    if _routes:
                        unit = APISchema(**unit)
                        resp_str = ''
                        if unit.response:
                            resp_str = f', response={unit.response.repr}'

                        sub_content = f'\nclass {name}SDK(SDK{resp_str}):\n\t'
                        kls, sub = resolve(unit.routes, base=name)
                        # kls.reverse()
                        sub_content += '\n\t'.join([line for line in sub.splitlines() if line])
                        cls_contents = [*kls, sub_content] + cls_contents
                        # cls_contents += [sub_content, *kls]     # the final result is reversed
                        instance_content += f'{key} = {name}SDK()\n'
                elif unit:
                    # route with more than 1 method
                    sub_content = f'\nclass {name}SDK(SDK):\n\t'
                    kls, sub = resolve(unit, base=name)
                    # kls.reverse()
                    sub_content += '\n\t'.join([line for line in sub.splitlines() if line])
                    cls_contents = [*kls, sub_content] + cls_contents
                    # cls_contents += [sub_content, *kls]     # the final result is reversed
                    instance_content += f'{key} = {name}SDK()\n'

            call_content = '\n\n'.join(call_contents)
            content = '\n\n'.join([c for c in (instance_content, schema_content, call_content) if c])
            return cls_contents, content

        _cls, template = resolve(api.routes)
        # cls.reverse()
        cls_content = '\n\n'.join(_cls)
        temp_content += '\n\t'.join([line for line in template.splitlines() if line])
        temp_file = f'{imports}\n\n{cls_content}\n\n{temp_content}\n\n{instance}'
        lines = []
        prev = ''
        for line in temp_file.splitlines():
            s_line = line.strip('\t')
            if s_line.startswith('@api.'):
                lines.append('')
            if s_line.startswith('class '):
                if not prev.startswith('class ') and clean_line(prev):
                    lines.append('')
            lines.append(line)
            prev = s_line
        lines.append('')
        return '\n'.join(lines)
