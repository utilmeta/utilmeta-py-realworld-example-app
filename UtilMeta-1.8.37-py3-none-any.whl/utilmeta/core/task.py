from utilmeta.types import *
from utilmeta.util.base import Meta, Util
from utilmeta.util.common import Attr, task, get_interval, \
    TaskStatus, camel_case, ignore_errors, SEG, UnitAttr, \
    exc, close_connections, pop, time_now, AlertLevel

from utilmeta.util.task.exceptions import WaitForNextCycle, InvalidStatus, SuccessRollback
from utilmeta.util.task.schedule import Schedule
from utilmeta.util.log import Logger
from utilmeta.util.error import Error
from utilmeta.conf import Task
from django.db.models import Model
from datetime import datetime, timedelta
from utilmeta.conf import config
from django.utils.functional import cached_property
import time
import os
import inspect
import random
from typing import TypeVar
from utilmeta.util.task.backends.base import BaseJob
from utilmeta.util.task.backends.thread import ThreadJob
T = TypeVar('T')

T1 = TypeVar('T1')
T2 = TypeVar('T2')

if TYPE_CHECKING:
    from .module import Module
    from utilmeta.ops.models.task import *

task_config = config.task or Task()


class TaskMeta(Meta):
    """
    Task can be combined, like a polling task with a inner concurrent task
    """
    _util_slots = [
        'module',
        'query',
    ]

    def __new__(mcs, name, bases: tuple, attrs: dict, **kwargs):
        if bases == (Util,):
            # cls.__locked__ = True   # lock the base Schema
            return super().__new__(mcs, name, bases, attrs)

        call = attrs.get(Attr.CALL)
        abstract = attrs.get('abstract')
        if not callable(call):
            raise TypeError(f'Task should define a __call__')

        attrs[Attr.CALL] = Task.__call__   # decorate call
        attrs[Attr.FUNC] = call
        module = attrs.get('module')

        cls = super().__new__(mcs, name, bases, attrs)

        cls.error_hooks = {}
        cls.before_hook = None
        cls.after_hook = None
        cls.timeout_hook = None
        cls.pre_condition = None
        cls.end_condition = None

        for key, val in cls.__dict__.items():
            if key.startswith(SEG) or key.endswith(SEG):
                continue
            if not callable(val):
                continue
            errors = getattr(val, UnitAttr.error_hook, None)
            before = getattr(val, UnitAttr.before_hook, None)
            after = getattr(val, UnitAttr.after_hook, None)
            timeout = getattr(val, UnitAttr.timeout, None)
            pre_condition = getattr(val, UnitAttr.pre, None)
            end_condition = getattr(val, UnitAttr.end, None)
            if errors:
                for err in errors:
                    cls.error_hooks[err] = ignore_errors(val)
            if after:
                cls.after_hook = val
            if before:
                cls.before_hook = val
            if timeout:
                cls.timeout_hook = ignore_errors(val)
            if pre_condition:
                cls.pre_condition = ignore_errors(val, default=False)
            if end_condition:
                cls.end_condition = ignore_errors(val, default=True)

        cls.iterable = bool(module or callable(attrs.get(Attr.ITER)))
        for base in bases:
            if issubclass(base, Task):
                if base.iterable:
                    cls.iterable = True

        cls.module_iter_schema = False
        cls.module_iter_model = False
        cls.abstract = bool(abstract)

        if module:
            from .module import Module
            from .schema import SchemaMeta
            assert issubclass(module, Module)
            _, *parameters = inspect.signature(call).parameters.values()
            assert len(parameters) >= 1, \
                TypeError(f'Task with module __call__ must have at least 1 param, got: {parameters}')
            param: inspect.Parameter = parameters[0]
            t = param.annotation
            if inspect.isclass(t) and issubclass(t, Model):
                assert issubclass(t, module.model)
                cls.module_iter_model = True
            elif SchemaMeta.__retrieve__(t, schema=True):
                cls.module_iter_schema = True

        from utilmeta.conf import config
        if config.task and not abstract:
            config.task.add_cls(cls)

        return cls

    def on_execute(cls: Type[T]) -> T:
        pass

    def on_finish(cls: Type[T]) -> T:
        pass

    def on_success(cls: Type[T]) -> T:
        pass

    def on_error(cls: Type[T],
                 *types: Type[Exception],
                 proportion: float = 1,
                 threshold: int = None,
                 ) -> T:
        pass

    def on_timeout(cls: Type[T],
                   timeout: Union[int, float, timedelta] = task_config.default_execution_timeout, *,
                   proportion: float = 1,
                   threshold: int = None) -> T:
        pass

    def workflow(cls, begin: bool = False, finish: bool = False):
        pass


class Task(Util, metaclass=TaskMeta):
    _MUTABLE = True

    Schedule = Schedule
    module: Type['Module'] = None
    query: dict = None
    abstract: bool = False
    iterable: bool = False

    FIRST = 'FIRST'
    LAST = 'LAST'
    ROTATE = 'ROTATE'
    HASH = 'HASH'
    LRU = 'LRU'
    LFU = 'LFU'

    MIN_TASKS = 'MIN_TASKS'
    MIN_EXECUTIONS = 'MIN_EXECUTIONS'
    MIN_MEMORY = 'MIN_MEMORY'
    MIN_LIFETIME = 'MIN_LIFETIME'

    def __init__(self,
                 name: str = None, *,
                 group: str = None,

                 module_query: dict = None,

                 dist_by_param: bool = False,
                 dist_by_event: bool = False,

                 concurrent_cls: str = None,

                 param_dist_event_randomness: bool = False,
                 # chunk_size: int = task_config.default_chunk_size,
                 # execute_condition: Callable = None,
                 # continue_condition: Callable = None,
                 reassign_strategy: str = task_config.task_reassign_default_strategy,

                 # must_execute_every_event: bool = False,
                 # must_execute_once: bool = False,
                 # must_record_failures: bool = False,
                 event_abandon_window: Union[int, timedelta] = task_config.event_abandon_default_window,
                 event_abandon_expired: bool = True,
                 # event_omit_recover_strategy: str = task_config.event_omit_recover_default_strategy,
                 job_max_local_retries: int = 1,
                 job_local_retry_interval: Union[float, int, timedelta] = None,

                 # dist_job_retries: bool = False,
                 max_concurrent_jobs: int = task_config.task_default_max_concurrent_jobs,
                 event_max_executions: int = None,
                 event_dist_strategy: str = task_config.event_dist_default_strategy,
                 store_job_result: bool = False,
                 alert_min_continuous_errors: int = None,

                 daemon_thread: bool = task_config.task_daemon_thread,
                 # turn off for long execution duration task to keep execution continue during retire
                 fixed_task_start_time: bool = task_config.fixed_task_start_time,
                 start_time: datetime = None,
                 stop_time: datetime = None,
                 interval_delta_ratio: float = task_config.default_interval_delta_ratio,

                 enable_log: bool = task_config.task_default_enable_log,
                 console_log: bool = task_config.console_log_execution,

                 # interval_jitter_ratio: float = task_config.default_interval_jitter_ratio,
                 tolerance_overtime: Union[int, float, timedelta] = 0,
                 max_times: int = None,
                 exec_timeout: Union[int, float, timedelta] = None,

                 schedule: Schedule = None,
                 interval: Union[int, float, timedelta] = None,
                 looped: bool = False,      # making a loop task, use while True
                 min_loop_interval: Union[int, timedelta] = None,
                 **kwargs
                 # max_concurrent_tasks: int = None,
                 ):
        """
        if from_store=True,
        task class will lookup database to find this task name and get params as init kwargs
        if there are no params in the storage, create an instance with above params
        """
        # schedule
        # interval

        if schedule:
            if isinstance(schedule, dict):
                schedule = Schedule(**schedule)
            assert isinstance(schedule, Schedule),\
                f'Task schedule should be Task.Schedule object, got {schedule}'
        elif interval:
            interval = get_interval(interval, ge=task_config.min_task_interval)
        self._schedule = schedule
        self._interval: Optional[float] = interval
        self._looped = looped
        self.min_loop_interval = get_interval(min_loop_interval, null=True)

        name = name or self.default_name
        kwargs.update(locals())
        pop(kwargs, 'kwargs')
        super().__init__(kwargs)

        self._name = name
        self._group = group or 'default'
        # self._context: Optional['Task.Context'] = None

        assert self.group.isidentifier()
        self.query_dict = None
        if module_query:
            assert isinstance(module_query, dict), \
                f'Task module query must be dict object, got {module_query}'
            if self.query and isinstance(self.query, dict):
                module_query.update(self.query)
            self.query_dict = dict(module_query)
        elif isinstance(self.__class__.query, property):
            pass
        elif isinstance(self.__class__.query, dict):
            self.query_dict = self.__class__.query
        if self.query_dict and self.module:
            self.module.read_option.check_query(self.query_dict)

        # self.chunk_size = chunk_size
        # self.max_workers = max_workers
        self.start_time = start_time
        self.stop_time = stop_time
        self.max_times = max_times
        self.exec_timeout = exec_timeout
        assert job_max_local_retries >= 1, f'Invalid Task job_max_local_retries: {job_max_local_retries} must >= 1'
        self.job_max_local_retries = job_max_local_retries
        self.store_job_result = store_job_result

        self.param_dist_event_randomness = param_dist_event_randomness
        self.event_abandon_window = event_abandon_window
        self.event_abandon_expired = event_abandon_expired
        self.concurrent_cls_string = concurrent_cls
        self.daemon_thread = daemon_thread

        self.enable_log = enable_log
        self.console_log = console_log
        self.max_concurrent_jobs = max_concurrent_jobs
        # self.from_store = from_store
        if looped:
            assert not schedule and not interval, \
                f'Looped task: <{name}> should not have schedule or interval settings'
        else:
            if schedule and interval:
                raise TypeError(f'Task must be either schedule (by declare schedule param)'
                                f' or periodic (by declare interval param)')

        # self.interval_init_delta = get_interval(interval_init_delta, null=True)
        self.one_off = not looped and not schedule and not interval
        self.interval_delta_ratio = interval_delta_ratio
        if interval_delta_ratio:
            assert 0 < interval_delta_ratio < 1

        self.tolerance_overtime = get_interval(tolerance_overtime, ge=None, null=True)
        # tolerance overtime can be a negative value
        if dist_by_param or dist_by_event:
            assert config.cluster, f'Task distribution through instances require to set conf.Cluster'
        if dist_by_param and dist_by_event:
            raise ValueError(f'Task distribution can choose one of dist_by_param, dist_by_event')
        self.dist_by_param = dist_by_param
        self.dist_by_event = dist_by_event

        if event_dist_strategy:
            assert event_dist_strategy in (self.FIRST, self.LAST, self.ROTATE, self.HASH, self.LRU, self.LFU)
        self.event_dist_strategy = event_dist_strategy if self.dist_by_event else None
        self.event_max_executions = event_max_executions
        self.reassign_strategy = reassign_strategy
        self.fixed_task_start_time = fixed_task_start_time

        self._event_id = None
        self._status = TaskStatus.idle
        self._cycle_start_time = start_time   # start time or worker_cycle
        self._timeout_limit = None

        self._exec_time = None
        self._done_time = None

        self._jobs_num = 9
        self._expect_exec_time = None
        self._execution: Optional['TaskExecution'] = None
        self._distribution: Optional['TaskDistribution'] = None
        self._instance: Optional['TaskSettings'] = None
        self.alert_min_continuous_errors = alert_min_continuous_errors

        self._result = None
        self._error = None
        self._timeout = None
        self._success = None

        # self._delay_pending =
        self.job_local_retry_interval = get_interval(
            job_local_retry_interval,
            null=True, ge=0,
            le=task_config.default_execution_timeout
        )

    def __call__(self, *args, **kwargs) -> BaseJob:
        func = self.__func__
        if not self.module:
            parser = config.preference.function_parser_cls(func, from_class=self.__class__)
            _args, _kwargs = parser.parse_params(args, kwargs)

        return self.job_cls(
            target=func,
            args=args,
            kwargs=kwargs,
            max_retries=self.job_max_local_retries,
            retry_interval=self.job_local_retry_interval,
            logger=Logger(root=True) if self.enable_log else None
        )

    __func__ = __call__

    def get_start_time_for_save(self) -> Optional[datetime]:
        if self.start_time:
            return self.start_time
        if self.fixed_task_start_time:
            if self.task_settings:
                return self.task_settings.start_time
        return None

    @property
    def process_id(self):
        return os.getpid()

    @property
    def thread_id(self):
        import threading
        return threading.current_thread().ident

    @property
    def name(self):
        return self._name

    @property
    def group(self):
        return self._group

    @property
    def jobs_num(self):
        return self._jobs_num

    @property
    def distributed(self):
        return self.dist_by_param or self.dist_by_event

    def __iter__(self) -> Iterator[BaseJob]:
        if self.module:
            module = self.module_instance
            if self.module_iter_schema:
                values = module.serialize()
                # ignore Page .etc
            elif self.module_iter_model:
                values = module.q
            else:
                values = module.q.pk_list
            for val in values:
                yield self(val)

    @property
    def default_type_label(self) -> str:
        if self.schedule:
            return str(self.schedule).lower()

        def _make(val: float):
            if val is None:
                return None
            if val - int(val) == 0:
                return int(val)
            return val
        if self.interval:
            return f'periodic(seconds={_make(self.interval)})'
        if self.looped:
            return f'looped(min_interval={_make(self.min_loop_interval)})'
        return 'one_off'

    @property
    def default_name(self) -> str:
        return f'{camel_case(self.__class__.__name__, reverse=True)}_{self.default_type_label}'

    @property
    def exec_time(self) -> Optional[datetime]:
        return self._exec_time

    @property
    def done_time(self) -> Optional[datetime]:
        return self._done_time

    @property
    def timeout_limit(self) -> Optional[datetime]:
        return self._timeout_limit

    @property
    def exec_duration(self) -> Optional[timedelta]:
        if self.exec_time and self.done_time:
            return self.done_time - self.exec_time
        return None

    @property
    def exec_id(self) -> Optional[datetime]:
        return self.task_execution.pk if self.task_execution else None

    @property
    def expect_exec_time(self) -> datetime:
        return self._expect_exec_time

    @property
    def next_event(self):
        from utilmeta.ops.models.task import TaskEvent
        if self._event_id:
            return TaskEvent.get(task=self.task_settings, event_id=self._event_id + 1)
        return TaskEvent.next(task=self.task_settings)

    @property
    def current_event(self):
        from utilmeta.ops.models.task import TaskEvent
        if self._event_id:
            return TaskEvent.get(task=self.task_settings, event_id=self._event_id)
        return TaskEvent.current(task=self.task_settings)

    @property
    def prev_event(self):
        from utilmeta.ops.models.task import TaskEvent
        if self._event_id:
            if self._event_id <= 1:
                return None
            return TaskEvent.get(task=self.task_settings, event_id=self._event_id - 1)
        return TaskEvent.previous(task=self.task_settings)

    @property
    def current_time(self) -> datetime:
        """
        An property that always return a valid datetime
        in cycle it is almost gonna be current event's exec_time
        """
        event = self.current_event
        if event:
            return event.exec_time
        return self.exec_time or time_now()

    @property
    def task_execution(self):
        return self._execution

    @property
    def event_id(self):
        if self._event_id:
            return self._event_id
        event = self.current_event
        return event.pk if event else 0

    def delay_execute(self, event_id: int = None, interval: float = 0,
                      from_cycle: bool = False, block: bool = False):
        """
        if interval=0, this is a omit thread task
        """
        import time
        kwargs = dict(
            event_id=event_id,
            from_cycle=from_cycle
        )
        if block:
            time.sleep(interval)
            self.execute(**kwargs)
            return

        job = self.delay_job_cls(
            target=self.execute,
            kwargs=kwargs,
        )
        job.execute(
            delay=interval,
            timeout=task_config.max_execution_timeout,      # set bottom line
            daemon=self.daemon_thread,                      # non-daemon thread for long task
            block=False
        )
        return job.worker

    def get_next_delay(self) -> Optional[float]:
        if not self.next_event or not self.current_event:
            return None
        return (self.next_event.exec_time - self.current_event.exec_time).total_seconds()

    def get_timeout(self) -> float:
        if self.exec_timeout:
            return self.exec_timeout
        if self._looped or self.tolerance_overtime is None:
            return task_config.default_execution_timeout
        delay = self.get_next_delay()
        if not delay:
            return task_config.default_execution_timeout
        return max(
            delay - task_config.worker_cycle_interval + self.tolerance_overtime,
            task_config.min_interval
        )

    @property
    def module_instance(self):
        if not self.module:
            return None
        if self.query:
            mod = self.module(query=self.query, auth=False)
        else:
            mod = self.module(queryset=self.module.all(), auth=False)
        mod.apply_alter(attr_only=True)
        # in case that module has Page util that only generate some part of the result
        return mod.assign()

    def fetch_jobs(self) -> List[BaseJob]:
        if not self.iterable:
            return [self()]
        if not self.dist_by_param:
            jobs = []
            for job in self:
                jobs.append(job)
            return jobs

        current = task_config.instance_id
        seed = self.event_id if self.param_dist_event_randomness else None
        if self.module:
            pk_list = self.module_instance.q.pk_list
            hash_map = config.cluster_manager.get_instance_hash_values(
                values=pk_list, reverse=True, seed=seed
            )
            if current not in hash_map:
                return []
            values = hash_map[current]
            if self.module_iter_model:
                values = self.module.filter(pk__in=values)
            elif self.module_iter_schema:
                mod = self.module(pk_list=values, auth=False)
                mod.apply_alter(attr_only=True)
                values = mod.assign().serialize()

            jobs = []
            for val in values:
                jobs.append(self(val))
            return jobs

        key_jobs = {}
        for job in self:
            key_jobs[job.hash] = job

        hash_map = config.cluster_manager.get_instance_hash_values(
            values=list(key_jobs), seed=seed,
            reverse=True, do_hash=False
        )
        if current not in hash_map:
            return []

        jobs = []
        for id_hash in hash_map[current]:
            jobs.append(key_jobs[id_hash])
        return jobs

    def _exec(self):
        self._exec_time = time_now()
        # self.log = Logger(root=True)
        # reset logger to prevent share the same id cache with original Task
        self._status = TaskStatus.busy
        # self._jobs = []
        self._result = None
        self._error = None
        self._timeout = False

    @property
    def job_cls(self) -> Type[BaseJob]:
        if not self.concurrent_cls_string:
            return task_config.get_job_cls()
        pool = task_config.get_concurrent_cls(cls_string=self.concurrent_cls_string)
        return pool.DEFAULT_JOB_CLS

    @property
    def delay_job_cls(self) -> Type[BaseJob]:
        return ThreadJob

    def get_concurrent_jobs(self):
        """
        According to the instance-level current jobs

        # temporarily return max_concurrent_jobs
        """
        if not self.max_concurrent_jobs:
            return None
        return min(self.max_concurrent_jobs, 1)

    def _execute(self):
        if config.task.console_log_execution and not self.one_off and self.console_log:
            print(f'[{time_now()}] ({os.getpid()}) EXECUTE: {self.name} on event [{self.event_id}]', flush=True)

        self._exec()
        timeout = self.get_timeout()
        self._timeout_limit = self.exec_time + timedelta(seconds=timeout)

        with task_config.concurrent_executor(
            concurrent_cls=self.concurrent_cls_string,
            max_workers=self.get_concurrent_jobs(),
            timeout=timeout,
            silent_timeout=True,
            on_complete=close_connections
        ) as executor:
            jobs = self.fetch_jobs()
            self._jobs_num = len(jobs)
            if not self.sync_execution():
                # excess execution (failed to acquire Consensus Lock), abort actual execution
                return
            for job in jobs:
                executor.submit_job(job)
            results = executor.get_results()
            self._result = self.reduce(results)
            self.done_execution(results)

        return self.result

    def claim_current_event(self) -> bool:
        return task_config.manager.claim_current_event(self)

    def execute(self, event_id: int = None, from_cycle: bool = False,
                transaction: List[str] = None, rollback: bool = False):
        try:
            if from_cycle:
                if self.status == TaskStatus.down:
                    raise InvalidStatus(f'Task<{self.name}> is down')
                if self.status == TaskStatus.pause:
                    raise InvalidStatus(f'Task<{self.name}> is paused')

            if not self.claim_current_event():
                return

            if self.pre_condition:
                if not self.pre_condition():
                    raise WaitForNextCycle

            executor = self._execute
            if transaction:
                for alias in transaction:
                    executor = task.transaction(alias)(executor)
            if rollback:
                assert transaction

            if event_id:
                if self._event_id and self._event_id != event_id:
                    raise RuntimeError(f'Invalid event: {self._event_id} with {event_id}')
                self._event_id = event_id

            if self.before_hook:
                self.before_hook()
            result = executor()
            if self.after_hook:
                self.after_hook()
            if rollback:
                # rollback even when success, used for testing
                raise SuccessRollback

            if self.max_times and self.event_id >= self.max_times\
                    or self.end_condition and self.end_condition():
                # stop iteration
                self.down()

            return result
        except WaitForNextCycle:
            return
        except Exception as e:
            self._error = Error(e)
            if config.task.console_log_execution:
                print(f'EXECUTE {self} ERROR:', self._error.full_info)
            self.done_execution()
        finally:
            self._event_id = None
            # self._on_schedule = None  # fire for _execute and back
            return close_connections()

    @cached_property
    def task_settings(self):
        """
        Serialize TaskClass model instance
        :return:
        """
        from utilmeta.ops.models.task import TaskSettings
        return TaskSettings.get(self.name)

    @property
    def task_distribution(self):
        """
        Serialize TaskClass model instance
        :return:
        """
        if self._distribution:
            return self._distribution
        from utilmeta.ops.models.task import TaskDistribution
        return TaskDistribution.get(self.task_settings)

    @cached_property
    def task_class(self):
        from utilmeta.ops.models.task import NativeTask
        return NativeTask.get(self.__class__.cls_path)

    @classmethod
    def deserialize(cls, inst) -> 'Task':
        from utilmeta.ops.models.task import TaskSettings
        if not isinstance(inst, TaskSettings):
            raise TypeError(f'Task can only deserialize TaskInstance object, got {inst}')
        kwargs = dict(inst.settings)
        kwargs.update(
            name=inst.name,
            group=inst.group,
            schedule=cls.Schedule(**inst.schedule) if inst.schedule else None,
            interval=inst.interval,
            max_times=inst.max_times,
            start_time=inst.start_time,
            looped=inst.looped,
            query=inst.query,
            stop_time=inst.stop_time,
            dist_by_param=inst.dist_by_param,
            dist_by_event=inst.dist_by_event,
            event_abandon_window=inst.event_abandon_window,
            event_abandon_expired=inst.event_abandon_expired,
        )
        return cls(**kwargs)

    @property
    def schedule(self):
        return self._schedule

    @property
    def interval(self):
        return self._interval

    @interval.setter
    def interval(self, val):
        # check and reschedule thread timers
        self._interval = val

    def load_cycle_start(self):
        if self._cycle_start_time:
            return self._cycle_start_time
        if self.task_settings:
            self._cycle_start_time = self.task_settings.start_time
            if not self._cycle_start_time:
                self._cycle_start_time = self.task_settings.start(delta=self.get_interval_delta())
        else:
            self._cycle_start_time = time_now()
        return self._cycle_start_time

    @property
    def cycle_start_time(self) -> datetime:
        return self.load_cycle_start()

    def iter_exec_time(self, from_time: datetime = None) -> Iterator[datetime]:
        if self.looped:
            return
        from_time = from_time or time_now()
        if self.schedule:
            for exec_time in self.schedule.iter_from(start_time=from_time):
                yield exec_time
            return
        if not self.interval:
            return
        start_time = self.cycle_start_time
        if not start_time:
            return
        period = (from_time - start_time).total_seconds()
        last_exec_time = start_time + timedelta(seconds=(period // self.interval) * self.interval)
        t = 1
        while True:
            yield last_exec_time + timedelta(seconds=self.interval * t)
            t += 1

    def get_next_exec_time(self, last_exec: datetime) -> Optional[datetime]:
        if self.looped:
            return
        if self.schedule:
            try:
                return next(self.schedule.iter_from(start_time=last_exec + task_config.min_timedelta))
            except StopIteration:
                return None
        if not self.interval:
            return None
        return last_exec + timedelta(seconds=self.interval)

    def get_interval_delta(self):
        if not self.interval_delta_ratio:
            return 0
        if not self.interval:
            return 0
        return (random.random() * 2 - 1) * self.interval_delta_ratio * self.interval

    def load_current_delay(self) -> Optional[float]:
        """
        Load current delay, include expected execution time
        :return:
        """
        try:
            exec_time = self.next_event.exec_time
        except (TypeError, AttributeError, exc.DatabaseError):
            exec_time = next(self.iter_exec_time())
        self._expect_exec_time = exec_time
        return (exec_time - time_now(exec_time)).total_seconds()

    @property
    def status(self) -> str:
        return self._status

    def load_status(self):
        dist = self._distribution
        if not dist:
            self.sync_distribution()
            return
        if dist.active ^ self.active:
            self._status = dist.status

    @property
    def active(self) -> bool:
        return self.status in (TaskStatus.busy, TaskStatus.idle)

    @property
    def result(self):
        return self._result

    @property
    def error(self) -> Error:
        return self._error

    @property
    def timeout(self) -> bool:
        return self._timeout

    @property
    def success(self) -> bool:
        return self._success

    def sync_execution(self):
        if not self.event_id:
            # one-shot or daemon-cycle event, just execute
            return True
        if not self.exec_time:
            # maybe worker cycle task
            return True
        return task_config.manager.sync_execution(self)

    def done_execution(self, results: List[BaseJob] = ()):
        if not self.event_id:
            return
        if self._done_time:
            return
        self._done_time = time_now()
        return task_config.manager.done_execution(self, results)

    def sync_distribution(self, execute: bool = False, done: bool = False):
        return task_config.manager.sync_distribution(self, execute=execute, done=done)

    @ignore_errors
    def relieve_alert(self, types=None, ident: str = None):
        return task_config.manager.alert_error(
            self,  relieve=True,
            ident=ident, type=types
        )

    @ignore_errors
    def alert_error(self, type: str, downgrade: bool = False, ident: str = None,
                    level: str = AlertLevel.CRITICAL, message: str = ''):
        return task_config.manager.alert_error(
            self, type=type, downgrade=downgrade,
            ident=ident, level=level, message=message
        )

    def pause(self):
        if self.status != TaskStatus.pause:
            self._status = TaskStatus.pause
            self.sync_distribution()

    def resume(self):
        if self.status == TaskStatus.pause:
            self._status = TaskStatus.idle
            self.sync_distribution()

    def down(self):
        if self.status != TaskStatus.down:
            self._status = TaskStatus.down
            self.sync_distribution()

    def _loop_daemon(self):
        while True:
            if not self.daemon():
                break

    def _loop_cycle(self):
        while True:
            if self.status == TaskStatus.down:
                break
            self.execute(from_cycle=True)
            if not self.min_loop_interval:
                continue
            if self.exec_time:
                seconds = max(self.min_loop_interval -
                              (time_now(self.exec_time) - self.exec_time).total_seconds(), 0)
                time.sleep(seconds)
            else:
                time.sleep(self.min_loop_interval)

    def start(self, block: bool = False):
        if not self.active:
            self._status = TaskStatus.idle
        # self.sync_distribution()
        if self.looped:
            if block:
                # block until break
                self._loop_cycle()
            else:
                from concurrent.futures import ThreadPoolExecutor
                executor = ThreadPoolExecutor(max_workers=1)
                executor.submit(self._loop_cycle)
            return
        if block:
            # block until break
            self._loop_daemon()
        else:
            from concurrent.futures import ThreadPoolExecutor
            executor = ThreadPoolExecutor(max_workers=1)
            executor.submit(self._loop_daemon)

    def __str__(self):
        return self._repr()

    def __repr__(self):
        return self.__str__()

    @property
    def looped(self):
        return self._looped

    def daemon(self, cycle_interval: int = None, directly_execute: bool = False) -> bool:
        delay = None
        cycle = cycle_interval or task_config.worker_cycle_interval
        try:
            if self.status == TaskStatus.down:
                # task is down
                raise StopIteration
            if self.status == TaskStatus.pause:
                raise WaitForNextCycle

            if directly_execute:
                self.execute(from_cycle=True)
            else:
                delay = self.load_current_delay()
                if delay > cycle:
                    raise WaitForNextCycle
                self.delay_execute(interval=delay, from_cycle=True)

            raise WaitForNextCycle
        except StopIteration:
            # end this daemon task when there is no task to perform
            return False
        except WaitForNextCycle:
            if cycle_interval:
                # cycle from manager
                return True
            if delay:
                cycle = max(delay - task_config.min_interval, cycle)
        except Exception as e:
            self.alert_error(type='daemon_error', message=Error(e).full_info)
        if cycle_interval:
            # cycle from manager
            return True
        time.sleep(cycle)
        # self.daemon()  # cycle single task
        return True

    # -- METHODS here is free to inherit

    def reduce(self, jobs: List[BaseJob]):
        if not jobs:
            return None
        if not self.iterable:
            return jobs[0].result
        # if self.ready:
        #     return self.job_result
        return [job.result for job in jobs]

    def pre_condition(self) -> bool:
        if self.stop_time:
            return time_now() < self.stop_time
        return True

    def end_condition(self) -> bool:
        if self.one_off:
            return False
        return False

    def __or__(self: T1, other: T2) -> Union[T1, T2]:
        pass

    def __invert__(self: T) -> T:
        pass
