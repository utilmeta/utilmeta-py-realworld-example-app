from django.http.response import HttpResponseBase
from django.db.models import Model
from utilmeta.util.common import (Reg, HAS_BODY_METHODS, get_doc, pop_null,
                                  PermissionDenied, BadRequest, Gone, MethodNotAllowed,
                                  handle_timeout, HOOK_TYPES, UnitAttr, handle_retries,
                                  METHOD_DEFAULT_STATUS, Attr, model_tag,
                                  METHOD_IDEMPOTENCY, import_util, cached_property,
                                  NotFound, make_header, METHODS, Key, multi, CONTENT_TYPE)
from utilmeta.util.response import Response
from utilmeta.util.rule import Rule
from utilmeta.util.base import Util
from utilmeta.util.auth import Auth
from utilmeta.util.request import Request
from utilmeta.util.cache import Cache

from datetime import timedelta
from functools import partial, wraps
from typing import Callable, Union, List, Dict, Type, Optional, TypeVar

T = TypeVar('T')
COOKIE = 'cookie'
NORMAL = 'Normal'

__all__ = ['Unit']


class Unit(Util):
    _util_slots = ['cache', 'request', 'response0']

    def __init__(self, f: Callable = None, *,
                 method: str = None,
                 path: str = None,
                 regex: bool = None,
                 alias: str = None,
                 path_unit: str = None,
                 public: bool = None,
                 depreciated: bool = None,
                 idempotent: bool = None,
                 cache: Cache = None,
                 request: Request = None,
                 response: Response = None,
                 transaction: Union[str, List[str], bool] = None,
                 timeout: timedelta = None,
                 wrapper: Callable = None,
                 max_retries: int = None,
                 block: bool = None,
                 parser_cls: str = None,
                 parser_kwargs: dict = None,
                 ):
        # public = False : still mount to resolver, don't doc (don't save data), don't serve request

        if f and f.__name__.lower() in METHODS:
            method = f.__name__.lower()
        elif method:
            method = method.lower()
            assert method in METHODS
        else:
            method = None
            
        self._init_f = f
        self._type = None
        for ht in HOOK_TYPES:
            if getattr(f, ht, None):
                self._type = ht

        self.inner = bool(getattr(f, Attr.INNER, False))
        self.depreciated = depreciated or False
        self.method = method
        self.name = self.__name__ = f.__name__ if f else None
        self.doc = self.__doc__ = get_doc(f)
        self.wrapper = wrapper
        if idempotent is None and method:
            idempotent = METHOD_IDEMPOTENCY.get(method)
        self.idempotent = idempotent

        if max_retries:
            assert max_retries >= 1, f'Unit max_retries must >= 1, got {max_retries}'
        self.max_retries = int(max_retries or 1)

        if depreciated:
            @wraps(f)
            def gone(*_, **__):
                raise Gone('This API is depreciated')
            f = gone
        if not f:
            def f(*_, **__):
                return None
        else:
            from utilmeta.conf import config
            if not config.utilmeta:
                raise RuntimeError('Service not initialized')
        assert callable(f), f'Invalid Unit function: {f}'
        if wrapper:
            # test if wrapper is valid
            wrapper(f)

        self.alias = alias
        self.path = (path or '').strip('/')

        from utilmeta.conf import config
        self.parser_cls_string = parser_cls or config.preference.request_parser_cls_string

        self.path_config = self.parser_cls.PathConfig(
            path=path, path_unit=path_unit, regex=regex
        ) if path else None

        self.parser = self.parser_cls(
            f, from_class=...,
            from_request=True,
            path_config=self.path_config,
            parse_params=bool(method),
            parse_result=False,
            **(parser_kwargs or {})
        )
        # function will get id before unit
        if self.method and not self.has_body:
            if self.parser.body:
                raise TypeError(f'Unit method: {self.method} do not support request body')
        super().__init__(locals())

        self.f = f
        self.parent = None
        self.path_unit = path_unit or Reg.URL_ALL
        self.regex_list = []

        # --- transaction
        transaction_using = []
        if isinstance(transaction, str):
            transaction_using = [transaction]
        elif multi(transaction):
            transaction_using = [str(t) for t in transaction]
        elif transaction:
            transaction_using = ['default']
        self.transaction_wrapper = None
        self.transaction_using = transaction_using
        if transaction:
            from django.db.transaction import atomic
            for using in transaction_using:
                from utilmeta.conf import config
                if using not in config.databases:
                    raise ValueError(f'Unit transaction using alias: {repr(using)} not in databases')
                self.transaction_wrapper = atomic(using=using)(self.transaction_wrapper)\
                    if self.transaction_wrapper else atomic(using=using)
        # --- transaction

        if request:
            assert isinstance(request, Request), \
                f'Unit request must be a Request object, got {request}'
        if cache:
            assert isinstance(cache, Cache), \
                f'Unit request must be a Cache object, got {cache}'
        if response:
            assert isinstance(response, Response)

        self.request: Request = request or Request()
        self.cache: Cache = cache

        if getattr(self.f, UnitAttr.log, None) is False:
            from utilmeta.util.log import Logger
            self.request.log_option = Logger.OMIT

        if timeout:
            assert isinstance(timeout, timedelta), \
                f"Unit timeout must be a valid timedelta. got {timeout}"
        self.timeout = timeout
        self.default_response = False
        # self.preserve = None

        resp = self.parser.return_type
        if isinstance(response, Response):
            self.response = response
        elif isinstance(resp, Response):
            self.response = resp
        else:
            self.default_response = True
            self.response = Response(
                schema=resp,
                status=getattr(f, Attr.STATUS, METHOD_DEFAULT_STATUS[self.method] if self.inner else 200),
            )

        if self.response.override is not True:
            self.response.override = False

        # self.template = {}
        self.mounted = self.name not in METHODS
        if not self.mounted and alias:
            raise ValueError(f'Core unit for method: <{self.name}> cannot assign alias ({alias})')

        if public is None:
            public = True
        self.public = bool(public)
        if block is None:
            block = True
        self.block = bool(block)
        self.unit_schema = {}
        self.endpoint_path = None
        self.header_as_params = False

        executor = self.parser.wrapper
        if self.wrapper:
            executor = self.wrapper(executor)
        if self.max_retries > 1:
            executor = handle_retries(self.max_retries)(executor)
        if self.transaction_wrapper:
            executor = self.transaction_wrapper(executor)
        if self.timeout:
            executor = handle_timeout(self.timeout)(executor)
        self.executor = executor

    @cached_property
    def parser_cls(self):
        from utilmeta.util.parser.req import RequestParser
        if not self.parser_cls_string:
            return RequestParser
        cls = import_util(self.parser_cls_string)
        if not issubclass(cls, RequestParser):
            raise TypeError(f'Preference.request_parser_cls must inherit {RequestParser}, got {cls}')
        return cls

    @classmethod
    def from_func(cls: Type[T], func: Callable, **kwargs) -> T:
        if not callable(func):
            raise TypeError(f'Unit only accept callable func')
        if isinstance(func, Unit):
            return func
        import inspect
        for key, val in inspect.signature(cls).parameters.items():
            v = getattr(func, key, None)
            if v is None:
                continue
            kwargs[key] = v
        return cls(func, **kwargs)

    @property
    def id(self):
        return getattr(self, Key.ID, None)

    @property
    def has_body(self):
        return self.method in HAS_BODY_METHODS

    @property
    def regex(self):
        if self.path_config:
            return self.path_config.regex
        return False

    def _make_path(self, declare_path):
        if self.__declare_path__:
            if self.__declare_path__ != declare_path:
                pass
                # import warnings
                # warnings.warn(f'same unit mount to different '
                #               f'endpoint path: {repr(self.__declare_path__)}, {repr(declare_path)}')
            return
        self.__declare_path__ = declare_path
        for slot in self._util_slots:
            util = getattr(self, slot, None)
            if isinstance(util, Util):
                path = f'{self.__declare_path__}.{slot}'
                if util.__declare_path__:
                    if util.__declare_path__ != path:
                        pass
                        # import warnings
                        # warnings.warn(f'same util: {util} mount to different '
                        #               f'path: {repr(path)}, {repr(util.__declare_path__)}')
                else:
                    util.__declare_path__ = path

    def generate(self,
                 path: str = '', ignore: bool = False,
                 prepend: str = None,
                 auth: Auth = None, model: Type[Model] = None,
                 before_hooks: List['Unit'] = (),
                 after_hooks: List['Unit'] = (),
                 error_hooks: Dict[Type[Exception], 'Unit'] = None,
                 ):
        from utilmeta.conf import config
        from utilmeta.util.common import RequestType
        from utilmeta.core.sdk import ResponseSchema, APIUnitData
        self.request.end_point = True   # valid request in Unit level

        responses = []
        response = self.response
        schema = response.schema

        if response.name:
            responses.append(ResponseSchema(name=response.name, **response.template()))

        for hook in after_hooks:
            if hook.response.schema:
                schema = hook.response.schema
            if not hook.default_response:
                responses.append(ResponseSchema(name=hook.response.name, **hook.response.template(schema)))

        response.schema = schema
        if not responses:
            responses.append(ResponseSchema(**response.template()))

        if not self.parser.vacuum:
            responses.append(ResponseSchema(
                name=BadRequest.__name__,
                **self.response.template(status=400)
            ))
        if self.path or prepend:
            responses.append(ResponseSchema(
                name=NotFound.__name__,
                **self.response.template(status=404)
            ))
        if auth or self.request.auth:
            responses.append(ResponseSchema(
                name=PermissionDenied.__name__,
                **self.response.template(status=403)
            ))

        if error_hooks:
            responses += [ResponseSchema(name=e.__name__, **u.response.template()) for e, u in error_hooks.items()]

        responses_dict = {}
        for resp in responses:
            responses_dict[str(resp.name)] = resp

        headers = {}
        for hook in before_hooks:
            hook: Unit
            if hook.header_as_params:
                headers.update(hook.parser.query)

        if self.parser.body:
            if CONTENT_TYPE not in headers:
                ct = self.parser.content_type
                if ct != RequestType.JSON:
                    headers[CONTENT_TYPE] = Rule(value=ct)

        if self.endpoint_path and self.endpoint_path != path:
            raise ValueError(f'same Unit mount to different path: {repr(self.endpoint_path)}, {repr(path)}')
        self.endpoint_path = path
        if config.ops and not ignore:
            config.ops.add_endpoint(self)

        self.parser.headers.update(make_header(headers))
        self.unit_schema = pop_null(APIUnitData(
            document=self.doc or None,
            method=self.method,
            model=model_tag(model) if model else None,
            path=path or None,
            prepend=prepend or None,
            append=self.path or None,
            regex=self.regex,
            idempotent=self.idempotent,
            request=self.request.get_params_schema(external_auth=auth),
            responses=sorted(list(responses_dict.values()), key=lambda r: r['status']),
            **Rule.note(dict(
                params=self.parser.path_params,
                query=self.parser.query,
                data=self.parser.body,
                headers=self.parser.headers,
            ))
        ))
        return self.unit_schema

    def valid_before(self):
        for key, val in self.parser.query.items():
            key: str
            assert key.islower(), f"before_hook defined Headers key should be lowercase, got {key}"
            if key == COOKIE:
                Request.Query.valid(val)
        self.header_as_params = True

    @property
    def main(self):
        return self.method and self.parent

    @property
    def type(self):
        if self.main:
            return UnitAttr.main
        return self._type

    @property
    def log_type(self) -> str:
        from .api import APIMeta
        from .module import ModuleMeta
        if isinstance(self.parent, APIMeta):
            prefix = 'api.'
        elif isinstance(self.parent, ModuleMeta):
            prefix = 'mod.'
        else:
            return UnitAttr.unit
        if self.method:
            return prefix + self.method
        return prefix + self._type

    @property
    def log_parent(self) -> Optional[str]:
        import inspect
        if inspect.isclass(self.parent):
            return self.parent.__name__
        return None

    def serve(self, api) -> HttpResponseBase:
        from .api import API
        api: API
        request = api.request
        if not self.main:
            raise TypeError('Auxiliary Unit should not use for server requests')
        if not self.public:
            raise BadRequest('Private api reject requests from network')
        if self.mounted:
            request.allow_methods = (self.method,)
        if request.method != self.method:
            raise MethodNotAllowed(method=request.method, allows=[self.method])
        if request.options:
            request.allow_headers += tuple(self.parser.headers.keys())
            return api.options()
        args, kwargs = self.parser.parse_request(request)
        result = self(api, *args, **kwargs)
        return self.response(result)

    def accepted_response(self, util, *_, **__):
        from .api import API
        util: API
        return util.response.accepted()

    def __call__(self, util, *args, **kwargs):
        request: Request = util.request

        # only handle the main METHODS, omit before / after hooks call
        if self.parent:
            if not isinstance(util, self.parent):
                util = self.parent(request)
            if request.options:
                return util.options()
            util.response = self.response

        if self.request:
            util.request = self.request(request)

        if self.main:
            util.request.enter_unit(self.endpoint_path)
        util.request.valid_response(self.response)

        # inner decorate the func
        executor = self.executor
        if self.cache:
            util.cache = self.cache.make_cache(request)
            if util.cache.api_cache:
                request.cached = True

                def whether_cached(exe):
                    # if exe func is executed, func is not cached
                    @wraps(exe)
                    def call(*_, **__):
                        request.cached = False
                        return exe(*_, **__)
                    return call
                executor = partial(util.cache, whether_cached(executor))

        with request.log(self):
            return executor(util, *args, **kwargs)
