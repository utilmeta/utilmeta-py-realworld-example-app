from django.db.models import Model
from django.db.models.fields.related_descriptors import (
    ForeignKeyDeferredAttribute, ForwardManyToOneDescriptor,
    ForwardOneToOneDescriptor, ManyToManyDescriptor,
    ReverseManyToOneDescriptor, ReverseOneToOneDescriptor,
)
from django.db.models import Field as BaseField

from django.db.models.fields import SmallAutoField, AutoField, BooleanField, BigIntegerField,\
    BinaryField, BigAutoField, CharField, CommaSeparatedIntegerField, DateField, \
    DateTimeField, DecimalField, DurationField, EmailField, \
    FilePathField, FloatField, GenericIPAddressField, IntegerField, \
    PositiveIntegerField, PositiveSmallIntegerField, SlugField, \
    SmallIntegerField, TextField, TimeField, URLField, UUIDField

try:
    from django.db.models.fields import PositiveBigIntegerField
except ImportError:
    pass

#   NullBooleanField  is deprecated. Support for it (except in historical migrations) will be removed in Django 4.0
#   IPAddressField: IPAddressField has been removed except for support in historical migrations

from django.db.models.fields.files import FileField, ImageField
from django.db.models import CASCADE, PROTECT, DO_NOTHING, \
    SET, SET_DEFAULT, SET_NULL, NOT_PROVIDED
from django.db.models.constraints import *

try:
    from django.db.models import RESTRICT
    # new feature in django 3.1
except ImportError:
    pass

from django.db.models.fields.related import OneToOneField, ForeignKey, ManyToManyField, \
    ManyToOneRel, OneToOneRel, ManyToManyRel

from utilmeta.util.common.constant import Reg
from utilmeta.util.common.datastructure import Static


class ModelOptions:
    base_manager_name = '_base_manager'
    default_manager_name = None
    db_table = ''
    ordering = []
    indexes = []
    constraints = []
    unique_together = []
    index_together = []
    select_on_save = False
    permissions = []
    # object_name = None
    get_latest_by = None
    order_with_respect_to = None
    db_tablespace = None
    required_db_features = []
    required_db_vendor = None
    # auto_field = None
    abstract = False
    managed = True
    proxy = False
    swappable = None

    def __init_subclass__(cls, **kwargs):
        from .util.common import SEG
        for key in list(ModelOptions.__dict__.keys()):
            if SEG not in key:
                delattr(ModelOptions, key)


MODEL_OPTIONS = [k for k in ModelOptions.__dict__.keys() if not k.startswith('_')]


def __postgres_contains():
    from utilmeta.util.common import DB
    from utilmeta.conf import config
    for db in config.databases.values():
        if db.type == DB.PostgreSQL:
            return True
    return False


def __all_sqlite():
    from utilmeta.util.common import DB
    from utilmeta.conf import config
    if not config.databases:
        return False
    for db in config.databases.values():
        if db.type != DB.SQLite:
            return False
    return True


class RawJSONField(BaseField):
    def __init__(self, verbose_name=None, name=None, encoder=None, decoder=None, **kwargs):
        from utilmeta.util.common.encoder import MetaJSONEncoder
        self.encoder = encoder or MetaJSONEncoder
        self.decoder = decoder
        super().__init__(verbose_name, name, **kwargs)

    def get_internal_type(self):
        # act like TextField
        # return 'JSONField'
        return 'TextField'

    def db_type(self, connection):
        return 'text'

    def from_db_value(self, value, expression, connection):
        if value is not None:
            return self.to_python(value)
        return value

    def to_python(self, value):
        import json
        if value is not None:
            try:
                return json.loads(value)
            except (TypeError, ValueError):
                return value
        return value

    def get_prep_value(self, value):
        import json
        if value is not None:
            return json.dumps(value, cls=self.encoder, ensure_ascii=False)
        return value

    def value_to_string(self, obj):
        return self.value_from_object(obj)

    def get_db_prep_value(self, value, connection, prepared=False):
        import json
        if value is not None:
            return json.dumps(value, cls=self.encoder, ensure_ascii=False)
        return value


if __all_sqlite():
    _JSONField = RawJSONField
else:
    try:
        from django.db.models import JSONField as _JSONField
    except ImportError:
        # use default
        _JSONField = RawJSONField

# same implement of origin field, just export the same interface for migrations of different databases


class JSONField(_JSONField):
    def __init__(
        self, verbose_name=None, name=None, encoder=None, decoder=None,
        **kwargs,
    ):
        from utilmeta.util.common.encoder import MetaJSONEncoder
        encoder = encoder or MetaJSONEncoder
        super().__init__(verbose_name, name, encoder=encoder, decoder=decoder, **kwargs)

    def get_prep_value(self, value):
        import json
        from utilmeta.conf import config
        if value is None:
            return value
        if config.preference.json_encoder_allow_nan is not False:
            value = config.preference.process_json_value(value)
        return json.dumps(value, cls=self.encoder)

    def from_db_value(self, value, expression, connection):
        if value is None:
            return value
        if isinstance(value, dict):
            return value
        if isinstance(value, (list, set, tuple)):
            return list(value)
        return super().from_db_value(value, expression, connection)


class _ArrayField(RawJSONField):
    def __init__(self, base_field, size=None, **kwargs):
        self.base_field = base_field
        self.size = size
        super().__init__(**kwargs)

    def get_internal_type(self):
        return 'ArrayField'

    def validate(self, value, model_instance):
        from django.core import exceptions
        super().validate(value, model_instance)
        for index, part in enumerate(value):
            self.base_field.validate(part, model_instance)
        if isinstance(self.base_field, self.__class__):
            if len({len(i) for i in value}) > 1:
                raise exceptions.ValidationError(
                    self.error_messages['nested_array_mismatch'],
                    code='nested_array_mismatch',
                )

    def run_validators(self, value):
        super().run_validators(value)
        for index, part in enumerate(value):
            self.base_field.run_validators(part)

    def to_python(self, value):
        import json
        if isinstance(value, str):
            if value.startswith('{') and value.endswith('}'):
                str_val = value.rstrip('}').lstrip('{')
                vals = str_val.split(',') if str_val else []
            else:
                vals = json.loads(value)
            value = [self.base_field.to_python(val) for val in vals]
        return value

    # def get_db_prep_value(self, value, connection, prepared=False):
    #     if isinstance(value, (list, tuple)):
    #         return [self.base_field.get_db_prep_value(i, connection, prepared=False) for i in value]
    #     return value

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        kwargs.update({
            'base_field': self.base_field.clone(),
            'size': self.size,
        })
        return name, path, args, kwargs


if __postgres_contains():
    try:
        from django.contrib.postgres.fields import HStoreField, BigIntegerRangeField, CICharField, CIEmailField, \
            CITextField, DateRangeField, DateTimeRangeField, DecimalRangeField, IntegerRangeField, RangeField
        from django.contrib.postgres.search import SearchQueryField, SearchVectorField
        from django.contrib.postgres.fields import ArrayField as _ArrayField
    except (ImportError, ModuleNotFoundError):
        # ignore when postgres packages not installed
        pass
# JSONField and ArrayField here is suitable for all databases but less featured than postgres field
# if you need the featured field, use from django.contrib.postgres.fields import ArrayField, JSONField


class ArrayField(_ArrayField):
    # provide the identical interface for array field for all db backends
    def _from_db_value(self, value, expression, connection):
        # need to compat str
        if isinstance(value, str):
            import json
            if value.startswith('{') and value.endswith('}'):
                str_val = value.rstrip('}').lstrip('{')
                vals = str_val.split(',') if str_val else []
            else:
                vals = json.loads(value)
            converter = getattr(self.base_field, 'from_db_value', lambda x: x)
            return [converter(val) for val in vals]
        try:
            return super()._from_db_value(value, expression, connection)
        except AttributeError:
            return value

    def from_db_value(self, value, expression, connection):
        if isinstance(value, list):
            return value
        return self._from_db_value(value, expression, connection)


from utilmeta.dist.id import DistributedID


class RichTextField(TextField):
    def get_prep_value(self, value):
        if not value:
            return ''
        from .util.secure.xss_filter import XSSHtml
        with XSSHtml() as parser:
            return parser.clean(str(value))


class PasswordField(CharField):
    @classmethod
    def guess_encoded(cls, pwd: str):
        if len(pwd) < 60:
            return False
        if pwd.count('$') < 3:
            return False
        if not pwd.endswith('='):
            return False
        return True

    def get_prep_value(self, value):
        if self.null and value is None:
            return None
        from django.contrib.auth.hashers import make_password
        from .util.common.functional import gen_key
        if self.guess_encoded(value):
            # already encoded, maybe error update using save() but did not specify update_fields
            return value
        return make_password(value, gen_key(self.salt_length))

    def __init__(self, max_length: int, min_length: int = 1, salt_length=32,
                 regex: str = None, *args, **kwargs):
        kwargs['max_length'] = 80 + salt_length
        assert isinstance(max_length, int) and isinstance(min_length, int) and max_length >= min_length > 0, \
            f'Password field length config must satisfy max_length >= min_length > 0'
        self.salt_length = salt_length
        self.regex = regex
        self._max_length = max_length
        self._min_length = min_length
        super().__init__(*args, **kwargs)

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        kwargs["max_length"] = self._max_length
        kwargs["min_length"] = self._min_length
        kwargs["salt_length"] = self.salt_length
        kwargs["regex"] = self.regex
        return name, path, args, kwargs


class ChoiceField(CharField):
    from typing import Union, Type, List, Optional
    from enum import Enum

    def get_prep_value(self, value):
        if self.null and value is None:
            return None
        v = str(value)
        if v in self.keys:
            if self.store_key:
                return v
            return self.choices_map[v]
        if not self.store_key:
            if v in self.values:
                return v
            if self.none_default:
                raise ValueError(f"ChoiceField contains value: {value} out of choices scope {self.values}, "
                                 f"if you don't wan't exception here, set a default value")
        val = self.reverse_choices_map.get(v)
        if val:
            return val
        if self.none_default:
            raise ValueError(f"ChoiceField contains value: {value} out of choices scope {self.keys + self.values}, "
                                 f"if you don't wan't exception here, set a default value")
        return self.default

    def from_db_value(self, value, expression=None, connection=None):
        return self.to_python(value)
        # return str(value)

    def to_python(self, value):
        # print('TO PYTHON:', value, self.retrieve_key)
        if value is None:
            return value
        if self.retrieve_key:
            if value in self.keys:
                return value
            return self.reverse_choices_map.get(value, self.default)
        if value in self.values:
            return value
        return self.choices_map.get(value, '')

    def __init__(self, choices: Union[Type[Static], Type[Enum], dict, tuple, List[str]],
                 retrieve_key: bool = True, store_key: bool = True, max_length: int = None,
                 default: Optional[str] = NOT_PROVIDED, *args, **kwargs):
        from .util.common.functional import repeat, multi
        import inspect
        import collections
        from enum import Enum

        _max_length = 0

        keys = []
        values = []
        _choices = []
        if inspect.isclass(choices) and issubclass(choices, Static) or isinstance(choices, Static):
            choices = choices.dict(reverse=True)
        if inspect.isclass(choices) and issubclass(choices, Enum):
            choices = dict(choices.__members__)

        if not choices:
            raise ValueError(f'ChoiceField must specify choices, got {choices}')
        if isinstance(choices, collections.abc.Iterator):
            choices = list(choices)

        if isinstance(choices, tuple):
            _max_length = len(str(len(choices) - 1))
            for i, c in enumerate(choices):
                if multi(c):
                    choices = list(choices)
                    _max_length = 0
                    # classic django choices
                    break

                keys.append(str(i))
                values.append(str(c))
                _choices.append((str(i), str(c)))

        if isinstance(choices, list):
            for t in choices:
                assert type(t) == tuple and len(t) == 2, \
                    ValueError('Choice field for list choices must be a 2-item tuple')
                if _max_length < len(str(t[0])):
                    _max_length = len(str(t[0]))
                keys.append(str(t[0]))
                values.append(str(t[1]))
                _choices.append((str(t[0]), str(t[1])))

        if isinstance(choices, dict):
            for k in choices.keys():
                if _max_length < len(str(k)):
                    _max_length = len(str(k))
                v = choices[k]

                if isinstance(v, Enum):
                    items = (str(v.value), v.name)
                else:
                    items = (str(k), str(v))

                keys.append(items[0])
                values.append(items[1])
                _choices.append(items)

        if not _choices:
            raise ValueError(f'ChoiceField choices must be list/tuple/dict got {choices}')

        if not store_key:
            retrieve_key = False
        elif repeat(keys + values):
            raise ValueError(f"ChoiceField choices's keys {keys} and values {values} should't repeat")

        self.keys = tuple(keys)
        self.values = tuple(values)
        self.value_set = self.keys + self.values
        self.retrieve_key = retrieve_key
        self.store_key = store_key

        self.choices_map = dict(_choices)
        self.reverse_choices_map = {c[1]: c[0] for c in _choices}

        if isinstance(default, Enum):
            default = default.value

        self.default = default
        if default is None:
            kwargs['null'] = True
        elif not self.none_default:
            if self.store_key:
                if str(default) not in self.keys:
                    try:
                        self.default = self.reverse_choices_map[str(default)]
                    except KeyError:
                        raise ValueError(f'ChoiceField default value: {default} '
                                         f'out of scope: {self.keys} and {self.values}')
            else:
                if str(default) not in self.values:
                    try:
                        self.default = self.choices_map[str(default)]
                    except KeyError:
                        raise ValueError(f'ChoiceField default value: {default} '
                                         f'out of scope: {self.keys} and {self.values}')

            # self.default = str(default) \
            #     if str(default) in self.keys else self.reverse_choices_map[default]
            if isinstance(self.default, str):
                if _max_length < len(self.default):
                    _max_length = len(self.default)
        if not self.store_key:
            _max_length = max([len(c) for c in self.choices_map.values()])

        if max_length and max_length < _max_length:
            raise ValueError(f'ChoiceField max_length: {max_length} '
                             f'if less than the longest choice length: {_max_length}')

        kwargs['max_length'] = max_length or _max_length
        kwargs['default'] = self.default
        kwargs['choices'] = tuple(_choices)
        self._choices = _choices    # be list type
        super().__init__(*args, **kwargs)

    @property
    def none_default(self):
        return self.default is NOT_PROVIDED

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        kwargs['retrieve_key'] = self.retrieve_key
        kwargs['store_key'] = self.store_key
        kwargs['choices'] = self._choices
        return name, path, args, kwargs


class CrossServiceForwardManyToOneDescriptor(ForwardManyToOneDescriptor):
    def __init__(self, field_with_rel: 'CrossServiceKey'):
        self.field = field_with_rel
        super().__init__(field_with_rel)

    def is_cached(self, instance):
        return self.field.is_cached(instance)

    def get_queryset(self, **hints):
        from utilmeta.util.query.remote import RemoteQuerySet
        return RemoteQuerySet(
            service_name=self.field.service_name,
            app_label=self.field.app_label,
            model_name=self.field.model_name
        ).all()
        # return self.field.remote_field.model._base_manager.db_manager(hints=hints).all()

    def get_prefetch_queryset(self, instances, queryset=None):
        pass

    def get_object(self, instance):
        qs = self.get_queryset(instance=instance)
        # Assuming the database enforces foreign keys, this won't fail.
        return qs.get(pk=getattr(instance, self.field.name))

    # def __get__(self, instance, cls=None):
    #     pass
    #
    # def __set__(self, instance, value):
    #     pass

    def __reduce__(self):
        """
        Pickling should return the instance attached by self.field on the
        model, not a new copy of that descriptor. Use getattr() to retrieve
        the instance directly from the model.
        """
        return getattr, (self.field.model, self.field.name)


class CrossServiceKey(CharField):
    # related_accessor_class = ReverseManyToOneDescriptor
    forward_related_accessor_class = CrossServiceForwardManyToOneDescriptor

    def __init__(self, service: str, app: str, model: str, on_delete, max_length: int = 120,
                 on_fail=None, related_name: str = None, timeout: int = None,
                 unique: bool = False, **kwargs):
        self.service_name = service
        self.app_label = app
        self.model_name = model
        self.on_delete = on_delete
        self.on_fail = on_fail
        self.related_name = related_name
        self.timeout = timeout
        super().__init__(max_length=max_length, unique=unique, **kwargs)

    @property
    def target_model(self):
        return f'{self.app_label}.{self.model_name}'.lower()

    def apply_remote_deletion(self, pks: list):
        if not pks:
            return
        from utilmeta.util.query import MetaQuerySet
        query = MetaQuerySet(model=self.model).filter(**{self.name + '__in': pks})
        if self.on_delete == DO_NOTHING:
            return
        if self.on_delete == CASCADE:
            return query.delete()
        if self.on_delete == SET_DEFAULT:
            return query.update(**{self.name: self.default})
        dec = getattr(self.on_delete, 'deconstruct', None)
        if callable(dec):
            value = dec()[1][0]
            return query.update(**{self.name: value})

    def contribute_to_class(self, cls, name, private_only=False):
        super().contribute_to_class(cls, name, private_only=private_only)
        from utilmeta.conf import config
        if not config.cluster:
            raise TypeError('CrossServiceKey require cluster enabled in config')
        config.cluster.add_cross_key(self)
        setattr(cls, self.name, self.forward_related_accessor_class(self))

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        kwargs.update(
            service=self.service_name,
            app=self.app_label,
            model=self.model_name,
            on_delete=self.on_delete,
            on_fail=self.on_fail,
            timeout=self.timeout,
            related_name=self.related_name
        )
        return name, path, args, kwargs

    # def get_forward_related_filter(self, obj):
    #     """
    #     Return the keyword arguments that when supplied to
    #     self.model.object.filter(), would select all instances related through
    #     this field to the remote obj. This is used to build the querysets
    #     returned by related descriptors. obj is an instance of
    #     self.related_field.model.
    #     """
    #     return {
    #         '%s__%s' % (self.name, rh_field.name): getattr(obj, rh_field.attname)
    #         for _, rh_field in self.related_fields
    #     }
    #
    # def get_reverse_related_filter(self, obj):
    #     """
    #     Complement to get_forward_related_filter(). Return the keyword
    #     arguments that when passed to self.related_field.model.object.filter()
    #     select all instances of self.related_field.model related through
    #     this field to obj. obj is an instance of self.model.
    #     """
    #     base_filter = {
    #         rh_field.attname: getattr(obj, lh_field.attname)
    #         for lh_field, rh_field in self.related_fields
    #     }
    #     descriptor_filter = self.get_extra_descriptor_filter(obj)
    #     base_q = Q(**base_filter)
    #     if isinstance(descriptor_filter, dict):
    #         return base_q & Q(**descriptor_filter)
    #     elif descriptor_filter:
    #         return base_q & descriptor_filter
    #     return base_q
    # def to_python(self, value):
    #     return self.target_field.to_python(value)
    #
    # @property
    # def target_field(self):
    #     return self.foreign_related_fields[0]
    #
    # def get_reverse_path_info(self, filtered_relation=None):
    #     """Get path from the related model to this field's model."""
    #     opts = self.model._meta
    #     from_opts = self.remote_field.model._meta
    #     return [PathInfo(
    #         from_opts=from_opts,
    #         to_opts=opts,
    #         target_fields=(opts.pk,),
    #         join_field=self.remote_field,
    #         m2m=not self.unique,
    #         direct=False,
    #         filtered_relation=filtered_relation,
    #     )]

    # def validate(self, value, model_instance):
    #     if self.remote_field.parent_link:
    #         return
    #     super().validate(value, model_instance)
    #     if value is None:
    #         return
    #
    #     using = router.db_for_read(self.remote_field.model, instance=model_instance)
    #     qs = self.remote_field.model._default_manager.using(using).filter(
    #         **{self.remote_field.field_name: value}
    #     )
    #     qs = qs.complex_filter(self.get_limit_choices_to())
    #     if not qs.exists():
    #         raise exceptions.ValidationError(
    #             self.error_messages['invalid'],
    #             code='invalid',
    #             params={
    #                 'model': self.remote_field.model._meta.verbose_name, 'pk': value,
    #                 'field': self.remote_field.field_name, 'value': value,
    #             },  # 'pk' is included for backwards compatibility
    #         )
    #
    # def resolve_related_fields(self):
    #     related_fields = super().resolve_related_fields()
    #     for from_field, to_field in related_fields:
    #         if to_field and to_field.model != self.remote_field.model._meta.concrete_model:
    #             raise exceptions.FieldError(
    #                 "'%s.%s' refers to field '%s' which is not local to model "
    #                 "'%s'." % (
    #                     self.model._meta.label,
    #                     self.name,
    #                     to_field.name,
    #                     self.remote_field.model._meta.concrete_model._meta.label,
    #                 )
    #             )
    #     return related_fields

    def get_attname(self):
        from utilmeta.util.common import add_field_id
        return add_field_id(self.name)

    def get_attname_column(self):
        attname = self.get_attname()
        column = self.db_column or attname
        return attname, column

    # def get_default(self):
    #     """Return the to_field if the default value is an object."""
    #     field_default = super().get_default()
    #     if isinstance(field_default, self.remote_field.model):
    #         return getattr(field_default, self.target_field.attname)
    #     return field_default
    #
    # def get_db_prep_save(self, value, connection):
    #     if value is None or (value == '' and
    #                          (not self.target_field.empty_strings_allowed or
    #                           connection.features.interprets_empty_strings_as_nulls)):
    #         return None
    #     else:
    #         return self.target_field.get_db_prep_save(value, connection=connection)
    #
    # def get_db_prep_value(self, value, connection, prepared=False):
    #     return self.target_field.get_db_prep_value(value, connection, prepared)
    #
    # def get_prep_value(self, value):
    #     return self.target_field.get_prep_value(value)

    def db_check(self, connection):
        return []

    # def db_type(self, connection):
    #     return self.target_field.rel_db_type(connection=connection)
    #
    # def db_parameters(self, connection):
    #     return {"type": self.db_type(connection), "check": self.db_check(connection)}
    #
    # def convert_empty_strings(self, value, expression, connection):
    #     if (not value) and isinstance(value, str):
    #         return None
    #     return value
    #
    # def get_db_converters(self, connection):
    #     converters = super().get_db_converters(connection)
    #     if connection.features.interprets_empty_strings_as_nulls:
    #         converters += [self.convert_empty_strings]
    #     return converters
    #
    # def get_col(self, alias, output_field=None):
    #     if output_field is None:
    #         output_field = self.target_field
    #         while isinstance(output_field, ForeignKey):
    #             output_field = output_field.target_field
    #             if output_field is self:
    #                 raise ValueError('Cannot resolve output_field.')
    #     return super().get_col(alias, output_field)
