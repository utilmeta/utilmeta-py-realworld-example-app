from .util.message import Message
from utilmeta.util.common import Language


class ErrorMessage(Message, default=Language.en):
    api_name_hint: str


class ErrorMessageEN(ErrorMessage, language=Language.en):
    api_name_hint = "if you define a function or property with this name, please use alias for @api function or move " \
                "the API/Module to router dict"


class ErrorMessageZH(ErrorMessage, language=Language.zh):
    api_name_hint = "如果你在类中定义了相同名称的函数或属性，请使用alias别名的@api函数或将它移至 router 字典中"


message = ErrorMessage(ErrorMessage.__find__(Language.en))
