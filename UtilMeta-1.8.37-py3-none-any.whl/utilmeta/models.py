from .fields import *
from utilmeta.util.query.manager import *

__all__ = ['BaseUser', 'MetaManager', 'MetaQuerySet']


class BaseUser(Model):
    objects = MetaManager()
    username = CharField(max_length=20, unique=True)
    password = PasswordField(min_length=6, max_length=60)
    email = EmailField(unique=True)
    admin = BooleanField(default=False)
    active = BooleanField(default=True)

    signup_time = DateTimeField(auto_now_add=True)
    last_login_time = DateTimeField(auto_now=True)
    last_login_ip = GenericIPAddressField(default=None, null=True)
    last_activity = DateTimeField(auto_now=True)

    session_expiry_age = PositiveBigIntegerField(default=None, null=True)
    session_verify_ip = BooleanField(default=None, null=True)
    session_verify_ua = BooleanField(default=None, null=True)
    session_limit = PositiveIntegerField(default=None, null=True)
    session_preemptive = BooleanField(default=None, null=True)

    allowed_addresses = ArrayField(GenericIPAddressField(), default=None, null=True)

    class Meta:
        abstract = True

    def get_allowed_addresses(self, login: bool = False):
        if not self.allowed_addresses:
            return None
        if not login:   # can be inherit and custom
            return None
        return self.allowed_addresses

    def disable(self):
        self.active = False
        self.save(update_fields=['active'])

    def enable(self):
        self.active = True
        self.save(update_fields=['active'])

    def __init_subclass__(cls, **kwargs):
        from utilmeta.conf import config
        if not config.auth.UserModel:
            config.auth.UserModel = cls
