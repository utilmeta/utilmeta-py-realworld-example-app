from utilmeta.types import *
from utilmeta.utils import *
from utilmeta.util.common import TokenType, time_now, utc_ms_ts
from .service import ServiceAPI
from .cluster import ClusterAPI
from .metrics import MetricsAPI
from .alert import AlertAPI
from .log import LogAPI
from .custom import CustomAPI
from .data import PublicDataAPI
from .task import TaskAPI
from .admin import AdminAPI, SupervisorAPI, SessionAPI
from utilmeta.dist.api import DistributedAPI
from utilmeta.conf import config
from ..schema.request import OpsPostSchema
from ..schema.service import StatusSchema
from ..sdk import ActionSDK
from ..models.admin import *
from ..models.service import ServiceInstance
from ..tasks import HeartbeatTask
from ..auth import valid, Opt


class OperationsAPI(API):
    __ignore_generate__ = not config.ops.ops_api_document
    __spec__ = True

    request = Request(
        admin_only=True,
        supervisor_exempt=False,
        allow_origin='*',
        log_option=Logger.OMIT,
        csrf_exempt=True,
    )
    response = Response(
        result_data_key='result',
        action_state_key='state',
        error_message_key='msg',
        total_count_key='count'
    )

    class Router:
        # called by the utilmeta platform admins
        log = LogAPI
        data = PublicDataAPI
        task = TaskAPI
        admin = AdminAPI
        alert = AlertAPI
        custom = CustomAPI
        metrics = MetricsAPI
        service = ServiceAPI
        session = SessionAPI
        supervisor = SupervisorAPI
        # --------------------------------------
        cluster = ClusterAPI        # called by other utilmeta service instances
        dist = DistributedAPI       # called by other utilmeta distributed cluster nodes

    @api.get(
        request=Request(max_rps=1, require=valid(Opt.api_view)),
        cache=Cache(client_cache=True) if config.auto_cache else None,
    )
    def document(self):
        instance = ServiceInstance.current()
        if not instance:
            return None
        return instance.document

    @api
    def auto_select(self, urls: Set[str] = Rule(min_length=1),
                    times: int = Rule(ge=1, default=3),
                    timedelta_tolerance: int = 5):
        if len(urls) == 1:
            return urls.pop()
        url_time = {}

        def request(_url):
            try:
                start = time_now()
                resp = ActionSDK(action_url=_url).ping()
                if not resp.success:
                    raise AttributeError
                ts = resp.result.timestamp
                end = time_now()
                current = utc_ms_ts()
                delta = abs(current - ts)
                duration = (end - start).total_seconds()
                if delta > timedelta_tolerance:
                    raise AttributeError
                if _url in url_time:
                    if isinstance(url_time[_url], list):
                        url_time[_url].append(duration)
                else:
                    url_time[_url] = [duration]
            except AttributeError:
                url_time[_url] = []

        with config.task.concurrent_executor(
            timeout=timedelta_tolerance,
            silent_timeout=True
        ) as executor:
            for url in urls:
                for i in range(0, times):
                    executor.submit(request, url)
            executor.wait()

        return sorted(urls, key=lambda u: sum(url_time[u]))[0]

    @api(transaction=config.ops.db_alias, request=Request(
        previous_exempt=True,
        supervisor_exempt=True,
        log_option=Logger.PERSIST,
        # exempt previous request rules, exempt supervisor here because it is the API where supervisor registered
        admin_only=True,
    ))
    def post(self, schema: OpsPostSchema = Request.Body):
        config.ops.valid_supervisor(self.request.origin)
        if config.cluster and not config.cluster.is_proxy:
            raise exc.BadRequest(f'Supervisor register not supported')
        if config.ops.valid_host and config.public_ops_api.strip('/') != self.request.full_path.strip('/'):
            raise exc.BadRequest(f'Unexpected host, except: {config.public_ops_api}')
        # sent from client / supervisor's proxy, use service token
        if not config.ops.valid(self.request.srv_token):
            raise exc.PermissionDenied('Invalid Service Token')

        retrieve_resp = ActionSDK(
            action_url=schema.action_url, ops_token=self.request.ops_token,
            token_type=TokenType.init, retrieve=True
        ).retrieve()
        token_resp = ActionSDK.InitResponse(retrieve_resp)
        if not token_resp.success:
            return self.response.bad(token_resp.message)
        supervisor_id = token_resp.result.node_id
        sp = Supervisor(
            id=supervisor_id,
            service_id=config.name,
            action_url=schema.action_url,
            backup_urls=list(token_resp.result.action_urls.difference({schema.action_url})),
            action_token=token_resp.result.action_token,
            name=schema.name,
            disabled=True
        )
        sp.save()
        admins = []
        for member in token_resp.result.members:
            admins.append(Admin(
                access_key=member.access_key,
                secret_key=member.secret_key,
                supervisor_id=supervisor_id,
                remote_id=member.remote_id,
                operations=member.operations,
                root=member.root
            ))
        Admin.objects.bulk_create(admins)
        resp = ActionSDK(
            to=sp, ops_token=self.request.ops_token,
        ).add_node(data=HeartbeatTask.init_heartbeat_data(sp))
        if not resp.success:
            raise exc.ServerError(resp.message)
        if str(resp.result.id) != str(supervisor_id):
            raise exc.ServerError('Inconsistent service id, please try again')
            # trigger the atomic and cancel this data transaction
        return supervisor_id

    @api(request=Request(admin_only=False, supervisor_exempt=True))
    def get(self):
        """
        Get Service status (service or instance level depend on the entry url)
        """
        request_metrics = server_metrics = None
        if self.request.action_token:
            if self.request.action_token != config.cluster_manager.self_action_token:
                raise exc.PermissionDenied(f'Invalid Action Token')
            try:
                from ..models.service import ServiceInstance, Server
                inst = ServiceInstance.current()
                server = Server.current()
                if inst:
                    request_metrics = inst.data
                if server:
                    server_metrics = server.data
            except exc.DatabaseError:
                # ignore data base error during query and return None as the metrics
                pass

        return StatusSchema(
            project=config.project_name,
            service=config.name,
            instance=config.deploy.instance_id,
            production=config.production,
            version=str(config.version),
            setup_time=config.setup_time,
            timestamp=utc_ms_ts(),
            server=server_metrics,
            metrics=request_metrics
        )
