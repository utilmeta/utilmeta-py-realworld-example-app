from utilmeta.types import *
from utilmeta.utils import *
from ..module.admin import *
from ..models.admin import *
from ..schema.action import *
from ..schema.admin import AdminAlterable
from ..sdk import ActionSDK, ClusterSDK
from ..auth import valid, Opt
from utilmeta.util.common import MetaHeader, TokenType
from ..tasks.heartbeat import HeartbeatTask
from utilmeta.conf import config

manager = config.cluster_manager

__all__ = ['AdminAPI', 'SupervisorAPI', 'SessionAPI']


class SessionAPI(API):
    request = Request(admin_only=False)
    module = SessionMain

    @api.delete
    def revoke(self, id: str):
        if not config.session or not config.session.use_db:
            raise exc.BadRequest(f'Invalid operation')
        inst: Session = self.module.fetch(id)
        if not inst or inst.delete_time:
            raise exc.NotFound
        if inst.session_key == self.request.session.session_key:
            self.request.session.flush()
            return
        if not inst.user_id:
            raise exc.BadRequest(f'Invalid operation')
        if inst.user_id != self.request.user_id:
            raise exc.PermissionDenied('Access denied')
        from django.contrib.sessions.backends.base import SessionBase
        cls = config.session.engine_cls
        session: SessionBase = cls(inst.session_key)
        session.delete()


class AdminAPI(API):
    request = Request(supervisor_exempt=False)
    module = AdminMain

    def __init__(self, request):
        super().__init__(request)
        self.target: Optional[Admin] = None
        self.data: Optional[AccessSchema] = None

    @api(transaction=config.ops.db_alias, request=Request(require=valid(Opt.admin_add)))
    def post(self, data: AdminAlterable = Request.Body):
        if self.target:
            raise exc.BadRequest(f'Admin already exists')
        sp = self.request.supervisor
        pk = self.module(self.request, data=dict(
            supervisor_id=sp.id,
            remote_id=self.data.target_id,
            access_key=self.data.access_key,
            secret_key=self.data.secret_key,
            granted_by_id=self.request.admin.id,
            operations=data.operations,
            access_control_types=data.access_control_types,
            permissions=data.generate_permissions(granted_by=self.request.admin)
        ))()
        resp = ActionSDK(
            to=sp, ops_token=self.request.ops_token,
        ).add_admin()
        if not resp.success:
            raise exc.BadRequest(f'manage data sync to supervisor: '
                                 f'{sp.id} failed ({resp.status}) with error: {resp.message}')
        return pk

    @api(transaction=config.ops.db_alias, request=Request(require=valid(Opt.admin_alter)))
    def patch(self, data: AdminAlterable = Request.Body):
        if not self.target:
            raise exc.NotFound(f'Admin not found')
        sp = self.request.supervisor
        self.module(self.request, instance=self.target, data=dict(
            operations=data.operations,
            access_control_types=data.access_control_types,
            permissions=data.generate_permissions(granted_by=self.request.admin)
        ))()
        resp = ActionSDK(
            to=sp, ops_token=self.request.ops_token,
        ).alter_admin()  # (data=data) data not required as will be loaded in sync_data
        if not resp.success:
            raise exc.BadRequest(f'manage data sync to supervisor: '
                                 f'{sp.id} failed ({resp.status}) with error: {resp.message}')

    @api(transaction=config.ops.db_alias, request=Request(require=valid(Opt.admin_remove)))
    def delete(self):
        if not self.target:
            raise exc.NotFound(f'Admin not found')
        sp = self.request.supervisor
        self.module(instance=self.target).remove()
        resp = ActionSDK(
            to=sp, ops_token=self.request.ops_token,
        ).delete_admin()
        if not resp.success:
            raise exc.BadRequest(f'manage data sync to supervisor: '
                                 f'{sp.pk} failed ({resp.status}) with error: {resp.message}')

    @api.put(transaction=config.ops.db_alias, request=Request(require=valid(Opt.admin_alter)))
    def token(self):
        if not self.target:
            raise exc.NotFound(f'Admin not found')
        sp = self.request.supervisor
        self.module(instance=self.target).update(
            access_key=self.data.access_key,
            secret_key=self.data.secret_key
        )
        resp = ActionSDK(
            to=sp, ops_token=self.request.ops_token
        ).renew_admin()
        if not resp.success:
            raise exc.BadRequest(f'sync new token to supervisor: {sp.pk} '
                                 f'failed ({resp.status}) with error: {resp.message}')

    @api.before(post, patch, delete, token)
    def validate(self):
        sp = self.request.supervisor
        if not sp:
            raise exc.PermissionDenied('Admin alter is not allowed')
        token_schema = {
            TokenType.ops: OperationSchema,
            TokenType.access: AccessSchema
        }.get(self.request.token_type, OperationSchema)

        token_data = token_schema(self.request.token_data)
        if not token_data.target_id:
            raise exc.BadRequest('Admin user_id is required')

        granted_by = Admin.get(remote_id=token_data.admin_id, supervisor_id=sp.pk)

        if not granted_by or self.request.admin != granted_by:
            raise exc.PermissionDenied(f'Invalid Admin')

        target = Admin.get(
            remote_id=token_data.target_id,
            supervisor_id=sp.pk
        )
        
        self.target = target
        self.data = token_data


class SupervisorAPI(API):
    module = SupervisorMain

    @api.put(transaction=config.ops.db_alias)
    def token(self):
        sp = self.request.supervisor
        data = ActionSchema(self.request.token_data)
        self.module(instance=sp).update(
            action_token=data.action_token
        )
        resp = ActionSDK(
            to=sp, ops_token=self.request.ops_token
        ).renew_node()
        if not resp.success:
            raise exc.BadRequest(f'sync new token to supervisor: {sp.pk} '
                                 f'failed ({resp.status}) with error: {resp.message}')

    @api.post(transaction=config.ops.db_alias, request=Request(admin_only=False))
    def confirm(self, data: ClusterSDK.ConfirmData = Request.Body):
        if not config.cluster and config.cluster.is_proxy:
            raise exc.BadRequest(f'Invalid operation')
        # init heartbeat for specific node
        if not self.request.ops_token:
            raise exc.BadRequest('Missing Operations Token')

        module = self.module(id=data.node_id)
        supervisor: Supervisor = module.instance
        proxy: Supervisor = self.module(id=data.proxy_id).instance
        if not supervisor:
            raise exc.NotFound(f'Supervisor: {data.node_id} not found')
        if data.disable:
            if supervisor.disabled:
                raise exc.BadRequest(f'Invalid confirm')
            module.update(disabled=True)
            return
        else:
            module.update(disabled=False)   # confirm and set disabled to False

        resp = ActionSDK(
            to=proxy,
            ops_token=self.request.ops_token
        ).add_node(data=data.init_data)
        if not resp.success:
            raise exc.ServerError(resp.message)

    @api.post(transaction=config.ops.db_alias, request=Request(admin_only=False))
    def disabled(self, id: str):
        if config.is_proxy:
            raise exc.BadRequest(f'Invalid operation')
        if self.request.action_token != manager.self_action_token:
            raise exc.PermissionDenied(f'Invalid Action Token')
        self.module(id=id).update(disabled=True)
        resp = ClusterSDK(
            proxy=True,
            append_headers={
                MetaHeader.OPERATION: self.request.ops_token,
            }
        ).confirm_supervisor(data=ClusterSDK.ConfirmData(
            node_id=id,
            disable=True
        ))
        if not resp.success:
            raise exc.ServerError(f'Supervisor confirm failed with error:', resp.message)

    @api(transaction=config.ops.db_alias, request=Request(admin_only=False))
    def post(self, data: NodeInitSchema = Request.Body):
        """
        This API can only be called by the proxy cluster (to this non-proxy node)
        with IP & Action-Token auth, this request should be trusted
        :return:
        """
        if config.is_proxy:
            raise exc.BadRequest(f'Invalid operation')
        if not self.request.ops_token:
            raise exc.BadRequest('Missing Operations Token')
        if self.request.action_token != manager.self_action_token:
            raise exc.PermissionDenied(f'Invalid Action Token')
        sp: Supervisor = self.module.filter(service_id=config.name, action_url=data.action_url).first()
        if sp:
            if not sp.disabled:
                return
        else:
            self.module(data=dict(
                id=data.node_id,
                service_id=config.name,
                action_token=data.action_token,
                name=data.name,
                action_url=data.action_url,
                backup_urls=data.backup_urls,
                offline_enabled=data.offline_enabled,
                operation_timeout=data.operation_timeout,
                open_operations=data.open_operations,
                disabled=False
            )).create()

        admins = []
        for member in data.members:
            admins.append(Admin(
                access_key=member.access_key,
                secret_key=member.secret_key,
                supervisor_id=data.node_id,
                remote_id=member.remote_id,
                operations=member.operations,
                root=member.root
            ))
        Admin.objects.bulk_create(admins)
        supervisor = Supervisor.get(data.node_id)
        resp = ClusterSDK(
            proxy=True,
            append_headers={
                MetaHeader.OPERATION: self.request.ops_token,
            }
        ).confirm_supervisor(data=ClusterSDK.ConfirmData(
            node_id=data.node_id,
            proxy_id=data.proxy_id,
            init_data=HeartbeatTask.init_heartbeat_data(supervisor),
            disable=False
        ))
        if not resp.success:
            raise exc.ServerError(f'Supervisor confirm failed with error: {resp.message}')
