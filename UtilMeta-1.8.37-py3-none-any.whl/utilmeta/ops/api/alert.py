from utilmeta.utils import *
from ..module.log import AlertSettingsMain, AlertTypeList

__all__ = ['AlertAPI']


class AlertAPI(API):
    module = AlertTypeList

    class Router:
        settings = AlertSettingsMain
