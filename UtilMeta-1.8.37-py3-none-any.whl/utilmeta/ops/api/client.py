from utilmeta.utils import *


class ClientAPI(API):
    class TrackSchema(Schema):
        client_id: str
        route: str = None
        event: str = None
        data: dict

    @api.post
    def track(self, data: TrackSchema = Request.Body):
        pass
