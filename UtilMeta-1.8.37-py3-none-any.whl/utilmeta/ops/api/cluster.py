from utilmeta.types import *
from utilmeta.utils import *
from utilmeta.conf import config
from utilmeta.util.common import gen_key, get_hostname, IPType, BroadcastCacheType, Param, convert_time
from utilmeta.util.query import MetaQuerySet
from utilmeta.util.query.schema import SchemaGenerator
from ..models.service import *
from ..module.service import CacheList, ServiceMain
from ..module.admin import SupervisorMain
from ..schema.service import *
from ..schema.metrics import ReportSchema
from ..sdk import ActionSDK, ClusterSDK
from ipaddress import ip_address

manager = config.cluster_manager

__all__ = ['ClusterAPI']


class CacheAPI(API):
    def __init__(self, request: Request):
        super().__init__(request)
        self.action_token = None
        self.service_name = None
        self.instance_id = None

    class CacheData(Schema):
        key: str
        value = None
        delete: bool = False
        type: str = Rule(choices=BroadcastCacheType.gen())
        kwargs: dict = {}

    @api(idempotent=True)
    def post(self, data: CacheData = Request.Body):
        cache = config.cluster.cache
        if data.type == BroadcastCacheType.session:
            if self.service_name != config.auth.auth_service:
                raise exc.BadRequest(f'Invalid source service for session cache')
        if data.delete:
            cache.delete(data.key)
        else:
            cache.set(data.key, data.value, **data.kwargs)

    @api.before(post)
    def parse_headers(self, x_meta_service_name: str, x_meta_action_token: str):
        self.action_token = x_meta_action_token
        self.service_name = x_meta_service_name
        if self.action_token != manager.self_action_token:
            raise exc.PermissionDenied('Cache alternation denied')
        inst = manager.get_instance(self.request.source_instance, service_name=self.service_name)
        if not inst:
            raise exc.BadRequest(f'Instance id required')
        # if self.request.ip != inst.ip:
        #     raise exc.PermissionDenied(f'Invalid source host')


class DataAPI(API):
    def __init__(self, request: Request):
        super().__init__(request)
        self.action_token = None
        self.service_name = None
        self.model = None

    class KeyData(Schema):
        pk_list: List[str]

    class DeletionData(KeyData):
        remote_model: str

    class QueryData(KeyData):
        schema: dict

    @api.get
    def keys(self, query: dict = Request.Query) -> List[str]:
        if not self.model:
            raise exc.BadRequest(f'Model tag must provide with X-Meta-Model-Tag in data retrieve')
        order_by = query.get(Param.order, ())
        return list(MetaQuerySet(model=self.model).order_by(*order_by).filter(**query).pk_list)

    @api.post
    def query(self, data: QueryData = Request.Body):
        if not self.model:
            raise exc.BadRequest(f'Model tag must provide with X-Meta-Model-Tag in data retrieve')
        schema = Schema.__from_dict__(data)
        func = SchemaGenerator(schema=schema, model=self.model).query()
        return func(MetaQuerySet(model=self.model).filter(pk__in=data.pk_list))

    @api.post
    def deletion(self, data: DeletionData = Request.Body):
        """
        remote deletion, if attached to another service CrossServiceKey, will trigger a rel_delete
        to apply further CASCADE/SET_NULL/...
        """
        keys = config.cluster.get_cross_keys(service=self.service_name, remote_model=data.remote_model)
        for key in keys:
            key.apply_remote_deletion(data.pk_list)

    @api.before('*')
    def check_headers(self, x_meta_service_name: str,
                      x_meta_action_token: str,
                      x_meta_model_tag: str = None):
        self.action_token = x_meta_action_token
        self.service_name = x_meta_service_name
        if self.action_token != manager.get_action_token(self.service_name):
            raise exc.PermissionDenied('Service data access denied')
        inst = manager.get_instance(self.request.source_instance, service_name=self.service_name)
        if not inst:
            raise exc.BadRequest(f'Instance id required')
        # if self.request.ip != inst.ip:
        #     raise exc.PermissionDenied(f'Invalid source host')
        if x_meta_model_tag:
            from django.apps.registry import apps
            try:
                app_label, model_name = x_meta_model_tag.split(':')
                self.model = apps.get_model(app_label=app_label, model_name=model_name)
            except (ValueError, LookupError):
                raise exc.BadRequest(f'Invalid model tag: {x_meta_model_tag}')


class ClusterAPI(API):
    request = Request(admin_only=False, log_option=Logger.VOLATILE)

    class Router:
        cache = CacheAPI
        data = DataAPI

    def __init__(self, request: Request):
        super().__init__(request)
        self.action_token = None
        self.service_name = None
        self.invoke_token = None
        self.confirm_token = None
        self.instance_id = None

    @api.get
    def documents(self, scope: Set[str] = None) -> Dict[str, dict]:
        """
        get (in scope or all) dependencies's api document
        :return:
        """
        if not config.cluster.is_proxy:
            raise exc.NotFound
        if self.action_token != manager.self_action_token:
            raise exc.PermissionDenied(f'Invalid Action Token')
        service = Service.get(self.service_name)
        if not service:
            raise exc.NotFound(f'Service: <{self.service_name}> not found')
        dependencies = service.get_forward_dependencies()
        if scope:
            dependencies = scope.intersection(dependencies)
        documents = {}
        for name in dependencies:
            inst = ServiceInstance.objects.filter(service=name).first()
            if not inst:
                continue
            documents[name] = inst.document
        return documents

    @api.post(transaction=config.ops.db_alias)
    def down(self):
        """
        a service instance is MANUALLY shutdown and will inform all other services to disconnect
        and stop assigning new requests to this instance
        instance will shutdown until all others confirmed and proxy has updated the load balance configuration
        :return:
        """
        if self.action_token != manager.self_action_token:
            raise exc.PermissionDenied(f'Invalid Action Token')
        inst = ServiceInstance.get(self.instance_id)
        inst.connected = False
        inst.save(update_fields=['connected'])
        manager.update_services()
        # update services to apply the latest status
        if config.cluster.is_proxy:
            # this api should take the responsibility of regenerate the load balance config file
            # if there is no instance left for a service, it will raise "Empty Instances" and return 500
            # received service will use it to determine whether or not to turn down the service
            config.utilmeta.load_proxy()

    @api.get
    def confirm(self) -> str:
        from utilmeta.conf.deploy import Lock
        return config.deploy.gen_confirm_token(Lock.register, get=True)

    @api.put(transaction=config.ops.db_alias)
    def backward(self, data: ServiceSchema = Request.Body):
        """
        for example <www> service depend on <auth> service to provide authentication
        this request is sent from proxy node when <www> service is registered to <auth> service
        to add this backward service
        """
        if self.action_token != manager.self_action_token:
            raise exc.PermissionDenied(f'Invalid Action Token')
        inst = ServiceInstance.get(self.instance_id)
        if not inst:
            raise exc.BadRequest('Instance not found')
        if not inst.service.proxy:
            raise exc.PermissionDenied('Access Denied')

        Service.objects.update_or_create(
            name=data.name,
            defaults=dict(
                action_token=data.action_token,
                ops_route=data.ops_route,
                expose=data.expose,
                proxy=data.proxy,
                single_endpoint=data.single_endpoint,
                root_routes=sorted(list(data.root_routes))
            )
        )
        current = Service.current()
        current.set_backward(data.name, relates=data.relates)

    @api.post
    def report(self, data: ReportSchema = Request.Body):
        for sp in SupervisorMain.filter(
            service_id=self.service_name, disabled=False
        ):
            sp: SupervisorMain.model
            if not sp.report_enabled:
                continue
            ActionSDK(to=sp).report(data=data)

    def post(self, data: RegisterSchema = Request.Body):
        """
        register or heartbeat (based on whether the unique_name / instance_id is registered or not)

        case 1: cluster register service to cluster proxy
        case 2: send by the cluster proxy, sync to service the dependencies data
        """
        if not config.cluster.is_proxy:
            raise exc.MethodNotAllowed
        if self.service_name == config.name:
            raise exc.BadRequest(f'Invalid request')

        if self.invoke_token != config.cluster.invoke_token:
            raise exc.PermissionDenied('Invalid invoke token')
        if config.cluster.proxy_config.private_only:
            if not self.request.ip_address.is_private:
                raise exc.PermissionDenied('Private host only')
            try:
                ip: IPType = ip_address(get_hostname(data.base_url))
                if not ip.is_private:
                    raise ValueError
            except ValueError:
                raise exc.BadRequest(f'Cluster proxy only allow private ip as base_url, '
                                     f'got {data.base_url}')

        invoke = ClusterSDK(base_url=data.ops_api)
        resp = invoke.confirm()
        if not resp.success or resp.result != self.confirm_token:
            raise exc.BadRequest(f'Invalid instance base_url: {data.base_url},'
                                 f' cannot confirm (inconsistent confirm token)')

        srv = Service.get(name=self.service_name)
        inst = ServiceInstance.get(self.instance_id)

        if srv and srv.action_token:
            # concrete service
            if self.action_token != manager.self_action_token:
                # valid action token, proved that this service is another instance of the registered service
                raise exc.PermissionDenied(f'Service <{self.service_name}> has registered, use valid action_token '
                                           f'to add another service instance')
            action_token = srv.action_token
        else:
            # non-exist service or abstract service
            if inst:
                raise exc.BadRequest(f'Invalid instance id')
            if not config.cluster.is_proxy:
                raise exc.BadRequest(f'Invalid service')
            action_token = gen_key(32, alnum=True)

        srv, created = Service.objects.update_or_create(
            name=self.service_name,
            defaults=dict(
                action_token=action_token,
                ops_route=data.ops_route,
                expose=data.expose,
                single_endpoint=data.single_endpoint,
                root_routes=sorted(list(data.root_routes))
            )
        )

        server = Server.load(ip=data.server.ip, metrics=data.server)
        inst_data = dict(
            server=server,
            base_url=data.base_url,
            document=data.document,
            version=data.version,
            version_id=data.version_id,
            utilmeta_version=data.utilmeta_version,
            production=data.production,
            proxy_timeout=data.proxy_timeout,
            max_retries=data.max_retries,
            options=data.options,
            connected=True,
            last_heartbeat=convert_time(self.request.time),
            **data.metrics
        )
        # updated = True
        if inst:
            # updated = data.document != inst.document
            inst.update(**inst_data)
        else:
            inst = ServiceInstance.objects.create(
                id=self.instance_id,
                service=srv,
                **inst_data
            )

        for cache in data.expose_caches:
            cache.server_id = Server.load(cache.host).id
            cache.init_version_id = None
            cache.current_version_id = None

        Bulk(model=CacheStorage, replace=True)(
            data.expose_caches,
            domain=CacheList.filter(service_id=self.service_name).pk_list
        )

        errors = manager.register_service(
            name=self.service_name,
            instance_id=inst.pk,
            dependencies=data.dependencies,
            service_relates=data.service_relates,
            # updated=updated
        )
        if errors:
            self.request.log.error('; '.join(errors))

        services: List[ServiceSchema] = ServiceMain(
            pk_list=list(set(data.dependencies).union({config.name}))).serialize()
        for service in services:
            service.instances = [inst for inst in service.instances if not inst.task]

        caches = CacheList(queryset=CacheList.filter(service__in=data.dependencies, expose=True)).serialize()
        return dict(
            action_token=action_token,
            services=services,
            expose_caches=caches
        )

    @api.before(post, down, backward, documents, report)
    def parse_headers(self, x_meta_service_name: str, x_meta_invoke_token: str = None,
                      x_meta_instance_id: str = None, x_meta_confirm_token: str = None,
                      x_meta_action_token: str = None):

        self.action_token = x_meta_action_token
        self.service_name = x_meta_service_name
        self.instance_id = x_meta_instance_id
        self.invoke_token = x_meta_invoke_token
        self.confirm_token = x_meta_confirm_token
