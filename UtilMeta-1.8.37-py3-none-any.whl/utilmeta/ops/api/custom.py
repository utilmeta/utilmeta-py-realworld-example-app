from utilmeta.types import *
from utilmeta.utils import *
from utilmeta.util.common import Static, time_now, LogLevel
from utilmeta.util.query import MetaQuerySet
from ..module.task import TaskSettingsMain
from ..module.metrics import ServiceAggregateSeries
from ..module.log import AlertTypeList, AlertSettingsMain, ServiceLogList
from ..module.service import *
from ..module.utils import *
from ..models.service import ServiceInstance
from ..auth import valid, Opt
from utilmeta.conf import config


class ServiceData(Static):
    task_settings = 'task_settings'
    metrics_layer0 = 'metrics_layer0'
    metrics_layer1 = 'metrics_layer1'
    metrics_realtime = 'metrics_realtime'
    alert_types = 'alert_types'
    alert_settings = 'alert_settings'
    servers = 'servers'
    instances = 'instances'
    endpoints = 'endpoints'
    document = 'document'
    databases = 'databases'
    caches = 'caches'


class RealtimeIndex(Static):
    requests = 'requests'
    uv = 'uv'
    ip = 'ip'
    errors = 'errors'
    users = 'users'
    avg_time = 'avg_time'
    active_sessions = 'active_sessions'


class ServiceExecutor:
    def __init__(self, request: Request, key: str, val=None):
        self.request = Request.custom(
            'get', headers=request.headers,
            user_id=request.user_id, admin=request.admin
        )
        self.log = request.log
        self.key = key
        self.func = getattr(self, key, None)
        if not self.func:
            raise AttributeError(f'Invalid service data type: {self.key}')
        self.val = val

    def task_settings(self):
        return TaskSettingsMain(self.request, queryset=TaskSettingsMain.filter(service_id=config.name))()

    def metrics_realtime(self):
        logs = ServiceLogList.filter(log__time__gte=time_now() - timedelta(seconds=self.val or 3600))
        users = None
        if config.auth.UserModel:
            users = MetaQuerySet(model=config.auth.UserModel).count()
        return dict(**logs.aggregate(
            avg_time=exp.Avg('log__duration'),
            requests=exp.Count('id'),
            errors=exp.Count('id', filter=exp.Q(log__level__gte=LogLevel.ERROR)),
            uv=exp.Count('user_id', distinct=True),
            ip=exp.Count('ip', distinct=True),
            active_sessions=exp.Count('session_id', distinct=True)
        ), users=users)

    def metrics_layer0(self):
        return ServiceAggregateSeries(self.request, query=dict(
            layer=0,
            service=config.name,
            within_hours=self.val or 24,
            instance=None,
            endpoint=None,
        ))()

    def metrics_layer1(self):
        return ServiceAggregateSeries(self.request, query=dict(
            layer=1,
            service=config.name,
            within_days=self.val or 7,
            instance=None,
            endpoint=None,
        ))()

    def alert_types(self):
        return AlertTypeList(self.request, queryset=AlertTypeList.filter(
            service_id=config.name,
            alert_logs__isnull=False))()

    def alert_settings(self):
        return AlertSettingsMain(self.request, queryset=AlertSettingsMain.filter(service_id=config.name))()

    def instances(self):
        instances = InstanceMain(self.request, queryset=InstanceMain.filter(
            service_id=config.name
        )).assign()()
        values = []
        for inst in instances:
            inst: InstanceMain.schema
            if inst.task:
                workers = TaskWorkerList(
                    queryset=TaskWorkerList.filter(
                        instance_id=inst.id, connected=True
                    ), auth=False).serialize()
            else:
                workers = ServiceWorkerList(
                    queryset=ServiceWorkerList.filter(
                        instance_id=inst.id, connected=True
                    ), auth=False).serialize()
            values.append(dict(
                workers=workers,
                **inst
            ))
        return values

    def servers(self):
        return ServerList(self.request, queryset=ServerList.all().exclude(hostname=''))()

    def endpoints(self):
        return EndpointList(self.request, queryset=EndpointList.filter(application__service_id=config.name))()

    def document(self):
        if not Auth(require=valid(Opt.api_view))(self.request):
            return
        instance = ServiceInstance.current()
        if not instance:
            return None
        return instance.document

    def databases(self):
        return DatabaseMain(self.request, queryset=DatabaseMain.filter(service_id=config.name))()

    def caches(self):
        return CacheList(self.request, queryset=CacheList.filter(service_id=config.name))()

    def __call__(self):
        if not self.key or not self.val:
            return None
        try:
            return self.func()
        except (exc.Unauthorized, exc.PermissionDenied):
            return None
        except Exception as e:
            self.log.error(e)


class CustomAPI(API):
    class CustomData(Schema):
        task_settings: bool = False
        metrics_realtime: int = None    # within seconds: default 3600
        metrics_layer0: int = None
        metrics_layer1: int = None
        alert_types: bool = False
        alert_settings: bool = False
        servers: bool = False
        endpoints: bool = False
        document: str = None
        databases: bool = False
        instances: bool = False
        caches: bool = False

        timeout: int = None

    # def save_admin_activity(self):
    #     admin = self.request.admin
    #     if not admin:
    #         return
    #     admin.last_activity = self.request.time
    #     admin.save(update_fields=['last_activity'])

    def post(self, data: CustomData = Request.Body):
        result = {}

        def fetch_data(key):
            result[key] = ServiceExecutor(self.request, key=key, val=data.get(key))()

        with config.task.concurrent_executor(
            timeout=data.timeout,
            silent_timeout=True
        ) as executor:
            jobs = []
            for item in ServiceData.gen():
                value = data.get(item)
                if not value:
                    continue
                jobs.append((fetch_data, item))
            if not jobs:
                return result
            if len(jobs) == 1:
                f, k = jobs[0]
                f(k)
                return result
            for f, k in jobs:
                executor.submit(f, k)
            executor.wait()
        return result
