from utilmeta.utils import *
from utilmeta.util.common import Opt, ModelOperation, \
    readable, get_field, SECRET
from utilmeta.util.common import CommonMethod as M
from utilmeta.util.query import MetaQuerySet
from ..schema.request import DataAccessSchema
from ..auth import valid, valid_model
from ..models.log import OperationLog
from utilmeta.conf import config

__all__ = ['PublicDataAPI']


class PublicDataAPI(API):
    request = Request(
        require=valid(Opt.data_query),
    )

    def __init__(self, request):
        super().__init__(request)
        self.opt = Opt.data_query

    @classmethod
    def parse_result(cls, data, model, reduce=True, max_length=60):
        from utilmeta.fields import PasswordField, FilePathField, FileField
        if isinstance(data, list):
            for d in data:
                cls.parse_result(d, model, reduce, max_length)
            return data
        elif isinstance(data, dict):
            for k in list(data.keys()):
                field = get_field(model, k)
                if isinstance(field, PasswordField) or config.ops.is_secret(k):
                    data[k] = SECRET
                if isinstance(field, FileField) or isinstance(field, FilePathField):
                    continue
                if not reduce:
                    continue
                if len(str(data[k])) > max_length:
                    data[k] = readable(data[k], max_length=max_length, rep=False)
            return data
        return readable(data, max_length=max_length, rep=False)

    def post(self, data: DataAccessSchema = Request.Body):
        opt = Opt.data_query
        operation = ModelOperation.query
        if data.method == M.DELETE:
            opt = Opt.data_delete
            operation = ModelOperation.delete
        elif data.method == M.POST:
            opt = Opt.data_create
            operation = ModelOperation.create
        elif data.method != M.GET:
            opt = Opt.data_modify
            operation = ModelOperation.modify
        if opt != Opt.data_query:
            # auth for generic options (create/modify/delete)
            Auth(require=valid(opt))(self.request)
        Auth(require=valid_model(data.model, operation=operation))(self.request)
        # model auth for specific model
        self.opt = opt
        result = None
        manager = MetaQuerySet(model=data.model)
        q = manager.exclude if data.exclude else manager.filter
        queryset = q(pk__in=data.id_list) if data.id_list else q(**data.query)
        if data.method == M.GET:
            count = queryset.count()
            queryset: MetaQuerySet = Page()(orders=queryset.order_by(*data.orders), page=data.page, rows=data.rows)
            values = self.parse_result(
                data=list(queryset.values('pk', *data.fields).result()),
                model=data.model, reduce=data.reduce)
            result = self.response(values, count=count)
        elif data.method == M.DELETE:
            queryset.delete()
        else:
            Bulk(model=data.model, post=data.method == M.POST)(data=data.data)
        return result

    @api.after(post)
    def log_operation(self, r):
        if self.opt != Opt.data_query:
            OperationLog.objects.create(
                executor=self.request.admin,
                operation=self.opt,
                version_id=config.version_id,
                data=self.request.data,
                ip=self.request.ip,
            )
        return r

    # @api.handle(post, exc.BadRequest, exc.PermissionDenied)
    # def handle_manage_normal_error(self, e: Error) -> Response(status=400):
    #     print(e.full_info)
    #     self
    #     return self.response.fail(e)

    @api.handle(post)
    def handle_manage(self, e: Error) -> Response(status=500):
        OperationLog.objects.create(
            executor=self.request.admin,
            operation=self.opt,
            version_id=config.version_id,
            data=self.request.data,
            success=False,
            error=e.full_info,
            ip=self.request.ip,
        )
        r = self.response.fail(e)
        return r


if config.deploy.media_access:
    class FileAPI(API):
        media = Media(name_func=Media.time_stamp)

        @api(cache=Cache(cache_control=Cache.PUBLIC) if config.auto_cache else None,
             request=Request(require=valid(Opt.file_download)))
        def get(self, path: str) -> File:
            return self.media.stream(path=path)

        @api(request=Request(require=valid(Opt.file_upload), max_rps=0.5))
        def post(self, file: File = File(max_size=100 * Media.MB)) -> str:
            return self.media.store(file=file, path='admin')

    PublicDataAPI.mount('file', FileAPI)
