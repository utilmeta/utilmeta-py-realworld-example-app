from utilmeta.types import *
from utilmeta.utils import *
from utilmeta.util.common import Opt, close_connections
from ..auth import valid
from ..schema.log import *
from ..module.log import *
from ..sdk import ClusterSDK
from utilmeta.conf import config

__all__ = ['LogAPI']


class LogAPI(API):
    module = LogList

    class Router:
        alert = AlertLogList
        cache = CacheLogList
        query = QueryLogList
        version = VersionLogList
        restart = RestartRecordList
        operation = OperationLogList

    @api.get(request=Request(require=valid(Opt.log_trace)))
    def tracing(self, origin_id: int, timeout: int = None):
        """
        Get CASCADE tracing logs from an original service log id
        using recursive resolving between cluster services

        but to get complete tracing log require a fine delete strategy
        if one log is in the context of a failure request, it should remain for debug use
        and if a service log cannot be deleted due to it's error or process-time
        corresponded request log should also remain

        the result data structure is like
        {
            "id": <original_id>,
            "requests": [{
                "id": <request_log_id>,
                "time": ...,
                "block": False,
                "target": <target_instance_id>,
                "remote_log": {
                    "id": <remote_service_log_id>,
                    "requests": [...],
                    ...fields
                }
            }],
            ... fields
        }
        since it will need to do cross service query and integration, it will use
            ConcurrentTask to fetch multiple remote logs's tracing values
        this API 's caller can be administrator or previous-layer
            service which is in the middle of a tracing query
        """
        if not config.cluster:
            raise exc.BadRequest(f'Tracing logs should enable cluster config')
        service_log = ServiceLogList(id=origin_id).serialize()
        if not service_log:
            raise exc.NotFound(f'Tracing origin log id: {origin_id} not found')
        data: ServiceLogSchema = service_log[0]
        request_logs: List[RequestLogSchema] = RequestLogList(query=dict(context_log=origin_id)).serialize()
        with config.task.concurrent_executor(
            timeout=timeout,
            silent_timeout=True,
            on_complete=close_connections
        ) as executor:
            for log in request_logs:
                if not log.remote_log or not log.to_service:
                    continue
                executor[log.id] = executor.submit(
                    ClusterSDK(service=log.to_service).tracing,
                    ClusterSDK.TracingQuery(origin_id=log.remote_log)
                )
            for job in executor.get_results():
                for log in request_logs:
                    if log.id == job.key:
                        log.remote = job.result
        data.requests = request_logs
        return data

    @api.get(request=Request(require=valid(Opt.log_query)))
    def aggregate(self, endpoint_id: str = None, instance_id: str = None):
        pass
