from utilmeta.utils import *
from utilmeta.util.common import Opt
from ..auth import valid
from ..module.metrics import *

__all__ = ['MetricsAPI']


class MetricsAPI(API):
    request = Request(
        require=valid(Opt.metrics_view)
    )

    class Router:
        service = ServiceAggregateSeries
        server = ServerMonitorSeries
        model = DataMonitorSeries
        task = TaskAggregateSeries
        user = UserAggregateSeries

        worker = WorkerMonitorSeries
        database = DatabaseMonitorSeries
        cache = CacheMonitorSeries
        instance = InstanceMonitorSeries

    @api.get
    def current(self, uv_within: int = 3600, active_session_within: int = 3600):
        pass
