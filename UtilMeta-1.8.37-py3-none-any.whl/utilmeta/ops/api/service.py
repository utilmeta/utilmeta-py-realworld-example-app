from utilmeta.utils import *
from ..module.service import *
from ..module.utils import *
# from ..module.utils import MountList, UtilList
from ..auth import valid, Opt
from utilmeta.conf import config


__all__ = ['ServiceAPI']


class ServiceAPI(API):
    request = Request(require=valid(Opt.service_view))
    module = ServiceMain

    class Router:
        worker = WorkerList
        instance = InstanceMain
        cache = CacheList
        server = ServerList
        database = DatabaseMain

        endpoint = EndpointList
        model = DataModelList

    @api.get
    def servers(self):
        servers = ServerList(queryset=ServerList.all().exclude(hostname=''), auth=False).serialize()
        result = []
        for server in servers:
            instances = InstanceMain(queryset=InstanceMain.filter(
                server_id=server.id,
                service_id=config.name
            ), auth=False).assign().serialize()
            values = []
            for inst in instances:
                inst: InstanceMain.schema
                if inst.task:
                    workers = TaskWorkerList(
                        queryset=TaskWorkerList.filter(
                            instance_id=inst.id, connected=True
                        ), auth=False).serialize()
                else:
                    workers = ServiceWorkerList(
                        queryset=ServiceWorkerList.filter(
                            instance_id=inst.id, connected=True
                        ), auth=False).serialize()
                values.append(dict(
                    workers=workers,
                    **inst
                ))
            result.append(dict(
                instances=values,
                **server
            ))
        return result
