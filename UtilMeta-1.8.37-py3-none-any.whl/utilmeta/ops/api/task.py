from utilmeta.utils import *
from ..module.task import *

__all__ = ['TaskAPI']


class TaskAPI(API):
    module = TaskSettingsMain

    class Router:
        base = TaskList
        flow = TaskFlow
        event = TaskEventList
        dist = TaskDistributionList
        exec = TaskExecutionList
        job = TaskJobList

    # @api.get
    # def status(self, settings_id: str):
    #     dist_qs = TaskDistributionList.filter(settings_id=settings_id)
    #     TaskDistributionList(queryset=dist_qs).serialize()
