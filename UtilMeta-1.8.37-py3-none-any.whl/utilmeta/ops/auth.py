from .models.admin import *
from .models.utils import Endpoint, DataModel
from utilmeta.utils import Request, Auth
from utilmeta.util.common import Opt, ModelOperation, ip_belong_networks, \
    APIOperation, MODEL_OPERATION_MAP, ResourceType, exc, MetaHeader, url_join, \
    TokenType, ACTION_INFO, get_content_tag, parse_raw_url
from utilmeta.conf import config
from utilmeta.ops.sdk import ActionSDK
from utilmeta.ops.schema.action import OperationSchema


def valid(*operations, root=False):
    def has_permission(admin: Admin):
        if not admin:
            return False
        if admin.root:
            return True
        if root:
            return False
        return set(operations).issubset(admin.operations)
    has_permission.admin = True
    return has_permission


def valid_model(model, operation=ModelOperation.query):
    def has_permission(admin: Admin):
        if not admin:
            return False
        if admin.root:
            return True
        if ResourceType.model in admin.access_control_types:
            _model = DataModel.get(model)
            if not _model:
                return False
            permission: Permission = Permission.objects.filter(resource=_model, admin=admin).first()
            if not permission:
                return False
            return operation in permission.operations
        return MODEL_OPERATION_MAP.get(operation) in admin.operations
    has_permission.admin = True
    return has_permission


def valid_request(request: Request):
    def has_permission(admin: Admin):
        if not admin:
            return False
        if admin.root:
            return True

        if ResourceType.api in admin.access_control_types:
            _api = Endpoint.get(request)
            if not _api:
                return False
            permission: Permission = Permission.objects.filter(resource=_api, admin=admin).first()
            if not permission:
                return False
            if APIOperation.sudo_call in permission.operations:
                return True
            if request.safe and APIOperation.safe_call in permission.operations:
                return True
            return False

        if Opt.api_sudo_call in admin.operations:
            return True
        if request.safe and Opt.api_safe_call in admin.operations:
            return True
        return False
    has_permission.admin = True
    return has_permission


def load_admin(request: Request):
    super_id = request.headers.get(MetaHeader.SUPERVISOR)
    super_origin = request.headers.get(MetaHeader.SUPERVISOR_ORIGIN)
    ops_token = request.headers.get(MetaHeader.OPERATION)
    user_id = request.headers.get(MetaHeader.USER)

    ops_req = request.raw_path.startswith(config.ops_url) if config.ops and config.ops.route else False
    if not ops_req:
        if config.cluster and config.cluster.action_token_required and not config.cluster.is_proxy:
            action_token = request.headers.get(MetaHeader.ACTION_TOKEN)
            # not-Operations request from other cluster internal services: check action token
            if action_token != config.cluster.self_action_token:
                raise exc.PermissionDenied('Invalid action token')

    if not config.ops:
        return
    if not super_id:
        if request.local and super_origin:
            if not config.ops.trust_localhost:
                raise exc.PermissionDenied('localhost operations not trusted, to enable you '
                                           'should set Operations(trust_localhost=True) in your config')
            # grant all access to localhost supervisor
            request.supervisor = Supervisor(service_id=config.name)
            request.admin = Admin(root=True, supervisor=request.supervisor)
            if user_id:
                request.user_id = user_id
        return

    request.user_id = None
    # set None to request.user, in case of using admin object (not UserModel)
    # as user to pass to functions is risky

    supervisor = Supervisor.get(super_id)
    if not supervisor:
        raise exc.NotFound(f'supervisor: {super_id} not found')
    request.supervisor = supervisor

    action_req = False
    token_type = None
    if ops_req:
        for action, (method, path, type) in ACTION_INFO.items():
            ops_path = url_join(config.ops_url, path, with_scheme=False)
            if request.METHOD == method.upper() \
                    and ops_path.strip('/') == request.path.strip('/'):
                token_type = type
                action_req = True
                break

    if token_type is None:
        # direct signature validation of admin (used by GET/OPTIONS/HEAD safe methods)
        # other critical operations need to imply token-retrieve
        if supervisor.offline_enabled:
            # only offline-enabled supervisor allow signature admin auth
            request.admin = Auth.valid_signature(request, model=Admin, defaulted=True)
            if request.admin:
                if user_id:
                    request.user_id = user_id
                    request.admin = None
                    # set user_id instead of admin after validate admin
                return
        token_type = TokenType.ops

    if not ops_token:
        if supervisor.open_operations:
            request.admin = Admin()
            request.admin.operations = supervisor.open_operations  # assign operations
            return
        else:
            raise exc.PermissionDenied('Operation Token required')

    if config.production:
        # non-ops critical managements should applied from utilmeta platform
        config.ops.valid_supervisor(request.origin)

    response = ActionSDK(
        to=supervisor,
        ops_token=ops_token, retrieve=True,
        token_type=token_type
    ).retrieve()
    if not response.success:
        raise exc.PermissionDenied(f'request validate failed with error: {response.message}')
    data = OperationSchema(response.result)

    if data.node_id != supervisor.pk:
        raise exc.PermissionDenied(f'Invalid supervisor')

    if (request.raw_path, request.query) != parse_raw_url(data.url):
        raise exc.PermissionDenied('Inconsistent request URL, refuse to process')

    if request.METHOD != data.method.upper():
        raise exc.PermissionDenied('Inconsistent request method, refuse to process')

    if action_req:
        # sync request: set sync data
        request.data = data.sync_data
    else:
        if get_content_tag(request.raw_body) != data.content_tag:
            raise exc.PermissionDenied('Inconsistent request data, refuse to process')

    request.token_data = dict(data)
    request.token_type = token_type
    request.admin = Admin.get(remote_id=data.admin_id, supervisor_id=super_id)
    if not request.admin:
        raise exc.PermissionDenied(f'Invalid access_key: {data.admin_id}')

    addresses = supervisor.allowed_addresses or request.admin.allowed_addresses
    if addresses:
        if not ip_belong_networks(request.ip_address, addresses):
            raise exc.PermissionDenied(f'Invalid request origin')

    if user_id:
        request.user_id = user_id
        request.admin = None
        # set user_id instead of admin after validate admin
