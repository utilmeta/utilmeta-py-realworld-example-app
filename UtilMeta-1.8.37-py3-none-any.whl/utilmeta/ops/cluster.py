from utilmeta import conf
from utilmeta.types import *
from utilmeta.utils import Bulk
if TYPE_CHECKING:
    from utilmeta.ops.schema.service import InstanceSchema, ServiceSchema
from utilmeta.fields import CrossServiceKey
from utilmeta.util.common import model_tag, bi_search, \
    make_hash, RED, ignore_errors, CommonMethod, COMMON_ERRORS
from utilmeta.util.error import Error
from utilmeta.conf import config
import warnings

STANDARD = 10


class ClusterManager:
    def __init__(self, cfg: conf.Cluster):
        self.config = cfg
        self.enabled = bool(cfg)
        self.services_key = None

        if self.config:
            self.services_key = self.cache.construct_key(
                f'{config.cache_prefix}#SERVICES',
                block_nodes=0, sync_nodes='*'
            )
        else:
            self.config = conf.Cluster()
            self.config.unique_name = config.name

        self._relates_keys = []
        self._backwards: Dict[str, List['CrossServiceKey']] = {}  # stored for remote deletion

    @property
    def concurrent_executor(self):
        return config.task.concurrent_executor(
            timeout=self.config.default_timeout,
            silent_timeout=True
        )

    @property
    def this_service(self):
        from utilmeta.ops.models.service import Service
        return Service.current()

    @property
    def register_required(self):
        return not self.config.is_proxy and self.config.proxy_service

    @ignore_errors
    def init_service(self):
        from utilmeta.ops.sdk import ClusterSDK
        from utilmeta.conf import config
        from utilmeta.conf.deploy import Lock
        from .models.service import Service
        from .module.service import ServiceMain, CacheList
        # from .models.log import VersionLog
        from .models.service import Server
        self.update_services()      # load services first
        # if self.config.register_required:
        if self.config.register_required:
            invoke = ClusterSDK(proxy=True)
            resp = invoke.register_instance(
                confirm_token=config.deploy.gen_confirm_token(Lock.register)
            )
            if not resp.success:
                # warnings.warn(f'Register instance failed with error: {resp.message}')
                raise resp.error

            try:
                Service.objects.filter(name=config.name).update(action_token=resp.result.action_token)
                if resp.result.services:
                    for srv in resp.result.services:
                        for inst in srv.instances:
                            inst.server_id = Server.load(inst.server.ip, metrics=inst.server).id
                            del inst.server

                        del srv.dependencies
                        del srv.backwards

                    ServiceMain(data=resp.result.services, method=CommonMethod.PUT)()

                if resp.result.expose_caches:
                    for cache in resp.result.expose_caches:
                        cache.server_id = Server.load(cache.host).id

                    Bulk(model=CacheList.model, replace=True)(
                        resp.result.expose_caches,
                        domain=CacheList.filter(expose=True).pk_list)
            except Exception as e:
                warnings.warn(f'load service caches with errors: {Error(e).full_info}')
                # update services right after register
            self.update_services(clear=True)

        if config.is_proxy:
            errors = self.register_service(
                name=config.name,
                instance_id=config.deploy.instance_id,
                dependencies=list(config.cluster.internals) if config.cluster else [],
                service_relates=config.cluster.cross_service_relates if config.cluster else {},
            )
            if errors:
                warnings.warn('Register service occur error: %s' % ';'.join(errors))

    def get_dependency_services(self) -> List['ServiceSchema']:
        if self.config.is_proxy:
            services = self.get_all_services()
        else:
            services = self.get_forward_dependencies()
            services[self.config.unique_name] = self.get_service(name=self.config.unique_name)
        return list(services.values())

    def update_services(self, clear: bool = False):
        if not self.enabled:
            return
        from utilmeta.ops.module.service import ServiceMain
        services: List['ServiceSchema'] = ServiceMain(
            queryset=ServiceMain.all()
        ).serialize()
        if not services:
            return
        # only non-abstract services
        # self.cache.set(self.services_key, services, sync=self.cache.ALL)
        try:
            if clear:
                self.cache.delete(self.services_key)
            self.cache.hmset(self.services_key, {srv.name: srv for srv in services})
        except Exception as e:
            warnings.warn(f'Set Services Error: {e}')
        # sync services to all instance caches, so every instance can read it from local cache
        # to reduce request resolve latency

    def update_service(self, service: str):
        if not self.enabled:
            return
        from utilmeta.ops.module.service import ServiceMain
        services: List['ServiceSchema'] = ServiceMain(id=service).serialize()
        if not services:
            return
        try:
            self.cache.hset(self.services_key, key=service, value=services[0])
        except Exception as e:
            warnings.warn(f'Set Services Error: {e}')

    @property
    def cache(self):
        from django.core.cache import caches
        from utilmeta.util.cache.cluster import BaseClusterCache
        cache: BaseClusterCache = caches[self.config.service_cache_alias]
        return cache

    @staticmethod
    def instance_rank(instances: List['InstanceSchema']) -> List['InstanceSchema']:
        import random
        connected = [inst for inst in instances if inst.connected and not inst.task]

        if not connected:
            raise ValueError('Empty instances')
        if len(connected) <= 1:
            return connected

        inst_scores = {}
        sort_by_load = sorted(
            connected, key=lambda inst: inst.server.load_index, reverse=True)
        sort_by_time = sorted(
            connected, key=lambda inst: inst.avg_time, reverse=True)
        for inst in connected:
            inst_scores[inst] = (sort_by_load.index(inst) + sort_by_time.index(inst) + 1) \
                                * inst.weight * random.randrange(8, 12) / 10  # add randomness
        return sorted(connected, key=lambda inst: inst_scores[inst], reverse=True)

    @staticmethod
    def instance_score(instances: List['InstanceSchema']) -> List[Tuple['InstanceSchema', int]]:
        instances = [inst for inst in instances if not inst.task]

        if not instances:
            return []
        if len(instances) <= 1:
            return [(instances[0], 1)]

        scores = []
        scale = 0
        for inst in instances:
            weight = max(min(inst.weight, STANDARD), 0)
            if not weight or not inst.connected:
                scores.append((inst, 0))
                continue
            score = (2 + 1 / STANDARD - weight / STANDARD) ** (-inst.server.load_index)
            _scale = STANDARD / score
            if _scale > scale:
                scale = _scale
            scores.append((inst, score))

        finals = []
        for inst, score in scores:
            if score:
                score = int(score * scale) + 1
            finals.append((inst, score))
        return finals

    @property
    def representative(self) -> 'InstanceSchema':
        return self.get_representative(self.config.unique_name)

    @property
    def is_representative(self) -> bool:
        rep = self.representative
        if not rep:
            return True
        return config.deploy.instance_id == rep.id

    def get_representative(self, service_name: str, task: bool = False) -> 'InstanceSchema':
        """
        Based on a simple common consensus to elect a
        representative instance of a service without network requests
        """
        instances = sorted(self.get_instances(service_name, connected=True, task=task),
                           key=lambda inst: inst.init_time)
        return instances[0] if instances else None

    @property
    def rank_algorithm(self) -> Callable[[List['InstanceSchema']], List['InstanceSchema']]:
        return self.config.rank_algorithm or self.instance_rank

    @property
    def score_algorithm(self) -> Callable[[List['InstanceSchema']], List[Tuple['InstanceSchema', int]]]:
        return self.config.score_algorithm or self.instance_score

    def get_instances_ranks(self, service_name: str) -> List['InstanceSchema']:
        return self.rank_algorithm(self.get_instances(service_name, connected=True))

    def get_instances_scores(self, service_name: str) -> List[Tuple['InstanceSchema', int]]:
        return self.score_algorithm(self.get_instances(service_name, connected=True))

    def get_instances(self, service_name: str = None,
                      connected: bool = None, task: bool = False) -> List['InstanceSchema']:
        service_name = service_name or self.config.unique_name
        service = self.get_service(service_name)
        if not service:
            return []
        return [inst for inst in service.instances if
                (connected is None or inst.connected == connected)
                and inst.task == task]

    def get_hash_instance(self, key: str):
        """
        generate an infinite loop of hash ring
        """
        return self.get_instance_hash_values([key])[key]

    def get_instance_hash_values(self, values: list, reverse: bool = False, do_hash: bool = True, seed=None):
        instances = self.get_instances(connected=True, task=True)
        if not instances or not values:
            return {}
        v_nodes = self.config.get_virtual_nodes(len(instances))  # times
        hash_id = {}
        for inst in instances:
            # inst.id: hash(inst.id) % N
            for i in range(0, v_nodes):
                key = f'{inst.id}#{i}'
                hash_id[make_hash(key, seed=seed)] = inst.id
                # only seed instance can provide the randomness
        hash_values = sorted(hash_id.keys())
        hash_map = {}
        for key in values:
            entry = make_hash(key) if do_hash else key
            point = bi_search(hash_values, entry)
            index = point if point in range(0, len(hash_values)) else 0
            inst_id = hash_id[hash_values[index]]
            if reverse:
                if inst_id in hash_map:
                    hash_map[inst_id].append(key)
                else:
                    hash_map[inst_id] = [key]
            else:
                hash_map[key] = inst_id
        return hash_map

    def get_instance(self, instance_id: str, service_name: str = None) -> Optional['InstanceSchema']:
        service_name = service_name or self.config.unique_name
        if not instance_id:
            return None
        instances = self.get_instances(service_name)
        for inst in instances:
            if inst.id == instance_id:
                return inst
        return None

    def get_action_token(self, service_name: str) -> Optional[str]:
        service = self.get_service(service_name)
        if service:
            return service.action_token
        return None

    @property
    def self_action_token(self) -> str:
        return self.get_action_token(self.config.unique_name)

    # ---------------------
    # USING CACHE

    def get_all_services(self) -> Dict[str, 'ServiceSchema']:
        if not self.enabled:
            return self._get_all_services()
        try:
            services = self.cache.hgetall(self.services_key)
        except Exception as e:
            warnings.warn(f'Get All Services Error: {e}')
            services = None
        if not services:
            return self._get_all_services()
        from utilmeta.ops.schema.service import ServiceSchema
        try:
            return {key: ServiceSchema(**data) for key, data in services.items()}
        except COMMON_ERRORS:
            return self._get_all_services()

    def get_services(self, *names: str) -> Dict[str, 'ServiceSchema']:
        if not self.enabled:
            return self._get_services(*names)
        from utilmeta.ops.schema.service import ServiceSchema
        values = {}
        if not names:
            return values
        try:
            services = self.cache.hmget(self.services_key, names)
        except Exception as e:
            warnings.warn(f'Get Services Error: {e}')
            services = None
        if not services or None in services:
            return self._get_services(*names)
        try:
            for name, data in zip(names, services):
                if data:
                    values[name] = ServiceSchema(**data)
        except COMMON_ERRORS:
            return self._get_services(*names)
        return values

    def get_service(self, name: str) -> Optional['ServiceSchema']:
        if not self.enabled:
            return self._get_service(name)
        if not name:
            return None
        from utilmeta.ops.schema.service import ServiceSchema
        try:
            service = self.cache.hget(self.services_key, name)
        except Exception as e:
            warnings.warn(f'Get Service Error: {e}')
            service = None
        if service:
            try:
                return ServiceSchema(**service)
            except COMMON_ERRORS:
                return self._get_service(name)
        return self._get_service(name)

    @classmethod
    def _get_all_services(cls):
        from utilmeta.ops.module.service import ServiceMain
        return {service.name: service for service in ServiceMain(queryset=ServiceMain.all()).serialize()}

    @classmethod
    def _get_services(cls, *names: str):
        if not names:
            return {}
        from utilmeta.ops.module.service import ServiceMain
        return {service.name: service for service in ServiceMain(pk_list=list(names)).serialize()}

    @classmethod
    def _get_service(cls, name: str):
        from utilmeta.ops.module.service import ServiceMain
        from utilmeta.ops.models.service import Service
        # bypass the action toke not null restrict
        services = ServiceMain(queryset=Service.objects.filter(name=name), auth=False)()
        return services[0] if services else None

    # ---------------------
    @property
    def proxy(self) -> Optional['ServiceSchema']:
        from utilmeta.ops.models.service import Service
        proxy: Service = Service.objects.filter(proxy=True).first()
        if proxy:
            return self.get_service(proxy.name)
        return None

    @classmethod
    def get_proxy_action_token(cls) -> Optional[str]:
        from utilmeta.ops.models.service import Service
        proxy: Service = Service.objects.filter(proxy=True).first()
        if proxy:
            return proxy.action_token
        return None

    def get_backward_dependencies(self, name: str = None) -> Dict[str, 'ServiceSchema']:
        current = self.get_service(name or self.config.unique_name)
        return self.get_services(*current.backwards) if current else {}

    def get_forward_dependencies(self, name: str = None) -> Dict[str, 'ServiceSchema']:
        current = self.get_service(name or self.config.unique_name)
        return self.get_services(*current.dependencies) if current else {}

    def broadcast_deletion(self, model, pk_list):
        from utilmeta.ops.sdk import ClusterSDK
        from utilmeta.ops.models.service import CrossServiceRelate
        tag = model_tag(model, lower=True)
        services = CrossServiceRelate.backward_services(self.config.unique_name, model=tag)
        if not services:
            return
        with self.concurrent_executor as task:
            for name in services:
                service = self.get_service(name)
                invoke = ClusterSDK(service=name, prepend_route=service.ops_route)
                data = invoke.DeletionData(model=tag, pk_list=pk_list)
                task.submit(invoke.deletion, data)
            if self.config.async_on_delete:
                return
            task.wait()

    def broadcast_cache(self, key: str, value=None, type: str = None,
                        delete=False, kwargs=None, block: bool = False):
        """
        Async broadcast cache set for cluster scoped cache
        (use Application-layer API instead of connect directly to the client for security concerns)
        """
        from utilmeta.ops.sdk import ClusterSDK
        with self.concurrent_executor as task:
            for name, service in self.get_backward_dependencies().items():
                invoke = ClusterSDK(service=name, prepend_route=service.ops_route)
                data = invoke.CacheData(key=key, value=value, delete=delete, kwargs=kwargs, type=type)
                task.submit(invoke.broadcast_cache, data)
            if block:
                task.wait()
                for t in task:
                    print(t.exception())

    def broadcast_down(self):
        """
        Async broadcast cache set for cluster scoped cache
        (use Application-layer API instead of connect directly to the client for security concerns)
        """
        from utilmeta.ops.sdk import ClusterSDK
        services = list(self.get_backward_dependencies().values())
        proxy = self.proxy
        if proxy:
            services.append(proxy)
        print('Broadcast down to cluster services...')
        failed = 0
        with self.concurrent_executor as task:
            for service in services:
                invoke = ClusterSDK(service=service.name, prepend_route=service.ops_route)
                task[service.name] = task.submit(invoke.broadcast_down)
            for job in task.get_results():
                if job.success:
                    print(f'Broadcast to [{job.key}] succeed')
                else:
                    failed += 1
                    print(RED % f'Broadcast to [{job.key}] failed')
        return failed

    def register_service(self, name: str, instance_id: str = None,
                         dependencies: List[str] = (), service_relates: dict = None):
        # unlike other services, proxy instance need not to walk through the whole register process
        # only couple of operations required
        # assume the service is already a Service database instance
        from utilmeta.ops.models.service import Service, ServiceInstance
        from utilmeta.ops.schema.service import InstanceAlterable
        from utilmeta.ops.module.admin import SupervisorMain
        from utilmeta.ops.sdk import ClusterSDK, ActionSDK

        srv = Service.get(name=name)
        inst = ServiceInstance.get(id=instance_id)
        if not srv or not inst:
            raise RuntimeError(f'Invalid Operation: register service')

        absence = set(dependencies).difference(Service.names())
        Service.objects.bulk_create([Service(name=name) for name in absence])

        errors = []
        if name != self.config.unique_name:
            unregistered = SupervisorMain.filter(
                service_id=self.config.unique_name, disabled=False
            ).exclude(action_url__in=list(SupervisorMain.filter(
                service_id=name, disabled=False
            ).values_list('action_url', flat=True)))
            for supervisor in unregistered:
                try:
                    ClusterSDK(
                        service=name,
                        prepend_route=srv.ops_route
                    ).register_node(supervisor.pk)
                except Exception as e:
                    errors.append(f'Register service: {name} to supervisor: {supervisor}'
                                  f' failed with error: {e}')
            srv.set_dependencies(dependencies, service_relates or {})

        if self.config.proxy_config and self.config.proxy_config.check_instances_db:
            srv.check_databases()

        if config.cluster:
            with self.concurrent_executor as executor:
                for service_name, service in self.get_backward_dependencies(name=name).items():
                    invoke = ClusterSDK(service=service_name, prepend_route=service.ops_route)
                    if service_relates:
                        service.relates = service_relates.get(service_name)
                    executor.submit(invoke.update_backward, service)
                try:
                    for job in executor.get_results():
                        if not job.success:
                            errors.append(f'Update backward service: <{job.key}> failed with error: {job.message}')
                except Exception as e:
                    errors.append(f'Update backward service failed with error: {Error(e).full_info}')

        for sp in SupervisorMain.filter(
            service_id=config.name,
            disabled=False,
        ):
            sp: SupervisorMain.model
            if not sp.instance_sync_enabled:
                continue

            resp = ActionSDK(to=sp).alter_inst(instances=[InstanceAlterable(
                id=instance_id,
                service=name,
                version=inst.version,
                version_id=inst.version_id,
                production=inst.production,
                utilmeta_version=inst.utilmeta_version,
                weight=inst.weight,
                ip=inst.server.ip,
                connected=True,
                ops_route=srv.ops_route,
                proxy_url=srv.proxy_url,
                description=srv.description,
                document=inst.document if sp.document_sync_enabled else None,
                utcoffset=config.time.value_utcoffset
            )])
            if not resp.success:
                errors.append(f'Update instance to {sp} failed with error: {resp.message}')
            # sp.report(self.current)

        self.update_services()
        return errors
