from .models.service import *
from .models.task import TaskInstance, TaskWorker
from .models.utils import *
from utilmeta.ops.models.task import TaskSettings, NativeTask
from .models.log import VersionLog, BaseLog, AlertLog, AlertSettings
from ..core.unit import Unit
from ..core.task import Task
from utilmeta.util.base import Util
from utilmeta.util.alert import Alert
from utilmeta.util.field import Field
from utilmeta.util.common import get_doc, gen_key, Attr, Key, \
    ResourceType, exc, normalize, FRAMEWORKS, ServerRole, TaskType, time_now, get_interval, COMMON_TYPES
from ..service import UtilMeta
from django.db import transaction
from utilmeta.conf import Config, config
from utilmeta import __version__, __spec_version__
from typing import Type
from datetime import timedelta
import os


class Loader(Util):
    def __init__(self, service: UtilMeta, background: bool = False, asynchronous: bool = None):
        super().__init__(locals())
        self.service = service
        self.config = service.config
        self.document = service.document

        self.background = background
        self.asynchronous = asynchronous

        self.master = None
        self.ops_route = self.config.ops.api_route
        self.srv = None
        self.inst = None
        self.version = None
        self.app_map = {}
        self.check_table()  # cannot execute in transaction

    @transaction.atomic(config.ops.db_alias)
    def __call__(self):
        self.load_service()
        self.load_version()
        self.load_servers()
        self.load_utils()
        if self.background:
            self.load_tasks()
            self.load_alerts()
        else:
            self.alter_logs()
            self.load_endpoints()
            self.log_info()

        self.clear_service()
        # self._lock_all()

    def check_table(self):
        try:
            Service.objects.count()
        except (exc.OperationalError, exc.ProgrammingError):
            from django.core.management import execute_from_command_line
            execute_from_command_line(['manage.py', 'migrate', 'ops', f'--database={self.config.ops.db_alias}'])

    def clear_service(self):
        master_pid = self.config.deploy.main_pid
        worker_cls = TaskWorker if self.background else ServiceWorker
        # instance_cls = TaskInstance if self.background else ServiceInstance

        if config.monitor.worker_disconnect_interval:
            Worker.objects.filter(
                time__lte=time_now() - timedelta(seconds=config.monitor.worker_disconnect_interval * 2)
            ).delete()

        worker_cls.current_workers().filter(master=None).exclude(pid=master_pid).delete()

        if not self.background:
            try:
                from utilmeta.ops.log import MetricsLogger
                MetricsLogger().reset(config.deploy.instance_id)
            except RuntimeError as e:
                print('ERR:', e)
                # probably <No available cache, please check your cache status> when init load ops data
                pass
            except Exception as e:
                print('Reset service occur error: ', e)

    def alter_logs(self):
        BaseLog.objects.filter(runtime=True, version__instance_id=self.inst.pk).update(runtime=False)
        AlertLog.objects.filter(runtime=True, version__instance_id=self.inst.pk).update(runtime=False)

    def load_alerts(self):
        if not self.config.alert:
            return

        for alert in self.config.alert.get_alerts():
            alert: Alert
            AlertSettings.objects.update_or_create(
                service_id=self.config.name,
                name=alert.name,
                defaults=dict(
                    index_name=alert.index_name,
                    index_class=alert.class_path,
                    index_params=alert.params,
                    server=Server.current() if alert.server else None,
                    instance=ServiceInstance.current() if alert.instance else None,
                    custom=True,
                    disabled=alert.disabled,
                    level=alert.level,
                    task_settings=alert.task.task_settings if isinstance(alert.task, Task) else None,
                    threshold=alert.threshold,
                    exceed=alert.exceed,
                )
            )

        for inst in AlertSettings.objects.filter(
            service_id=self.config.name
        ).exclude(
            name__in=self.config.alert.names,
        ):
            inst: AlertSettings
            if not inst.external:
                inst.delete()

    def load_tasks(self):
        """
        Tasks in the code and database
        Deserialize
        :return:
        """
        from utilmeta.core.task import Task
        cls_map = {}
        for cls in self.config.task.get_task_classes():
            cls: Type[Task]
            label = self.config.app.get_app_label(cls.cls_path)
            ident = f'{label}.{cls.__name__.lower()}' if label != Attr.MAIN else cls.__name__.lower()
            obj, created = NativeTask.objects.update_or_create(
                ident=ident,
                defaults=dict(
                    ref=cls.cls_path,
                    ident=ident,
                    application=Application.get(label),
                    model=DataModel.get(cls.module.model) if cls.module else None,
                    module_path=cls.module.__declare_path__ if cls.module else None,
                    iterable=cls.iterable,
                    type=ResourceType.task,
                    document=get_doc(cls),
                    current_version=VersionLog.current(),
                    task_type=TaskType.native
                )
            )
            cls_map[cls] = obj

        excludes = ['name', 'group', 'max_times', 'schedule', 'interval', 'start_time',
                    'aggregate', 'module_query', 'dist_by_params', 'dist_by_event',
                    'event_abandon_window', 'event_abandon_expired', 'looped']

        def parse_val(_v):
            if isinstance(_v, timedelta):
                return get_interval(_v)
            if not isinstance(_v, COMMON_TYPES):
                return str(_v)
            return _v

        for task in self.config.task.get_tasks():
            task: Task
            cls = cls_map.get(task.__class__)
            if not cls:
                raise ValueError(f'Invalid task: {task}')
            settings = {k: parse_val(v) for k, v in task.__spec_kwargs__.items() if k not in excludes}
            TaskSettings.objects.update_or_create(name=task.name, service_id=config.name, defaults=dict(
                base=cls,
                group=task.group,
                max_times=task.max_times,
                schedule=task.schedule.params if task.schedule else None,
                interval=timedelta(seconds=task.interval) if task.interval else None,
                start_time=task.get_start_time_for_save(),
                stop_time=task.stop_time,
                query=normalize(task.query_dict, _json=True) if task.query_dict else None,
                dist_by_param=task.dist_by_param,
                dist_by_event=task.dist_by_event,
                event_abandon_window=timedelta(seconds=task.event_abandon_window) if
                task.event_abandon_window is not None else None,
                event_abandon_expired=task.event_abandon_expired,
                looped=task.looped,
                # chunk_size=task.chunk_size,
                settings=settings,
            ))

        for inst in TaskSettings.objects.filter(
            service_id=self.config.name
        ).exclude(
            name__in=self.config.task.names,
        ):
            inst: TaskSettings
            if inst.external:
                if inst.disabled:
                    self.config.task.load_instance(inst)
            else:
                inst.delete()

    def load_service(self):
        from utilmeta.conf import Cluster
        conf = config.cluster or Cluster()
        self.srv, created = Service.objects.update_or_create(
            name=config.name,
            defaults=dict(
                proxy=config.is_proxy,
                expose=conf.expose,
                ops_route=self.ops_route,
                single_endpoint=conf.single_endpoint,
                root_routes=self.service.root_routes,
                description=config.description,
                proxy_url=config.public_base_url if config.is_proxy else None
            )
        )
        if created and config.is_proxy:
            Service.objects.filter(name=config.name).update(action_token=gen_key(32, alnum=True))

        if config.cluster:
            self.srv.set_dependencies(list(config.cluster.internals), config.cluster.cross_service_relates)

        try:
            inst_data = dict(
                service=self.srv,
                server=Server.load(config.private_ip, domain=config.host),
                connected=True,
                last_restart=time_now(),
                config=Config.clean_kwargs(config),
                utilmeta_version=__version__,
                version=str(config.version),
                production=config.production,
                task=self.background,
                wsgi=self.asynchronous is False,
                asgi=self.asynchronous is True,
            )

            if self.background:
                self.inst, created = TaskInstance.objects.update_or_create(
                    id=config.task.instance_id,
                    defaults=dict(
                        **inst_data,
                        master=config.task.master,
                        main_cycle_interval=config.task.main_cycle_interval,
                        worker_cycle_interval=config.task.worker_cycle_interval,
                        max_concurrent_jobs=config.task.task_default_max_concurrent_jobs,
                        default_concurrent_cls=config.task.concurrent_cls_string,
                        manager_cls=config.task.manager_cls_string,
                        process_start_method=config.task.process_start_method
                    ),
                )

            else:
                # if config.is_proxy:
                #     inst = ServiceInstance.current()
                #     if inst and inst.base_url != config.base_url:
                #         print('Service base_url changed, sync to supervisors...')
                #         from .sdk import ActionSDK
                #         ActionSDK.alter_urls(config.name, base_url=config.base_url)

                reset_metrics = dict(
                    requests=0,
                    req_per_sec=0,
                    in_traffic=0,
                    out_traffic=0,
                    errors=0,
                    avg_time=0,
                    invokes=0,
                    invoke_per_sec=0,
                    timeout_invokes=0,
                    error_invokes=0,
                    avg_invoke_time=0
                )

                self.inst, created = ServiceInstance.objects.update_or_create(
                    id=config.deploy.instance_id,
                    defaults=dict(
                        **inst_data,
                        **reset_metrics,
                        engine=self.config.deploy.wsgi_class,
                        document=normalize(self.document, _json=True),
                        base_url=config.base_url,
                        proxy_timeout=conf.proxy_timeout,
                        max_retries=conf.max_retries,
                        options=conf.options
                    ),
                )

        except exc.IntegrityError as e:
            raise exc.IntegrityError(f'Instance create failed with error: {e}, \n'
                                     f'note: DO NOT change your service name manually, use [meta reset]\n'
                                     f'      to reset your service name (but do as little as possible)\n'
                                     f'      otherwise unexpected error may happens')
        self.srv.check_databases()
        # ensure all instance are using the same ops dv (including current one)

    def load_version(self):
        import platform
        VersionLog.check_version(inst_id=self.inst.id, version=config.version)
        self.version = VersionLog.objects.create(
            instance_id=self.inst.pk,
            major=config.version.major,
            minor=config.version.minor,
            patch=config.version.patch,
            meta=config.version.meta,
            version=str(config.version),
            spec_version=__spec_version__,
            python_version=platform.python_version(),
            utilmeta_version=__version__,
            updates=normalize(VersionLog.diff(
                instance=self.inst,
                data=self.document,
            ), _json=True),
        )
        self.inst.version_id = self.version.id
        self.inst.save(update_fields=['version_id'])

    def load_servers(self):
        for alias, db in self.config.databases.items():
            obj, created = DatabaseStorage.objects.update_or_create(
                server=Server.load(ip=db.host, role=ServerRole.db),
                port=db.port,
                name=db.name,
                defaults=dict(
                    service_id=config.name,
                    alias=alias,
                    type=ServerRole.db,
                    backend=db.type,
                    password=None,       # configured
                    current_version=self.version,
                    clustered=False
                )
            )
            if created:
                obj.init_version = self.version
                obj.save(update_fields=['init_version'])

        for alias, cache in config.caches.items():
            if not cache.ops_store:
                continue
            obj, created = CacheStorage.objects.update_or_create(
                server=Server.load(cache.host, role=ServerRole.cache),
                port=cache.port,
                defaults=dict(
                    alias=alias,
                    service_id=config.name,
                    type=ServerRole.cache,
                    password=cache.password,
                    backend=cache.type,
                    expose=bool(cache.cluster_scope),
                    current_version=self.version,
                    clustered=cache.clustered
                ),
            )
            if created:
                obj.init_version = self.version
                obj.save(update_fields=['init_version'])

        for web_server in config.web_servers:
            obj, created = WebServer.objects.update_or_create(
                server=Server.load(web_server.host, role=ServerRole.web, ssh=web_server.ssh_host),
                port=web_server.port,
                defaults=dict(
                    local_file=web_server.file,
                    service_id=config.name,
                    https_config=web_server.https.__spec_kwargs__ if web_server.https else None,
                    link=web_server.link,
                    main_file=web_server.main,
                    includes=web_server.includes,
                    backend=web_server.type,
                    current_version=self.version,
                    type=ServerRole.web
                ),
            )
            if created:
                obj.init_version = self.version
                obj.save(update_fields=['init_version'])

        if not self.background:
            if not self.service.is_worker:
                try:
                    self.master = ServiceWorker.load(os.getpid(), parent=False)
                    Worker.update(self.master, record=False)
                except Exception as e:
                    print(f'load master with error: {e}')

        config.sync_caches(retrieve_only=True)

    def load_utils(self):
        from django.apps import apps, AppConfig
        from django.db.models.options import Options
        main, created = Application.objects.update_or_create(
            service_id=config.name,
            label=Attr.MAIN,
            defaults=dict(
                name=Attr.MAIN,
                path=config.service.path,
            ),
        )
        app_objs = [main]
        labels = [Attr.MAIN]

        model_updates = []
        model_creates = []
        model_id_map = {}

        def register_model(mod, label, app_id):
            meta: Options = getattr(mod, Key.META)
            if meta.auto_created:
                return
            if mod in model_id_map:
                return
            base = Field.get_first_base(mod)
            base_id = None
            if base:
                base_id = model_id_map.get(base)
                if not base_id:
                    lb = getattr(base, Key.META).app_label
                    base_id = register_model(base, label=lb, app_id=app_id)
            model_name = mod.__name__.lower()
            display_name = meta.verbose_name or mod.__name__
            ident = f'{label}.{model_name}'
            md: DataModel = DataModel.objects.filter(ident=ident).first()
            obj = DataModel(
                type=ResourceType.model,
                ref=f'{mod.__module__}.{mod.__name__}',
                ident=ident,
                current_version=self.version,
                app_label=label,
                base_id=base_id,
                model_name=model_name,
                display_name=display_name,
                db_table=meta.db_table,
                application_id=app_id,
            )
            if md:
                obj.pk = md.pk
                model_updates.append(obj)
            else:
                obj.pk = gen_key(6, alnum=True)
                obj.init_version = self.version
                model_creates.append(obj)

            model_id_map[mod] = obj.pk
            return obj.pk

        for i, (key, cfg) in enumerate(apps.app_configs.items()):
            cfg: AppConfig
            labels.append(cfg.label)
            app, created = Application.objects.update_or_create(
                service_id=config.name,
                label=cfg.label,
                defaults=dict(
                    name=cfg.name,
                    path=cfg.path,
                ),
            )
            app_objs.append(app)
            if any([cfg.name.startswith(fm + '.') for fm in FRAMEWORKS]):
                continue
            for name, _m in cfg.models.items():
                register_model(_m, label=cfg.label, app_id=app.pk)

        Application.objects.filter(service_id=config.name).exclude(label__in=labels).delete()
        for _mod in model_creates:
            _mod.save()
        # DataModel.objects.bulk_create(model_creates)
        if model_updates:
            DataModel.objects.bulk_update(model_updates, fields=[
                'current_version', 'base_id',
                'display_name', 'db_table',
                'application_id', 'info'
            ])

    def load_endpoints(self):
        endpoint_creates = []
        endpoint_updates = []

        for ident, unit in self.config.ops.pop_endpoints().items():
            if not isinstance(unit, Unit):
                continue
            ex: Endpoint = Endpoint.objects.filter(ident=ident).first() or \
                Endpoint.objects.filter(method=unit.method.upper(), path=unit.endpoint_path).first()

            model = unit.unit_schema.get('model')
            model_inst = DataModel.objects.filter(
                ident__iexact=model,
                application__service=self.srv,
            ).first() if model else None
            endpoint = Endpoint(
                pk=ex.pk if ex else gen_key(6, alnum=True),
                init_version=ex.init_version if ex else self.version,
                ref=unit.__declare_path__,
                ident=ident,
                type=ResourceType.api,
                method=unit.method.upper(),
                application=Application.get(self.config.app.get_app_label(unit.__declare_path__)),
                path=unit.endpoint_path,
                idempotent=unit.idempotent,
                depreciated=unit.depreciated,
                model_id=model_inst.pk if model_inst else None,
                current_version=self.version
            )
            if ex:
                endpoint_updates.append(endpoint)
            else:
                endpoint_creates.append(endpoint)

        # the endpoints create in previous version and depreciated in current version will not assign current version
        # Endpoint.objects.bulk_create(endpoint_creates)
        Endpoint.objects.bulk_update(endpoint_updates, fields=[
            'current_version', 'idempotent', 'depreciated', 'model_id', 'ref'
        ])

        for obj in endpoint_creates:
            obj.save()

    def log_info(self):
        if config.cluster and config.cluster.register_required:
            print(f'OperationsAPI is mounted to cluster proxy, use proxy\'s public ops_api'
                  f' to manage your cluster (include current service)')
        elif self.ops_route:
            print(f'OperationsAPI loaded at: {config.public_ops_api} use this API to manage your service')
        else:
            print('WARNING: you activated Operation in your config, '
                  'but did not mount utilmeta.ops.api.OperationsAPI to your API, \n'
                  'you will not be able to manage your service from admin platform')
