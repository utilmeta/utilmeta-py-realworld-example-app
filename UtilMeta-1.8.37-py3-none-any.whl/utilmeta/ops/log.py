from utilmeta.util.common import GeneralType, replace_null, get_sql_type, get_sql_tables, \
    file_like, Hint, Header, ignore_errors, exp, write_to, AlertCategory, parse_user_agents,  \
    http_header, Format, SECRET, request_length, get_ip, LogType, task, \
    response_length, MetaHeader, LOG_LEVELS, LogLevel, normalize, time_now, convert_time
from utilmeta.util.log import Logger
from utilmeta.util.query import MetaQuerySet
from utilmeta.utils import Request, Call, Response
from django.http.response import HttpResponseBase
from typing import List, Tuple, Union
from http.client import HTTPResponse
from ipaddress import ip_address
import os
from django.db import transaction
import threading
from utilmeta.conf import config
from utilmeta.core.task import Task
from datetime import timedelta

__all__ = ['MetricsLogger', 'LogManager']

_api_log_queue: List[Tuple[Request, HttpResponseBase]] = []
_job_log_queue: List[Task] = []
_context_log_queue: List[Logger] = []


class MetricsLogger:
    def __init__(self, in_process: bool = False):
        self.in_process = in_process
        self._total_requests = 0
        self._total_errors = 0
        self._total_time = 0
        self._total_in = 0
        self._total_out = 0
        self._total_invokes = 0
        self._total_invoke_time = 0
        self._total_error_invokes = 0
        self._total_timeout_invokes = 0
        self._total_window = 0

    @classmethod
    def make_key(cls, key, item):
        from utilmeta.conf import config
        key_val = f'{config.cache_prefix}#{key}-{item}'
        if config.cluster:
            return config.cluster.cache.construct_key(key_val, local_only=True)
        return key_val

    @classmethod
    def get_cache(cls):
        from utilmeta.conf import config
        if config.cluster:
            return config.cluster.cache
        return config.ops.cache

    @ignore_errors
    def log(self, time: float, in_traffic: int, out_traffic: int, key: str = None, invoke: bool = False,
            error: bool = False, window: float = None, timeout: bool = False):
        if self.in_process:
            self._total_in += in_traffic
            self._total_out += out_traffic
            if invoke:
                self._total_invokes += 1
                self._total_error_invokes += int(error)
                self._total_timeout_invokes += int(timeout)
                self._total_invoke_time += time
            else:
                self._total_requests += 1
                self._total_errors += int(error)
                self._total_time += time
                self._total_window += window or 0
        else:
            if not key:
                raise ValueError(f'Empty key')
            cache = self.get_cache()
            key_incr = {
                self.make_key(key, 'in'): in_traffic,
                self.make_key(key, 'out'): out_traffic,
            }
            if invoke:
                key_incr.update({
                    self.make_key(key, 'invokes'): 1,
                    self.make_key(key, 'invoke-time'): time,
                    self.make_key(key, 'error-invokes'): int(error),
                    self.make_key(key, 'timeout-invokes'): int(timeout)
                })
            else:
                key_incr.update({
                    self.make_key(key, 'requests'): 1,
                    self.make_key(key, 'time'): time,
                    self.make_key(key, 'errors'): int(error),
                    self.make_key(key, 'window'): window,
                })
            for k, amount in key_incr.items():
                if not amount:
                    continue
                try:
                    cache.incr(k, amount)
                except ValueError:
                    cache.set(k, amount)

    def retrieve(self, inst) -> dict:
        if not inst:
            return {}
        now = time_now()
        key = inst.pk
        cache = self.get_cache()
        requests = self._total_requests if self.in_process \
            else cache.get(self.make_key(key, 'requests')) or 0
        in_traffic = self._total_in if self.in_process \
            else cache.get(self.make_key(key, 'in')) or 0
        out_traffic = self._total_out if self.in_process \
            else cache.get(self.make_key(key, 'out')) or 0
        total_time = self._total_time if self.in_process \
            else cache.get(self.make_key(key, 'time')) or 0
        total_window = self._total_window if self.in_process \
            else cache.get(self.make_key(key, 'window')) or 0
        errors = self._total_errors if self.in_process \
            else cache.get(self.make_key(key, 'errors')) or 0
        invokes = self._total_invokes if self.in_process \
            else cache.get(self.make_key(key, 'invokes')) or 0
        total_invoke_time = self._total_invoke_time if self.in_process \
            else cache.get(self.make_key(key, 'invoke-time')) or 0
        error_invokes = self._total_error_invokes if self.in_process \
            else cache.get(self.make_key(key, 'error-invokes')) or 0
        timeout_invokes = self._total_timeout_invokes if self.in_process \
            else cache.get(self.make_key(key, 'timeout-invokes')) or 0
        values = dict(
            time=now,
            requests=exp.F('requests') + requests,
            req_per_sec=round(requests / (now - inst.time).total_seconds(), 2),
            avg_time=((exp.F('avg_time') * exp.F('requests') + total_time) /
                      (exp.F('requests') + requests)) if requests else exp.F('avg_time'),
            invokes=exp.F('invokes') + invokes,
            error_invokes=exp.F('error_invokes') + error_invokes,
            timeout_invokes=exp.F('timeout_invokes') + timeout_invokes,
            invoke_per_sec=round(invokes / (now - inst.time).total_seconds(), 2),
            avg_invoke_time=((exp.F('invokes') * exp.F('avg_invoke_time') +
                              total_invoke_time) / (exp.F('invokes') + invokes))
            if invokes else exp.F('avg_invoke_time'),
            in_traffic=exp.F('in_traffic') + in_traffic,
            out_traffic=exp.F('out_traffic') + out_traffic,
            errors=exp.F('errors') + errors
        )
        if total_window:
            if inst.avg_window:
                values.update(avg_window=((exp.F('avg_window') * exp.F('requests') + total_window)
                                          / (exp.F('requests') + requests)) if requests else exp.F('avg_window'))
            elif requests:
                values.update(avg_window=total_window / requests)

        return replace_null(values)

    def reset(self, key: str):
        if self.in_process:
            self._total_requests = 0
            self._total_errors = 0
            self._total_time = 0
            self._total_in = 0
            self._total_out = 0
            self._total_invokes = 0
            self._total_invoke_time = 0
            self._total_error_invokes = 0
            self._total_timeout_invokes = 0
            self._total_window = 0
        else:
            cache = self.get_cache()
            cache.set(self.make_key(key, 'requests'), 0)
            cache.set(self.make_key(key, 'in'), 0)
            cache.set(self.make_key(key, 'out'), 0)
            cache.set(self.make_key(key, 'time'), 0)
            cache.set(self.make_key(key, 'window'), 0)
            cache.set(self.make_key(key, 'errors'), 0)
            cache.set(self.make_key(key, 'invokes'), 0)
            cache.set(self.make_key(key, 'invoke-time'), 0)
            cache.set(self.make_key(key, 'error-invokes'), 0)
            cache.set(self.make_key(key, 'timeout-invokes'), 0)

    def save(self, inst, **kwargs):
        values = self.retrieve(inst)
        values.update(kwargs)
        self.reset(inst.pk)
        MetaQuerySet(model=inst.__class__).filter(pk=inst.pk).update(**values)
        return values

    def serialize(self, inst) -> dict:
        values = self.retrieve(inst)
        return MetaQuerySet(model=inst.__class__).filter(pk=inst.pk).values(**values)[0]


class LogManager:
    def __init__(self, logger: Logger):
        from utilmeta.conf import config
        self.logger = logger
        self.config = config.log
        self.secret_names = config.ops.secret_names

    @property
    def id(self):
        return self.logger.id

    @property
    def invoke(self):
        return self.logger.invoke

    @property
    def process_id(self):
        return self.logger.process_id

    @property
    def from_process(self):
        return self.logger.from_process

    @property
    def thread_id(self):
        return self.logger.thread_id

    @property
    def from_thread(self):
        return self.logger.from_thread

    @property
    def to_service(self):
        return self.logger.to_service

    @property
    def to_instance(self):
        return self.logger.to_instance

    def get_context_id(self):
        if not self.logger.context_logger:
            return None
        return self.logger.context_logger.id

    @classmethod
    def append_api_queue(cls, request: Union[Request, Call], response):
        global _api_log_queue
        _api_log_queue.append((request, response))
        cls.append_context_queue(request)
        if len(_api_log_queue) >= config.log.cache_max_entries:
            with threading.Lock():
                task.omit(cls.consume_api_queue)(_api_log_queue, close=True)
                _api_log_queue = []
        return

    @classmethod
    def append_context_queue(cls, request):
        if request.log.context_logger:
            global _context_log_queue
            _context_log_queue.append(request.log)
        return

    @classmethod
    # @print_queries(config.ops.db_alias)
    def consume_api_queue(cls, queue=None, worker=None, close: bool = False):
        from utilmeta.ops.models.log import BaseLog, ServiceLog, QueryLog
        from utilmeta.ops.models.service import ServiceWorker
        from utilmeta.ops.models.utils import Endpoint

        with threading.Lock():
            base_creates = []
            query_creates = []
            base_updates = []
            # base_logs = []
            loggers = []

            log_values = []
            cls_logs = {}
            global _api_log_queue
            empty = queue is None
            queue = queue or _api_log_queue
            # empty this queue
            if empty:
                _api_log_queue = []

            endpoint_map = {}
            endpoint_idents = set()
            for req, resp in queue:
                if isinstance(req, Request):
                    endpoint_idents.add(req.endpoint_ident)

            if endpoint_idents:
                endpoint_map = {val[0]: val[1] for val in Endpoint.objects.filter(
                    ident__in=endpoint_idents).values_list('ident', 'id')}

            worker = worker or ServiceWorker.get(os.getpid())
            for i, (req, resp) in enumerate(queue):
                try:
                    eid = None
                    if isinstance(req, Request):
                        eid = endpoint_map.get(req.endpoint_ident)

                    logs = cls(logger=req.log).generate_api_logs(
                        req, resp,
                        worker=worker,
                        endpoint_id=eid
                    )

                    if not logs:
                        continue
                    base_log, *class_logs = logs

                    srv_log = None
                    for log in class_logs:
                        if isinstance(log, ServiceLog):
                            srv_log = log
                            break

                    if srv_log:
                        if config.log.log_db_query:
                            query_logs = cls(logger=req.log).generate_query_logs(context_log=srv_log)
                            query_creates.extend(query_logs)

                    if base_log.pk:
                        base_updates.append(base_log)
                    else:
                        base_creates.append(base_log)
                        loggers.append(req.log)
                        # base_logs.append(base_log)
                        log_values.append(class_logs)

                    for log in class_logs:
                        if log.__class__ in cls_logs:
                            cls_logs[log.__class__].append(log)
                        else:
                            cls_logs[log.__class__] = [log]

                except Exception as e:
                    from utilmeta.util.error import Error
                    print('generate api logs with error:', Error(e).full_info)
                    continue
                finally:
                    if resp:
                        resp.close()

            if not base_updates and not base_creates:
                return

            with transaction.atomic(config.ops.db_alias):
                if base_updates:
                    MetaQuerySet(model=BaseLog).bulk_update(
                        base_updates, fields=['duration', 'volatile', 'out_traffic']
                    )
                if base_creates:
                    if config.ops.db_support_bulk_with_pk:
                        base_creates = MetaQuerySet(model=BaseLog).bulk_create(base_creates)
                        # cannot use ignore_conflicts=True, or pk will be None
                    else:
                        for log in base_creates:
                            log.save()

                for log, values, logger in zip(base_creates, log_values, loggers):
                    for val in values:
                        val.log_id = log.pk
                    logger.id = log.pk

                for log_cls, logs in cls_logs.items():
                    MetaQuerySet(model=log_cls).bulk_create(logs, ignore_conflicts=True)

                if query_creates:
                    MetaQuerySet(model=QueryLog).bulk_create(query_creates, ignore_conflicts=True)

            if config.alert:
                from utilmeta.ops.models.log import AlertLog
                from utilmeta.util.alert import Alert

                if config.alert.service_error_auto_relieve:
                    for log_id in set(BaseLog.objects.filter(
                        level=LogLevel.INFO,
                        type=LogType.service,
                        time__gte=time_now() - timedelta(seconds=config.monitor.worker_monitor_interval),
                        alert__type__category=AlertCategory.service_error,
                        alert__relieved_time=None
                    ).values_list('alert', flat=True)):
                        log = AlertLog.get(log_id)
                        if not log:
                            continue
                        if log.relieve():
                            continue
                        Alert.notify_supervisor(log)

                if config.alert.downgrade_auto_relieve:
                    for log_id in set(BaseLog.objects.filter(
                        type=LogType.service,
                        duration__lte=config.alert.slow_response_threshold * 1000,
                        time__gte=time_now() - timedelta(seconds=config.monitor.worker_monitor_interval),
                        alert__type__category=AlertCategory.service_downgrade,
                        alert__relieved_time=None
                    ).values_list('alert', flat=True)):
                        log = AlertLog.get(log_id)
                        if not log:
                            continue
                        if log.relieve():
                            continue
                        Alert.notify_supervisor(log)

        if close:
            from utilmeta.util.common import close_connections
            close_connections()
        return

    @classmethod
    def consume_context_queue(cls):
        with threading.Lock():
            cases = []
            pks = []
            global _context_log_queue
            for log in _context_log_queue:
                if log.id and log.context_logger.id:
                    pks.append(log.id)
                    cases.append(exp.When(pk=log.id, then=log.context_logger.id))
                    _context_log_queue.remove(log)
                if log.expired:
                    _context_log_queue.remove(log)
            if cases:
                from utilmeta.ops.models.log import RequestLog
                RequestLog.objects.filter(pk__in=pks).update(context_log_id=exp.Case(*cases))
        return

    @classmethod
    @ignore_errors
    def parse(cls, data):
        from utilmeta.conf import config
        if not config.ops:
            return str(data)
        if isinstance(data, dict):
            result = {}
            for k, v in data.items():
                k: str
                if isinstance(v, list):
                    result[k] = cls.parse(v)
                elif file_like(v):
                    result[k] = str(v)
                else:
                    for key in config.ops.secret_names:
                        if key in k.lower():
                            v = SECRET
                            break
                    result[k] = v
            return result
        if isinstance(data, list):
            result = []
            for d in data:
                if file_like(d):
                    result.append(str(d))
                else:
                    result.append(d)
            return result
        if file_like(data):
            return Hint.STREAMING_CONTENT
        return str(data)

    @classmethod
    def status_level(cls, status: int):
        level = LogLevel.INFO
        if not status:
            level = LogLevel.ERROR
        elif status >= 500:
            level = LogLevel.ERROR
        elif status >= 400:
            level = LogLevel.WARN
        return LOG_LEVELS.index(level)

    # @print_queries(config.ops.db_alias)
    def generate_api_logs(self, request: Union['Call', 'Request'],
                          response: Union[HTTPResponse, HttpResponseBase],
                          worker=None, endpoint_id=None):

        if self.logger.omitted or not self.logger.root:
            return
        if self.config.api_log_pre_save_hook:
            self.config.api_log_pre_save_hook(request, response)

        from utilmeta.ops.models.log import RequestLog, ServiceLog, HttpLog, BaseLog
        from utilmeta.ops.models.service import ServiceWorker

        duration = self.logger.duration or self.logger.relative_time()
        from utilmeta.conf import config

        resp_length = response_length(response, content_only=True)
        resp_full_length = response_length(response, content_only=False)
        req_full_length = request_length(request)

        status = response.status if isinstance(response, HTTPResponse) \
            else response.status_code if isinstance(response, HttpResponseBase) else None
        error = not status or status >= 500
        window = None
        host = None
        public = True
        log_type = LogType.service
        if response:
            resp_headers = response if isinstance(response, HttpResponseBase) else response.headers
        else:
            resp_headers = {}

        if isinstance(request, Call):
            from urllib.parse import urlparse
            res = urlparse(request.url)
            host = res.netloc
            path = res.path.strip('/')
            in_traffic = resp_full_length
            out_traffic = req_full_length
            level = self.status_level(status)
            duration = request.duration
            data = request.data
            query = request.query
            method = request.method.lower()
            log_type = LogType.request

            if self.to_instance:
                recv_ts = resp_headers.get(MetaHeader.RECV_TIMESTAMP) if response else None
                window = (request.send_utc_timestamp - float(recv_ts)) / 1000 if recv_ts else None
            try:
                public = not ip_address(get_ip(request.url, ip_only=True)).is_private
            except ValueError:
                pass
        else:
            path = request.path
            in_traffic = req_full_length
            out_traffic = resp_full_length
            level = self.logger.level
            query = dict(request.QUERY or {})
            data = request.BODY
            method = request.METHOD.lower()

            log_text = f"[{request.time.strftime(Format.DATETIME)}] {request.method} {request.full_path} " \
                       f"from [{request.ip}] -- response [{status}] " \
                       f"with [{resp_length}] Bytes in [{duration}] ms\n{self.logger.message}"
            if self.config.log_file:
                if not os.path.exists(self.config.log_file):
                    mode = 'w'
                else:
                    mode = 'a'
                write_to(self.config.log_file, content=log_text, mode=mode)
            if self.config.print:
                print(log_text)
                print(self.logger.message)
            try:
                public = not request.ip_address.is_private
            except ValueError:
                pass

        if config.monitor:
            metrics = dict(
                time=duration or 0, invoke=isinstance(request, Call),
                error=error, timeout=not response, window=window,
                in_traffic=in_traffic, out_traffic=out_traffic
            )
            ServiceWorker.logger.log(**metrics)
            MetricsLogger().log(key=config.deploy.instance_id, **metrics)

        if not self.config or not config.ops:
            # if request level > INFO/DEBUG, ignore omit
            return

        volatile = self.logger.option == Logger.VOLATILE
        if level >= self.config.log_persist_level:
            volatile = False
        if duration and duration >= self.config.log_persist_time_limit * 1000:
            volatile = False

        if self.logger.foreground_saved:
            self.logger.wait_for_id()

        log = BaseLog(
            id=self.id,
            version_id=config.version_id,
            level=str(level),
            volatile=volatile,
            time=convert_time(request.time),
            type=log_type,
            duration=duration,
            worker=worker,
            scheme=request.scheme,
            thread_id=self.thread_id,
            in_traffic=in_traffic,
            out_traffic=out_traffic,
            public=public,
            path=path,
        )
        objects = [log]
        if request.is_http:
            request_headers = {}
            response_headers = {}
            if level >= self.config.headers_store_level:
                for key, val in request.headers.items():
                    key: str
                    if key.startswith('X-') and not key.startswith('X-Forwarded'):
                        if config.csrf.header_name == http_header(key):
                            val = SECRET
                        for k in self.secret_names:
                            if k in key.lower():
                                val = SECRET
                                break
                        request_headers[key] = val

                for key, val in resp_headers.items():
                    key: str
                    if key == Header.CONTENT_LANGUAGE:
                        response_headers[key] = val
                    elif not key.startswith('Content-'):
                        for k in self.secret_names:
                            if k in key.lower():
                                val = SECRET
                                break
                        response_headers[key] = val

            http_log = HttpLog(
                log_id=self.id,
                query=normalize(query, _json=True),
                data=None,
                result=None,
                user_agent=None,
                status=status,
                request_type=request.content_type,
                response_type=GeneralType.get(resp_headers.get(Header.TYPE)) if response else None,
                request_headers=request_headers,
                response_headers=response_headers if response else None,
                length=resp_length if response else None,
                method=method
            )

            if level >= self.config.result_store_level:
                http_log.result = Response.get_clear_content(response)
            if level >= self.config.data_store_level:
                if data:
                    http_log.data = normalize(self.parse(data), _json=True)
            if self.config.parse_user_agent:
                http_log.user_agent = parse_user_agents(request.ua_string)

            objects.append(http_log)

        if isinstance(request, Call):
            block = not (self.from_process and self.from_thread)
            if not request.block:
                block = False
            remote_log = None
            if response and MetaHeader.LOG in resp_headers:
                remote_log = int(resp_headers.get(MetaHeader.LOG))
            objects.append(RequestLog(
                log_id=self.id,
                block=block,
                host=host,
                timeout=request.timeout,
                timeout_error=request.timeout_error,
                to_service_id=resp_headers.get(MetaHeader.SERVICE_NAME, self.to_service),
                to_instance_id=resp_headers.get(MetaHeader.INSTANCE, self.to_instance),
                context_log_id=self.get_context_id(),
                remote_log=remote_log,
            ))
        elif isinstance(request, Request):
            service_log = ServiceLog(
                log_id=self.id,
                endpoint_id=endpoint_id,
                messages=self.logger.messages,
                trace=normalize(self.logger.events, _json=True),
                from_service_id=request.source_service,
                from_instance_id=request.source_instance,
                user_id=request.user_id,
                session_id=getattr(request.session, 'session_id', None),
                admin=request.admin,
                ip=str(request.ip),
                queries_num=self.logger.queries_num,
                queries_duration=self.logger.queries_duration_ms,
            )

            if config.ops and config.ops.ignore_ops_alerts and request.is_ops:
                # not record ops errors
                pass
            else:
                if config.alert and config.alert.slow_response_threshold:
                    from utilmeta.util.alert import Alert
                    trigger = duration >= config.alert.slow_response_threshold * 1000
                    if trigger:
                        log.volatile = not trigger
                        message = f'Slow response at {request.METHOD} /{request.endpoint_path}'\
                                  f' for {round(duration / 1000, 2)} s: {self.logger.brief_message}'

                        log.alert = Alert.log(
                            subcategory='endpoint_slow_response',
                            level=config.alert.slow_response_alert_level,
                            ident=f'endpoint_slow_response:{request.endpoint_ident}'[:200],
                            category=AlertCategory.service_downgrade,
                            name=f'slow response at {request.METHOD} /{request.endpoint_path}'[:100],
                            message=message,
                            request_ip=str(request.ip),
                            request_user_id=request.user_id,
                            trigger_time=request.time,
                            trigger_value=duration,
                            trigger=trigger,
                            threshold=config.alert.slow_response_threshold,
                            # if not trigger then relieve
                            endpoint_id=endpoint_id,
                            data=dict(
                                method=request.METHOD,
                                path=request.endpoint_path,
                                level=str(level),
                                status=status,
                            )
                        )

                # if self.logger.level >= LOG_LEVELS.index(LogLevel.ERROR):
                if config.alert and config.alert.error_request_alert_level:
                    trigger = self.logger.level >= LOG_LEVELS.index(LogLevel.ERROR)
                    if trigger or config.alert.service_error_auto_relieve:
                        from utilmeta.util.alert import Alert
                        log.volatile = not trigger
                        log.alert = Alert.log(
                            subcategory=f'endpoint_error_response',
                            ident=f'endpoint_error_response:{request.endpoint_ident}'[:200],
                            level=config.alert.error_request_alert_level,
                            message=self.logger.brief_message,
                            category=AlertCategory.service_error,
                            name=f'error at {request.METHOD} /{request.endpoint_path}'[:100],
                            trigger=trigger,
                            request_ip=str(request.ip),
                            request_user_id=request.user_id,
                            trigger_time=request.time,
                            endpoint_id=endpoint_id,
                            data=dict(
                                method=request.METHOD,
                                path=request.endpoint_path,
                                status=status,
                                level=str(level),
                            )
                        )

            objects.append(service_log)
        return objects

    def generate_query_logs(self, context_log=None, context_job=None):
        from utilmeta.ops.models.log import QueryLog
        from utilmeta.ops.models.service import DatabaseStorage, Worker
        logs = []
        now = time_now()

        for alias, queries in self.logger.queries.items():
            db_storage = DatabaseStorage.get(alias)
            db = config.databases.get(alias)
            if not db_storage or not db:
                continue
            if config.ops and config.ops.ignore_ops_alerts and alias == config.ops.db_alias:
                # ignore ops alerts
                continue

            for sql in queries:
                sql: dict
                if db.pooled and sql.get('key') != db.get_pooled_key():
                    continue
                duration_ms = int(float(sql.get('time') or 0) * 1000)
                log_trigger = duration_ms >= config.log.query_limit * 1000
                if not log_trigger:
                    continue

                alert = None
                query = sql['sql']
                type = get_sql_type(query)
                tables = get_sql_tables(query)
                sql_time = sql.get('init') or now
                ident = (f'{type}:%s' % ','.join(tables))[:100]

                if config.alert and config.alert.slow_query_threshold:
                    trigger = duration_ms >= config.alert.slow_query_threshold * 1000
                    if trigger:
                        # if duration_ms >= config.alert.slow_query_threshold * 1000:
                        from utilmeta.util.alert import Alert
                        sub = 'endpoint' if context_log else 'execution'
                        message = f'Slow query at {ident} for {round(duration_ms / 1000, 2)} s: {query}'
                        try:
                            endpoint_id = context_log.endpoint.id
                        except AttributeError:
                            endpoint_id = None

                        alert = Alert.log(
                            subcategory=f'{sub}_slow_query',
                            level=config.alert.slow_query_alert_level,
                            category=AlertCategory.service_downgrade if context_log else AlertCategory.task_downgrade,
                            ident=f'{sub}_slow_query:{ident}',
                            name=f'slow query at {ident}',
                            trigger=trigger,
                            trigger_time=sql_time,
                            trigger_value=duration_ms,
                            endpoint_id=endpoint_id,
                            threshold=config.alert.slow_query_threshold,
                            request_ip=str(context_log.ip) if context_log else None,
                            request_user_id=context_log.user_id if context_log else None,
                            message=message,
                            data=dict(
                                type=type,
                                tables=tables,
                                duration=duration_ms
                            )
                        )

                logs.append(QueryLog(
                    time=sql_time,
                    context_log=context_log,
                    context_job=context_job,
                    database=db_storage,
                    query=query,
                    alert=alert,
                    type=type,
                    tables=tables,
                    duration=duration_ms,
                    worker=Worker.current()
                ))

        return logs

    def save_api_log(self, request: Request):
        if self.logger.omitted or not self.logger.root or self.id:
            return
        from utilmeta.ops.models.log import BaseLog
        from utilmeta.ops.models.service import ServiceWorker
        self.append_context_queue(request)
        try:
            public = not request.ip_address.is_private
        except ValueError:
            public = False
        obj = BaseLog(
            version_id=config.version_id,
            level=str(self.logger.level),
            volatile=True,
            time=convert_time(request.time),
            type=LogType.service,
            duration=None,
            scheme=request.scheme,
            worker=ServiceWorker.get(self.process_id),
            thread_id=self.thread_id,
            path=request.path,
            in_traffic=request_length(request),
            public=public
        )
        obj.save(force_insert=True)
        self.logger.id = obj.pk
        return
