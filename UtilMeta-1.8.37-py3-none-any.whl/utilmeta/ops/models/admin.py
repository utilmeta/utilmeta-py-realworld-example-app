from utilmeta.fields import *
from utilmeta.models import *
from utilmeta.types import *
from utilmeta.util.common import Scheme, get_origin, exp, constant, time_now
from .service import Service
from .utils import Resource

__all__ = ['Supervisor', 'Admin', 'Session', 'Permission', 'ExternalMixin']


class Supervisor(Model):
    objects = MetaManager()
    id = CharField(max_length=40, primary_key=True)
    # cluster_id = CharField(max_length=40)
    # auto-generated from platform to identify cluster, identical cluster_id represent that those supervisor
    # are from one platform
    service: Service = ForeignKey(Service, on_delete=CASCADE, related_name='supervisors')
    name = CharField(max_length=64)
    offline_enabled = BooleanField(default=True)
    # enable offline (ak/signature-only, no remote-auth/token-retrieve) to open resources to utilmeta ecosystem
    backup_urls = ArrayField(URLField(), default=list)
    # direct callback to master url, like https://utilmeta.com/api/action/backup?id=<ID> for backup node servers
    action_url = URLField()
    # remote_ops_api = URLField(default=None, null=True)
    # when local ops_api changed on proxy (including base_url/host altered)
    action_token = CharField(max_length=64, unique=True)
    setup_time = DateTimeField(auto_now_add=True)
    last_heartbeat = DateTimeField(default=time_now)
    # last_operation = DateTimeField(default=time_now)
    operation_timeout = DecimalField(max_digits=8, decimal_places=3, default=5)
    disabled = BooleanField(default=True)
    open_operations = ArrayField(CharField(max_length=40), default=list)
    # open for every request user
    latency = PositiveIntegerField(default=None, null=True)     # ms
    heartbeat_times = PositiveBigIntegerField(default=0)
    allowed_addresses = ArrayField(GenericIPAddressField(), default=None, null=True)
    # reported_version = ForeignKey(
    #     'VersionLog', related_name='reported_supervisors',
    #     on_delete=SET_NULL, null=True, default=None
    # )
    # average ms latency for request to the supervisor
    settings: dict = JSONField(default=dict)
    # heartbeat_enabled: False
    # report_enabled: true
    # notify_enabled: false
    # instance_sync_enabled: false
    # document_sync_enabled: false

    info = JSONField(default=dict)  # store backward compat information

    class Meta(ModelOptions):
        db_table = 'utilmeta_supervisor'
        unique_together = ('service', 'action_url')

    @classmethod
    def get(cls, id: str, disabled: Optional[bool] = False) -> 'Supervisor':
        from utilmeta.conf import config
        qs = cls.objects.filter(id=id, service_id=config.name)
        if disabled is not None:
            qs = qs.filter(disabled=disabled)
        return qs.first()

    @property
    def secure(self) -> str:
        from urllib.parse import urlparse
        return urlparse(str(self.action_url)).scheme == Scheme.HTTPS

    @property
    def origin(self) -> str:
        return get_origin(str(self.action_url), default_scheme=Scheme.HTTPS)

    @property
    def heartbeat_enabled(self):
        return self.settings.get('heartbeat_enabled', False)

    @property
    def report_enabled(self):
        return self.settings.get('report_enabled', True)

    @property
    def notify_enabled(self):
        return self.settings.get('notify_enabled', False)

    @property
    def instance_sync_enabled(self):
        return self.settings.get('instance_sync_enabled', False)

    @property
    def document_sync_enabled(self):
        return self.settings.get('document_sync_enabled', False)

    # def report(self, version_log):
    #     self.reported_version = version_log
    #     self.save(update_fields=['reported_version'])


class Admin(Model):
    objects = MetaManager()
    supervisor = ForeignKey(Supervisor, on_delete=CASCADE)
    access_key = CharField(max_length=64, unique=True)
    secret_key = CharField(max_length=64)
    remote_id = CharField(max_length=100)
    # team manager can create an abstract Admin template (with configured permissions)
    root = BooleanField(default=False)
    operations = ArrayField(CharField(max_length=40), default=list)
    resources = ManyToManyField(
        Resource, through='Permission',
        related_name='accessible_admins',
        through_fields=('admin', 'resource')
    )
    access_control_types = ArrayField(
        ChoiceField(constant.ResourceType.gen(), retrieve_key=False, store_key=False), default=list
    )
    # if access_control is enabled, permission validation will use Permission table
    # for fine-granularity authentication
    # elsewhere will use admin.operations
    allowed_addresses = ArrayField(GenericIPAddressField(), default=None, null=True)
    last_updated = DateTimeField(auto_now=True)
    last_activity = DateTimeField(default=None, null=True)
    granted_by = ForeignKey('self', related_name='granted_admins', on_delete=SET_NULL, null=True, default=None)
    granted_time = DateTimeField(auto_now_add=True)
    info = JSONField(default=dict)  # store backward compat information

    class Meta(ModelOptions):
        db_table = 'utilmeta_admin'
        unique_together = ('supervisor', 'remote_id')
        constraints = [
            UniqueConstraint(fields=['supervisor'], condition=exp.Q(root=True), name='one_root_per_supervisor')
        ]

    @classmethod
    def get(cls, access_key: str = None, remote_id: str = None, supervisor_id: str = None) -> Optional['Admin']:
        if access_key:
            return cls.objects.filter(access_key=access_key).first()
        return cls.objects.filter(remote_id=remote_id, supervisor_id=supervisor_id).first()


class Permission(Model):
    objects = MetaManager()
    admin = ForeignKey(Admin, on_delete=CASCADE, related_name='permissions')
    resource = ForeignKey(Resource, on_delete=CASCADE, related_name='permissions')
    operations = ArrayField(CharField(max_length=20), default=list)
    granted_by = ForeignKey(Admin, on_delete=SET_NULL, null=True, related_name='granted_permissions')
    granted_time = DateTimeField(auto_now_add=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_permission'
        unique_together = ('admin', 'resource')


class Session(Model):
    objects = MetaManager()
    id = CharField(max_length=20, primary_key=True)
    session_key = CharField(max_length=60, unique=True)
    # data = JSONField(default=dict)
    encoded_data = TextField()
    ip = GenericIPAddressField(default=None, null=True)
    ua_string = TextField(default=None, null=True)
    user_agent = JSONField(default=None, null=True)
    user_id = CharField(max_length=60, default=None, null=True, db_index=True)

    setup_time = DateTimeField(auto_now_add=True)
    expiry_time = DateTimeField(default=None, null=True)
    delete_time = DateTimeField(default=None, null=True)
    expiry_age = PositiveBigIntegerField(default=None, null=True)
    last_activity = DateTimeField(default=time_now)

    class Meta(ModelOptions):
        db_table = 'utilmeta_session'


class ExternalMixin(Model):
    added_time = DateTimeField(default=time_now)
    added_by = ForeignKey(Admin, on_delete=SET_NULL, null=True)
    last_disable = DateTimeField(default=None, null=True)
    last_enable = DateTimeField(default=None, null=True)
    external = BooleanField(default=False)
    disabled = BooleanField(default=False)

    class Meta(ModelOptions):
        abstract = True
