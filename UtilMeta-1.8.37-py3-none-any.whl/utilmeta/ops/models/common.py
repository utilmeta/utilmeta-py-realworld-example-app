from utilmeta.fields import *
from utilmeta.util.common import gen_key

__all__ = ['RequestMetrics', 'SystemMetrics', 'id_generator', 'TaskMetrics',
           'LoggerMixin', 'TaskJobMetrics', 'CommonAggregate']


def id_generator():
    return gen_key(6, alnum=True)


class LoggerMixin(Model):
    queries_num = PositiveIntegerField(default=0)
    queries_duration = PositiveBigIntegerField(default=0)
    trace = JSONField(default=list)
    messages = ArrayField(TextField(), default=list)

    class Meta(ModelOptions):
        abstract = True


class CommonAggregate(Model):
    mean_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 50%
    p95_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 95%
    p99_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 99%
    p999_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 99.9%
    time_stddev = DecimalField(max_digits=10, decimal_places=2, default=0.00, null=True)

    class Meta(ModelOptions):
        abstract = True


class RequestMetrics(Model):
    """
    request metrics that can simply be calculated in form of incr and divide
    """
    requests = PositiveBigIntegerField(default=0)   # requests made from current service to target instance
    req_per_sec = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    in_traffic = PositiveBigIntegerField(default=0, null=True)    # in bytes
    out_traffic = PositiveBigIntegerField(default=0, null=True)    # in bytes
    # data_trans = PositiveBigIntegerField(default=0, null=True)
    errors = PositiveBigIntegerField(default=0)     # error requests made from current service to target instance
    avg_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    # avg process time of requests made from this service
    invokes = PositiveIntegerField(default=0)      # total request log count
    invoke_per_sec = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    timeout_invokes = PositiveBigIntegerField(default=0)    # total timeout invokes
    error_invokes = PositiveBigIntegerField(default=0)      # total error invokes
    avg_invoke_time = DecimalField(max_digits=10, decimal_places=2, default=0)

    SUM_KEYS = [requests, invokes, error_invokes, req_per_sec, timeout_invokes,
                errors, in_traffic, out_traffic, invoke_per_sec]

    class Meta(ModelOptions):
        abstract = True


class SystemMetrics(Model):
    cpu_percent = DecimalField(max_digits=6, decimal_places=2, default=0.00)
    memory_percent = DecimalField(max_digits=6, decimal_places=2, default=0.00)
    used_memory = PositiveBigIntegerField(default=0)
    disk_percent = DecimalField(max_digits=6, decimal_places=2, default=0.00)
    file_descriptors = PositiveIntegerField(default=None, null=True)
    open_files = PositiveBigIntegerField(default=0)
    active_net_connections = PositiveIntegerField(default=0)
    total_net_connections = PositiveIntegerField(default=0)

    class Meta(ModelOptions):
        abstract = True


class TaskJobMetrics(Model):
    total_jobs = PositiveBigIntegerField(default=0)
    failed_jobs = PositiveBigIntegerField(default=0)
    timeout_jobs = PositiveBigIntegerField(default=0)
    retried_jobs = PositiveBigIntegerField(default=0)

    job_min_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    job_avg_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    job_max_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    jobs_per_sec = DecimalField(max_digits=10, decimal_places=2, default=0.00)      # concurrency

    class Meta(ModelOptions):
        abstract = True


class TaskMetrics(TaskJobMetrics):
    executed_events = PositiveBigIntegerField(default=0)
    abandoned_events = PositiveIntegerField(default=0)

    executed_executions = PositiveBigIntegerField(default=0)
    failed_executions = PositiveBigIntegerField(default=0)
    timeout_executions = PositiveBigIntegerField(default=0)

    avg_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)

    class Meta(ModelOptions):
        abstract = True
