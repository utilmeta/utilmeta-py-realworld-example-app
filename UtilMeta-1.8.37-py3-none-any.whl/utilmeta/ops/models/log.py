from utilmeta.fields import *
from utilmeta.util.common import constant, time_now, ProblemTarget, exp, exc
from utilmeta.util.query import MetaManager
from utilmeta.conf import Version
from typing import Optional
from .common import LoggerMixin, id_generator
from .service import BaseInstance, Worker, Service,\
    CacheStorage, Server, DatabaseStorage
from .admin import Admin, ExternalMixin, Session
from .utils import Endpoint
from .task import TaskSettings, TaskJob
from datetime import timedelta, datetime


__all__ = ['VersionLog', 'AlertLog', 'BaseLog', 'HttpLog', 'CacheLog',
           'AlertSettings', 'QueryLog', 'AlertType',
           'ServiceLog', 'RequestLog', 'ViolateLog', 'OperationLog']


class VersionLog(Model):
    objects = MetaManager()
    setup_time = DateTimeField(auto_now_add=True)
    updates = JSONField(default=dict)       # document updates
    # migrations = JSONField(default=dict)      # models migrates
    version = CharField(max_length=100)
    spec_version = CharField(max_length=20)
    python_version = CharField(max_length=20)
    utilmeta_version = CharField(max_length=20)
    info = JSONField(default=dict)  # store backward compat information
    instance = ForeignKey(BaseInstance, on_delete=CASCADE, related_name='version_logs')
    major = PositiveSmallIntegerField(default=0)
    minor = PositiveSmallIntegerField(default=1)
    patch = PositiveSmallIntegerField(default=0)
    meta = CharField(max_length=50, default=None, null=True)
    # reported = BooleanField(default=False)      # report version update to supervisor

    class Meta(ModelOptions):
        db_table = 'utilmeta_version_log'

    @classmethod
    def check_version(cls, inst_id: str, version: Version):
        base = cls.objects.filter(instance_id=inst_id).order_by('major', 'minor', 'patch')
        reset = f'set version correctly or use [meta version reset] to clear all previous versions'
        m1 = base.filter(major__gt=version.major)
        if m1.exists():
            raise ValueError(f'Invalid version with decreased major version:'
                             f' {m1.last().major} -> {version.major}, {reset}')
        m2 = base.filter(major=version.major, minor__gt=version.minor)
        if m2.exists():
            raise ValueError(f'Invalid version with decreased minor version:'
                             f' {m2.last().minor} -> {version.minor}, {reset}')
        m3 = base.filter(major=version.major, minor=version.minor, patch__gt=version.patch)
        if m3.exists():
            raise ValueError(f'Invalid version with decreased patch version:'
                             f' {m3.last().patch} -> {version.patch}, {reset}')

    @classmethod
    def diff(cls, instance: BaseInstance, data: dict):
        from utilmeta.util.common import temp_diff, temp_patch, COMMON_ERRORS
        version_base = cls.objects.filter(instance=instance).exclude(updates={}).order_by('pk')
        versions = list(version_base.values_list('updates', flat=True))
        updates = data
        if versions:
            root, *updates = versions
            try:
                updates = temp_diff(temp=data, base=temp_patch(root, *updates))
            except COMMON_ERRORS as e:
                print(f'detect a version update of VersionLog that cause an error: {e}, clearing updates')
                version_base.update(updates={})
        return updates

    @classmethod
    def valid_instances(cls, major: int, minor: int, minor__ge: int = None):
        from utilmeta.conf import config
        base = cls.objects.filter(instance__service_id=config.name, major=major)
        if minor is not None:
            base = base.filter(minor=minor)
        elif minor__ge is not None:
            base = base.filter(minor__ge=minor__ge)
        return list(set(base.values_list('instance', flat=True)))

    @classmethod
    def latest(cls, inst_id) -> Optional['VersionLog']:
        return VersionLog.objects.filter(instance_id=inst_id).order_by('-setup_time').first()

    @classmethod
    def current(cls):
        from utilmeta.util.common import exc
        from utilmeta.conf import config
        try:
            return cls.latest(config.deploy.instance_id) or cls.latest(config.task.instance_id)
        except exc.DatabaseError:
            return None


class CacheLog(Model):
    objects = MetaManager()
    time = DateTimeField(default=time_now)
    type = CharField(max_length=60)
    error = TextField(default='')
    targets = JSONField(default=list)
    # [dict(time=<TIME>, message='', key=..., value=...)]
    cache = ForeignKey(CacheStorage, on_delete=CASCADE, related_name='logs')
    latest_time = DateTimeField(default=time_now)
    count = PositiveBigIntegerField(default=1)

    class Meta(ModelOptions):
        db_table = 'utilmeta_cache_log'


class AlertSettings(ExternalMixin):
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    service = ForeignKey(Service, on_delete=CASCADE, related_name='alert_settings')
    index_name = CharField(max_length=100)      # data field
    # == manual
    index_class = CharField(max_length=200)                             # datasource
    index_params = JSONField(default=None, null=True)                   # data query
    custom = BooleanField(default=True)
    # --- inline
    # index_source = CharField(max_length=200, default=None, null=True)     # either index_class (manual) / index_source
    # index_query = JSONField(default=dict)
    index_aggregator = CharField(max_length=20, default=None, null=True)

    level = ChoiceField(constant.AlertLevel.gen(), default=constant.AlertLevel.WARNING, retrieve_key=False)
    threshold = FloatField(default=None, null=True)  # static threshold
    dynamic_thresholds = JSONField(default=dict)

    exceed = BooleanField(default=True)
    name = CharField(max_length=100)

    # target
    server = ForeignKey(Server, on_delete=CASCADE, related_name='alert_settings', default=None, null=True)
    instance = ForeignKey(BaseInstance, on_delete=CASCADE, related_name='alert_settings', default=None, null=True)
    # --
    task_settings = ForeignKey(
        TaskSettings, on_delete=SET_NULL, related_name='alert_settings', default=None, null=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_alert_settings'
        # unique_together = ('index', 'level', 'server', 'service', 'instance')
        unique_together = ('service', 'name')

    @classmethod
    def get(cls, name: str) -> Optional['AlertSettings']:
        from utilmeta.conf import config
        return cls.objects.filter(service_id=config.name, name=name).first()


class AlertType(Model):
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    service = ForeignKey(Service, on_delete=CASCADE, related_name='alert_types')
    category = ChoiceField(constant.AlertCategory.gen(), retrieve_key=False, default=constant.AlertCategory.custom)
    level = ChoiceField(constant.AlertLevel.gen(), default=constant.AlertLevel.WARNING, retrieve_key=False)
    # configurable

    settings: AlertSettings = OneToOneField(
        AlertSettings, on_delete=SET_NULL, default=None, null=True, related_name='alert_type')
    threshold = FloatField(default=None, null=True)
    # for downgrade types, configurable

    subcategory = CharField(max_length=200)
    name = CharField(max_length=100)   # settings name or custom name
    target = ChoiceField(ProblemTarget.gen(), store_key=False, retrieve_key=False, default=None, null=True)
    # eg
    # type.category: resource_saturated
    # type.subcategory: cpu_percent_exceed
    # type.name: cpu_percent > 80

    # type.category: service_downgrade
    # type.subcategory: slow_response
    # type.name: Slow response at POST /api/user

    ident = CharField(max_length=200)

    compress_window: timedelta = DurationField(null=True, default=None)
    min_times: int = PositiveIntegerField(default=1)

    endpoint = ForeignKey(
        Endpoint, on_delete=SET_NULL,
        null=True, default=None, related_name='alert_types',
        db_constraint=False
    )
    task = ForeignKey(
        TaskSettings, on_delete=SET_NULL,
        related_name='alert_types', default=None, null=True,
        db_constraint=False
    )
    added_time = DateTimeField(auto_now_add=True)

    # unstable = BooleanField(default=False)
    # unstable alert is triggered and recovered endlessly and often due to other issue (network, provider, .etc)
    # unstable alert only need to store 1 record and then add count
    # (only report to supervisor when first trigger or recover)
    data = JSONField(default=dict)

    class Meta(ModelOptions):
        db_table = 'utilmeta_alert_type'
        unique_together = ('service', 'ident')

    @classmethod
    def get(cls, ident: str) -> Optional['AlertSettings']:
        from utilmeta.conf import config
        return cls.objects.filter(service_id=config.name, ident=ident).first()


class AlertLog(Model):
    # log from monitor, manual triggered background task
    objects = MetaManager()
    id = BigAutoField(primary_key=True)

    type: AlertType = ForeignKey(AlertType, on_delete=CASCADE, related_name='alert_logs')
    server: Server = ForeignKey(Server, on_delete=CASCADE, related_name='alert_logs', default=None, null=True)
    instance: BaseInstance = ForeignKey(BaseInstance, on_delete=CASCADE,
                                        related_name='alert_logs', default=None, null=True)

    version = ForeignKey(VersionLog, on_delete=CASCADE)
    runtime = BooleanField(default=True)

    impact_requests = PositiveBigIntegerField(default=None, null=True)
    impact_users = PositiveIntegerField(default=None, null=True)
    impact_ips = PositiveIntegerField(default=None, null=True)
    # impact services / tasks can be interfere from [server] field

    relieved_by = ForeignKey(Admin, default=None, null=True, on_delete=SET_NULL)
    relieved_time = DateTimeField(default=None, null=True)  # relieved_time=None (opening alert) are open for new count

    review = RichTextField(default='')
    trigger_times: list = ArrayField(DateTimeField(), default=list)
    relieve_times: list = ArrayField(DateTimeField(), default=list)
    trigger_values: list = ArrayField(FloatField(), default=list)
    # [dict(value=<SOME_VALUE>, time=<SOME_TIME>), ...]
    time = DateTimeField(auto_now_add=True)             # start time (first alert trigger time)
    latest_time: datetime = DateTimeField(default=time_now)      # latest time (latest alert trigger time)

    # current_count = PositiveBigIntegerField(default=1)
    count = PositiveBigIntegerField(default=1)

    cause = ForeignKey('self', on_delete=CASCADE, default=None, null=True, related_name='caused_alerts')
    latest_alarm_time = DateTimeField(default=None, null=True)      # alarm to notify supervisor as an incident
    message = TextField(default='')     # brief message to notify
    data = JSONField(default=None, null=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_alert_log'

    @classmethod
    def get(cls, id) -> Optional['AlertLog']:
        if not id:
            return None
        return cls.objects.filter(id=id).first()

    @property
    def uncertain(self):
        return self.count < self.type.min_times

    @property
    def compressible(self):
        if not self.type.compress_window:
            return False
        return time_now() - self.latest_time < self.type.compress_window

    def relieve(self):
        if self.relieved_time:
            return True

        if self.uncertain:
            # only append relieve times so the alert is still open
            # try:
            #     self.__class__.objects.filter(pk=self.pk).update(
            #         count=0,
            #         relieve_times=exp.Func(exp.F('relieve_times'), exp.Value(time_now()), function='array_append'),
            #     )
            # except exc.DatabaseError:
            #     self.__class__.objects.filter(pk=self.pk).update(
            #         count=0,
            #         relieve_times=self.relieve_times + [time_now()],
            #     )
            self.delete()
            return True
        self.relieved_time = time_now()
        self.save(update_fields=['relieved_time'])


class BaseLog(Model):
    """
    Base class of HTTP log model
    """
    objects = MetaManager()
    id = BigAutoField(primary_key=True)
    # this id is generated in incr cache before the log saved
    version = ForeignKey(VersionLog, on_delete=CASCADE)
    level = ChoiceField(constant.LOG_LEVELS, default=constant.LogLevel.INFO, retrieve_key=False)
    type = ChoiceField(constant.LogType.gen(), retrieve_key=False)
    scheme = CharField(default=None, null=True, max_length=20)
    volatile = BooleanField(default=True)        # volatile log will be deleted when it is not count by any aggregates
    runtime = BooleanField(default=True)
    time = DateTimeField()  # not auto_now_add, cache stored log may add after request for some time
    duration = PositiveBigIntegerField(default=None, null=True)
    # for http requests duration is the time between server receive request and send response
    # for ws requests duration is the time between client open a ws connection and close it
    review = RichTextField(default='')  # operation worker's review, probably contains hyper link/img
    # as_service = BooleanField(default=False)
    worker = ForeignKey(
        Worker, related_name='logs',
        on_delete=SET_NULL, null=True, default=None,
        db_constraint=False
    )
    thread_id = PositiveBigIntegerField(default=None, null=True)  # thread id that handle this request / invoke
    alert = ForeignKey(
        AlertLog, related_name='source_logs',
        on_delete=SET_NULL, null=True, default=None, db_constraint=False
    )

    # scheme = ChoiceField(choices=constant.SCHEMES, default=constant.Scheme.HTTP, retrieve_key=False)
    # use scheme to dispatch other scheme log data (Http/Websocket)
    path = URLField()  # replace the unit property
    # regard current server (who write logs) as target, count it's in & out
    in_traffic = PositiveBigIntegerField(default=0)
    out_traffic = PositiveBigIntegerField(default=0)
    public = BooleanField(default=True)  # public request or invoke
    # process_id = PositiveIntegerField(default=None, null=True)    # process id that handle this request / invoke

    class Meta(ModelOptions):
        db_table = 'utilmeta_log'


# class TaskLog(LoggerMixin):
#     log = OneToOneField(BaseLog, related_name='task_log', on_delete=CASCADE, primary_key=True)
#     job = OneToOneField(TaskJob, related_name='log', on_delete=CASCADE)
#
#     class Meta(ModelOptions):
#         db_table = 'utilmeta_task_log'


class HttpLog(Model):
    """
        Log data using http/https schemes
    """
    objects = MetaManager()
    log = OneToOneField(BaseLog, related_name='http_log', on_delete=CASCADE, primary_key=True)
    # log = OneToOneField(BaseLog, related_name='http', on_delete=CASCADE)
    method = ChoiceField(choices=constant.METHODS, retrieve_key=False)  # replace the unit property
    # path = URLField(null=True)  # replace the unit property
    request_type = ChoiceField(choices=constant.REQUEST_TYPES, default=None, null=True, retrieve_key=False)
    response_type = ChoiceField(choices=constant.GENERAL_TYPES, default=None, null=True, retrieve_key=False)
    request_headers = JSONField(default=dict, null=True)
    response_headers = JSONField(default=dict, null=True)
    user_agent = JSONField(default=None, null=True)
    status = PositiveSmallIntegerField(default=200, null=True)
    # duration = PositiveIntegerField(default=0)
    length = PositiveBigIntegerField(default=0, null=True)
    query = JSONField(default=dict)
    data = JSONField(null=True, default=None)
    result = JSONField(null=True, default=None)
    # cached = BooleanField(default=False)

    class Meta(ModelOptions):
        db_table = 'utilmeta_http_log'


# class ChannelClient(Model):
#     channel = CharField(max_length=200)
#     timeout = PositiveIntegerField(default=None, null=True)
#
# class WebSocketEvent(Model):
#     """
#         Websocket connection contains a series of events (connect/accept/send/recv/close/disconnect)
#         according to config, some normal responses is omitted
#     """


class ServiceLog(LoggerMixin):
    """
    EXAMPLE DATA STRUCTURES:
    -----------------------
        db_queries: {
            "default": [{
                "sql": "SELECT ...",
                "time": 11,
            }]
        }
        messages: [
            "File ....",
            "Downstream failed with error: ....",
            ...
        ]
        trace: [{
            "name": "handle_headers",
            "type": "api.before",
            "unit": "u8Alsd",
            "init": 3,
            "time": 2,
            “events”: []
        }, {
            "name": "account",
            "unit": "Yta23f",
            "type": "api.post",        // scope / api (before/get/post/.../after)
                                    // stamp / log (info/warn/error/urgent/debug)
            "init": 11,             // in milliseconds, relative to the log start timestamp
            "time": 20,             // in milliseconds
            "events": [{
                "name": "tag1",
                "type": "stamp",
                "init": 12,
            }, {
                "name": "AccountMain.serialize",
                "type": "scope",
                "init": 13,
                "time": 65,
                "queries": {
                    "default": [1, 5]       // queries 1, 2, 3, 4
                },
                "events": [{
                    "name": "ERROR",
                    "type": "log.error",
                    "init": 21
                    "data": {
                        "a-user-defined-key": <some value>
                    },
                    "msg": 3,       // use reference (index) of the messages
                                    // messages use list of str can illustrate the critical log info
                                    // more explicitly than a deep trace
                }, {
                    "name": "sub-scope",       // there can be a sub scope inside another scope
                    "type": "scope",
                    "events": [...]
                }, {
                    "name": "sub-call",         // there can be another api call inside scope
                    "type": "unit",
                    "events": [...]
                }],
            }]
        }, {
            "name": "process_result",  // name of the function,
            "unit": "WFa14a",              // unit id
            "type": "mod.after",
            "init": 32,
            "time": 45,
            "events": []
        }, {
            "name": "append_headers",
            "unit": "yu7DFa",
            "type": "api.after",
            "init": 102,
            "time": 3,
            "events": []
        }]

        context types: scope / api (contains events, init and time)
        tag types: stamp / log     (only init)
        types that contains events: scope / api (context)
    """
    objects = MetaManager()
    log = OneToOneField(BaseLog, related_name='service_log', on_delete=CASCADE, primary_key=True)
    endpoint = ForeignKey(
        Endpoint, on_delete=SET_NULL,
        null=True, default=None, related_name='logs',
        db_constraint=False
    )
    # endpoint_path = URLField(default=None, null=True)
    # units = ArrayField(CharField(max_length=10), default=list)
    # the orders that the process unit is called
    user_id = CharField(max_length=100, null=True, default=None)
    session = ForeignKey(
        Session, on_delete=SET_NULL, db_constraint=False,
        related_name='logs', null=True, default=None
    )
    admin = ForeignKey(Admin, on_delete=SET_NULL, related_name='logs', null=True, default=None)

    ip = GenericIPAddressField()
    # send_mail = BooleanField(default=False)
    from_instance = ForeignKey(
        BaseInstance, related_name='service_logs', db_constraint=False,     # should be strong db constraints on this
        on_delete=SET_NULL, null=True, default=None
    )
    from_service = ForeignKey(
        Service, related_name='service_logs', db_constraint=False,     # should be strong db constraints on this
        on_delete=CASCADE, null=True, default=None
    )
    # source instance maybe volatile but source service is consider stable

    # !! NO SUCH THING AS ArrayField(JSONField())
    # logs = JSONField(default=list)        # list of dict
    # stamps = JSONField(default=list)      # list of dict

    class Meta(ModelOptions):
        db_table = 'utilmeta_service_log'


class QueryLog(Model):
    # SLOW or error db query log
    objects = MetaManager()
    id = BigAutoField(primary_key=True)
    time = DateTimeField()
    database = ForeignKey(DatabaseStorage, on_delete=CASCADE, related_name='query_logs')
    query = TextField()
    duration = PositiveBigIntegerField(default=None, null=True)  # ms
    message = TextField(default='')
    worker = ForeignKey(
        Worker, related_name='query_logs', on_delete=SET_NULL,
        null=True, default=None, db_constraint=False
    )

    type = CharField(max_length=32, default=None, null=True)
    tables = ArrayField(CharField(max_length=200), default=list)

    context_log = ForeignKey(
        ServiceLog, related_name='query_logs',
        null=True, default=None, on_delete=SET_NULL,
        db_constraint=False,  # request & service log are cached and store so there cannot be constraints
    )

    context_job = ForeignKey(
        TaskJob, related_name='query_logs',
        null=True, default=None, on_delete=SET_NULL,
        db_constraint=False,  # request & service log are cached and store so there cannot be constraints
    )
    alert = ForeignKey(
        AlertLog, related_name='query_logs',
        on_delete=SET_NULL, null=True, default=None,
        db_constraint=False
    )

    class Meta(ModelOptions):
        db_table = 'utilmeta_query_log'


class RequestLog(Model):
    objects = MetaManager()
    log = OneToOneField(BaseLog, related_name='request_log', on_delete=CASCADE, primary_key=True)
    # requests made in other service request context
    context_log = ForeignKey(
        BaseLog, related_name='request_logs',
        null=True, default=None, on_delete=SET_NULL,
        db_constraint=False,    # request & service log are cached and store so there cannot be constraints
    )

    host = URLField(default=None, null=True)      # host of the requested host (ip or domain name)
    remote_log = PositiveBigIntegerField(default=None, null=True)
    # remote utilmeta log id (in target service) to support recursive tracing
    block = BooleanField(default=None, null=True)
    timeout = DecimalField(max_digits=10, decimal_places=2, default=None, null=True)
    timeout_error = BooleanField(default=False)     # request is timeout
    # if request to
    # service = ForeignKey(Service, default=None, null=True, on_delete=SET_NULL)
    # instance is more likely to delete than service although a instance can infer to service
    to_instance = ForeignKey(
        BaseInstance, related_name='request_logs', db_constraint=False,
        default=None, null=True, on_delete=SET_NULL
    )
    to_service = ForeignKey(
        Service, related_name='request_logs', db_constraint=False,
        default=None, null=True, on_delete=CASCADE
    )

    class Meta(ModelOptions):
        db_table = 'utilmeta_request_log'


class ViolateLog(Model):
    objects = MetaManager()
    # Invalid / Illegal Access log
    time = DateTimeField()
    log = OneToOneField(
        ServiceLog, related_name='violation',
        null=True, default=None, on_delete=SET_NULL,
        db_constraint=False,
    )
    violate_key = CharField(max_length=50)      # request IP of user id
    util_params = JSONField(default=dict)
    violate_item = CharField(max_length=30)
    req_per_sec = DecimalField(max_digits=10, decimal_places=2, default=None, null=True)
    left_times = PositiveIntegerField(default=None, null=True)
    left_errors = PositiveIntegerField(default=None, null=True)
    reset_time = DateTimeField(default=None, null=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_violate_log'


class OperationLog(Model):
    objects = MetaManager()
    log = OneToOneField(
        ServiceLog, related_name='operation',
        null=True, default=None, on_delete=SET_NULL,
        db_constraint=False,
    )
    executor = ForeignKey(Admin, related_name='operation_logs', on_delete=SET_NULL, null=True)
    operation = CharField(max_length=40)
    version = ForeignKey(VersionLog, related_name='operation_logs', on_delete=CASCADE)

    success = BooleanField(default=True)
    error = TextField(default='')

    query = JSONField(default=None, null=True)
    data = JSONField(default=None, null=True)

    ip = GenericIPAddressField()
    time = DateTimeField(auto_now_add=True)
    info = JSONField(default=dict)  # store backward compat information
    alert = ForeignKey(AlertLog, related_name='source_operation_logs', on_delete=SET_NULL, null=True, default=None)

    class Meta(ModelOptions):
        db_table = 'utilmeta_operation_log'
