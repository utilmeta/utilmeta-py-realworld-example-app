from utilmeta.fields import *
from utilmeta.models import *
from utilmeta.types import *
from utilmeta.util.common import time_now
from .common import RequestMetrics, SystemMetrics, CommonAggregate, TaskMetrics
from .utils import Endpoint, DataModel
from .service import Service, ServiceInstance, BaseInstance, Server, \
    DatabaseStorage, CacheStorage, Worker
from .log import AlertLog
from .task import TaskSettings, TaskInstance


__all__ = ['TaskAggregate', 'ServiceAggregate', 'UserAggregate', 'InstanceMonitor',
           'ServiceWorkerMonitor', 'WorkerMonitor', 'ServiceInstanceMonitor',
           'ServerMonitor', 'DataMonitor', 'DatabaseMonitor', 'CacheMonitor']


class TaskAggregate(CommonAggregate, TaskMetrics):
    objects = MetaManager()
    time = DateTimeField(default=time_now)  # latest metrics update time
    layer = PositiveSmallIntegerField(default=0)
    task_settings = ForeignKey(
        TaskSettings, related_name='task_aggregate_metrics',
        db_constraint=False, default=None, null=True, on_delete=SET_NULL
    )
    # the task that execute this aggregate
    service = ForeignKey(Service, on_delete=CASCADE, related_name='task_aggregates')
    # when service contains more than 2 instances, the following metrics is not addable and must calculate alone
    # when doing instance aggregate, a instance realize that it is the cluster representative and cluster has
    # more than 2 instances will save data for service
    instance = ForeignKey(
        TaskInstance, related_name='aggregate_monitors',
        on_delete=SET_NULL, null=True, default=None
    )
    task = ForeignKey(TaskSettings, on_delete=SET_NULL, null=True, default=None, related_name='aggregates')

    event_cursor = PositiveBigIntegerField(default=None, null=True)  # cursor for the latest log

    alerts = PositiveBigIntegerField(default=0)
    avg_workers = DecimalField(max_digits=8, decimal_places=2, default=0.00)

    data = JSONField(default=dict)

    class Meta(ModelOptions):
        db_table = 'utilmeta_task_aggregate'
        ordering = ('time',)


class ServiceAggregate(CommonAggregate, RequestMetrics):
    """
    Aggregate logs at endpoint / instance / service level, time interval usually in 1h ~ 24h
    ONLY RECORD IN MONITOR INTERVAL, CAM STILL ADD WITH exp.Sum() to get accumulate results
    """
    objects = MetaManager()
    time = DateTimeField(default=time_now)  # latest metrics update time
    layer = PositiveSmallIntegerField(default=0)
    task_settings = ForeignKey(
        TaskSettings, related_name='service_aggregate_metrics',
        db_constraint=False, default=None, null=True, on_delete=SET_NULL
    )
    service = ForeignKey(Service, on_delete=CASCADE, related_name='service_aggregates')
    # when service contains more than 2 instances, the following metrics is not addable and must calculate alone
    # when doing instance aggregate, a instance realize that it is the cluster representative and cluster has
    # more than 2 instances will save data for service
    instance = ForeignKey(
        ServiceInstance, related_name='aggregate_monitors',
        on_delete=SET_NULL, null=True, default=None
    )
    endpoint = ForeignKey(Endpoint, on_delete=SET_NULL, null=True, default=None, related_name='aggregates')

    log_cursor = PositiveBigIntegerField(default=None, null=True)      # cursor for the latest log
    # avg_time in most recent 1h
    max_rps = DecimalField(max_digits=10, decimal_places=2, default=0.00)       # max requests per seconds
    max_rps_time = DateTimeField(default=None, null=True)       # max requests per seconds
    # max requests per seconds in the interval (with the query window of 1s, measuring the concurrent level)
    uv = PositiveBigIntegerField(default=0, null=True)  # user views in interval
    ip = PositiveBigIntegerField(default=0, null=True)  # IP in interval

    total_sessions = PositiveBigIntegerField(default=0, null=True)
    active_sessions = PositiveBigIntegerField(default=0, null=True)
    avg_user_active_time = DecimalField(max_digits=10, decimal_places=2, default=None, null=True)

    users = PositiveBigIntegerField(default=0)
    new_users = PositiveBigIntegerField(default=0)

    public_in_traffic = PositiveBigIntegerField(default=0)
    public_out_traffic = PositiveBigIntegerField(default=0)     # usually this one really count into money
    private_in_traffic = PositiveBigIntegerField(default=0)
    private_out_traffic = PositiveBigIntegerField(default=0)

    operations = PositiveBigIntegerField(default=0)    # admin operations
    violates = PositiveBigIntegerField(default=0)

    targets = JSONField(default=dict)       # request target service name and corresponding requests
    sources = JSONField(default=dict)       # served source service name and corresponding requests
    statuses = JSONField(default=dict)      # http status: count
    schemes = JSONField(default=dict)       # request scheme: count

    avg_workers = DecimalField(max_digits=8, decimal_places=2, default=0.00)

    alerts = PositiveBigIntegerField(default=0)
    # queries = PositiveBigIntegerField(default=0)
    levels = JSONField(default=dict)  # log levels: count

    os_dist = JSONField(default=dict)
    browser_dist = JSONField(default=dict)
    device_dist = JSONField(default=dict)

    data = JSONField(default=dict)

    class Meta(ModelOptions):
        db_table = 'utilmeta_service_aggregate'
        ordering = ('time',)


class UserAggregate(Model):
    objects = MetaManager()
    time = DateTimeField(default=time_now)
    layer = PositiveSmallIntegerField(default=0)
    user_id = CharField(max_length=100)     # can be ID of user model / or access_key for key based auth
    service = ForeignKey(Service, on_delete=CASCADE, related_name='user_aggregates')

    in_traffic = PositiveBigIntegerField(default=0)  # in bytes (public)
    out_traffic = PositiveBigIntegerField(default=0)  # in bytes (public)
    requests = PositiveBigIntegerField(default=0)  # requests made from current service to target instance
    avg_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    mean_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 50%
    p95_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 95%
    p99_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 99%
    p999_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 99.9%
    time_stddev = DecimalField(max_digits=10, decimal_places=2, default=0.00, null=True)

    sessions = PositiveIntegerField(default=None, null=True)
    active_time = DurationField(default=0)
    endpoints = JSONField(default=dict)     # <GET/api/test>: <count>
    relations = JSONField(default=dict)     # many-to count
    violates = PositiveBigIntegerField(default=0)

    levels = JSONField(default=dict)  # log levels: count
    info = JSONField(default=dict)

    ips = ArrayField(GenericIPAddressField(), default=list)
    agents = JSONField(default=None, null=True)

    data = JSONField(default=dict)

    class Meta(ModelOptions):
        db_table = 'utilmeta_user_aggregate'
        ordering = ('time',)


class ServerMonitor(SystemMetrics):
    objects = MetaManager()
    id = BigAutoField(primary_key=True)
    time = DateTimeField(default=time_now)
    task_settings = ForeignKey(TaskSettings, db_constraint=False, on_delete=SET_NULL, default=None, null=True)
    layer = PositiveSmallIntegerField(default=0)
    server = ForeignKey(Server, related_name='metrics', on_delete=CASCADE)
    # version = ForeignKey(VersionLog, on_delete=SET_NULL, null=True, default=None)
    load_avg_1 = DecimalField(max_digits=8, decimal_places=2, default=None, null=True)
    load_avg_5 = DecimalField(max_digits=8, decimal_places=2, default=None, null=True)
    load_avg_15 = DecimalField(max_digits=8, decimal_places=2, default=None, null=True)
    load_index = DecimalField(max_digits=8, decimal_places=2, default=None, null=True)
    alert = ForeignKey(AlertLog, related_name='source_metrics', on_delete=SET_NULL, null=True, default=None)

    class Meta(ModelOptions):
        db_table = 'utilmeta_server_monitor'
        ordering = ('time',)

    @classmethod
    def current(cls) -> Optional['ServerMonitor']:
        return cls.objects.last()   # already order by time


class WorkerMonitor(SystemMetrics):
    objects = MetaManager()
    id = BigAutoField(primary_key=True)
    time = DateTimeField(default=time_now)
    worker = ForeignKey(Worker, related_name='metrics', on_delete=CASCADE)
    threads = PositiveIntegerField(default=0)

    class Meta(ModelOptions):
        db_table = 'utilmeta_worker_monitor'
        ordering = ('time',)

    @classmethod
    def current(cls) -> Optional['WorkerMonitor']:
        return cls.objects.last()   # already order by time


class ServiceWorkerMonitor(WorkerMonitor, RequestMetrics):
    class Meta(ModelOptions):
        db_table = 'utilmeta_service_worker_monitor'
        ordering = ('time',)


class InstanceMonitor(SystemMetrics):
    objects = MetaManager()
    id = BigAutoField(primary_key=True)
    time = DateTimeField(default=time_now)
    instance = ForeignKey(BaseInstance, related_name='metrics', on_delete=CASCADE)
    task_settings = ForeignKey(TaskSettings, db_constraint=False, on_delete=SET_NULL, default=None, null=True)
    threads = PositiveIntegerField(default=0)

    class Meta(ModelOptions):
        db_table = 'utilmeta_instance_monitor'
        ordering = ('time',)


class ServiceInstanceMonitor(InstanceMonitor, RequestMetrics):
    class Meta(ModelOptions):
        db_table = 'utilmeta_service_instance_monitor'
        ordering = ('time',)


class DataMonitor(Model):
    objects = MetaManager()
    id = BigAutoField(primary_key=True)
    time = DateTimeField(default=time_now)
    task_settings = ForeignKey(TaskSettings, db_constraint=False, on_delete=SET_NULL, default=None, null=True)
    model = ForeignKey(DataModel, on_delete=CASCADE, related_name='metrics')
    service = ForeignKey(Service, related_name='data_metrics', on_delete=CASCADE)
    count = PositiveBigIntegerField(default=None, null=True)
    relations = JSONField(default=dict)
    aggregates = JSONField(default=dict)

    class Meta(ModelOptions):
        db_table = 'utilmeta_data_monitor'
        ordering = ('time',)


class DatabaseMonitor(Model):
    objects = MetaManager()
    id = BigAutoField(primary_key=True)
    time = DateTimeField(default=time_now)
    task_settings = ForeignKey(TaskSettings, db_constraint=False, on_delete=SET_NULL, default=None, null=True)
    # layer = PositiveSmallIntegerField(default=0)
    database = ForeignKey(DatabaseStorage, on_delete=CASCADE, related_name='metrics')

    used_space = PositiveBigIntegerField(default=0)  # used disk space
    server_used_space = PositiveBigIntegerField(default=0)  # used disk space
    active_connections = PositiveBigIntegerField(default=0)
    current_connections = PositiveBigIntegerField(default=0)
    server_connections = PositiveBigIntegerField(default=0)
    queries_num = PositiveBigIntegerField(default=0)
    qps = DecimalField(max_digits=10, decimal_places=2, default=None, null=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_database_monitor'
        ordering = ('time',)


class CacheMonitor(Model):
    objects = MetaManager()
    id = BigAutoField(primary_key=True)
    time = DateTimeField(default=time_now)
    task_settings = ForeignKey(TaskSettings, db_constraint=False, on_delete=SET_NULL, default=None, null=True)
    # layer = PositiveSmallIntegerField(default=0)
    cache = ForeignKey(CacheStorage, on_delete=CASCADE, related_name='metrics')

    used_memory = PositiveBigIntegerField(default=0)
    current_connections = PositiveBigIntegerField(default=0)
    total_connections = PositiveBigIntegerField(default=0)
    qps = DecimalField(max_digits=10, decimal_places=2, default=None, null=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_cache_monitor'
        ordering = ('time',)
