from utilmeta.fields import *
from utilmeta.models import *
from datetime import datetime
from utilmeta.util.common import WorkerType, get_ip, IPType, Format, \
    localhost, distinct_add, ServerRole, time_now, convert_time, pop, exp, replace_null
from utilmeta.conf import SSH
from typing import Optional, List, TypeVar, Type
from .common import *
from ..log import MetricsLogger
import os
from ipaddress import ip_address


T = TypeVar('T')

__all__ = ['Service', 'Dependency', 'CrossServiceRelate', 'ServiceInstance', 'Server', 'Worker', 'ServiceWorker',
           'CacheStorage', 'DatabaseStorage', 'DatabaseConnection', 'WebServer', 'BaseInstance', 'RestartRecord']


class Service(Model):
    # store multiple micro-service
    objects = MetaManager()
    # id = CharField(max_length=10, primary_key=True, default=id_generator)
    name = CharField(max_length=60, primary_key=True)
    action_token = CharField(max_length=64, unique=True, null=True, default=None)
    ops_route = URLField(default=None, null=True)

    proxy = BooleanField(default=False)
    proxy_url = URLField(default=None, null=True)
    description = TextField(default='')

    info = JSONField(default=dict)  # store backward compat data
    init_time = DateTimeField(auto_now_add=True)

    expose = BooleanField(default=False)
    root_routes = ArrayField(CharField(max_length=100), null=True, default=None)
    # when single_endpoint=False, use root_routes to mount url
    single_endpoint = BooleanField(default=False)
    dependencies = ManyToManyField(
        'self', symmetrical=False,
        related_name='backwards',
        through='Dependency'
    )
    # dependencies = ArrayField(CharField(max_length=60), default=list)

    class Meta(ModelOptions):
        db_table = 'utilmeta_service'

    @property
    def this(self):
        from utilmeta.conf import config
        return self.name == config.name

    @classmethod
    def names(cls) -> list:
        return list(cls.objects.values_list('name', flat=True))

    @classmethod
    def concretes(cls) -> list:
        return list(cls.objects.exclude(action_token=None).values_list('name', flat=True))

    @classmethod
    def get(cls, name: str = None) -> Optional['Service']:
        if not name:
            return None
        return cls.objects.filter(name=name).first()

    @classmethod
    def current(cls) -> 'Service':
        from utilmeta.conf import config
        return cls.get(config.service_name)

    def set_dependencies(self, dependencies: list, relates: dict):
        """
        Consider recursive dependencies
        """
        exists = set(Service.names()).intersection(dependencies)
        current = Dependency.objects.filter(source=self.name).values_list('target', flat=True)
        objs = [
            Dependency(source_id=self.name, target_id=target)
            for target in list(set(exists).difference(current))
        ]
        Dependency.objects.bulk_create(objs)
        deletes = list(set(current).difference(exists))
        if deletes:
            Dependency.objects.filter(source_id=self.name, target_id__in=deletes).delete()
        for dep in Dependency.objects.filter(source_id=self.name):
            CrossServiceRelate.objects.filter(base=dep).delete()
            CrossServiceRelate.objects.bulk_create([CrossServiceRelate(
                base=dep, **kwargs) for kwargs in relates.get(dep.target_id, [])])

    def set_backward(self, name: str, relates: List[dict]):
        """
        Consider recursive dependencies
        """
        dep, created = Dependency.objects.update_or_create(source_id=name, target_id=self.name)
        CrossServiceRelate.objects.filter(base=dep).delete()
        if relates:
            CrossServiceRelate.objects.bulk_create([CrossServiceRelate(base=dep, **kwargs) for kwargs in relates])

    def get_forward_dependencies(self) -> list:
        return list(Dependency.objects.filter(source=self.name).values_list('target', flat=True))

    def get_backward_dependencies(self) -> list:
        return list(Dependency.objects.filter(target=self.name).values_list('source', flat=True))

    @property
    def relate_services(self):
        return self.get_forward_dependencies() + self.get_backward_dependencies()

    def check_databases(self):
        from utilmeta.conf import Database, config
        if config.cluster and not config.cluster.check_instances_db:
            return
        ops_dbs = []
        values = getattr(self, 'instances').values_list('config', 'server__ip')
        if len(values) <= 1:
            return
        for cfg, ip in values:
            cfg: dict
            cfg.update(readonly=True)
            try:
                db_alias = cfg['ops']['db']
                ops_db = Database.construct(cfg['databases'][db_alias])
                ops_dbs.append((ops_db, ip))
            except KeyError:
                continue
        ops_locations = Database.locations(ops_dbs)
        if len(ops_locations) > 1:
            raise ValueError(F'Service instances should use same Operations databases, got {ops_locations}')


class Dependency(Model):
    objects = MetaManager()
    source = ForeignKey(Service, related_name='forward_dependencies', on_delete=CASCADE)
    target = ForeignKey(Service, related_name='backward_dependencies', on_delete=CASCADE)

    class Meta(ModelOptions):
        db_table = 'utilmeta_service_dependency'
        unique_together = ('source', 'target')


class CrossServiceRelate(Model):
    """
    source: 'www'
    target: 'auth'  this=True
    relates:
    [{
        'model': 'forum.Content',   # remote model (from this service)
        'field': 'creator',         # model's field name (seem useless)
        'target': 'user.User',      # in this service
        'relate': 'contents',       # backward relates
        'unique': False,            # whether if one-to-one
    }]
    """
    objects = MetaManager()
    base = ForeignKey(Dependency, on_delete=CASCADE, related_name='relates')
    model = CharField(max_length=100)
    target = CharField(max_length=100)
    field = CharField(max_length=100)
    relate = CharField(max_length=100)
    unique = BooleanField(default=False)

    class Meta(ModelOptions):
        db_table = 'utilmeta_service_relate'

    @classmethod
    def backward_services(cls, name: str, model: str):
        return list(cls.objects.filter(base__target_id=name, target=model).values_list('base__source', flat=True))


class Server(SystemMetrics):
    """
    Server manager, including api / wen / cache / db servers
    """
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    ip = GenericIPAddressField(unique=True)
    # if server do not have private ip, user public ip, elsewhere use private ip
    # in node scope (cluster's service instances), ip can identify a Server resource
    public_ip = GenericIPAddressField(default=None, null=True)

    domain = CharField(max_length=400, default=None, null=True)     # a private / public DNS for this server
    system = CharField(max_length=100)
    platform = JSONField(default=dict)

    active = BooleanField(default=True)
    utcoffset = SmallIntegerField(default=None, null=True)       # seconds

    hostname = CharField(max_length=100, default='')
    roles: List[str] = ArrayField(CharField(max_length=10), default=list)
    ssh_port = PositiveSmallIntegerField(default=22)
    ssh_user = CharField(max_length=100, default=None, null=True)
    ssh_password = CharField(max_length=400, default=None, null=True)
    ssh_key_file = FilePathField(default=None, null=True)

    max_open_files = PositiveIntegerField(default=None, null=True)
    max_socket_conn = PositiveIntegerField(default=None, null=True)

    setup_script = TextField(default=None, null=True)

    cpu_num = PositiveSmallIntegerField(default=0)
    memory_total = PositiveBigIntegerField(default=0)
    disk_total = PositiveBigIntegerField(default=0)
    devices = JSONField(default=dict)       # disk devices

    load_avg_1 = DecimalField(max_digits=8, decimal_places=2, default=None, null=True)
    load_avg_5 = DecimalField(max_digits=8, decimal_places=2, default=None, null=True)
    load_avg_15 = DecimalField(max_digits=8, decimal_places=2, default=None, null=True)
    load_index = DecimalField(max_digits=8, decimal_places=2, default=None, null=True)

    last_updated = DateTimeField(null=True, default=None)
    # if server statics can be updated by self or instance fetch, this is updated
    # elsewhere (only ip/roles is recorded) this will leave None

    class Meta(ModelOptions):
        db_table = 'utilmeta_server'

    @classmethod
    def current(cls) -> Optional['Server']:
        from utilmeta.conf import config
        return cls.objects.filter(ip=config.private_ip).first()

    @property
    def data(self):
        from utilmeta.ops.schema.service import ServerMetrics
        return ServerMetrics(
            ip=self.ip,
            hostname=self.hostname,
            system=self.system,
            platform=self.platform,
            utcoffset=self.utcoffset,
            load_index=self.load_index,
            cpu_num=self.cpu_num,
            memory_total=self.memory_total,
            cpu_percent=self.cpu_percent,
            memory_percent=self.memory_percent,
            max_socket_conn=self.max_socket_conn,
            max_open_files=self.max_open_files
        )

    @classmethod
    def get(cls, ip: str) -> Optional['Server']:
        return cls.objects.filter(ip=ip).first()

    @classmethod
    def load(cls, ip: str, role: str = ServerRole.wsgi,
             domain: str = None, ssh: SSH = None, metrics: dict = None) -> 'Server':
        from utilmeta.conf import config
        if not ip or localhost(ip):
            ip = config.private_ip
        try:
            addr: IPType = ip_address(ip)
        except ValueError:
            ip = get_ip(ip)
            domain = domain or ip
            addr: IPType = ip_address(ip)
        server = cls.get(ip)
        roles = [role]
        data = dict(
            public_ip=None if addr.is_private else ip,
            domain=domain
        )
        if ssh:
            data.update(
                ssh_port=ssh.port,
                ssh_user=ssh.username,
                ssh_password=ssh.password,
                ssh_key_file=ssh.key_file
            )
        if server:
            if role not in server.roles:
                roles = distinct_add(server.roles, [role])

        data.update(roles=roles)

        if isinstance(metrics, dict):
            current = ServiceInstance.current()
            if current and current.server.ip != ip:
                # only accept server metrics that cannot update by oneself
                for key, val in metrics.items():
                    if not hasattr(cls, key):
                        continue
                    if key in ('ip', 'id', 'hostname', 'system', 'platform'):
                        continue
                    data[key] = val
                data.update(last_updated=time_now())

        elif ip == config.private_ip:
            # consider this server
            from utilmeta.ops.tasks.monitor import ServerMonitorTask
            data.update(ServerMonitorTask.get_server_statics())
            data.update(last_updated=time_now())

        server_set = Server.objects.filter(ip=ip)
        # update or create might cause integrity error in transaction, use other
        if server_set.exists():
            server_set.update(**data)
            server = server_set.first()
        else:
            server = Server.objects.create(ip=ip, **data)
        return server


class BaseInstance(SystemMetrics):
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    service: Service = ForeignKey(Service, on_delete=CASCADE, related_name='instances')
    server: Server = ForeignKey(Server, on_delete=CASCADE, related_name='instances')
    # version = OneToOneField('VersionLog', related_name='current_instance', on_delete=SET_NULL)
    version = CharField(max_length=32)  # humanized version string, like 1.x.x
    version_id = PositiveBigIntegerField(default=0)  # actual service version to control, correlate to version log id
    utilmeta_version = CharField(max_length=20)
    # because new version of utilmeta will cause new useless migrates
    production = BooleanField(default=False)
    init_time = DateTimeField(auto_now_add=True)
    connected = BooleanField(default=True)
    threads = PositiveIntegerField(default=0)

    last_restart = DateTimeField(null=True, default=None)
    last_heartbeat = DateTimeField(default=time_now)   # clean unconnected instance
    weight = DecimalField(default=1.00, max_digits=5, decimal_places=2)
    # a manual configured weight (set from upper-layer)
    options = JSONField(default=dict)

    config = JSONField(default=dict)

    master = BooleanField(default=True)
    wsgi = BooleanField(default=False)
    asgi = BooleanField(default=False)
    task = BooleanField(default=False)

    class Meta(ModelOptions):
        db_table = 'utilmeta_base_instance'

    @property
    def serve_task(self):
        return self.task

    @property
    def serve_request(self):
        return self.wsgi or self.asgi

    @classmethod
    def get(cls, id: str) -> Optional['BaseInstance']:
        if not id:
            return None
        return cls.objects.filter(id=id).first()

    def update(self, **data):
        for key, val in data.items():
            setattr(self, key, val)
        self.last_heartbeat = time_now()
        self.save()

    @classmethod
    def current(cls: Type[T]) -> T:
        raise NotImplementedError

    @classmethod
    def self_heartbeat(cls):
        current = cls.current()
        if not current:
            return
        current.update(connected=True)

    def get_workers(self) -> MetaQuerySet:
        raise NotImplementedError

    @property
    def total_memory(self):
        mem = 0
        for pss, uss in self.get_workers().values_list('memory_info__pss', 'memory_info__uss'):
            mem += pss or uss or 0
        return mem

    @property
    def sys_metrics(self):
        return replace_null(dict(**self.get_workers().aggregate(
            total_net_connections=exp.Sum('total_net_connections'),
            active_net_connections=exp.Sum('active_net_connections'),
            file_descriptors=exp.Sum('file_descriptors'),
            cpu_percent=exp.Sum('cpu_percent'),
            memory_percent=exp.Sum('memory_percent'),
            threads=exp.Sum('threads'),
            open_files=exp.Sum('open_files'),
        ), used_memory=self.total_memory))


class RestartRecord(Model):
    objects = MetaManager()
    instance: BaseInstance = ForeignKey(BaseInstance, on_delete=CASCADE, related_name='restart_records')
    time: datetime = DateTimeField(auto_now_add=True)

    graceful_timeout = PositiveIntegerField(default=None, null=True)
    graceful_duration = PositiveIntegerField(default=None, null=True)

    unavailable = BooleanField(default=False)

    trigger_index = CharField(max_length=100, default=None, null=True)
    trigger_value = FloatField(default=None, null=True)
    threshold = FloatField(default=None, null=True)

    return_code = PositiveSmallIntegerField(default=None, null=True)
    manual = BooleanField(default=False)
    success = BooleanField(default=True)
    reload = BooleanField(default=False)

    info = JSONField(default=dict)

    class Meta(ModelOptions):
        db_table = 'utilmeta_restart_record'

    @property
    def message(self):
        man_str = 'Manual' if self.manual else 'Automatic'
        type = 'task' if self.instance.task else 'service'
        state = 'successfully' if self.success else 'failed'
        restart = 'reload' if self.reload else 'restart'
        due = f' due to [{self.trigger_index} > {self.threshold}]' \
              f' (={self.trigger_value})' if self.trigger_value else ''
        ident = f'[{self.instance.service}]({self.instance.server.ip})'
        return f'{man_str} triggered {type} instance {ident} {restart}' \
               f'{due} at {self.time.strftime(Format.DATETIME)} {state}'

    def save(self, force_insert=False, force_update=False, using=None,
             update_fields=None):
        if not self.pk:
            from utilmeta.util.alert import Alert
            man_str = 'manual' if self.manual else 'automatic'
            type = 'task' if self.instance.task else 'service'
            self.time = time_now()
            Alert.inform(
                event_time=self.time,
                type=f'{type}_restart',
                name=f'{man_str} {type} restart',
                message=self.message,
                data=dict(
                    return_code=self.return_code,
                    success=self.success,
                    reload=self.reload
                )
            )
        super().save(force_insert=force_insert, force_update=force_update, using=using, update_fields=update_fields)


class ServiceInstance(BaseInstance, RequestMetrics):
    """
    Instance of a specific service, usually under a same load balance
    there maybe couple of versions of a same service
    load balance of request will choice in priority of
    - connected and available
    - matched version (usually major version)
    - lowest latency and load index
    """
    time = DateTimeField(default=time_now)  # latest metrics update time
    engine = CharField(max_length=20, default=None, null=True)  # uwsgi / gunicorn
    base_url = URLField()
    avg_window = FloatField(default=0)  # receive window (server.ts - client.ts)

    document = JSONField(default=dict)
    # models = JSONField(default=dict)

    proxy_timeout = DecimalField(max_digits=8, decimal_places=3, default=None, null=True)
    max_retries = PositiveSmallIntegerField(default=1)

    class Meta(ModelOptions):
        db_table = 'utilmeta_service_instance'

    @classmethod
    def current(cls) -> 'ServiceInstance':
        from utilmeta.conf import config
        return cls.get(config.deploy.instance_id)

    def get_workers(self):
        return ServiceWorker.objects.filter(connected=True, instance=self)

    @property
    def data(self):
        from utilmeta.ops.schema.metrics import RequestMetricsMixin
        return RequestMetricsMixin(
            requests=self.requests,
            req_per_sec=self.req_per_sec,
            avg_time=self.avg_time,
            errors=self.errors,
            invokes=self.invokes,
            timeout_invokes=self.timeout_invokes,
            error_invokes=self.error_invokes,
            avg_invoke_time=self.avg_invoke_time,
            invoke_per_sec=self.invoke_per_sec,
            in_traffic=self.in_traffic,
            out_traffic=self.out_traffic
        )


class ServiceUtility(Model):
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    alias = CharField(max_length=60, default='default')
    type = CharField(max_length=40, default=None, null=True)    # ServerRole
    service = ForeignKey(Service, on_delete=CASCADE, related_name='utilities')
    server = ForeignKey(Server, on_delete=CASCADE, related_name='utilities')

    port = PositiveIntegerField()
    backend = CharField(max_length=40)
    connected = BooleanField(default=True)

    init_version = ForeignKey('VersionLog', related_name='init_utilities', on_delete=SET_NULL, null=True)
    current_version = ForeignKey('VersionLog', related_name='current_utilities', on_delete=SET_NULL, null=True)

    info = JSONField(default=dict)

    class Meta(ModelOptions):
        db_table = 'utilmeta_service_utility'
        # unique_together = ('server', 'port')


class StorageMixin(Model):
    objects = MetaManager()
    master = ForeignKey('self', on_delete=SET_NULL, default=None, null=True, related_name='replicas')
    password = CharField(max_length=400, null=True, default=None)
    clustered = BooleanField(default=False)
    partition_level = PositiveSmallIntegerField(default=1)  # partition_level for cached data
    # last_heartbeat = DateTimeField(default=datetime.now)
    # metrics recalculated only in every INFO heartbeat

    class Meta(ModelOptions):
        abstract = True


class CacheStorage(ServiceUtility, StorageMixin):
    """
    Cache cluster configuration
    """
    pid = PositiveIntegerField(default=None, null=True)
    # instance = ForeignKey(Instance, on_delete=CASCADE, default=None, null=True, related_name='caches')
    # worker = ForeignKey(Worker, on_delete=CASCADE)
    expose = BooleanField(default=False)

    used_memory = PositiveBigIntegerField(default=0)
    memory_limit = PositiveBigIntegerField(default=None, null=True)
    current_connections = PositiveBigIntegerField(default=0)
    max_connections = PositiveBigIntegerField(default=0)
    total_connections = PositiveBigIntegerField(default=0)
    qps = DecimalField(max_digits=10, decimal_places=2, default=None, null=True)
    max_qps = DecimalField(max_digits=10, decimal_places=2, default=None, null=True)
    max_qps_time = DateTimeField(default=None, null=True)
    # latency = FloatField(default=0)

    class Meta(ModelOptions):
        db_table = 'utilmeta_cache'
        # unique_together = ('service', 'alias')

    @classmethod
    def get(cls, host: str, port: int) -> 'CacheStorage':
        return cls.objects.filter(host=host, port=port).first()


class DatabaseStorage(ServiceUtility, StorageMixin):
    name = CharField(max_length=100)
    user = CharField(max_length=100)
    # used_memory = PositiveBigIntegerField(default=0)
    used_space = PositiveBigIntegerField(default=0)     # used disk space
    server_used_space = PositiveBigIntegerField(default=0)     # used disk space
    active_connections = PositiveIntegerField(default=0)
    current_connections = PositiveIntegerField(default=0)
    server_connections = PositiveIntegerField(default=0)
    server_connections_limit = PositiveIntegerField(default=None, null=True)
    qps = DecimalField(max_digits=10, decimal_places=2, default=None, null=True)
    max_qps = DecimalField(max_digits=10, decimal_places=2, default=None, null=True)
    max_qps_time = DateTimeField(default=None, null=True)

    # queries_num = PositiveBigIntegerField(default=0)    # store temporarily

    class Meta(ModelOptions):
        db_table = 'utilmeta_database'
        # unique_together = ('service', 'alias')

    @classmethod
    def get(cls, alias: str) -> Optional['DatabaseStorage']:
        from utilmeta.conf import config
        return cls.objects.filter(service_id=config.name, alias=alias).first()


class DatabaseConnection(Model):
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    database = ForeignKey(DatabaseStorage, related_name='connections', on_delete=CASCADE)
    # remote_id = CharField(max_length=100)
    status = CharField(max_length=40)
    active = BooleanField(default=False)
    client_addr = GenericIPAddressField()   # mysql use ADDR:PORT as HOST
    client_port = PositiveIntegerField()
    pid = PositiveIntegerField(default=None, null=True)

    query = TextField(default='')
    type = CharField(max_length=32, default=None, null=True)
    tables = ArrayField(CharField(max_length=200), default=list)

    backend_start = DateTimeField(default=None, null=True)
    query_start = DateTimeField(default=None, null=True)
    state_change = DateTimeField(default=None, null=True)
    # in postgresql pid is listed
    info = JSONField(default=dict)

    class Meta(ModelOptions):
        db_table = 'utilmeta_database_connection'
        # unique_together = ('database', 'remote_id')


class WebServer(ServiceUtility):
    local_file = FilePathField(default=None, null=True)
    https_config = JSONField(default=None, null=True)
    link = FilePathField(default=None, null=True)
    main_file = FilePathField(default=None, null=True)
    includes = ArrayField(TextField(default=''), default=list)

    class Meta(ModelOptions):
        db_table = 'utilmeta_web_server'


class Worker(SystemMetrics):
    # per-process (worker) counter cache
    TYPE = WorkerType.common
    objects = MetaManager()

    id = CharField(max_length=10, primary_key=True, default=id_generator)
    server = ForeignKey(Server, related_name='workers', on_delete=CASCADE)
    pid: int = PositiveIntegerField()
    memory_info = JSONField(default=dict)
    threads = PositiveIntegerField(default=0)
    start_time = DateTimeField(default=time_now)
    info = JSONField(default=dict)      # store backward compat information
    utility = ForeignKey(ServiceUtility, related_name='workers', on_delete=SET_NULL, null=True, default=None)
    master = ForeignKey('self', related_name='workers', on_delete=CASCADE, null=True, default=None)
    connected = BooleanField(default=True)
    type = ChoiceField(WorkerType.gen(), retrieve_key=False, store_key=False, default=WorkerType.common)
    time = DateTimeField(default=time_now)  # latest metrics update time

    status = CharField(max_length=100, default=None, null=True)
    user = CharField(max_length=100, default=None, null=True)
    # queries_num = PositiveBigIntegerField(default=0)

    class Meta(ModelOptions):
        db_table = 'utilmeta_worker'
        unique_together = ('server', 'pid')

    @classmethod
    def get(cls: Type[T], pid: int) -> Optional[T]:
        if not pid:
            return None
        return cls.objects.filter(pid=pid, server=Server.current()).first()

    @classmethod
    def local_workers(cls):
        from utilmeta.conf import config
        return cls.objects.filter(instance_id=config.deploy.instance_id)

    @classmethod
    def current(cls: Type[T]) -> Optional[T]:
        return cls.get(os.getpid())

    @classmethod
    def current_workers(cls: Type[T]) -> MetaQuerySet:
        return cls.objects.filter(server=Server.current())

    @classmethod
    def load(cls: Type[T], pid: int = None, parent: bool = False, force: bool = True, **kwargs) -> T:
        from .task import TaskInstance, TaskWorker
        import psutil
        pid = pid or os.getpid()
        try:
            proc = psutil.Process(pid)
        except psutil.Error:
            return None
        server = Server.current()
        if not server:
            return None

        if force:
            Worker.objects.filter(server=server, pid=pid).exclude(type=cls.TYPE).delete()

        parent_pid = None
        if parent and proc.parent():
            parent_pid = proc.parent().pid
        data = dict(
            start_time=convert_time(datetime.fromtimestamp(proc.create_time())),
            type=cls.TYPE,
            user=proc.username(),
            status=proc.status()
        )
        data.update(kwargs)
        master = cls.get(parent_pid)
        if master:
            data.update(master_id=master.pk)    # do not user master=

        instance = ServiceInstance.current() if issubclass(cls, ServiceWorker)\
            else TaskInstance.current() if issubclass(cls, TaskWorker) else None
        if instance:
            data.update(instance_id=instance.pk)

        worker, created = cls.objects.update_or_create(
            server_id=server.pk,
            pid=pid,
            defaults=data
        )
        return worker

    @property
    def sys_metrics(self):
        import psutil
        try:
            process = psutil.Process(self.pid)
        except psutil.Error:
            return None
        mem_info = process.memory_full_info()

        try:
            open_files = len(process.open_files())
        except psutil.Error:
            open_files = 0

        return dict(
            used_memory=getattr(mem_info, 'uss', getattr(mem_info, 'rss')),
            memory_info={f: getattr(mem_info, f) for f in getattr(mem_info, '_fields')},
            total_net_connections=len(process.connections()),
            active_net_connections=len([c for c in process.connections() if c.status != 'CLOSE_WAIT']),
            file_descriptors=process.num_fds() if psutil.POSIX else None,
            cpu_percent=process.cpu_percent(interval=0.5),
            memory_percent=round(process.memory_percent('uss'), 2),
            open_files=open_files,
            threads=process.num_threads(),
            time=time_now()
        )

    def update(self, record: bool = True):
        metrics = self.sys_metrics
        if not metrics:
            return
        MetaQuerySet(model=self.__class__).filter(pk=self.pk).update(**metrics, connected=True)
        if record:
            from .metrics import WorkerMonitor
            pop(metrics, 'memory_info')
            WorkerMonitor.objects.create(
                worker=self,
                **metrics
            )


class ServiceWorker(Worker, RequestMetrics):
    TYPE = WorkerType.service

    logger = MetricsLogger(in_process=True)
    instance: ServiceInstance = ForeignKey(ServiceInstance, related_name='workers', on_delete=CASCADE)

    class Meta(ModelOptions):
        db_table = 'utilmeta_service_worker'

    @property
    def task(self) -> bool:
        return bool(self.instance and self.instance.task)

    @property
    def wsgi(self) -> bool:
        return bool(self.instance and self.instance.wsgi)

    @property
    def asgi(self) -> bool:
        return bool(self.instance and self.instance.asgi)

    @property
    def data(self):
        from utilmeta.ops.schema.metrics import RequestMetricsMixin
        return RequestMetricsMixin(
            requests=self.requests,
            req_per_sec=self.req_per_sec,
            avg_time=self.avg_time,
            errors=self.errors,
            invokes=self.invokes,
            timeout_invokes=self.timeout_invokes,
            error_invokes=self.error_invokes,
            avg_invoke_time=self.avg_invoke_time,
            invoke_per_sec=self.invoke_per_sec,
            in_traffic=self.in_traffic,
            out_traffic=self.out_traffic
        )

    @classmethod
    def current_workers(cls: Type[T]) -> MetaQuerySet:
        from utilmeta.conf import config
        return super().current_workers().filter(instance_id=config.deploy.instance_id)

    @classmethod
    def get_master(cls) -> Optional['ServiceWorker']:
        from utilmeta.conf import config
        return cls.objects.filter(instance_id=config.deploy.instance_id, master=None).first()

    def update(self, record: bool = True):
        metrics = self.sys_metrics
        self.logger.save(self, **metrics, connected=True)
        if record:
            from .metrics import ServiceWorkerMonitor
            pop(metrics, 'memory_info')
            inst: ServiceWorker = self.__class__.objects.filter(pk=self.pk).first()
            if not inst:
                return
            ServiceWorkerMonitor.objects.create(
                worker=self,
                **metrics,
                **inst.data
            )
