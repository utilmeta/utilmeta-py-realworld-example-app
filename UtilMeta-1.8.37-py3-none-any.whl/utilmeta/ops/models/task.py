from utilmeta.fields import *
from utilmeta.types import *
from utilmeta.util.common import TaskStatus, EventStatus, TaskConditionType, constant, time_now
from utilmeta.util.query import MetaManager, MetaQuerySet
from .common import id_generator, TaskJobMetrics, LoggerMixin, TaskMetrics
from .service import BaseInstance, Worker, Service
from .utils import Resource, DataModel
from .admin import ExternalMixin, Admin
from typing import TypeVar
import os

T = TypeVar('T')

__all__ = ['TaskInstance', 'NativeTask', 'TaskSettings', 'TaskWorker', 'BaseTask', 'RequestTask',
           'TaskDistribution', 'TaskEvent', 'TaskExecution', 'TaskJob', 'ScriptTask', 'TaskDependency']


class TaskInstance(BaseInstance):
    main_cycle_interval = PositiveSmallIntegerField()
    worker_cycle_interval = PositiveSmallIntegerField()

    process_start_method = CharField(max_length=20, default=None, null=True)
    default_concurrent_cls = CharField(max_length=200, default=None, null=True)
    manager_cls = CharField(max_length=200, default=None, null=True)

    max_concurrent_jobs = PositiveBigIntegerField(default=None, null=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_task_instance'

    @classmethod
    def current(cls) -> 'TaskInstance':
        from utilmeta.conf import config
        return cls.get(config.task.instance_id)

    def get_workers(self):
        return TaskWorker.objects.filter(connected=True, instance=self)


class TaskWorker(Worker):
    TYPE = constant.WorkerType.task
    instance: TaskInstance = ForeignKey(TaskInstance, related_name='workers', on_delete=CASCADE)
    retire_time = DateTimeField(default=None, null=True)
    group_name = CharField(max_length=100, default=None, null=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_task_worker'

    @classmethod
    def current_workers(cls: Type[T]) -> MetaQuerySet:
        from utilmeta.conf import config
        return super().current_workers().filter(
            instance_id=config.task.instance_id,
        )

    @property
    def tasks(self) -> int:
        dist = getattr(self, 'task_distributions', None)
        if not dist:
            return 0
        return dist.count()

    @classmethod
    def reassign_targets(cls):
        return cls.normal_workers().filter(
            master__isnull=False
        ).exclude(pid=os.getpid())

    @classmethod
    def retire_workers(cls):
        return cls.current_workers().filter(retire_time__isnull=False)

    @classmethod
    def normal_workers(cls):
        return cls.current_workers().filter(retire_time__isnull=True, connected=True)


class BaseTask(Resource):
    upstream_tasks = ManyToManyField(
        'self', through='TaskDependency',
        related_name='downstream_tasks', symmetrical=False,
        through_fields=('target', 'source')
    )
    task_type = ChoiceField(
        constant.TaskType.gen(), retrieve_key=False, store_key=False,
        default=constant.TaskType.native
    )
    priority = PositiveSmallIntegerField(default=1)     # not implement in this version

    class Meta(ModelOptions):
        db_table = 'utilmeta_base_task'

    @classmethod
    def get(cls: Type[T], ident: str) -> Optional[T]:
        if not ident:
            return None
        return cls.objects.filter(ident=ident).first()


class NativeTask(BaseTask):
    model = ForeignKey(DataModel, db_constraint=False, default=None, null=True, on_delete=SET_NULL)
    module_path = CharField(max_length=200, null=True, default=None)
    iterable = BooleanField(default=False)
    exec_params = JSONField(default=dict)       # execute params for __call__
    init_params = JSONField(default=dict)       # external params for __init__

    class Meta(ModelOptions):
        db_table = 'utilmeta_native_task'


class ScriptTask(BaseTask):
    language = CharField(max_length=100)
    executable = FilePathField()                # executable of the language
    environment = JSONField(default=dict)       # env variables
    chdir = FilePathField(default=None, null=True)  # script execution cwd
    script = TextField()
    args = ArrayField(TextField(), default=list)

    added_time = DateTimeField(auto_now_add=True)
    added_by = ForeignKey(Admin, on_delete=SET_NULL, null=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_script_task'


class RequestTask(BaseTask):
    method = ChoiceField(constant.HTTP_METHODS, retrieve_key=False)
    scheme = ChoiceField(constant.SCHEMES, retrieve_key=False, store_key=False)
    path = CharField(max_length=300)
    query = JSONField(default=dict)

    hosts = ArrayField(CharField(max_length=100))
    urls = ArrayField(URLField())    # full encoded url

    max_retries = PositiveIntegerField(default=0)
    headers = JSONField(default=dict)

    data = JSONField(default=None, null=True)
    files = JSONField(default=None, null=True)

    timeout = DecimalField(max_digits=10, decimal_places=2, default=None, null=True)
    success_format = JSONField(default=dict)        # like {"state": 0} or {"code": 200}

    added_time = DateTimeField(auto_now_add=True)
    added_by = ForeignKey(Admin, on_delete=SET_NULL, null=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_request_task'


class TaskDependency(ExternalMixin):
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)

    target = ForeignKey(BaseTask, on_delete=CASCADE, related_name='upstream_dependencies')
    source = ForeignKey(BaseTask, on_delete=CASCADE, related_name='downstream_dependencies')
    name = CharField(max_length=100)
    condition = ChoiceField(TaskConditionType.gen(), retrieve_key=False, store_key=False)
    params = JSONField(default=dict)

    invert = BooleanField(default=False)

    class Meta(ModelOptions):
        db_table = 'utilmeta_task_dependency'


class TaskSettings(ExternalMixin):
    """
    TaskInstance can be altered from admin platform
    """
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    name = CharField(max_length=100)
    group = CharField(max_length=100, default=None, null=True)
    query = JSONField(default=None, null=True)

    service = ForeignKey(Service, on_delete=CASCADE, related_name='task_settings')
    base: BaseTask = ForeignKey(BaseTask, on_delete=CASCADE, related_name='settings')
    # aggregate = BooleanField(default=False)

    schedule = JSONField(default=None, null=True)
    interval: timedelta = DurationField(default=None, null=True)
    looped = BooleanField(default=False)

    # time configs
    max_times = PositiveBigIntegerField(default=None, null=True)
    start_time = DateTimeField(default=None, null=True)
    stop_time = DateTimeField(default=None, null=True)

    # dist settings
    dist_by_param = BooleanField(default=False)
    dist_by_event = BooleanField(default=False)
    # a fixed time calculated by schedule or start_time + interval * N

    begin_workflow = BooleanField(default=False)      # as a workflow
    finish_workflow = BooleanField(default=False)      # as a workflow

    event_abandon_window = DurationField(default=None, null=True)
    event_abandon_expired = BooleanField(default=False)
    # other kwargs settings
    settings = JSONField(default=dict)

    params = JSONField(default=dict)    # override some task class params (for script task and request task)
    # init params for native class

    class Meta(ModelOptions):
        db_table = 'utilmeta_task_settings'
        unique_together = ('service', 'name')

    @classmethod
    def get(cls, name: str) -> Optional['TaskSettings']:
        if not name:
            return None
        return cls.objects.filter(name=name).first()

    def start(self, delta: float = 0):
        if not self.start_time:
            self.start_time = time_now() + timedelta(seconds=delta)
            self.save(update_fields=['start_time'])
        return self.start_time


class TaskEvent(ExternalMixin):
    objects = MetaManager()
    id = BigAutoField(primary_key=True)
    task: TaskSettings = ForeignKey(TaskSettings, related_name='events', on_delete=CASCADE)
    exec_time: datetime = DateTimeField()   # expected execution time
    event_id = PositiveBigIntegerField()

    queue = BooleanField(default=False)     # whether if in the waiting queue
    status = ChoiceField(EventStatus.gen(), retrieve_key=False, store_key=False, default=EventStatus.pending)
    volatile = BooleanField(default=True)

    info = JSONField(default=dict)

    class Meta(ModelOptions):
        db_table = 'utilmeta_task_event'
        ordering = ('exec_time', )
        unique_together = ('task', 'event_id')

    @classmethod
    def next(cls, task: TaskSettings) -> Optional['TaskEvent']:
        return cls.incoming_events(task=task).first()

    @classmethod
    def incoming_events(cls, task, desc: bool = False) -> MetaQuerySet:
        prefix = '-' if desc else ''
        return cls.objects.filter(exec_time__gte=time_now(), task=task).order_by(prefix + 'event_id')

    @classmethod
    def last(cls, task) -> Optional['TaskEvent']:
        return cls.objects.filter(task=task).order_by('event_id').last()

    @classmethod
    def current(cls, task: TaskSettings) -> Optional['TaskEvent']:
        return cls.previous_events(task=task).last()

    @classmethod
    def get(cls, task: TaskSettings, event_id: int) -> Optional['TaskEvent']:
        return cls.objects.filter(task=task, event_id=event_id).first()

    @classmethod
    def previous_events(cls, task: TaskSettings, desc: bool = False) -> MetaQuerySet:
        prefix = '-' if desc else ''
        return cls.objects.filter(task=task, exec_time__lte=time_now()).order_by(prefix + 'event_id')

    @classmethod
    def previous(cls, task: TaskSettings) -> Optional['TaskEvent']:
        try:
            return cls.previous_events(task=task, desc=True)[1]
        except IndexError:
            return None


class TaskDistribution(TaskMetrics):
    """
    Track the execution in distribution of tasks
    """
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    task: TaskSettings = ForeignKey(TaskSettings, related_name='distributions', on_delete=CASCADE)
    instance: TaskInstance = ForeignKey(TaskInstance, related_name='task_distributions', on_delete=CASCADE)
    worker: TaskWorker = ForeignKey(
        TaskWorker, on_delete=SET_NULL,
        null=True, default=None,
        related_name='task_distributions',
        db_constraint=False
    )   # only make sense for looped tasks in Queue mode

    status = ChoiceField(TaskStatus.gen(), retrieve_key=False, store_key=False, default=TaskStatus.idle)
    init_time = DateTimeField(auto_now_add=True)

    worker_avg_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    worker_executed_events = PositiveBigIntegerField(default=0)    # current executed events for worker

    current_event = ForeignKey(
        TaskEvent, related_name='current_distributions',
        on_delete=SET_NULL, default=None, null=True
    )
    # current_jobs = PositiveBigIntegerField(default=0)
    info = JSONField(default=dict)

    # metrics
    latest_total_jobs = PositiveBigIntegerField(default=0)
    latest_failed_jobs = PositiveBigIntegerField(default=0)
    latest_timeout_jobs = PositiveBigIntegerField(default=0)
    latest_retried_jobs = PositiveBigIntegerField(default=0)

    latest_job_min_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    latest_job_avg_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    latest_job_max_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    latest_jobs_per_sec = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # concurrency

    latest_executed_events = PositiveBigIntegerField(default=0)
    latest_abandoned_events = PositiveIntegerField(default=0)
    latest_executed_executions = PositiveBigIntegerField(default=0)
    latest_failed_executions = PositiveBigIntegerField(default=0)
    latest_timeout_executions = PositiveBigIntegerField(default=0)
    latest_avg_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)

    latest_mean_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 50%
    latest_p95_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 95%
    latest_p99_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 99%
    latest_p999_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 99.9%
    latest_time_stddev = DecimalField(max_digits=10, decimal_places=2, default=0.00, null=True)

    class Meta(ModelOptions):
        db_table = 'utilmeta_task_distribution'
        unique_together = ('task', 'instance')

    @classmethod
    def lfu(cls, task: 'TaskSettings') -> Optional['TaskDistribution']:
        if not task:
            return None
        return cls.objects.filter(task=task).order_by('executed_events', 'init_time').first()

    @classmethod
    def lru(cls, task: 'TaskSettings') -> Optional['TaskDistribution']:
        if not task:
            return None
        return cls.objects.filter(task=task).order_by('current_event__exec_time', 'init_time').first()

    @property
    def active(self) -> bool:
        return self.status in (TaskStatus.idle, TaskStatus.busy)

    @classmethod
    def currents(cls) -> MetaQuerySet:
        from utilmeta.conf import config
        return cls.objects.filter(
            instance_id=config.task.instance_id,
            task__disabled=False,
            status__in=[TaskStatus.idle, TaskStatus.busy]
        ).distinct()

    @classmethod
    def get(cls, task: TaskSettings, instance_id: int = None) -> Optional['TaskDistribution']:
        from utilmeta.conf import config
        if not task:
            return None
        if not instance_id:
            instance_id = config.task.instance_id
        return cls.objects.filter(task=task, instance_id=instance_id).first()

    def transfer_to(self, worker: 'TaskWorker'):
        if not worker:
            return
        self.worker = worker
        self.worker_avg_time = 0
        self.worker_executed_events = 0
        self.save(update_fields=['worker', 'worker_avg_time', 'worker_executed_events'])


class ExecuteMixin(Model):
    objects = MetaManager()
    id = BigAutoField(primary_key=True)
    exec_time: datetime = DateTimeField(default=None, null=True)      # actual exec_time
    done_time: datetime = DateTimeField(null=True, default=None)
    duration = PositiveBigIntegerField(default=None, null=True)
    timeout_time: datetime = DateTimeField(null=True, default=None)
    timeout = BooleanField(default=None, null=True)
    success = BooleanField(default=True)
    message = TextField(default='')
    info = JSONField(default=dict)

    class Meta(ModelOptions):
        abstract = True


class TaskExecution(ExecuteMixin, TaskJobMetrics):
    """
    Each distribution's single execution log
    """
    dist: TaskDistribution = ForeignKey(TaskDistribution, related_name='executions', on_delete=CASCADE)
    event: TaskEvent = ForeignKey(TaskEvent, related_name='executions', on_delete=CASCADE)
    worker: TaskWorker = ForeignKey(
        TaskWorker, on_delete=SET_NULL,
        null=True, default=None,
        db_constraint=False,
        related_name='executions'
    )
    dependencies = ManyToManyField(
        TaskDependency, db_table='utilmeta_task_execution_dependencies',
        related_name='executions'
    )

    alert = ForeignKey(
        'AlertLog', related_name='task_executions',
        on_delete=SET_NULL, null=True, default=None,
        db_constraint=False
    )

    job_mean_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 50%
    job_p95_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 95%
    job_p99_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 99%
    job_p999_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 99.9%
    job_time_stddev = DecimalField(max_digits=10, decimal_places=2, default=0.00, null=True)
    avg_job_retries = DecimalField(max_digits=10, decimal_places=2, default=0.00)

    class Meta(ModelOptions):
        db_table = 'utilmeta_task_execution'
        unique_together = ('dist', 'event')

    @classmethod
    def last(cls, task: TaskSettings) -> Optional['TaskExecution']:
        if not task:
            return None
        return cls.objects.filter(event__task=task).exclude(done_time=None).order_by('-exec_time').first()

    def done(self, **kwargs):
        for key, val in kwargs.items():
            setattr(self, key, val)
        self.save(update_fields=list(kwargs))

    # @property
    # def ms_duration(self):
    #     if self.exec_time and self.done_time:
    #         return int((self.done_time - self.exec_time).total_seconds() * 1000)
    #     return 0


class TaskJob(ExecuteMixin, LoggerMixin):
    """
    Realtime task jobs, only record error ones or timeout ones
    """
    execution: TaskExecution = ForeignKey(TaskExecution, related_name='jobs', on_delete=CASCADE)
    thread_id = PositiveBigIntegerField(default=None, null=True)

    args = JSONField(default=list)  # serialized with pickle
    kwargs = JSONField(default=dict)  # serialized with pickle

    result = TextField(null=True, default=None)     # pickle serialized result

    local_retries = PositiveIntegerField(default=0)
    retry_for = ForeignKey('self', on_delete=SET_NULL, null=True, default=None, related_name='retry_jobs')

    class Meta(ModelOptions):
        db_table = 'utilmeta_task_job'

    @classmethod
    def get(cls, id: int) -> Optional['TaskJob']:
        return cls.objects.filter(id=id).first()
