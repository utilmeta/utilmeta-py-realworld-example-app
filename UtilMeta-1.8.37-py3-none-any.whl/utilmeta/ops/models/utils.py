from utilmeta.fields import *
from utilmeta.util.common import constant
from utilmeta.util.query import MetaManager, MetaQuerySet
from typing import Optional
from .common import id_generator
from .service import Service, ServiceInstance

__all__ = ['Application', 'Endpoint', 'DataModel', 'Resource', 'EndpointDistribution']


class Application(Model):
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    service = ForeignKey(Service, on_delete=CASCADE)
    label = CharField(max_length=60)
    path = FilePathField()
    name = CharField(max_length=60)

    class Meta(ModelOptions):
        db_table = 'utilmeta_application'
        unique_together = ('service', 'label')

    @classmethod
    def get(cls, label: str) -> Optional['Application']:
        from utilmeta.conf import config
        return cls.objects.filter(service_id=config.name, label=label).first()


class Resource(Model):
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    # service = ForeignKey(Service, on_delete=CASCADE)
    init_version = ForeignKey(
        'VersionLog', null=True,
        on_delete=SET_NULL, related_name='init_resources'
    )
    current_version = ForeignKey(
        'VersionLog', null=True,
        on_delete=SET_NULL, related_name='current_resources'
    )
    info = JSONField(default=dict)
    type = ChoiceField(constant.ResourceType.gen(), retrieve_key=False, store_key=False)
    application = ForeignKey(
        Application, related_name='resources', on_delete=CASCADE,
    )
    ref = CharField(max_length=200)     # identifier
    # a reference of like utilmeta.ops.models.utils.Resource
    document = TextField(default='')
    ident = CharField(max_length=200, unique=True)
    #   api: use method + path like get:user/list
    # model: use app label + model name like account.user
    #  task: use app + task class name like ops.monitor_task, script use name

    class Meta(ModelOptions):
        db_table = 'utilmeta_resource'
        # unique_together = ('service', 'ref')

    @classmethod
    def current_instances(cls) -> MetaQuerySet:
        from utilmeta.conf import config
        base = cls.objects.filter(current_version_id__gte=config.version_id)\
            if config.version_id else cls.objects.all()
        return base.filter(
            application__service_id=config.name,
        )


class DataModel(Resource):
    app_label = CharField(max_length=100)
    model_name = CharField(max_length=100)
    display_name = CharField(max_length=100, default='')
    db_table = CharField(max_length=100, default=None, null=True)
    base = ForeignKey(
        'self', related_name='children',
        db_constraint=False, on_delete=SET_NULL, null=True, default=None
    )

    class Meta(ModelOptions):
        db_table = 'utilmeta_model'
        unique_together = ('app_label', 'model_name')

    @classmethod
    def get(cls, model) -> Optional['DataModel']:
        from django.db.models.options import Options
        meta: Options = getattr(model, '_meta', None)
        if not meta:
            return None
        return cls.objects.filter(app_label=meta.app_label, model_name=meta.model_name).first()


class Endpoint(Resource):
    """
    An endpoint mounted at version 14 (init_version) and depreciated at version 28 (remain as current version)
    all endpoint with current_version == latest version is current service endpoints
    """
    method = ChoiceField(constant.HTTP_METHODS, retrieve_key=False)
    path = URLField()

    idempotent = BooleanField(default=None, null=True)
    depreciated = BooleanField(default=False)

    model = ForeignKey(DataModel, related_name='endpoints', default=None, null=True, on_delete=SET_NULL)
    # RESTful API for model (usually defined in Module)

    class Meta(ModelOptions):
        db_table = 'utilmeta_endpoint'
        unique_together = ('method', 'path')

    @classmethod
    def get(cls, request) -> Optional['Endpoint']:
        from utilmeta.util.request import Request
        req = Request(request)
        return cls.objects.filter(method=req.METHOD, path=req.endpoint_path).first()

    @classmethod
    def current_instances(cls) -> MetaQuerySet:
        return super().current_instances().filter(depreciated=False)


class EndpointDistribution(Model):
    objects = MetaManager()
    id = CharField(max_length=10, primary_key=True, default=id_generator)
    time = DateTimeField(default=None, null=True)

    endpoint = ForeignKey(Endpoint, on_delete=CASCADE, related_name='distributions')
    instance = ForeignKey(ServiceInstance, on_delete=CASCADE, related_name='endpoint_distributions')

    requests = PositiveBigIntegerField(default=0)
    errors = PositiveBigIntegerField(default=0)

    avg_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    max_rps = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # max requests per seconds
    max_rps_time = DateTimeField(default=None, null=True)  # max requests per seconds

    latest_requests = PositiveBigIntegerField(default=0)
    latest_errors = PositiveBigIntegerField(default=0)
    latest_rps = DecimalField(max_digits=10, decimal_places=2, default=0.00)
    latest_avg_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)

    latest_uv = PositiveBigIntegerField(default=0)  # user views in interval
    latest_ip = PositiveBigIntegerField(default=0)  # IP in interval

    latest_mean_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 50%
    latest_p95_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 95%
    latest_p99_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 99%
    latest_p999_time = DecimalField(max_digits=10, decimal_places=2, default=0.00)  # 99.9%
    latest_time_stddev = DecimalField(max_digits=10, decimal_places=2, default=0.00, null=True)

    levels = JSONField(default=dict)
    statuses = JSONField(default=dict)
    latest_levels = JSONField(default=dict)
    latest_statuses = JSONField(default=dict)

    alerts = PositiveBigIntegerField(default=0)
    latest_alerts = PositiveBigIntegerField(default=0)

    latest_in_traffic = PositiveBigIntegerField(default=0)
    latest_out_traffic = PositiveBigIntegerField(default=0)

    class Meta(ModelOptions):
        db_table = 'utilmeta_endpoint_distribution'
        unique_together = ('endpoint', 'instance')
