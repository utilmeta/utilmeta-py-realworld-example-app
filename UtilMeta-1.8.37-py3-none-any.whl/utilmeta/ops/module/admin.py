from utilmeta.utils import *
from ..schema.admin import *
from ..models.admin import *
from ..sdk import ActionSDK, ClusterSDK
from utilmeta.conf import config
from ..auth import valid, Opt

__all__ = ['AdminMain', 'SupervisorAlter', 'SupervisorView', 'SupervisorMain', 'SessionMain']


class SessionMain(Module):
    model = Session
    schema = SessionSchema
    option = Option(
        filters={
            model.user_id: Filter('=', '^'),
            model.ip: Filter('=', '^'),
            model.expiry_age: Filter('>=', '<=', '='),
            model.expiry_time: Filter('>=', '<='),
            model.setup_time: Filter('>=', '<='),
            model.last_activity: Filter('>=', '<='),
        },
        base_filter=exp.Q(delete_time=None)
    )
    method = Method(
        get=(
            Auth(relate=model.user_id) | Auth(require=valid(Opt.session_view)),
            Page(max_rows=50, default_page=1),
            Request(admin_only=False)
        ),
        delete=(
            Auth(require=valid(Opt.session_delete)),
        )
    )

    def delete(self):
        from django.contrib.sessions.backends.base import SessionBase
        from django.core.cache.backends.base import BaseCache
        cls = config.session.engine_cls
        session: SessionBase = cls()
        self.q.update(delete_time=self.request.time)
        cache = getattr(session, '_cache', None)
        if isinstance(cache, BaseCache):
            keys = []
            for i in self.q:
                i: Session
                inst = cls(i.session_key)
                k1 = getattr(inst, 'cache_key', None)
                k2 = getattr(inst, 'service_cache_key', None)
                if k1:
                    keys.append(k1)
                if k2:
                    keys.append(k2)
            cache.delete_many(*keys)


class AdminMain(Module):
    model = Admin
    schema = AdminSchema
    option = Option(
        client_option=Option.Client(field=True),
        filters={
            model.access_key: Filter('='),
            model.supervisor: Filter('='),
            model.operations: Filter('=', '^'),
            model.root: Filter('='),
            model.granted_by: Filter('='),
        },
    )
    method = Method(
        get=Auth(require=valid(Opt.admin_audit)),
        post=Auth(require=valid(Opt.admin_add)),
        patch=Auth(require=valid(Opt.admin_alter)),
        delete=Auth(require=valid(Opt.admin_remove)),
    )


class SupervisorAlter(Module):
    model = Supervisor
    schema = SupervisorAlterable
    method = Method(
        patch=(
            Auth(require=valid(root=True)),
            Unit(transaction=config.ops.db_alias),
        ),
        delete=(
            Unit(transaction=config.ops.db_alias)
        )
    )

    def patch(self):
        sp = self.request.supervisor
        if not sp:
            raise exc.NotFound('Supervisor not found')
        self.i = sp
        self.modify()
        resp = ActionSDK(
            to=sp, ops_token=self.request.ops_token,
        ).alter_node()
        if not resp.success:
            raise exc.BadRequest(f'service data sync to supervisor: '
                                 f'{sp.id} failed ({resp.status}) with error: {resp.message}')

    def delete(self):
        sp = self.request.supervisor
        if sp:
            Auth(require=valid(root=True))(self.request)
            self.i = sp
            sid = sp.pk
        else:
            if not config.is_proxy:
                raise exc.PermissionDenied
            if self.request.action_token != config.cluster_manager.self_action_token:
                raise exc.PermissionDenied(f'Invalid Action Token')
            sid = self.pk

        if not self.exists():
            raise exc.NotFound('Supervisor not found')

        if not config.is_proxy:
            proxy = config.cluster_manager.proxy
            if proxy:
                resp = ClusterSDK(
                    service=proxy.name,
                    prepend_route=proxy.ops_route
                ).delete_supervisor(id=sp.pk)
                if not resp.success:
                    raise exc.ServerError(f'Delete supervisor: {self.i} from proxy failed with error: {resp.message}')

        if sp:
            def del_callback():
                if config.is_proxy:
                    # as proxy, not only self-supervisor need to be delete, other services supervisors else
                    return self.filter(action_url=sp.action_url).delete()
                return sp.delete()

            resp = ActionSDK(
                to=sp, ops_token=self.request.ops_token,
                init_callback=del_callback
            ).delete_node()

            if not resp.success:
                raise exc.BadRequest(f'service data sync to supervisor: '
                                     f'{sid} failed ({resp.status}) with error: {resp.message}')
        else:
            return self.remove()


class SupervisorView(Module):
    model = Supervisor
    schema = SupervisorSchema
    option = Option(
        filters={
            model.service: Filter('='),
            model.disabled: Filter('='),
            'heartbeat': Filter('=', field='settings.heartbeat_enabled', custom_lookup=True)
        }
    )
    method = Method(
        get=Auth(require=valid(root=True)),
    )


class SupervisorMain(SupervisorView, SupervisorAlter):
    pass
