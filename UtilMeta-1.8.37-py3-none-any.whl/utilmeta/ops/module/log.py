from utilmeta.utils import *
from utilmeta.util.common import Opt, Scheme, LogType
from ..models.log import *
from ..models.service import RestartRecord
from ..schema.log import *
from ..auth import valid
from utilmeta.conf import config

__all__ = ['OperationLogList', 'CacheLogList', 'AlertSettingsMain', 'VersionLogList', 'AlertTypeList',
           'AlertLogList', 'LogList', 'ServiceLogList', 'RequestLogList', 'QueryLogList', 'RestartRecordList']


class VersionLogList(Module):
    model = VersionLog
    schema = VersionLogSchema
    option = Option(
        filters={
            model.version: Filter(),
            model.instance: Filter(),
            'service': Filter(field='instance.service'),
            model.python_version: Filter(),
            model.utilmeta_version: Filter(),
            model.major: Filter('>=', '<=', '='),
            model.minor: Filter('>=', '<=', '='),
            model.patch: Filter('>=', '<=', '=')
        },
        order_by='-version',
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.log_query)),
            Page(default_rows=20)
        ),
    )


class RestartRecordList(Module):
    model = RestartRecord
    schema = RestartRecordSchema
    option = Option(
        filters={
            model.instance: Filter(),
            'ip': Filter(field='instance.server.ip'),
            'service': Filter(field='instance.service'),
            model.manual: Filter(),
            model.unavailable: Filter(),
            model.success: Filter(),
        },
        order_by='-time',
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.log_query)),
            Page(default_rows=20)
        ),
        delete=Auth(require=valid(Opt.log_delete))
    )


class OperationLogList(Module):
    model = OperationLog
    option = Option(
        filters={
            (model.executor, model.operation, model.version): Filter('='),
            'inst_id': Filter(field='version.instance_id'),
            model.time: Filter('>=', '<='),
        },
        order_by='-time',
        client_cache=bool(config.auto_cache),
        client_option=Option.Client(order=True, template=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.admin_audit)) | Auth(relate=model.executor),
            Page(default_rows=20)
        ),
        delete=Auth(require=valid(Opt.admin_audit))
    )


class CacheLogList(Module):
    model = CacheLog
    schema = CacheLogSchema
    option = Option(
        filters={
            model.cache: Filter('='),
            'alias': Filter('=', field='cache.alias'),
            'service': Filter('=', field='cache.service'),
            model.time: Filter('>=', '<=')
        },
        order_by='-latest_time',
        client_option=Option.Client(template=True, exclude=True, order=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.log_query)),
            Page(all=True)
        ),
        delete=Auth(require=valid(Opt.log_delete))
    )


class QueryLogList(Module):
    model = QueryLog
    schema = QueryLogSchema
    option = Option(
        filters={
            model.database: Filter('='),
            'table': Filter(field='tables.contains'),
            model.type: Filter('='),
            'service': Filter('=', field='database.service'),
            'name': Filter('=', field='database.name'),
            'alias': Filter(field='database.alias'),
            'host': Filter(field='database.server.ip'),
            model.time: Filter('>=', '<=')
        },
        order_by='-time',
        client_option=Option.Client(template=True, exclude=True, order=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.log_query)),
            Page(all=True)
        ),
        delete=Auth(require=valid(Opt.log_delete))
    )


class AlertSettingsMain(Module):
    model = AlertSettings
    schema = AlertSettingsSchema
    option = Option(
        filters={
            model.server: Filter('='),
            model.instance: Filter('='),
            model.task_settings: Filter('='),   # for alert task query
            model.service: Filter('='),
            model.index_name: Filter('='),
            model.disabled: Filter('=')
        },
        client_option=Option.Client(order=True, template=True, exclude=True),
        order_by=model.added_time
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.alert_query)),
            Page(default_rows=20, default_page=1)
        ),
        patch=Auth(require=valid(Opt.alert_add)),
        post=Auth(require=valid(Opt.alert_add)),
    )


class AlertTypeList(Module):
    model = AlertType
    schema = AlertTypeSchema
    option = Option(
        filters={
            model.category: Filter('='),
            model.subcategory: Filter('='),
            model.name: Filter('='),
            model.level: Filter('='),
            model.target: Filter('='),
            model.service: Filter('='),
            model.endpoint: Filter('='),
            model.task: Filter('='),
        },
        client_option=Option.Client(order=True, template=True, exclude=True),
        order_by=model.added_time
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.alert_query)),
            Page(default_rows=20, default_page=1)
        ),
        patch=Auth(require=valid(Opt.alert_add)),
    )


class AlertLogList(Module):
    model = AlertLog
    schema = AlertLogSchema
    option = Option(
        filters={
            (model.instance, model.server): Filter('='),
            model.cause: Filter('='),
            model.version: Filter('=', '>=', '<=', '^'),
            (model.time, model.latest_time, model.count): Filter('>=', '<='),
            'service': Filter('=', field='type.service'),
            'level': Filter('=', '^', field='type.level'),
            'target': Filter('=', field='type.target'),
            'category': Filter('=', '^', field='type.category'),
            'subcategory': Filter('=', '^', field='type.subcategory'),
            'unrelieved': Filter('=', field='relieved_time__isnull'),
        },
        base_filter=exp.Q(count__gt=0),
        order_by='-latest_time',
        post_query=True,
        client_cache=bool(config.auto_cache),
        client_option=Option.Client(order=True, template=True, exclude=True),
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.alert_query)),
            Page(default_rows=20, default_page=1)
        ),
        patch=Auth(require=valid(Opt.alert_relieve)),
        delete=Auth(require=valid(Opt.alert_relieve))
    )


log_method = Method(
    get=(
        Auth(require=valid(Opt.log_query)),
        Page(default_rows=20, default_page=1)
    ),
    delete=Auth(require=valid(Opt.log_delete))
)


class HttpLogList(Module):
    model = HttpLog
    schema = HttpLogSchema
    option = Option(
        filters={
            model.status: Filter('>=', '<=', '=', '^'),
            model.method: Filter('^', '='),
        },
        client_option=Option.Client(order=True, template=True, exclude=True),
    )
    method = log_method


class RequestLogList(Module):
    model = RequestLog
    schema = RequestLogSchema
    option = Option(
        filters={
            model.timeout: Filter('>=', '<='),
            (model.block, model.context_log, model.remote_log,
             model.to_instance, model.to_service): Filter('='),
        },
        client_option=Option.Client(order=True, template=True, exclude=True),
    )
    method = log_method


class ServiceLogList(Module):
    model = ServiceLog
    schema = ServiceLogSchema
    option = Option(
        filters={
            (model.user_id, model.endpoint,
             model.from_service, model.from_instance): Filter('=', '^'),
            'endpoint_path': Filter('=', field='endpoint.path'),
            'model': Filter('=', field='endpoint.model.ident'),
            'idempotent': Filter('=', field='endpoint.idempotent'),
            model.admin: Filter('=', Filter.isnull)
        },
        client_option=Option.Client(order=True, template=True, exclude=True),
    )
    method = log_method


# class LogList(Module):
#     model = BaseLog
#     schema = BaseLogSchema
#     mixins = [RequestLogList, ServiceLogList, HttpLogList]


class LogList(RequestLogList, ServiceLogList, HttpLogList, mixin=True):
    model = BaseLog
    schema = BaseLogSchema

    @staticmethod
    def scheme_query_exp(v: str):
        values = []
        if v == Scheme.HTTP:
            values = [Scheme.HTTP, Scheme.HTTPS]
        elif v == Scheme.WS:
            values = [Scheme.WS, Scheme.WSS]
        if not values:
            raise ValueError(f'Invalid type: {v}')
        return exp.Q(scheme__in=values)

    option = Option(
        filters={
            model.time: Filter('>=', '<='),
            model.runtime: Filter('='),
            model.level: Filter('^'),
            model.path: Filter('^', '*%'),
            model.type: Filter(mixins={
                LogType.request: RequestLogList,
                LogType.service: ServiceLogList,
                # LogType.task: TaskLogList
            }),
            'protocol': Filter(mixins={
                Scheme.HTTP: HttpLogList
            }, query_exp=scheme_query_exp, rule=Rule(choices=[Scheme.HTTP])),
            'inst_id': Filter(field='version.instance_id'),
            'major_ver': Filter('=', '^', '>=', '<=', field='version.major'),
            'minor_ver': Filter('=', '^', '>=', '<=', field='version.minor'),
            'patch_ver': Filter('=', '^', '>=', '<=', field='version.patch'),
        },
        orders={
            model.time: Order(asc=True, desc=True),
            model.duration: Order(asc=True, desc=True),
            model.in_traffic: Order(asc=True, desc=True),
            model.out_traffic: Order(asc=True, desc=True),
        },
        order_by='-time',
        post_query=True,
        discard_incomplete_mixin=True,
        ignore_mixin_conflicts=True,
        base_filter=~exp.Q(duration=None),
        client_cache=bool(config.auto_cache),
        client_option=Option.Client(order=True, template=True, exclude=True),
    )
    method = log_method

    @api.after(method.DELETE)
    def log_delete(self, r):
        from utilmeta.conf import config
        OperationLog.objects.create(
            executor=self.request.admin,
            operation=Opt.log_delete,
            version_id=config.version_id,
            ip=self.request.ip,
        )
        return r
