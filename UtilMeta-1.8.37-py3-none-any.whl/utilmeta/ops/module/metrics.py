from utilmeta.utils import *
from utilmeta.types import *
from ..schema.metrics import *
from ..models.metrics import *
from utilmeta.util.common import Opt, time_now, WorkerType
from utilmeta.conf import config
from ..auth import valid

__all__ = ['ServiceAggregateSeries', 'TaskAggregateSeries', 'InstanceMonitorSeries',
           'DatabaseMonitorSeries', 'WorkerMonitorSeries', 'CacheMonitorSeries',
           'ServerMonitorSeries', 'DataMonitorSeries', 'UserAggregateSeries']


class ServiceAggregateSeries(Module):
    model = ServiceAggregate
    schema = ServiceAggregateSchema
    option = Option(
        data_frame=True,
        filters={
            model.service: Filter('='),
            model.instance: Filter('='),
            model.endpoint: Filter('='),
            model.time: Filter('>=', '<='),
            model.layer: Filter('='),
            # 'type': Filter('=', field='task_settings.name', require=True),
            # queried result should in the same interval level
            'within_hours': Filter(query_exp=lambda v: exp.Q(
                time__gte=time_now() - timedelta(hours=v)), rule=int),
            'within_days': Filter(query_exp=lambda v: exp.Q(
                time__gte=time_now() - timedelta(days=v)), rule=int),
        },
        order_by=model.time,
        client_option=Option.Client(template=True, exclude=True, order=True, dataframe=True, key=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        )
    )

    @api.after(method.GET)
    def process(self):
        self.cache.expiry_time = self.query.get('interval')


class TaskAggregateSeries(Module):
    model = TaskAggregate
    schema = TaskAggregateSchema
    option = Option(
        data_frame=True,
        filters={
            model.service: Filter('='),
            model.instance: Filter('='),
            model.task: Filter('='),
            model.time: Filter('>=', '<='),
            model.layer: Filter('='),
            # 'type': Filter('=', field='task_settings.name', require=True),
            # queried result should in the same interval level
            'within': Filter(query_exp=lambda v: exp.Q(
                time__gte=time_now() - timedelta(hours=v)), rule=int),
        },
        order_by=model.time,
        client_option=Option.Client(template=True, exclude=True, order=True, dataframe=True, key=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        )
    )


class ServerMonitorSeries(Module):
    model = ServerMonitor
    schema = ServerMonitorSchema
    option = Option(
        data_frame=True,
        filters={
            model.server: Filter('=', require=True),
            model.time: Filter('>=', '<='),
            model.layer: Filter('='),
            # 'type': Filter('=', field='task.name', require=True),
            # queried result should in the same interval level
            'within': Filter(query_exp=lambda v: exp.Q(
                time__gte=time_now() - timedelta(hours=v)), rule=int),
        },
        client_option=Option.Client(template=True, exclude=True, order=True, dataframe=True, key=True),
        order_by=model.time
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        )
    )

    @classmethod
    def current(cls, inst_id: str = None) -> Optional[ServerMonitorSchema]:
        last = cls.filter(inst_id=inst_id or config.deploy.instance_id).last()
        if not last:
            return None
        return ServerMonitorSchema(**list(cls.filter(pk=last.pk).values())[0])


class DataMonitorSeries(Module):
    model = DataMonitor
    schema = DataMonitorSchema
    option = Option(
        data_frame=True,
        filters={
            'target': Filter('=', field='model.ident', require=True),
            model.time: Filter('>=', '<='),
            'within': Filter(query_exp=lambda v: exp.Q(
                time__gte=time_now() - timedelta(hours=v)), rule=int),
        },
        order_by=model.time,
        client_option=Option.Client(template=True, exclude=True, order=True, dataframe=True, key=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        )
    )


class InstanceMonitorSeries(Module):
    model = InstanceMonitor
    schema = InstanceMonitorSchema
    option = Option(
        data_frame=True,
        filters={
            'server': Filter('=', field='instance.server'),
            'task': Filter(assign=True, field='instance.task'),
            model.instance: Filter('=', require=True),
            model.time: Filter('>=', '<='),
            'within': Filter(query_exp=lambda v: exp.Q(
                time__gte=time_now() - timedelta(hours=v)), rule=int),
        },
        order_by=model.time,
        client_option=Option.Client(template=True, exclude=True, order=True, dataframe=True, key=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        )
    )


class ServiceInstanceMonitorSeries(InstanceMonitorSeries):
    model = ServiceInstanceMonitor
    schema = ServiceInstanceMonitorSchema
    option = Option(
        filters={
            'task': Filter(set_as=False, field='instance.task')
        }
    )


class WorkerMonitorSeries(Module):
    model = WorkerMonitor
    schema = WorkerMonitorSchema
    option = Option(
        data_frame=True,
        filters={
            model.time: Filter('>=', '<='),
            'within': Filter(query_exp=lambda v: exp.Q(
                time__gte=time_now() - timedelta(hours=v)), rule=int),
            'type': Filter(assign=True, field='worker.type'),
            model.worker: Filter('='),
            'server': Filter(field='worker.server'),
            'pid': Filter(field='worker.pid'),
        },
        order_by=model.time,
        client_option=Option.Client(template=True, exclude=True, order=True, dataframe=True, key=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        )
    )


class ServiceWorkerMonitorSeries(WorkerMonitorSeries):
    model = ServiceWorkerMonitor
    schema = ServiceWorkerMonitorSchema
    option = Option(
        filters={
            'type': Filter(set_as=WorkerType.service, field='worker.type')
        }
    )


class DatabaseMonitorSeries(Module):
    model = DatabaseMonitor
    schema = DatabaseMonitorSchema
    option = Option(
        data_frame=True,
        filters={
            model.time: Filter('>=', '<='),
            'within': Filter(query_exp=lambda v: exp.Q(
                time__gte=time_now() - timedelta(hours=v)), rule=int),
            model.database: Filter('='),
            'server': Filter(field='database.server'),
            'alias': Filter(field='database.alias'),
        },
        order_by=model.time,
        client_option=Option.Client(template=True, exclude=True, order=True, dataframe=True, key=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        )
    )


class CacheMonitorSeries(Module):
    model = CacheMonitor
    schema = CacheMonitorSchema
    option = Option(
        data_frame=True,
        filters={
            model.time: Filter('>=', '<='),
            'within': Filter(query_exp=lambda v: exp.Q(
                time__gte=time_now() - timedelta(hours=v)), rule=int),
            model.cache: Filter('='),
            'server': Filter(field='cache.server'),
            'alias': Filter(field='cache.alias'),
        },
        order_by=model.time,
        client_option=Option.Client(template=True, exclude=True, order=True, dataframe=True, key=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        )
    )


class UserAggregateSeries(Module):
    DAYS_RULE = Rule(type=int, ge=0, le=timedelta(seconds=config.ops.user_aggregate_maintain).days)

    model = UserAggregate
    schema = UserAggregateSchema
    option = Option(
        filters={
            model.layer: Filter('='),
            model.user_id: Filter('=', '^'),
            model.time: Filter('>=', '<='),
            model.service: Filter('='),
            model.active_time: Filter('>=', '<='),
            model.requests: Filter('>=', '<='),
            'history_days': Filter('=', rule=DAYS_RULE, custom=True),
            'date': Filter('=', '>=', '<=', field='time.date'),
            'within_days': Filter(query_exp=lambda v: exp.Q(
                time__gte=time_now() - timedelta(days=v)), rule=DAYS_RULE),
        },
        order_by=model.time,
        client_option=Option.Client(template=True, exclude=True, order=True, dataframe=True, key=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        )
    )

    @api.after(method.GET)
    def append_history(self, values: List[schema]):
        history = self.query.get('history_days')
        if history:
            users = [val.user_id for val in values]
            result = self.__class__(query={
                'user_id^': users,
                'within_days': history,
                '@dataframe': 1,
                '@key': 'user_id'
            })()
            for val in values:
                val.history = result.get(val.user_id)
        return values
