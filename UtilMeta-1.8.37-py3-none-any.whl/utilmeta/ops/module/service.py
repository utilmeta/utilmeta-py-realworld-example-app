from utilmeta.utils import *
from utilmeta.types import *
from ..schema.service import *
from ..models.service import *
from ..models.task import TaskWorker, TaskInstance

from utilmeta.util.common import Opt, WorkerType
from utilmeta.conf import config
from ..auth import valid

__all__ = ['ServerList', 'WorkerList', 'CacheList',
           'ServiceWorkerList', 'TaskWorkerList',
           'TaskInstanceMain', 'ServiceInstanceMain',
           'ServiceMain', 'InstanceMain', 'DatabaseMain']


class ServerList(Module):
    model = Server
    schema = ServerSchema
    option = Option(
        filters={
            model.ip: Filter('='),
            model.roles: Filter(Filter.contains),
            model.active: Filter('=')
        },
        base_filter=exp.Q(
            last_updated__isnull=False,
            hostname__isnull=False,
        )
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        ),
    )


class WorkerList(Module):
    model = Worker
    schema = WorkerSchema
    option = Option(
        client_option=Option.Client(order=True),
        order_by=model.pid,
        filters={
            model.server: Filter('='),
            'instance': Filter('=', field='server.instances'),
            model.pid: Filter('='),
            model.connected: Filter('='),
            model.type: Filter(assign=True)
        }
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        ),
    )


class ServiceWorkerList(WorkerList):
    model = ServiceWorker
    schema = ServiceWorkerSchema
    option = Option(
        filters={
            model.type: Filter(set_as=WorkerType.service),
            model.instance: Filter('=')
        }
    )

    @classmethod
    def workers(cls) -> List[schema]:
        return cls(
            queryset=cls.filter(instance_id=config.deploy.instance_id, connected=True)
        ).serialize()


class TaskWorkerList(WorkerList):
    model = TaskWorker
    schema = TaskWorkerSchema
    option = Option(
        filters={
            model.type: Filter(set_as=WorkerType.task),
            model.instance: Filter('=')
        }
    )

    @classmethod
    def workers(cls) -> List[schema]:
        return cls(
            queryset=cls.filter(instance_id=config.task.instance_id, connected=True)
        ).serialize()


class CacheList(Module):
    model = CacheStorage
    schema = CacheInstanceSchema
    option = Option(
        filters={
            model.connected: Filter('='),
            model.service: Filter('='),
            model.server: Filter('='),
            model.backend: Filter('='),
            model.type: Filter('='),
            model.alias: Filter('=')
        },
        order_by=('server.ip', model.port),
        client_option=Option.Client(template=True, exclude=True, order=True)
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.metrics_view)),
            Page(all=True)
        ),
    )

    @api.after(method.GET)
    def remove_pwd(self, values: List[schema]):
        for val in values:
            del val.password
        return values


class DatabaseConnectionMain(Module, register=True):
    model = DatabaseConnection
    schema = DatabaseConnectionSchema
    option = Option(
        filters={
            model.database: Filter('='),
            model.active: Filter('='),
            model.type: Filter('='),
            'table': Filter('=', field='tables.contains'),
            model.status: Filter('='),
            'server': Filter('=', field='database.server')
        },
    )
    method = Method(
        put=(Bulk(replace=True), Unit(public=False)),
        get=Auth(require=valid(Opt.metrics_view))
    )


class DatabaseMain(Module):
    model = DatabaseStorage
    schema = DatabaseSchema
    option = Option(
        filters={
            model.service: Filter('='),
            model.server: Filter('='),
            model.type: Filter('='),
            model.connected: Filter('='),
            model.backend: Filter('=')
        },
        client_option=Option.Client(template=True, exclude=True, order=True)
    )
    method = Method(
        get=Auth(require=valid(Opt.metrics_view)),
        put=(Bulk(), Unit(public=False))
    )


class InstanceMain(Module, register=True):
    model = BaseInstance
    schema = InstanceSchema
    option = Option(
        filters={
            model.service: Filter('='),
            model.server: Filter('='),
            model.task: Filter(assign=True)
        },
        client_option=Option.Client(template=True, exclude=True, order=True)
    )
    method = Method(
        get=Auth(require=valid(Opt.metrics_view)),
        put=(Bulk(replace=True), Unit(public=False))
    )


class ServiceInstanceMain(InstanceMain):
    model = ServiceInstance
    schema = ServiceInstanceSchema
    option = Option(
        filters={
            model.task: Filter(set_as=False),
        }
    )


class TaskInstanceMain(InstanceMain):
    model = TaskInstance
    schema = TaskInstanceSchema
    option = Option(
        filters={
            model.task: Filter(set_as=True)
        },
        split_many_relation_query=True
    )


class ServiceMain(Module):
    model = Service
    schema = ServiceSchema
    option = Option(
        filters={
            model.dependencies: Filter('='),     # dependencies=SRV find SRV 's backward dependencies
            'backward_dependencies': Filter('=')    # backward_dependencies=SRV find SRV 's dependencies
        },
        base_filter=exp.Q(action_token__isnull=False)
    )
    method = Method(
        get=Auth(require=valid()),
        put=(Bulk(), Unit(public=False))
    )
