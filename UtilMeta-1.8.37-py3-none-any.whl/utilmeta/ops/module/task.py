from utilmeta.utils import *
from ..schema.task import *
from ..models.task import *
from utilmeta.util.common import TaskType
from ..auth import Opt, valid

__all__ = ['TaskList', 'TaskFlow',
           'TaskDistributionList',
           'TaskEventList', 'TaskExecutionList', 'TaskJobList', 'TaskSettingsMain']


class TaskList(Module):
    model = BaseTask
    schema = BaseTaskSchema
    option = Option(
        filters={
            model.task_type: Filter('=', assign=True)
        }
    )
    method = Method(
        get=Auth(require=valid(Opt.task_view)),
        post=Auth(require=valid(Opt.task_add)),
    )


class NativeTaskList(TaskList):
    model = NativeTask
    schema = NativeTaskSchema
    option = Option(
        filters={
            model.task_type: Filter('=', set_as=TaskType.native)
        }
    )


class ScriptTaskList(TaskList):
    model = ScriptTask
    schema = ScriptTaskSchema
    option = Option(
        filters={
            model.task_type: Filter('=', set_as=TaskType.script)
        }
    )


class RequestTaskList(TaskList):
    model = RequestTask
    schema = RequestTaskSchema
    option = Option(
        filters={
            model.task_type: Filter('=', set_as=TaskType.request)
        }
    )


class TaskFlow(Module):
    model = TaskDependency
    schema = TaskDependencySchema
    option = Option(
        filters={
            model.name: Filter('='),
            model.target: Filter('='),
            model.source: Filter('='),
            model.invert: Filter('=')
        }
    )
    method = Method(
        get=Auth(require=valid(Opt.task_view)),
        post=Auth(require=valid(Opt.task_arrange)),
    )


class TaskSettingsMain(Module):
    model = TaskSettings
    schema = TaskSettingsSchema
    option = Option(
        filters={
            model.disabled: Filter('='),
            model.external: Filter('='),
            model.name: Filter('='),
            model.group: Filter('='),
        },
        split_many_relation_query=True,
        client_option=Option.Client(template=True, order=True),
        order_by=model.added_time
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.task_view)),
            Page(all=True)
        ),
        post=(
            Auth(require=valid(Opt.task_add)),
        ),
        patch=(
            Auth(require=valid(Opt.task_control)),
            Request.Body(model.disabled)
        )
    )


class TaskDistributionList(Module):
    model = TaskDistribution
    schema = TaskDistributionSchema
    option = Option(
        filters={
            model.status: Filter('=', '^'),
            model.task: Filter('='),
            'executions_num': Filter(field=exp.Count('executions'))
        },
        client_option=Option.Client(template=True, order=True),
        orders={
            'executions_num': Order(field=exp.Count('executions'))
        },
        order_by=model.init_time
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.task_view)),
            Page(default_page=1, default_rows=20)
        ),
        patch=(
            Auth(require=valid(Opt.task_control)),
            Request.Body(model.status)
        )
    )


class TaskEventList(Module):
    model = TaskEvent
    schema = TaskEventSchema
    option = Option(
        filters={
            model.exec_time: Filter('>=', '<='),
            model.event_id: Filter('>=', '<=', '='),
            model.task: Filter('='),
            'name': Filter('=', field='task.name'),
            model.status: Filter('=', '^'),
            model.volatile: Filter('='),
            model.external: Filter('='),
            model.disabled: Filter('='),
            'failed_jobs': Filter('=', '>', '<', field=exp.Sum('executions__failed_jobs')),
            'failed_executions': Filter('=', '>', '<', field=exp.Count(
                'executions', filter=exp.Q(executions__success=False))),
            'timeout_executions': Filter('=', '>', '<', field=exp.Count(
                'executions', filter=exp.Q(executions__timeout=True))),
            # 'failed': Filter('=', rule=bool, query_exp=lambda v: exp.Q(failed_jobs)),
            'executions_num': Filter('=', '>', '<', field=exp.Count('executions'))
        },
        client_option=Option.Client(template=True, order=True),
        orders={
            'executions_num': Order(field=exp.Count('executions')),
            'failed_jobs': Order(field=exp.Sum('executions__failed_jobs')),
        },
        post_query=True,
        logic_query=True,
        order_by='-exec_time'
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.task_view)),
            Page(default_page=1, default_rows=20)
        ),
        post=(
            Auth(require=valid(Opt.task_add)),
            Bulk()
        ),
        # delete=Auth(require=valid(Opt.task_control))
    )


class TaskExecutionList(Module):
    model = TaskExecution
    schema = TaskExecutionSchema
    option = Option(
        filters={
            model.exec_time: Filter('>=', '<='),
            model.dist: Filter('='),
            'task': Filter('=', field='dist.task'),
            'instance': Filter('=', field='dist.instance'),
            model.event: Filter('='),
        },
        client_option=Option.Client(template=True, order=True),
        order_by='-exec_time'
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.task_view)),
            Page(default_page=1, default_rows=20)
        ),
    )


class TaskJobList(Module):
    model = TaskJob
    schema = TaskJobSchema
    option = Option(
        filters={
            'exec_time': Filter('>=', '<=', field='execution.exec_time'),
            'task': Filter('=', field='execution.event.task'),
            'event': Filter('=', field='execution.event'),
            'pending': Filter(Filter.isnull, field=model.done_time, sole=True),
            'dist': Filter('=', field='execution.dist'),
            'instance': Filter('=', field='execution.dist.instance'),
            model.execution: Filter('='),
            model.success: Filter('='),
            model.timeout: Filter('='),
        },
        client_option=Option.Client(template=True, order=True),
        order_by='-exec_time'
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.task_view)),
            Page(default_page=1, default_rows=20)
        ),
    )
