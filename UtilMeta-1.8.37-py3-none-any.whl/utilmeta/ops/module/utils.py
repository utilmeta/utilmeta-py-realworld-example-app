from utilmeta.utils import *
from utilmeta.util.common import Opt, ResourceType
from ..auth import valid
from ..models.utils import *
from ..schema.utils import *
from utilmeta.conf import config

__all__ = ['ApplicationList', 'ResourceList', 'DataModelList', 'EndpointList']


class ApplicationList(Module):
    model = Application
    schema = ApplicationSchema
    option = Option(
        filters={
            model.service: Filter('='),
            model.label: Filter('=')
        },
    )
    method = Method(
        get=(
            Auth(require=valid(Opt.api_view)),
            Page(all=True)
        )
    )


class ResourceList(Module):
    model = Resource
    schema = ResourceSchema
    option = Option(
        filters={
            model.type: Filter('=', assign=True),
            'service': Filter('=', field='application.service'),
            'app_label': Filter('=', field='application.label')
        },
        base_filter=lambda: exp.Q(current_version__gte=config.version_id) if config.version_id else exp.Q(),
    )
    method = Method(
        get=Auth(login=True)
    )


class DataModelList(ResourceList):
    model = DataModel
    schema = DataModelSchema
    option = Option(
        filters={
            model.type: Filter('=', set_as=ResourceType.model)
        }
    )


class EndpointList(ResourceList):
    model = Endpoint
    schema = EndpointSchema
    option = Option(
        filters={
            model.type: Filter('=', set_as=ResourceType.api),
            'model_ident': Filter('=', field='model.ident'),
            model.depreciated: Filter(default=False),
            model.idempotent: Filter('='),
        },
        orders={
            'requests': Order(field=exp.Sum('distributions__requests')),
            'latest_requests': Order(field=exp.Sum('distributions__latest_requests')),
            'errors': Order(field=exp.Sum('distributions__errors')),
            'latest_errors': Order(field=exp.Sum('distributions__latest_errors')),
            'avg_time': Order(field=exp.Avg('distributions__avg_time')),
            'max_rps': Order(field=exp.Max('distributions__max_rps')),
            'uv': Order(field=exp.Max('distributions__latest_uv')),
            'ip': Order(field=exp.Max('distributions__latest_ip')),
        },
        client_option=Option.Client(template=True, order=True, exclude=True)
    )
    method = Method(
        get=Auth(require=valid(Opt.api_metrics_view))
    )
