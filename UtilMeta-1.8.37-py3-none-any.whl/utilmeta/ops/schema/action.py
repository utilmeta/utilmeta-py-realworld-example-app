from utilmeta.types import *
from utilmeta.utils import *
from utilmeta.util.common import constant, get_content_tag, retrieve_path, \
    ACTION_INFO, valid_url
from utilmeta.conf import config
from .admin import SupervisorAlterable
from .service import InstanceAlterable

__all__ = ['TokenSchema', 'InitHeartbeatSchema', 'AccessSchema', 'ScopeMemberSchema',
           'TokenMixin', 'AlertReportSchema', 'EventInformSchema',
           'ActionSchema', 'InitSchema', 'NodeInitSchema', 'OperationSchema', 'CommonHeartbeatSchema']


class AuthMixin(Schema):
    access_key: str
    secret_key: str


class InitMixin(Schema):
    proxy_id: str = None
    project_id: str


class ActionMixin(Schema):
    action_token: str


class TokenMixin(Schema):
    total_times: int = Rule(ge=1, default=1)
    left_times: int = Rule(ge=0, default=1)


class TokenBody(Schema):
    url: str = Rule(converter=retrieve_path)
    method: str = Rule(choices=constant.COMMON_METHODS)
    content_tag: str = ''
    sync_data: dict = None  # sync data (request body)


class AdminMixin(Schema):
    admin_id: str
    node_id: str        # need to sync with service (as supervisor id)


class TokenSchema(TokenBody, TokenMixin):
    def __validate__(self):
        path = self.url.split('?')[0]
        total_times = 1
        for _method, _path, _type in ACTION_INFO.values():
            if _method.upper() == self.method.upper() and path.endswith(_path):
                # sync operations have 2 total_times
                total_times = 2
        self.left_times = self.total_times = total_times

    @classmethod
    def from_request(cls, request: Request, sync: bool = False):
        schema = cls(
            url=request.full_path,
            method=request.method,
            content_tag=get_content_tag(request.body),
        )
        if sync:
            # schema.sync = True
            schema.sync_data = request.data
        return schema


class OperationSchema(TokenBody, TokenMixin, AdminMixin):
    # use TokenBody instead of TokenSchema to prevent left_times update during __validate__
    target_id: str = None
    __options__ = Schema.Options(excess_preserve=True)


class ScopeMemberSchema(Schema):
    remote_id: str
    operations: List[str]
    access_key: str
    secret_key: str
    root: bool


class InitSchema(TokenMixin, InitMixin, ActionMixin):
    node_id: str
    cluster_name: str = None
    service_name: str = None
    action_urls: Set[str] = set()
    members: List[ScopeMemberSchema] = []
    total_times: int = 2
    left_times: int = 2

    def __validate__(self):
        if not self.members:
            return
        root = None
        for member in self.members:
            if member.root:
                if root is None:
                    root = member
                else:
                    raise TypeError('More than 1 root in members')
        if root is None:
            raise TypeError(f'Must be 1 root in members')


class AccessSchema(OperationSchema, AuthMixin):
    pass


class ActionSchema(OperationSchema, ActionMixin):
    pass


class CommonHeartbeatSchema(Schema):
    class InstanceCommon(Schema, isolate=True):
        id: str
        service: str
        connected: bool
    disable: bool = False
    instances: List[InstanceCommon] = []


class InitHeartbeatSchema(Schema):
    __options__ = Schema.Options(excess_preserve=True)

    id: str             # supervisor-id (node-id)
    name: str           # service name
    ops_route: str = Rule(converter=lambda s: s.strip('/'))              # service ops_route
    proxy_url: Optional[str] = Rule(converter=lambda s: valid_url(s) if s else None)
    # if service is proxy, use proxy.base_url, otherwise None
    description: str
    action_url: str = Rule(converter=valid_url)
    instances: List[InstanceAlterable]
    utcoffset: int = config.time.value_utcoffset


class NodeInitSchema(InitSchema, SupervisorAlterable):
    pass


class AlertReportSchema(Schema):
    alert_id: int
    ident: str      # ident or settings.id use to category incidents
    type: str
    level: str
    category: str
    subcategory: str

    class impact(Schema):
        users: int = 0
        ips: int = 0
        requests: int = 0

    class target(Schema):
        name: Optional[str]
        instance_id: Optional[str]
        instance_ip: Optional[str]
        server_ip: Optional[str]

    message: str
    count: int
    data: dict
    time: datetime
    latest_time: datetime
    relieved_time: Optional[datetime] = None     # if this is a recover report, this is not None


class EventInformSchema(Schema):
    time: datetime
    type: str
    name: str
    message: str
    data: Optional[dict]
