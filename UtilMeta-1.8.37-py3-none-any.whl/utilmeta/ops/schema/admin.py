from datetime import datetime
from typing import List, Dict, Optional
from utilmeta.utils import *
from utilmeta.util.common import OPERATIONS, valid_url, time_now

__all__ = ['PermissionSchema', 'AdminSchema', 'AdminAlterable', 'ExternalMixinSchema',
           'SupervisorAlterable', 'SupervisorSchema', 'PermissionMixin', 'SessionSchema']


class SessionSchema(Schema):
    id: str
    ip: Optional[str]
    ua_string: str
    user_agent: Optional[dict]
    user_id: str

    setup_time: datetime
    expiry_time: Optional[datetime]
    delete_time: Optional[datetime]
    expiry_age: int
    last_activity: datetime


class PermissionSchema(Schema):
    admin_id: int = None
    resource_id: str
    operations: List[str]
    granted_by: int = None
    granted_time: datetime = Rule(default=time_now)


class PermissionMixin(Schema):
    permissions: Dict[str, Dict[str, List[str]]]

    @property
    def access_control_types(self):
        return list(self.permissions)

    def generate_permissions(self, granted_by=None) -> List[PermissionSchema]:
        from ..module.utils import ResourceList
        from django.db.models import Model
        granted_by = granted_by.pk if isinstance(granted_by, Model) else granted_by
        permissions = []
        for tp, values in self.permissions.items():
            id_map = {}
            for id, ident in ResourceList.filter(ident__in=list(values)).values_list('id', 'ident'):
                id_map[ident] = id
            for ident, ops in values.items():
                permissions.append(PermissionSchema(
                    # admin_id=admin_id,
                    resource_id=id_map[ident],
                    grant_by_id=granted_by,
                    operations=ops,
                ))
        return permissions


class AdminSchema(Schema):
    id: int
    root: bool
    operations: List[str] = Rule(choices=OPERATIONS, multiple=True)
    granted_by: int
    granted_time: datetime
    supervisor_id: str
    last_updated: datetime = Rule(default=time_now)
    permissions: List[PermissionSchema] = Field(relate_creation=True)


class AdminAlterable(PermissionMixin):
    operations: List[str] = Rule(choices=OPERATIONS, multiple=True, strict=False)


class SupervisorAlterable(Schema):
    name: str
    offline_enabled: bool
    backup_urls: List[str]
    action_url: str = Rule(converter=valid_url)
    operation_timeout: float
    open_operations: List[str]


class SupervisorSchema(SupervisorAlterable):
    id: str
    service: str
    setup_time: datetime
    last_heartbeat: datetime
    disabled: bool
    latency: int
    heartbeat_times: int
    info: dict


class ExternalMixinSchema(Schema):
    added_time: datetime
    added_by_id: Optional[int]
    last_disable: Optional[datetime]
    last_enable: Optional[datetime]
    external: bool
    disabled: bool
