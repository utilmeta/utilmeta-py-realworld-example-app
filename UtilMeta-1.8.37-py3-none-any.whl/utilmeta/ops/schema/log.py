from utilmeta.types import *
from utilmeta.utils import *

__all__ = ['AlertLogSchema', 'HttpLogSchema', 'LoggerMixin', 'BaseLogSchema',
           'AlertTypeSchema', 'AlertSettingsSchema', 'VersionLogSchema',
           'RequestLogSchema', 'ServiceLogSchema', 'QueryLogSchema',
           'CacheLogSchema', 'UserAgentSchema', 'RestartRecordSchema']


class LoggerMixin(Schema):
    queries_num: int
    queries_duration: int
    # db_queries: dict
    trace: List[dict]
    messages: List[str]


class QueryLogSchema(Schema):
    id: int
    time: datetime

    class database(Schema):
        alias: str
        name: str
        host: str = Field('server.ip')
        backend: str
        port: int

    query: str
    duration: int
    message: str
    worker_pid = Field('worker.pid')
    type: str
    tables: List[str]

    context_log_id: int
    context_job_id: int


class VersionMetaData(Schema):
    id: int
    instance_id: str

    version: str
    spec_version: str
    python_version: str
    utilmeta_version: str

    service_name: str = Field('instance.service')


class VersionLogSchema(VersionMetaData):
    id: int
    setup_time: datetime
    updates: dict
    info: dict
    major: int
    minor: int
    patch: int
    meta: str


class BaseLogSchema(Schema):
    id: int = Rule(require=False)
    runtime: bool
    level: str
    time: datetime
    duration: int
    worker_id: str
    thread_id: int
    review: str
    type: str
    alert_id: int
    version: VersionMetaData
    scheme: Optional[str]

    path: str
    in_traffic: int
    out_traffic: int
    public: bool


class AlertSettingsSchema(Schema):
    id: str
    name: str

    index_name: str
    index_class: str
    index_params: Optional[dict]
    index_aggregator: Optional[str]

    custom: bool
    threshold: float
    dynamic_thresholds: dict
    exceed: bool
    level: str

    server: str
    service: str
    instance: str

    disabled: bool
    external: bool


class AlertTypeSchema(Schema):
    id: str
    service: str
    category: str
    subcategory: str
    name: str
    level: str
    settings: AlertSettingsSchema

    target: str
    ident: str
    endpoint: Optional[str]
    task: Optional[str]
    data: dict

    alerts_num: int = exp.Sum('alert_logs__count')


class AlertLogSchema(Schema):
    id: int
    version: VersionMetaData

    category: str = Field('type.category')
    subcategory: str = Field('type.subcategory')
    name: str = Field('type.name')
    level: str = Field('type.level')

    instance: str
    service: str = Field('type.service')
    server: str
    server_ip: str = Field('server.ip')
    server_name: str = Field('server.hostname')
    instance_ip: str = Field('instance.server.ip')

    runtime: bool
    impact_requests: int
    impact_users: int
    impact_ips: int

    relieved_by_id: Optional[int]
    relieved_time: Optional[datetime]

    review: str
    trigger_times: List[datetime]
    trigger_values: List[float]
    time: datetime
    latest_time: datetime

    count: int

    latest_alarm_time: Optional[datetime]
    message: str
    data: Optional[dict]


class RestartRecordSchema(Schema):
    instance_id: str
    instance_ip: str = Field('instance.server.ip')

    time: datetime

    graceful_timeout: Optional[int]
    graceful_duration: Optional[int]

    unavailable: bool

    trigger_index: Optional[str]
    trigger_value: Optional[float]
    threshold: Optional[float]

    return_code: int
    manual: bool
    success: bool


class UserAgentSchema(Schema):
    browser: str
    os: str
    mobile: bool
    bot: bool
    device: str

    def __init__(self, browser: str, os: str, mobile: bool, bot: bool, device: str):
        super().__init__(locals())


class HttpLogSchema(Schema):
    id: int
    request_type: Optional[str]
    response_type: Optional[str]
    request_headers: dict
    response_headers: dict
    user_agent: Optional[UserAgentSchema]
    query: dict
    data: Optional[dict]
    result: Union[dict, list, str]
    status: int
    method: str
    length: int


class RequestLogSchema(Schema):
    id: int
    context_log: Optional[int]
    remote_log: Optional[int]
    block: bool
    timeout: Optional[int]
    timeout_error: bool
    to_service: Optional[str]
    to_instance: Optional[str]
    remote: dict = None


class ServiceLogSchema(LoggerMixin):
    id: int
    user_id: Optional[str]
    session_id: Optional[str]
    admin_id: Optional[str]
    from_service: Optional[str]
    from_instance: Optional[str]
    ip: str
    requests: List[dict] = None
    query_logs: List[QueryLogSchema]

    slow_queries_num: int = exp.Count('query_logs')
    endpoint_ref: Optional[str] = Field('endpoint.ref')
    endpoint_model: Optional[str] = Field('endpoint.model.ident')


class CacheLogSchema(Schema):
    time: datetime
    type: str
    error: str
    targets: List[dict]
    cache_id: str
    latest_time: datetime
    count: int
