from utilmeta.types import *
from utilmeta.utils import *

__all__ = ['ServiceAggregateSchema', 'TaskAggregateSchema', 'ReportSchema',
           'ServerMonitorSchema', 'DataMonitorSchema', 'JobMetricsMixin', 'TaskMetricsMixin',
           'DatabaseMetricsMixin', 'ServiceInstanceMonitorSchema',
           'ServiceWorkerMonitorSchema', 'InstanceMonitorSchema',
           'WorkerMonitorSchema', 'DatabaseMonitorSchema', 'CacheMonitorSchema',
           'RequestMetricsMixin', 'SystemMetricsMixin', 'UserAggregateSchema']


class DatabaseMetricsMixin(Schema):
    used_space: int
    server_used_space: int
    active_connections: int
    current_connections: int
    server_connections: int
    qps: float


class JobMetricsMixin(Schema):
    total_jobs: int
    failed_jobs: int
    timeout_jobs: int
    retried_jobs: int

    job_min_time: float
    job_avg_time: float
    job_max_time: float
    jobs_per_sec: float


class TaskMetricsMixin(JobMetricsMixin):
    executed_events: int
    abandoned_events: int

    executed_executions: int
    failed_executions: int
    timeout_executions: int

    avg_time: float


class RequestMetricsMixin(Schema):
    requests: int = None
    req_per_sec: float = None
    avg_time: float = None
    errors: int = None

    invokes: int = None
    timeout_invokes: int = None
    error_invokes: int = None
    avg_invoke_time: float = None
    invoke_per_sec: float = None

    in_traffic: int = None
    out_traffic: int = None


class SystemMetricsMixin(Schema):
    used_memory: float
    cpu_percent: float
    memory_percent: float
    disk_percent: float
    file_descriptors: int
    active_net_connections: int
    total_net_connections: int
    open_files: int

    def __init__(self, cpu_percent: float, used_memory: float,
                 memory_percent: float, disk_percent: float,
                 file_descriptors: int, active_net_connections: int,
                 total_net_connections: int, open_files: int, **kwargs):
        kwargs.update(locals())
        Schema.__init__(**kwargs)


class CommonAggregateMixin(Schema):
    mean_time: float
    p95_time: float
    p99_time: float
    p999_time: float
    time_stddev: Optional[float]


class ServiceAggregateSchema(CommonAggregateMixin, RequestMetricsMixin):
    alerts: int
    levels: dict
    service: Optional[str]
    instance_id: Optional[str]

    time: datetime
    layer: int
    avg_workers: float

    endpoint: Optional[str]
    max_rps: float
    max_rps_time: Optional[datetime]

    uv: int
    ip: int

    users: int
    new_users: int

    public_in_traffic: int
    public_out_traffic: int
    private_in_traffic: int
    private_out_traffic: int

    operations: int
    violates: int

    statuses: dict
    schemes: dict
    sources: dict
    targets: dict

    @classmethod
    def make_key(cls, key, item):
        return key + item

    @classmethod
    def get_cache(cls):
        return None


class TaskAggregateSchema(CommonAggregateMixin, TaskMetricsMixin):
    alerts: int
    service: Optional[str]
    instance_id: Optional[str]

    layer: int
    avg_workers: float
    task_id: str


class ServerMonitorSchema(SystemMetricsMixin):
    id: int
    time: datetime
    server_id: str

    load_avg_1: float
    load_avg_5: float
    load_avg_15: float
    load_index: float


class DataMonitorSchema(Schema):
    id: str
    time: datetime
    model_app: str = Field('model.application.label')
    model_name: str = Field('model.model_name')
    service: str
    count: int
    aggregates: dict
    relations: dict


class ReportSchema(Schema):
    time: datetime
    layer: int = 0
    seconds: int
    requests: int

    class alerts(Schema):
        WARNING: int = Rule(require=False)
        CRITICAL: int = Rule(require=False)
        DISASTER: int = Rule(require=False)

    class levels(Schema):
        DEBUG: int = Rule(require=False)
        INFO: int = Rule(require=False)
        WARN: int = Rule(require=False)
        ERROR: int = Rule(require=False)
        URGENT: int = Rule(require=False)

    os_dist: dict
    browser_dist: dict
    device_dist: dict

    statuses: Dict[Rule(ge=100, le=600), int]
    in_traffic: int
    out_traffic: int
    avg_time: float
    mean_time: float

    p95_time: float
    p99_time: float
    p999_time: float

    uv: int
    ip: int
    users: int
    new_users: int


class UserAggregateSchema(Schema):
    time: datetime
    layer: int
    user_id: str
    service: str

    in_traffic: int
    out_traffic: int
    requests: int
    avg_time: int
    mean_time: float
    p95_time: float
    p99_time: float
    p999_time: float
    time_stddev: float

    active_time: float
    endpoints: dict
    relations: dict
    violates: int

    levels: dict
    info: dict
    ips: List[str]
    agents: Optional[List[dict]]

    history: dict = None


class WorkerMonitorSchema(SystemMetricsMixin):
    time: datetime
    worker_id: str
    worker_pid: int = Field('worker.pid')
    threads: int


class ServiceWorkerMonitorSchema(WorkerMonitorSchema, RequestMetricsMixin):
    pass


class DatabaseMonitorSchema(DatabaseMetricsMixin):
    time: datetime
    queries_num: int


class CacheMonitorSchema(Schema):
    time: datetime
    used_memory: int
    current_connections: int
    total_connections: int
    qps: float


class InstanceMonitorSchema(SystemMetricsMixin):
    id: int
    time: datetime
    instance_id: str


class ServiceInstanceMonitorSchema(InstanceMonitorSchema, RequestMetricsMixin):
    pass
