from typing import List, Type, Set
from utilmeta.utils import *
from utilmeta.util.common import constant

__all__ = ['DataAccessSchema', 'OpsPostSchema']


class DataAccessSchema(Schema):
    from django.db.models import Model

    @staticmethod
    def get_model(val: str) -> Type[Model]:
        from django.apps.registry import apps
        app_label, model_name = val.split(':')
        return apps.get_model(app_label=app_label, model_name=model_name)

    method: str = Rule(choices=constant.COMMON_METHODS)
    model: Type[Model] = Rule(type=str, converter=get_model)
    id_list: list = None
    reduce: bool = True
    fields: list = []
    rows: int = Rule(ge=1, default=10)
    page: int = 1
    data: List[dict] = []
    query: dict = {}
    orders: List[str] = ['pk']
    exclude: bool = False

    def __validate__(self):
        from utilmeta.conf import config
        if self.data:
            self.data = config.preference.base_parser_cls.parse(
                data=self.data,
                template=[{
                    'pk': Rule(require=False),
                    **Field.gen_for(
                        self.model,
                        optional=self.method != constant.CommonMethod.POST
                    )
                }]
            )
        if self.method == constant.CommonMethod.GET:
            if not self.fields:
                self.fields = Field.all_fields(self.model)
            self.orders = Field.valid_order_bys(self.model, self.orders)


class OpsPostSchema(Schema):
    # heartbeat_url: str = Rule(converter=url_normalize)
    # retrieve_url: str = Rule(converter=url_normalize)
    name: str
    action_url: str

    def __init__(self, name: str, action_url: str):
        super().__init__(locals())

    def __validate__(self):
        from utilmeta.conf import config
        config.ops.valid_supervisor(self.action_url)
