from utilmeta.types import *
from utilmeta.utils import *
from utilmeta.util.common import LOCAL_IP, make_hash, convert_time, url_join, TaskStatus
from .metrics import RequestMetricsMixin, SystemMetricsMixin, DatabaseMetricsMixin

__all__ = ['ServerSchema', 'InstanceAlterable', 'InstanceSchema', 'TaskInstanceSchema', 'StatusSchema',
           'ServiceSchema', 'ServiceInstanceSchema', 'CacheStatus', 'ServerMetrics',
           'CacheInstanceSchema', 'DatabaseSchema', 'WorkerSchema', 'RegisterSchema',
           'CacheBaseSchema', 'DatabaseConnectionSchema', 'ServiceWorkerSchema', 'TaskWorkerSchema']


class ServerSchema(SystemMetricsMixin):
    id: str
    ip: str
    public_ip: str
    hostname: str

    domain: Optional[str]
    system: str
    platform: dict
    active: bool
    utcoffset: Optional[int]

    roles: List[str]
    ssh_port: int
    ssh_user: str
    ssh_password: str
    ssh_key_file: str

    setup_script: str

    cpu_num: int
    memory_total: int
    disk_total: int

    load_avg_1: float
    load_avg_5: float
    load_avg_15: float
    load_index: float
    devices: dict

    max_open_files: int
    max_socket_conn: int


class ServerMetrics(Schema):
    ip: str
    hostname: str
    system: str
    platform: dict
    utcoffset: int
    load_index: float
    cpu_num: int
    memory_total: int
    cpu_percent: float
    memory_percent: float
    max_open_files: int
    max_socket_conn: int


class StatusSchema(Schema):
    project: str = None
    service: str
    instance: str = None
    production: bool = False
    version: str
    setup_time: datetime
    timestamp: int
    server: Optional[ServerMetrics] = None
    metrics: Optional[RequestMetricsMixin] = None


class InstanceSchema(SystemMetricsMixin):
    id: str
    service: str
    server_id: str
    version: str
    version_id: int
    utilmeta_version: str
    # because new version of utilmeta will cause new useless migrates
    production: bool
    init_time: datetime = Rule(converter=convert_time)
    connected: bool
    last_heartbeat: datetime = Rule(converter=convert_time)
    weight: float
    options: dict
    master: bool = True
    wsgi: bool
    asgi: bool
    task: bool
    ip: str = Field('server.ip')
    server: ServerMetrics = Rule(require=False)
    last_restart: Optional[datetime] = None

    @classmethod
    def make_key(cls, key, item):
        from utilmeta.conf import config
        key_val = f'{config.cache_prefix}#INSTANCE#{key}-{item}'
        if config.cluster:
            return config.cluster.cache.construct_key(key_val, local_only=True)
        return key_val

    @classmethod
    def get_cache(cls):
        from utilmeta.conf import config
        if config.cluster:
            return config.cluster.cache
        return config.ops.cache

    def __hash__(self):
        return make_hash(self.id)

    def __eq__(self, other: 'CacheInstanceSchema'):
        if isinstance(other, self.__class__):
            return self.id == other.id
        return False


class InstanceAlterable(Schema):
    id: str
    service: str
    utilmeta_version: str = Rule(require=False)
    version: str = Rule(require=False)
    version_id: int = Rule(require=False)
    production: bool = Rule(require=False)
    weight: float = Rule(require=False)
    ip: str = Rule(require=False)
    connected: bool

    proxy_url: Optional[str] = None
    ops_route: str = None
    description: str = None
    document: dict = None
    utcoffset: int = None


class ServiceInstanceSchema(RequestMetricsMixin, InstanceSchema):
    time: datetime = Rule(null=True, default=None, converter=convert_time)
    base_url: str
    avg_window: float
    engine: str
    proxy_timeout: float
    max_retries: int

    def get_request_url(self):
        from utilmeta.conf import config
        from urllib.parse import urlparse
        from utilmeta.util.common import LOCAL_IP, localhost
        if self.ip == config.private_ip:
            if localhost(self.base_url):
                return self.base_url
            path = urlparse(self.base_url).path
            port = urlparse(self.base_url).port
            port_str = f':{port}' if port else ''
            return f'http://{LOCAL_IP}{port_str}{path}'
        return self.base_url

# class InstanceHeartbeatSchema(Schema):
#     metrics: RequestMetricsMixin
#     server: ServerMetrics


class TaskInstanceSchema(InstanceSchema):
    # config: dict
    main_cycle_interval: int
    worker_cycle_interval: int

    current_tasks: int = exp.Count('task_distributions')
    busy_tasks: int = exp.Count('task_distributions', filter=exp.Q(task_distributions__status=TaskStatus.busy))
    executed_events: int = exp.Sum('task_distributions__executed_events')
    executed_executions: int = exp.Count('task_distributions__executions')
    error_executions: int = exp.Count(
        'task_distributions__executions', filter=exp.Q(task_distributions__executions__success=False))
    timeout_executions: int = exp.Count(
        'task_distributions__executions', filter=exp.Q(task_distributions__executions__timeout=True))
    total_jobs: int = exp.Sum('task_distributions__executions__total_jobs')
    failed_jobs: int = exp.Sum('task_distributions__executions__failed_jobs')
    avg_time: float = exp.Avg('task_distributions__avg_time', filter=exp.Q(task_distributions__avg_time__gt=0))


class CacheStatus(Schema):
    pid: int = Rule(alias_from=['process_id'])
    used_memory: int = Rule(alias_from=['limit_maxbytes'])
    current_connections: int = Rule(alias_from=['connected_clients', 'curr_connections'])
    total_connections: int = Rule(alias_from=['total_connections_received'])
    qps: float = Rule(alias_from=['instantaneous_ops_per_sec'], default=None)


class UtilitySchema(Schema):
    id: str
    alias: str
    service: str
    server_id: str
    host: str = Field('server.ip')
    port: int
    type: str
    backend: str
    connected: bool
    init_version_id: Optional[int]
    current_version_id: Optional[int]
    info: dict


class StorageMixin(Schema):
    master_id: str
    password: Optional[str]
    clustered: bool
    partition_level: int
    # used_memory: int


class CacheBaseSchema(UtilitySchema, StorageMixin):
    expose: bool
    used_memory: int


class CacheInstanceSchema(CacheBaseSchema, CacheStatus):
    """
    Cache cluster configuration
    """
    max_qps: float
    max_qps_time: Optional[datetime]

    @property
    def id_hash(self) -> int:
        return make_hash(self.id)

    @property
    def loc(self) -> str:
        return f'{self.host}:{self.port}'

    @property
    def location(self) -> str:
        from utilmeta.conf import config, Cache
        host = LOCAL_IP if self.host in (LOCAL_IP, config.private_ip) else self.host
        loc = f'{host}:{self.port}'
        if self.backend == 'redis':
            return Cache.REDIS_TCP + loc
        return loc

    @property
    def alias_key(self):
        return f'{self.service}.{self.alias}'

    def __hash__(self):
        return self.id_hash

    def __eq__(self, other: 'CacheInstanceSchema'):
        if not isinstance(other, CacheInstanceSchema):
            return False
        return self.id == other.id


class DatabaseConnectionSchema(Schema):
    id: str = Rule(require=False)
    database_id: str = None
    # remote_id: str = None
    status: str
    active: bool
    client_addr: str
    client_port: str
    pid: int
    # in postgresql pid is listed
    query: str
    type: str
    tables: List[str]
    backend_start: Optional[datetime]
    query_start: Optional[datetime]
    state_change: Optional[datetime]
    info: dict = Rule(require=False)


class DatabaseSchema(UtilitySchema, StorageMixin, DatabaseMetricsMixin):
    name: str
    user: str
    max_qps: float
    max_qps_time: Optional[datetime]
    server_connections_limit: int
    connections: List[DatabaseConnectionSchema] = Field(module='DatabaseConnectionMain', readonly=False)


class ServiceSchema(Schema):
    name: str
    action_token: str
    ops_route: str
    proxy: bool
    instances: List[Union[ServiceInstanceSchema, TaskInstanceSchema]]\
        = Field(module='InstanceMain', relate_creation=True, readonly=False)
    expose: bool
    root_routes: List[str]
    single_endpoint: bool
    dependencies: List[str] = Field(readonly=True, default=list)
    backwards: List[str] = Field(readonly=True, default=list)
    relates: List[dict] = None      # used by upper layer


class WorkerSchema(SystemMetricsMixin):
    id: str
    pid: int
    memory_info: dict = Rule(require=False)
    start_time: datetime
    threads: int
    info: dict
    server_id: Optional[str]
    utility_id: Optional[str]
    type: str
    master: Optional[str]

    status: str
    user: str

    @property
    def rss_memory(self):
        return self.memory_info.get('rss')

    @property
    def vms_memory(self):
        return self.memory_info.get('vms')

    @property
    def pss_memory(self):
        return self.memory_info.get('pss')


class ServiceWorkerSchema(WorkerSchema, RequestMetricsMixin):
    time: datetime = Rule(null=True, default=None, converter=convert_time)
    instance_id: str


class TaskWorkerSchema(WorkerSchema):
    instance_id: str
    current_tasks: int = exp.Count('task_distributions')
    executed_executions: int = exp.Count('executions')


class RegisterSchema(Schema):
    __options__ = Schema.Options(excess_preserve=True)

    version: str
    version_id: int
    production: bool
    utilmeta_version: str
    base_url: str = None
    proxy_timeout: int
    max_retries: int
    options: dict

    description: str
    ops_route: str
    document: dict

    service_relates: Dict[str, List[dict]]
    dependencies: List[str]
    expose_caches: List[CacheBaseSchema]

    expose: bool
    single_endpoint: bool
    root_routes: List[str]

    server: ServerMetrics
    metrics: RequestMetricsMixin

    @property
    def ops_api(self):
        return url_join(self.base_url, self.ops_route)
