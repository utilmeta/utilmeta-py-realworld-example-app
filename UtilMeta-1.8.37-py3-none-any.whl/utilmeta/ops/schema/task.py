from utilmeta.types import *
from utilmeta.utils import *
from utilmeta.util.common import EventStatus
from .utils import ResourceSchema
from .log import QueryLogSchema, LoggerMixin
from .metrics import JobMetricsMixin, TaskMetricsMixin
from .admin import ExternalMixinSchema

__all__ = ['BaseTaskSchema', 'ScriptTaskSchema', 'NativeTaskSchema',
           'RequestTaskSchema', 'TaskDependencySchema',
           'TaskExecutionSchema', 'TaskJobSchema',
           'TaskDistributionSchema', 'TaskEventSchema', 'TaskSettingsSchema']


class BaseTaskSchema(ResourceSchema):
    type: str
    priority: int


class NativeTaskSchema(BaseTaskSchema):
    model_id: str
    module_path: str
    iterable: bool
    exec_params: dict
    init_params: dict


class ScriptTaskSchema(BaseTaskSchema):
    language: str
    executable: str
    environment: dict
    chdir: str
    script: str
    args: List[str]

    added_time: datetime
    added_by_id: str


class RequestTaskSchema(BaseTaskSchema):
    method: str
    scheme: str
    hosts: List[str]
    urls: List[str]
    max_retries: int

    path: str
    query: dict

    headers: dict
    data = None
    timeout: float
    success_format: dict

    added_time: datetime
    added_by_id: str


class TaskDependencySchema(ExternalMixinSchema):
    id: str
    target_id: str
    source_id: str
    name: str
    condition: str
    params: dict
    invert: bool


class TaskDistributionSchema(TaskMetricsMixin):
    """
    Track the execution in distribution of tasks
    """
    id: str
    task_id: str
    instance_id: str
    instance_ip: str = Field('instance.server.ip')
    instance_hostname: str = Field('instance.server.hostname')
    instance_connected: bool = Field('instance.connected')
    init_time: datetime

    # realtime updates
    worker_pid: int = Field('worker.pid')
    worker_connected: bool = Field('worker.connected')
    # worker == None stand for not assigned
    status: str
    current_event_id: int
    current_event_time: Optional[datetime] = Field('current_event.exec_time')

    latest_total_jobs: int
    latest_failed_jobs: int
    latest_timeout_jobs: int
    latest_retried_jobs: int

    latest_job_min_time: float
    latest_job_avg_time: float
    latest_job_max_time: float
    latest_jobs_per_sec: float  # concurrency

    latest_executed_events: int
    latest_abandoned_events: int
    latest_executed_executions: int
    latest_failed_executions: int
    latest_timeout_executions: int
    latest_avg_time: float

    latest_mean_time: float  # 50%
    latest_p95_time: float  # 95%
    latest_p99_time: float  # 99%
    latest_p999_time: float  # 99.9%
    latest_time_stddev: float
    

class TaskSettingsSchema(ExternalMixinSchema):
    """
    TaskInstance can be altered from admin platform
    """
    id: str
    name: str
    group: str
    base: BaseTaskSchema
    distributions: List[TaskDistributionSchema]

    query: dict

    schedule: Optional[dict]
    interval: Optional[float]
    looped: bool

    # time configs
    max_times: Optional[datetime]
    start_time: Optional[datetime]
    stop_time: Optional[datetime]

    abandoned_events_num: int = exp.Count('events', filter=exp.Q(events__status=EventStatus.abandoned))
    failed_jobs_num: int = exp.Sum('events__executions__failed_jobs')
    failed_executions_num: int = exp.Count('events__executions', filter=exp.Q(events__executions__success=False))

    # dist settings
    dist_by_param: bool
    dist_by_event: bool
    # chunk_size: int

    disabled: bool
    external: bool

    # other kwargs settings
    settings: dict

    params: dict


class ExecMixin(Schema):
    id: int
    exec_time: Optional[datetime]
    done_time: Optional[datetime]
    timeout_time: Optional[datetime]
    timeout: bool
    success: bool
    message: str


class TaskExecutionSchema(ExecMixin, JobMetricsMixin):
    dist_id: str
    worker_pid: int = Field('worker.pid')
    instance_ip: str = Field('dist.instance.server.ip')
    instance_hostname: str = Field('dist.instance.server.hostname')
    event_id: int
    event_time: datetime = Field('event.exec_time')
    # worker_pid = Field('dist.worker.pid')
    
    avg_job_retries: float
    job_mean_time: float
    job_p95_time: float
    job_p99_time: float
    job_p999_time: float
    job_time_stddev: float
    
    @property
    def delta(self):
        if self.event_time and self.exec_time:
            return (self.exec_time - self.event_time).total_seconds()
        return None

    @property
    def duration(self):
        if self.exec_time and self.done_time:
            return (self.done_time - self.exec_time).total_seconds()
        return None


class TaskEventSchema(ExternalMixinSchema):
    """
    Realtime task events. only error ones stay, other is deleted when finished
    This is also a queue
    """
    id: int
    task_id: str
    exec_time: datetime
    event_id: int
    status: str
    volatile: bool
    executions: List[TaskExecutionSchema]

    @property
    def pending_executions_num(self):
        n = 0
        for exe in self.executions:
            if not exe.done_time:
                n += 1
        return n

    @property
    def timeout_executions_num(self):
        n = 0
        for exe in self.executions:
            if exe.timeout:
                n += 1
        return n

    @property
    def error_executions_num(self):
        n = 0
        for exe in self.executions:
            if not exe.success:
                n += 1
        return n


class TaskJobSchema(ExecMixin, LoggerMixin):
    execution_id: int
    thread_id: int
    args: list
    kwargs: dict
    local_retries: int
    retry_for_id: int

    query_logs: List[QueryLogSchema]
