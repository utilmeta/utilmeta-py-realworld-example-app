from utilmeta.utils import *
from utilmeta.types import *

__all__ = ['ModelSchema', 'ApplicationSchema',
           'ResourceSchema', 'DataModelSchema', 'EndpointSchema']


class ModelField(Schema):
    type: str
    category: str
    primary_key: bool = False
    foreign_key: bool = False
    readonly: bool = False
    unique: bool = False
    null: bool = False
    index: bool = False
    require: bool = True
    choices: list = None       # value enum, useful for domain knowledge

    # only for fk
    to_model: str = None
    to_field: str = None
    relate_name: str = None


class ManyRelationSchema(Schema):
    to_model: str
    relate_name: str        # reverse relate (if relation is a ManyToOneRel, relate name is the reverse ForeignKey)
    symmetrical: bool = None
    through_model: str = None
    through_table: str
    through_fields: Tuple[str, str] = None


class ModelSchema(Schema):
    name: str
    base: Optional[str]  # <app_label>.<model_name> for base model
    table: str
    role: Optional[str]
    fields: Dict[str, ModelField]
    relations: Dict[str, ManyRelationSchema]
    # many to relations <many-relationship-name>


class ApplicationSchema(Schema):
    id: str
    label: str
    path: str
    name: str
    service: str


class ResourceSchema(Schema):
    id: str
    service: str = Field('application.service')
    init_version_id: Optional[int]
    current_version_id: Optional[int]
    info: dict
    type: str
    ref: str
    application_id: str
    document: str


class EndpointDistributionSchema(Schema):
    id: str
    time: datetime

    endpoint_id: str
    instance_id: str
    instance_ip: str = Field('instance.server.ip')

    requests: int
    errors: int

    avg_time: float
    max_rps: float
    max_rps_time: Optional[datetime]

    latest_requests: int
    latest_errors: int
    latest_rps: float
    latest_avg_time: float

    latest_uv: int
    latest_ip: int

    latest_mean_time: float
    latest_p95_time: float
    latest_p99_time: float
    latest_p999_time: float
    latest_time_stddev: Optional[float]

    levels: dict
    statuses: dict
    latest_levels: dict
    latest_statuses: dict

    alerts: int
    latest_alerts: int

    latest_in_traffic: int
    latest_out_traffic: int


class EndpointSchema(ResourceSchema):
    method: str
    path: str
    idempotent: bool
    depreciated: bool
    model_ident: str = Field('model.ident')
    distributions: List[EndpointDistributionSchema]


class DataModelSchema(ResourceSchema):
    app_label: str
    model_name: str
    db_table: str
    base_id: Optional[str]
