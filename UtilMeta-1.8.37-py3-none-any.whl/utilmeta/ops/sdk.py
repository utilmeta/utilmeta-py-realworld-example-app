from utilmeta.core.sdk import BaseResponse, DocumentSchema
from utilmeta.util.common import url_join, MetaHeader, TokenType, ignore_errors, utc_ms_ts
from utilmeta.utils import *
from utilmeta.types import *
from .models.admin import Supervisor
from .schema.service import ServiceSchema, CacheBaseSchema, StatusSchema, \
    InstanceAlterable, RegisterSchema
from .schema.log import ServiceLogSchema
from .schema.action import TokenMixin, TokenSchema, InitSchema, EventInformSchema, \
    NodeInitSchema, InitHeartbeatSchema, CommonHeartbeatSchema, AlertReportSchema
from .schema.metrics import ReportSchema

from utilmeta.conf import config
from utilmeta import __version__

manager = config.cluster_manager

__all__ = ['ClusterSDK', 'ActionSDK']


class ClusterSDK(SDK):
    response = Response(
        result_data_key='result',
        action_state_key='state',
        error_message_key='msg'
    )

    def __init__(self, base_url: str = None, service: str = None, raise_error: bool = False,
                 action_token: str = None, append_headers: dict = None,
                 timeout: float = None,
                 max_retries: int = None,
                 retry_interval: Union[int, timedelta] = None,
                 prepend_route: str = None, proxy: bool = False, token_required: bool = False):
        headers = {
            MetaHeader.SERVICE_NAME: config.name,
            MetaHeader.INSTANCE: config.deploy.instance_id,
        }

        if not action_token:
            if proxy:
                action_token = manager.get_proxy_action_token()
                base_url = config.ops_api if config.is_proxy else config.cluster.proxy_service.ops_api
            elif service:
                action_token = manager.get_action_token(service)

        if action_token:
            headers[MetaHeader.ACTION_TOKEN] = action_token
        elif token_required:
            raise ValueError(f'Action token required, no available service instances')

        if isinstance(append_headers, dict):
            headers.update(append_headers)
        # when super template initialize, it will
        super().__init__(
            base_url=base_url, service=service, timeout=timeout,
            max_retries=max_retries, retry_interval=retry_interval,
            base_headers=headers, prepend_route=prepend_route, raise_error=raise_error
        )

    class RegisterResponse(BaseResponse):
        class result(Schema):
            action_token: str
            services: List[ServiceSchema]
            expose_caches: List[CacheBaseSchema]

    class HeartbeatResponse(BaseResponse):
        class result(Schema):
            instance: str
            services: Optional[List[ServiceSchema]]

    class QueryKeysResponse(BaseResponse):
        result: List[str]

    class QuerySchemaResponse(BaseResponse):
        result: List[dict]

    class TracingResponse(BaseResponse):
        result: ServiceLogSchema

    class DocumentResponse(BaseResponse):
        result: Dict[str, DocumentSchema]

    class DeletionData(Schema):
        def __init__(self, model: str, pk_list: list):
            super().__init__(locals())

    class CacheData(Schema):
        def __init__(self, key: str, type: str, value=None, kwargs: dict = None, delete: bool = False):
            super().__init__(locals())

    class QueryData(Schema):
        def __init__(self, pk_list: List[str], schema: dict = None):
            super().__init__(locals())

    class TracingQuery(Schema):
        def __init__(self, origin_id: int):
            super().__init__(locals())

    class DocQuery(Schema):
        def __init__(self, scope: Set[str] = None):
            super().__init__(locals())

    class ConfirmData(Schema):
        node_id: str
        proxy_id: str = None
        disable: bool = False
        init_data: Optional[InitHeartbeatSchema] = None

        def __init__(self, node_id: str, proxy_id: str = None, disable: bool = False,
                     init_data: Optional[InitHeartbeatSchema] = None):
            super().__init__(locals())

        def __validate__(self):
            if not self.disable and not self.init_data:
                raise ValueError(f'Init data must provide to enable supervisor')

    class StatusResponse(BaseResponse):
        result: StatusSchema

        def valid(self, service: str = None):
            if not self.success or self.status != 200:
                return False
            from utilmeta.conf import config
            service = service or config.name
            if service != self.result.service:
                return False
            ts = utc_ms_ts()
            if abs((ts - self.result.timestamp) / 1000) > config.deploy.check_deployed_timeout:
                return False
            return True

    @api.get(idempotent=True, route='', log=False)
    def status(self) -> StatusResponse:
        pass

    @api.get(idempotent=True, route='cluster/data/keys', log=True)
    def query_keys(self, query: dict = Request.Query) -> QueryKeysResponse:
        pass

    @api.post(idempotent=True, route='cluster/data/query', log=True)
    def query_schema(self, data: QueryData = Request.Body) -> QuerySchemaResponse:
        pass

    @api.post(idempotent=True, route='cluster/cache', log=True)
    def broadcast_cache(self, data: CacheData = Request.Body) -> BaseResponse:
        pass

    @api.post(idempotent=True, route='cluster/down', log=True)
    def broadcast_down(self) -> BaseResponse:
        pass

    @api.post(idempotent=True, route='cluster/data/deletion', log=True)
    def deletion(self, data: DeletionData = Request.Body) -> BaseResponse:
        pass

    @api.put(idempotent=True, route='cluster/backward', log=True)
    def update_backward(self, data: ServiceSchema = Request.Body) -> BaseResponse:
        pass

    @api.get(route='cluster/confirm', log=True)
    def confirm(self) -> BaseResponse:
        pass

    @api.get(route='cluster/documents', log=False)
    def documents(self, query: DocQuery = Request.Query) -> DocumentResponse:
        pass

    # @api.post(idempotent=True, route='cluster/heartbeat', log=False)
    # def heartbeat(self, data: InstanceHeartbeatSchema = Request.Body) -> HeartbeatResponse:
    #     pass

    @api.post(route='cluster/report', log=False)
    def report(self, data: ReportSchema = Request.Body) -> BaseResponse:
        pass

    @api.post(route='supervisor', log=True)
    def register_supervisor(self, data: NodeInitSchema = Request.Body) -> BaseResponse:
        pass

    @api.post(route='supervisor/confirm', log=True)
    def confirm_supervisor(self, data: ConfirmData = Request.Body) -> BaseResponse:
        pass

    @api.post(idempotent=True, route='supervisor/disabled')
    def disable_supervisor(self, id: str) -> BaseResponse:
        pass

    @api.delete(idempotent=True, route='supervisor')
    def delete_supervisor(self, id: str) -> BaseResponse:
        pass

    @api.get(route='log/tracing', log=True)
    def tracing(self, query: TracingQuery = Request.Query) -> TracingResponse:
        pass

    @api.post
    @ignore_errors(log_detail=True)
    def register_node(self, sid: str):
        from .module.admin import SupervisorMain
        from .models.admin import Supervisor
        supervisor = Supervisor.get(sid, disabled=None)
        if not supervisor:
            print('Supervisor not exists')
            return
        if SupervisorMain.filter(
            service=self._service,
            action_url=supervisor.action_url,
            disabled=False
        ).exists():
            print('Supervisor already exists')
            return
        SupervisorMain.filter(
            service=self._service,
            action_url=supervisor.action_url,
            disabled=True
        ).delete()
        # if a already exists not enabled supervisor exists, delete

        init_resp = ActionSDK(
            to=supervisor,
            token_type=TokenType.init
        ).token(name=self._service, data=None)
        if not init_resp.success:
            # supervisor is isolated from each other, if one supervisor is down, just ignore
            print(f'generate init token failed ({init_resp.status}) failed with error: {init_resp.message}')
            return
        token = init_resp.result
        resp = ActionSDK(
            to=supervisor, ops_token=token,
            token_type=TokenType.init, retrieve=True
        ).retrieve()
        if not resp.success:
            # supervisor is isolated from each other, if one supervisor is down, just ignore
            print(f'retrieve init token failed ({resp.status}) failed with error: {resp.message}')
            return

        data = ActionSDK.InitResponse(resp).result
        supervisor_data = dict(
            name=supervisor.name,
            action_url=supervisor.action_url,
            backup_urls=supervisor.backup_urls,
            offline_enabled=supervisor.offline_enabled,
            operation_timeout=supervisor.operation_timeout,
            open_operations=supervisor.open_operations
        )
        # with transaction.atomic(using=config.ops.db_alias):
        # this context is usually under transaction
        # redundant transaction often cause dead lock of threads, use manual
        Supervisor.objects.create(
            id=data.node_id,
            service_id=self._service,
            action_token=data.action_token,
            **supervisor_data,
            disabled=True  # create disabled supervisor first for confirm
        )
        self._base_headers[MetaHeader.OPERATION] = token
        resp = self.register_supervisor(data=NodeInitSchema(
            **data,
            **supervisor_data
        ))
        if not resp.success:
            raise resp.error

    @api.post
    def register_instance(self, confirm_token: str) -> RegisterResponse:
        from .models.service import ServiceInstance, Server
        if not config.cluster.proxy_service:
            raise ValueError(f'Cluster proxy required')
        inst = ServiceInstance.current()
        if not inst:
            raise ValueError(f'Service setup required')
        server = Server.current()

        return Call(url=url_join(config.cluster.proxy_service.ops_api, 'cluster'),
                    logger=self._logger, data=RegisterSchema(
            base_url=config.base_url,
            ops_route=config.ops.route,
            document=inst.document,
            expose=config.cluster.expose,
            single_endpoint=config.cluster.single_endpoint,
            root_routes=inst.service.root_routes,
            service_relates=config.cluster.cross_service_relates,
            description=config.description,
            dependencies=list(config.cluster.internals),
            proxy_timeout=inst.proxy_timeout,
            max_retries=inst.max_retries,
            options=inst.options,
            metrics=inst.data,
            server=server.data if server else None,
            expose_caches=self.get_expose_caches(),
            **self.get_instance_data(),
        ), timeout=config.cluster.default_timeout, headers={
            MetaHeader.INVOKE_TOKEN: config.cluster.proxy_service.invoke_token,
            MetaHeader.CONFIRM_TOKEN: confirm_token,
            **self._base_headers
        }).post()

    @classmethod
    def get_expose_caches(cls):
        from .module.service import CacheList
        return CacheList(queryset=CacheList.filter(service_id=config.name, expose=True)).serialize()

    @classmethod
    def get_instance_data(cls):
        return dict(
            load_index=config.monitor.load_index,
            version=str(config.version),
            version_id=config.version_id,
            production=config.production,
            utilmeta_version=__version__,
        )


class ActionSDK(SDK):
    response = Response(
        result_data_key='result',
        action_state_key='state',
        error_message_key='msg'
    )

    def __init__(self, action_url: str = None, ops_token: str = None, headers: dict = None,
                 to: Union[Supervisor, str] = None, retrieve: bool = False,
                 token_type: str = None, init_callback=None):
        headers = headers or {}
        query = {}
        timeout = config.ops.supervisor_timeout
        if ops_token:
            headers[MetaHeader.OPERATION] = ops_token
        if to:
            if not isinstance(to, Supervisor):
                to = Supervisor.get(id=str(to))
            action_url = to.action_url
            timeout = to.operation_timeout
            headers.update({
                MetaHeader.SUPERVISE_TOKEN: to.action_token,
                MetaHeader.NODE: to.pk
            })
        append_route = None
        if token_type:
            if retrieve:
                query.update(type=token_type)
            else:
                append_route = token_type
        # when super template initialize, it will
        super().__init__(
            base_url=action_url,
            base_query=query,
            base_headers=headers,
            timeout=timeout,
            append_route=append_route,
            max_retries=config.ops.supervisor_max_retries
        )
        if callable(init_callback):
            init_callback()

    class InitResponse(BaseResponse):
        result: InitSchema

    class HeartbeatResponse(BaseResponse):
        class result(Schema):
            id: str

    class PingResponse(BaseResponse):
        class result(Schema):
            timestamp: int

    class TokenDataResponse(BaseResponse):
        class result(TokenMixin):
            __options__ = Schema.Options(excess_preserve=True)

    @api.get(route='')
    def ping(self) -> PingResponse:
        pass

    @api.post(log=True)
    def token(self, name: str = None, data: Optional[TokenSchema] = Request.Body) -> BaseResponse:
        pass

    @api.post(log=True)
    def proxy(self, query: dict = Request.Query, data: dict = Request.Body):
        pass

    @api.get(route='token', idempotent=False)
    def retrieve(self) -> TokenDataResponse:
        pass

    @api.post
    def report(self, data: ReportSchema = Request.Body) -> BaseResponse:
        pass

    @api.post
    def alert(self, data: AlertReportSchema = Request.Body) -> BaseResponse:
        pass

    @api.post
    def inform(self, data: EventInformSchema = Request.Body) -> BaseResponse:
        pass

    @api.post(idempotent=True)
    def alter_inst(self, instances: List[InstanceAlterable] = Request.Body) -> BaseResponse:
        pass

    @api.post(idempotent=True)
    def heartbeat(self, data: CommonHeartbeatSchema = Request.Body) -> HeartbeatResponse:
        pass

    @api.post(log=True)
    def add_node(self, data: dict = Request.Body) -> HeartbeatResponse:
        pass

    @api.post(log=True)
    def add_admin(self) -> BaseResponse:
        pass

    @api.post(log=True)
    def alter_node(self) -> BaseResponse:
        pass

    @api.post(log=True)
    def alter_admin(self) -> BaseResponse:
        pass

    @api.post(log=True)
    def renew_node(self) -> BaseResponse:
        pass

    @api.post(log=True)
    def renew_admin(self) -> BaseResponse:
        pass

    @api.post(log=True)
    def delete_node(self) -> BaseResponse:
        pass

    @api.post(log=True)
    def delete_admin(self) -> BaseResponse:
        pass
