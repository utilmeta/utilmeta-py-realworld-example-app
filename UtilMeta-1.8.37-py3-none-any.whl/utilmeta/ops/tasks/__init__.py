from .aggregate import *
from .heartbeat import *
from .monitor import *
from .health import *

_TASK_LOADED = False


def load_tasks():
    from datetime import timedelta
    from utilmeta.core.task import Task
    from utilmeta.conf import config
    dist = bool(config.cluster)

    global _TASK_LOADED
    if _TASK_LOADED:
        return

    config.task.add(InstanceHealthCheckTask(
        task=False,
        name='instance_health_check', group='ops',
        interval=config.ops.health_check_interval,
        event_abandon_window=config.task.min_interval
    ), ClusterHealthCheckTask(
        name='cluster_health_check', group='ops',
        interval=config.ops.health_check_interval,
        dist_by_event=dist,
        event_abandon_window=config.task.min_interval,
        # max_concurrent_jobs=config.ops.task_max_concurrent_jobs,
    ), ClearTask(
        name='clear', group='ops',
        interval=config.ops.clear_interval,
        dist_by_event=dist,
        event_abandon_window=config.task.min_interval
    ))

    if config.is_proxy:
        config.task.add(HeartbeatTask(
            name='heartbeat', group='ops',
            interval=config.ops.heartbeat_interval,
            dist_by_event=dist,
            event_abandon_window=config.task.min_interval
        ))

    if config.monitor:
        config.task.add(LogAggregateTask(
            dist_by_event=dist,
            name='service_aggregate', group='ops',
            schedule=Task.Schedule(minute=0),
            max_concurrent_jobs=config.ops.task_max_concurrent_jobs,
        ), JobAggregateTask(
            name='task_aggregate', group='ops',
            dist_by_event=dist,
            schedule=Task.Schedule(minute=0),
            max_concurrent_jobs=config.ops.task_max_concurrent_jobs,
        ))
        if config.monitor.server_monitor_interval:
            config.task.add(ServerMonitorTask(
                'server_monitor', group='ops',
                interval=config.monitor.server_monitor_interval,
            ))
        if config.monitor.db_monitor_interval:
            config.task.add(DatabaseMonitorTask(
                'database_monitor', group='ops',
                dist_by_event=dist,
                interval=config.monitor.db_monitor_interval,
            ))
        if config.monitor.cache_monitor_interval:
            config.task.add(CacheMonitorTask(
                'cache_monitor', group='ops',
                dist_by_event=dist,
                interval=config.monitor.cache_monitor_interval,
            ))

        if config.auth.enabled:
            config.task.add(UserAggregateTask(
                name='user_aggregate', group='ops',
                dist_by_event=dist,
                layer_interval=timedelta(days=1),
                schedule=Task.Schedule(minute=0, hour=0),
                max_concurrent_jobs=config.ops.task_max_concurrent_jobs,
                # concurrent_jobs=False,
            ))

        if config.auth.last_activity_field or config.session and config.session.use_db:
            config.task.add(SessionTask(
                name='last_activity_update', group='ops',
                dist_by_event=dist,
                interval=config.ops.last_activity_update_interval
            ))

    _TASK_LOADED = True
