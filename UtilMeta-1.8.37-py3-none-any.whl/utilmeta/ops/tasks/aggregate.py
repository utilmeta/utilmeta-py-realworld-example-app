from utilmeta.utils import Task
from utilmeta.ops.models.log import BaseLog, RequestLog, \
    ServiceLog, HttpLog, ViolateLog, AlertLog
from utilmeta.ops.models.service import ServiceInstance, ServiceWorker
from utilmeta.ops.models.task import TaskInstance, TaskSettings, TaskEvent, \
    TaskExecution, TaskWorker, TaskDistribution
from utilmeta.ops.models.metrics import ServiceAggregate, TaskAggregate, UserAggregate
from utilmeta.ops.schema.metrics import ReportSchema
from utilmeta.ops.models.utils import Endpoint, EndpointDistribution
from utilmeta.conf import config
from utilmeta.util.query import MetaQuerySet
from utilmeta.util.task.backends.base import BaseJob
from utilmeta.util.common import exp, exc, constant, LogType, replace_null, AgentDevice, AgentOS, AgentBrowser, \
    AlertLevel, ignore_errors, closest_hour, EventStatus, dict_number_add, LogLevel
from typing import List, Tuple
from datetime import datetime, timedelta

BATCH_SIZE = 1000
WINDOW = timedelta(seconds=1)

__all__ = ['LogAggregateTask', 'JobAggregateTask', 'ServiceAggregateTask', 'TaskAggregateTask', 'UserAggregateTask']


def get_percent_times(times: List[Tuple[int, float, float, float, float]]) -> Tuple[float, float, float, float]:
    time_values = []
    total = 0
    for req, p50, p95, p99, p999 in times:
        if not req:
            continue
        total += req
        time_values.extend([
            (req // 2, float(p50)),
            (req // 20, float(p95)),
            (req // 100, float(p99)),
            (req // 1000, float(p999)),
        ])

    p50 = p95 = p99 = p999 = 0
    if total:
        acc = 0
        for req, time in sorted(time_values, key=lambda x: x[1]):
            acc += req
            if acc >= total * 0.5 and not p50:
                p50 = time
            if acc >= total * 0.95 and not p95:
                p95 = time
            if acc >= total * 0.99 and not p99:
                p99 = time
            if acc >= total * 0.999 and not p999:
                p999 = time
    if not p95:
        p95 = p50
    if not p99:
        p99 = p95
    if not p999:
        p999 = p99
    return p50, p95, p99, p999


class ServiceAggregateBase(Task):
    abstract = True

    def __iter__(self):
        inst_query = ServiceInstance.objects.filter(service_id=config.name)
        count = inst_query.count()
        if not count:
            return
        sole = count == 1
        yield self(service_id=config.name)
        if not sole:
            for inst in inst_query:
                yield self(service_id=config.name, instance_id=inst.pk)
        for endpoint in Endpoint.current_instances():
            yield self(service_id=config.name, endpoint_id=endpoint.pk)

    def __call__(self, service_id: str, instance_id: str = None, endpoint_id: str = None):
        raise NotImplementedError

    def reduce(self, jobs: List[BaseJob]):
        objs = []
        for job in jobs:
            if isinstance(job.result, ServiceAggregate):
                objs.append(job.result)
        MetaQuerySet(model=ServiceAggregate).bulk_create(objs)

    @classmethod
    def get_agent_dist(cls, logs: MetaQuerySet):
        # service logs
        try:
            os_dist = {}
            browser_dist = {}
            device_dist = {}
            for os in AgentOS.gen():
                num = logs.filter(log__http_log__user_agent__os__icontains=os).count()
                if num:
                    os_dist[os] = num
            for br in AgentBrowser.gen():
                num = logs.filter(log__http_log__user_agent__browser__icontains=br).count()
                if num:
                    browser_dist[br] = num
            for device in AgentDevice.gen():
                num = logs.filter(log__http_log__user_agent__device=device).count()
                if num:
                    device_dist[device] = num
            return dict(
                os_dist=os_dist,
                browser_dist=browser_dist,
                device_dist=device_dist
            )
        except exc.DatabaseError:
            return {}

    @ignore_errors
    def report_metrics(self, obj: ServiceAggregate, start: datetime):
        if not config.ops.supervisor_report_metrics:
            return
        alert_logs = MetaQuerySet(model=AlertLog).filter(
            time__gte=start,
            time__lt=obj.time,
            type__service_id=obj.service.pk,
        )
        alerts = {}
        for level in AlertLevel.gen():
            alerts[level] = alert_logs.filter(type__level=level).count()

        metrics = ReportSchema(
            time=obj.time,
            layer=obj.layer,
            seconds=int((obj.time - start).total_seconds()),
            requests=obj.requests,
            users=obj.users,
            new_users=obj.new_users,
            alerts=alerts,
            levels=obj.levels,
            statuses=obj.statuses,
            in_traffic=obj.in_traffic,
            out_traffic=obj.out_traffic,
            mean_time=obj.mean_time,
            avg_time=obj.avg_time,
            p95_time=obj.p95_time,
            p99_time=obj.p99_time,
            p999_time=obj.p999_time,
            os_dist=obj.os_dist,
            device_dist=obj.device_dist,
            browser_dist=obj.browser_dist,
            uv=obj.uv,
            ip=obj.ip
        )

        if config.is_proxy:
            from ..sdk import ActionSDK
            from utilmeta.ops.module.admin import SupervisorMain
            for sp in SupervisorMain.filter(disabled=False, service_id=config.name):
                sp: SupervisorMain.model
                if not sp.report_enabled:
                    continue
                action = ActionSDK(to=sp)
                resp = action.report(data=metrics)
                if not resp.success:
                    self.alert_error(
                        type='supervisor_report_error',
                        ident=sp.pk,
                        level=AlertLevel.WARNING,
                        message=resp.message,
                    )
        else:
            from ..sdk import ClusterSDK
            resp = ClusterSDK(proxy=True).report(data=metrics)
            if not resp.success:
                self.alert_error(
                    type='cluster_report_error',
                    level=AlertLevel.WARNING,
                    message=resp.message,
                )


class TaskAggregateBase(Task):
    abstract = True

    def __iter__(self):
        inst_query = TaskInstance.objects.filter(service_id=config.name)
        count = inst_query.count()
        if not count:
            return
        sole = count == 1
        yield self(service_id=config.name)
        if not sole:
            for inst in inst_query:
                yield self(service_id=config.name, instance_id=inst.pk)
        for settings in TaskSettings.objects.filter(disabled=False):
            yield self(service_id=config.name, settings_id=settings.pk)

    def __call__(self, service_id: str, instance_id: str = None, settings_id: str = None):
        raise NotImplementedError

    def reduce(self, jobs: List[BaseJob]):
        objs = []
        for job in jobs:
            if isinstance(job.result, TaskAggregate):
                objs.append(job.result)
        MetaQuerySet(model=TaskAggregate).bulk_create(objs)


class LogAggregateTask(ServiceAggregateBase):
    @property
    def time(self):
        return self.current_event.exec_time if self.current_event else closest_hour(self.exec_time)

    @property
    def utc_day_begin(self):
        from pytz import utc
        return self.time.astimezone(utc).hour == 0

    def __iter__(self):
        inst_query = ServiceInstance.objects.filter(service_id=config.name)
        count = inst_query.count()
        if not count:
            return
        sole = count == 1
        yield self(service_id=config.name)
        if not sole:
            for inst in inst_query:
                yield self(service_id=config.name, instance_id=inst.pk)

        for endpoint in Endpoint.current_instances():
            yield self(service_id=config.name, endpoint_id=endpoint.pk)

            # calculate distribution
            for inst in inst_query:
                yield self(service_id=config.name, endpoint_id=endpoint.pk, instance_id=inst.pk)

    def __call__(self, service_id: str, instance_id: str = None, endpoint_id: str = None):
        start = self.prev_event.exec_time if self.prev_event else self.time - timedelta(hours=1)
        current = self.time
        seconds = (current - start).total_seconds()

        base_query = dict(time__lte=current)  # only apply to BaseLog
        log_query = dict(log__time__lte=current)  # apply to child of BaseLog (exclude BaseLog itself)
        common_query = dict()  # apply to all logs
        http_query = dict()
        service_query = dict()
        request_query = dict()
        worker_query = dict()
        violate_query = dict()

        base_query.update(time__gt=start)
        log_query.update(log__time__gt=start)

        if instance_id:
            base_query.update(version__instance_id=instance_id)
            log_query.update(log__version__instance_id=instance_id)
            worker_query.update(instance__id=instance_id)

        if endpoint_id:
            service_query.update(endpoint_id=endpoint_id)
            request_query.update(context_log__service_log__endpoint_id=endpoint_id)
            base_query.update(service_log__endpoint_id=endpoint_id)
            http_query.update(log__service_log__endpoint_id=endpoint_id)
            violate_query.update(service_log__endpoint_id=endpoint_id)
            worker_query.update(logs__service_log__endpoint_id=endpoint_id)

        if service_id:
            # by default the db only store one service's log, but add a condition for other case
            base_query.update(version__instance__service_id=service_id)
            log_query.update(log__version__instance__service_id=service_id)
            worker_query.update(instance__service_id=service_id)

        base_logs = MetaQuerySet(model=BaseLog).filter(
            type=LogType.service,
            **base_query, **common_query).order_by('time')

        if not base_logs.exists():
            return

        http_logs = MetaQuerySet(model=HttpLog).filter(
            **log_query, **common_query, **http_query, log__type=LogType.service).distinct()
        service_logs = MetaQuerySet(model=ServiceLog).filter(
            **log_query, **common_query, **service_query).order_by('-log__duration').distinct()
        request_logs = MetaQuerySet(model=RequestLog).filter(
            **log_query, **common_query, **request_query).distinct()
        violate_logs = MetaQuerySet(model=ViolateLog).filter(log__in=service_logs).distinct()

        requests = service_logs.count()
        if not requests:
            return

        errors = service_logs.filter(log__level__gte=LogLevel.ERROR).count()
        alerts = base_logs.exclude(alert=None).count()
        invokes = request_logs.count()
        last_log = base_logs.last()
        aggregate_info = [
            ('status', 'statuses', http_logs, None),
            ('level', 'levels', base_logs, constant.LOG_LEVELS),
            ('scheme', 'schemes', base_logs, constant.SCHEMES),
            ('to_service', 'targets', request_logs, None),
            ('from_service', 'sources', service_logs, None),
        ]
        dict_values = {}
        for name, field, query, enums in aggregate_info:
            try:
                values = list(query.order_by(name).distinct(name).values_list(name, flat=True))
            except exc.NotSupportedError:
                if enums:
                    values = [val for val in enums if query.filter(**{name: val}).exists()]
                else:
                    values = list(set(query.values_list(name, flat=True)))
            if None in values:
                values.remove(None)
            dict_values[field] = query.aggregate(
                **{str(val): exp.Count('pk', filter=exp.Q(**{name: val})) for val in values}
            ) if values else {}

        max_rps = 0
        max_rps_time = None
        n = 0
        service_targets = service_logs.order_by('log__time')
        while service_targets.exists():
            service_targets = service_targets[BATCH_SIZE * n: BATCH_SIZE * (n + 1)]
            values = list(service_targets.values_list('log__time', flat=True))
            for i, time in enumerate(values):
                j = 1
                while i + j < len(values):
                    _time = values[i + j]
                    if time + WINDOW < _time:
                        if max_rps < j:
                            max_rps = j
                            max_rps_time = time
                        break
                    j += 1
            n += 1
        workers = MetaQuerySet(model=ServiceWorker).filter(**worker_query)

        mean_time = service_logs[requests // 2].log.duration if requests else 0
        p95_time = service_logs[requests // 20].log.duration if requests else 0
        p99_time = service_logs[requests // 100].log.duration if requests else 0
        p999_time = service_logs[requests // 1000].log.duration if requests else 0

        if endpoint_id and instance_id:
            dist: EndpointDistribution = EndpointDistribution.objects.filter(
                endpoint_id=endpoint_id,
                instance_id=instance_id
            ).first()

            latest = replace_null(service_logs.aggregate(
                latest_avg_time=exp.Avg('log__duration'),
                latest_time_stddev=exp.StdDev('log__duration'),
                latest_uv=exp.Count('user_id', distinct=True),
                latest_ip=exp.Count('ip', distinct=True),
            ))

            avg_time = latest.get('latest_avg_time') or 0
            latest_levels = levels = dict_values.get('levels') or {}
            latest_statuses = statuses = dict_values.get('statuses') or {}
            dist_max_rps = max_rps
            dist_max_rps_time = max_rps_time

            if dist and dist.requests:
                total_duration = service_logs.aggregate(v=exp.Sum('log__duration'))['v'] or 0
                avg_time = (dist.requests * dist.avg_time + total_duration) / (dist.requests + requests)
                levels = dict_number_add(dist.levels, levels)
                statuses = dict_number_add(dist.statuses, statuses)
                if dist.max_rps > max_rps:
                    dist_max_rps = dist.max_rps
                    dist_max_rps_time = dist.max_rps_time

            EndpointDistribution.objects.update_or_create(
                endpoint_id=endpoint_id,
                instance_id=instance_id,
                defaults=dict(
                    time=current,
                    requests=(dist.requests + requests) if dist else requests,
                    errors=(dist.errors + errors) if dist else errors,
                    alerts=(dist.alerts + alerts) if dist else alerts,
                    max_rps=dist_max_rps,
                    max_rps_time=dist_max_rps_time,
                    avg_time=avg_time,
                    latest_requests=requests,
                    latest_errors=errors,
                    latest_rps=round(requests / seconds, 2),
                    levels=levels,
                    latest_levels=latest_levels,
                    statuses=statuses,
                    latest_statuses=latest_statuses,
                    latest_alerts=alerts,
                    latest_mean_time=mean_time,
                    latest_p95_time=p95_time,
                    latest_p99_time=p99_time,
                    latest_p999_time=p999_time,
                    **replace_null(base_logs.aggregate(
                        latest_in_traffic=exp.Sum('in_traffic'),
                        latest_out_traffic=exp.Sum('out_traffic'),
                    )),
                    **latest,
                ),
            )
            return

        new_users = users = 0
        if not instance_id and not endpoint_id:
            if config.auth.UserModel:
                users = MetaQuerySet(model=config.auth.UserModel).count()
                if config.auth.signup_time_field:
                    new_users = MetaQuerySet(model=config.auth.UserModel).filter(
                        **{
                            config.auth.signup_time_field + '__date': start.date(),
                            config.auth.signup_time_field + '__hour': start.hour,
                        }
                    ).count()
                else:
                    last: ServiceAggregate = ServiceAggregate.objects.filter(
                        service_id=service_id,
                        instance_id=instance_id,
                        endpoint_id=endpoint_id,
                        layer=0,
                    ).order_by('time').last()

                    new_users = max(users - last.users, 0) if last else users

        total_sessions = None
        if config.session and config.session.use_db:
            from utilmeta.ops.models.admin import Session
            total_sessions = Session.objects.filter(expiry_time__gt=current, delete_time=None).count()

        obj = ServiceAggregate(
            time=current,
            layer=0,
            service_id=service_id,
            instance_id=instance_id,
            endpoint_id=endpoint_id,
            users=users,
            new_users=new_users,
            task_settings=self.task_settings,
            log_cursor=last_log.pk if last_log else None,
            invokes=invokes,
            error_invokes=request_logs.filter(log__http_log__status__gte=500).count(),
            timeout_invokes=request_logs.filter(timeout_error=True).count(),
            invoke_per_sec=round(invokes / seconds, 2),
            avg_invoke_time=request_logs.aggregate(v=exp.Avg('log__duration'))['v'] or 0,
            requests=requests,
            max_rps=max_rps,
            max_rps_time=max_rps_time,
            errors=errors,
            req_per_sec=round(requests / seconds, 2),
            mean_time=mean_time,
            p95_time=p95_time,
            p99_time=p99_time,
            p999_time=p999_time,
            alerts=alerts,
            violates=violate_logs.count(),
            operations=service_logs.exclude(admin=None).count(),
            avg_workers=workers.count(),
            total_sessions=total_sessions,
            **self.get_agent_dist(service_logs),
            **replace_null(base_logs.aggregate(
                in_traffic=exp.Sum('in_traffic'),
                out_traffic=exp.Sum('out_traffic'),
            )),
            **replace_null(base_logs.aggregate(
                public_in_traffic=exp.Sum('in_traffic', filter=exp.Q(public=True)),
                public_out_traffic=exp.Sum('out_traffic', filter=exp.Q(public=True)),
                private_in_traffic=exp.Sum('in_traffic', filter=exp.Q(public=False)),
                private_out_traffic=exp.Sum('out_traffic', filter=exp.Q(public=False)),
            )),
            **replace_null(service_logs.aggregate(
                avg_time=exp.Avg('log__duration'),
                time_stddev=exp.StdDev('log__duration'),
                uv=exp.Count('user_id', distinct=True),
                ip=exp.Count('ip', distinct=True),
                active_sessions=exp.Count('session_id', distinct=True)
            )),
            **dict_values
        )
        if not instance_id and not endpoint_id and config.ops.supervisor_report_metrics:
            self.report_metrics(obj, start=start)
        return obj

    def reduce(self, jobs: List[BaseJob]):
        super().reduce(jobs)
        if self.utc_day_begin:
            ServiceAggregateTask(
                source_layer=0,
                interval=timedelta(days=1),
                time=self.time
            ).execute()


class ServiceAggregateTask(ServiceAggregateBase):
    def __init__(self, source_layer: int, interval: timedelta, time: datetime, **kwargs):
        self.source_layer = source_layer
        self.layer = source_layer + 1
        self.layer_interval = interval
        self.time = time

        kwargs.update(
            source_layer=source_layer,
            interval=interval,
            time=time
        )
        super().__init__(**kwargs)

    def __call__(self, service_id: str, instance_id: str = None, endpoint_id: str = None):
        seconds = self.layer_interval.total_seconds()
        current = self.time
        start = current - timedelta(seconds=seconds)

        aggregates = MetaQuerySet(model=ServiceAggregate).filter(
            service_id=service_id,
            instance_id=instance_id,
            endpoint_id=endpoint_id,
            layer=self.source_layer,
            time__gt=start,
            time__lte=current
        ).order_by('time')

        if not aggregates.exists():
            return

        p50, p95, p99, p999 = get_percent_times(list(aggregates.values_list(
            'requests',
            'mean_time',
            'p95_time',
            'p99_time',
            'p999_time',
        )))
        dict_keys = [
            'statuses',
            'levels',
            'schemes',
            'targets',
            'sources'
        ]
        dict_values = {key: {} for key in dict_keys}
        for data in list(aggregates.values(*dict_keys)):
            for key, val in data.items():
                values = dict_values[key]
                for k, v in val.items():
                    if k in values:
                        values[k] += v
                    else:
                        values[k] = v

        basic = aggregates.aggregate(
            invokes=exp.Sum('invokes'),
            requests=exp.Sum('requests'),
        )
        invokes = basic['invokes'] or 0
        requests = basic['requests'] or 0
        avg_invoke_time = (aggregates.aggregate(v=exp.Sum(
            exp.F('avg_invoke_time') * invokes) / invokes)['v'] or 0) if invokes else 0
        avg_time = (aggregates.aggregate(v=exp.Sum(
            exp.F('avg_time') * requests) / requests)['v'] or 0) if requests else 0

        visits: dict = dict(
            uv=None,
            ip=None
        )
        agent_dist = {}
        if config.log.volatile_maintain >= seconds:
            base_query = dict()  # only apply to BaseLog
            log_query = dict()  # apply to child of BaseLog (exclude BaseLog itself)
            service_query = dict()

            if instance_id:
                base_query.update(version__instance_id=instance_id)
                log_query.update(log__version__instance_id=instance_id)
            elif endpoint_id:
                service_query.update(endpoint_id=endpoint_id)
            elif service_id:
                # by default the db only store one service's log, but add a condition for other case
                base_query.update(version__instance__service_id=service_id)
                log_query.update(log__version__instance__service_id=service_id)

            service_logs = MetaQuerySet(model=ServiceLog).filter(
                **log_query, **service_query,
                log__time__gte=self.current_time - timedelta(seconds=seconds)
            )
            logs = service_logs.count()
            p50 = service_logs[logs // 2].log.duration if logs else 0
            p95 = service_logs[logs // 20].log.duration if logs else 0
            p99 = service_logs[logs // 100].log.duration if logs else 0
            p999 = service_logs[logs // 1000].log.duration if logs else 0
            agent_dist = self.get_agent_dist(service_logs)
            visits = replace_null(service_logs.aggregate(
                uv=exp.Count('user_id', distinct=True),
                ip=exp.Count('ip', distinct=True),
            ))
        elif config.auth and config.auth.last_activity_field:
            visits.update(uv=MetaQuerySet(model=config.auth.UserModel).filter(
                **{config.auth.last_activity_field + '__gte': start}).count())

        new_users = users = 0
        if config.auth.UserModel:
            users = MetaQuerySet(model=config.auth.UserModel).count()
            if config.auth.signup_time_field:
                new_users = MetaQuerySet(model=config.auth.UserModel).filter(
                    **{
                        config.auth.signup_time_field + '__gte': start,
                    }
                ).count()
            else:
                last: ServiceAggregate = ServiceAggregate.objects.filter(
                    service_id=service_id,
                    instance_id=instance_id,
                    endpoint_id=endpoint_id,
                    layer=self.layer,
                ).order_by('time').last()
                new_users = max(users - last.users, 0) if last else users

        avg_user_active_time = None
        if not instance_id and not endpoint_id:
            avg_user_active_time = UserAggregate.objects.filter(
                time__date=self.time.date(), service_id=config.name).aggregate(v=exp.Avg('active_time'))['v']

        obj = ServiceAggregate(
            time=current,
            service_id=service_id,
            instance_id=instance_id,
            endpoint_id=endpoint_id,
            task_settings=self.task_settings,
            layer=self.layer,
            mean_time=p50,
            p95_time=p95,
            p99_time=p99,
            p999_time=p999,
            users=users,
            new_users=new_users,
            time_stddev=None,

            avg_user_active_time=avg_user_active_time,
            invokes=invokes,
            requests=requests,
            avg_invoke_time=avg_invoke_time,
            avg_time=avg_time,
            max_rps_time=aggregates.order_by('max_rps').last().max_rps_time,
            **visits,
            **agent_dist,
            **replace_null(aggregates.aggregate(
                max_rps=exp.Max('max_rps'),
                errors=exp.Sum('errors'),
                error_invokes=exp.Sum('error_invokes'),
                timeout_invokes=exp.Sum('timeout_invokes'),
                invoke_per_sec=exp.Sum('invokes') / seconds,
                req_per_sec=exp.Sum('requests') / seconds,
                alerts=exp.Sum('alerts'),
                violates=exp.Sum('violates'),
                operations=exp.Sum('operations'),
                in_traffic=exp.Sum('in_traffic'),
                out_traffic=exp.Sum('out_traffic'),
                public_in_traffic=exp.Sum('public_in_traffic'),
                public_out_traffic=exp.Sum('public_out_traffic'),
                private_in_traffic=exp.Sum('private_in_traffic'),
                private_out_traffic=exp.Sum('private_out_traffic'),
                avg_workers=exp.Avg('avg_workers'),
            )),
            **dict_values
        )
        if not instance_id and not endpoint_id and \
                config.ops.supervisor_report_metrics and config.log.maintain >= seconds:
            self.report_metrics(obj, start=start)
        return obj


class JobAggregateTask(TaskAggregateBase):
    def __iter__(self):
        inst_query = TaskInstance.objects.filter(service_id=config.name)
        count = inst_query.count()
        if not count:
            return
        sole = count == 1
        yield self(service_id=config.name)
        if not sole:
            for inst in inst_query:
                yield self(service_id=config.name, instance_id=inst.pk)

        for settings in TaskSettings.objects.filter(disabled=False):
            yield self(service_id=config.name, settings_id=settings.pk)
            for inst in inst_query:
                yield self(service_id=config.name, instance_id=inst.pk, settings_id=settings.pk)

    @property
    def time(self):
        return self.current_event.exec_time if self.current_event else closest_hour(self.exec_time)

    @property
    def utc_day_begin(self):
        from pytz import utc
        return self.time.astimezone(utc).hour == 0

    def __call__(self, service_id: str = None, instance_id: str = None, settings_id: str = None):
        last: TaskAggregate = TaskAggregate.objects.filter(
            service_id=service_id,
            instance_id=instance_id,
            task_id=settings_id,
            layer=0,
        ).order_by('time').last()

        start = self.prev_event.exec_time if self.prev_event \
            else last.time if last else self.time - timedelta(hours=1)
        current = self.time

        seconds = (current - start).total_seconds()

        log_query = dict(log__time__gt=start, log__time__lte=current)
        alert_query = dict(time__gt=start, time__lte=current)
        # apply to child of BaseLog (exclude BaseLog itself)
        exec_query = dict(exec_time__lte=current)
        event_query = dict(exec_time__lte=current)
        worker_query = dict(connected=True)

        event_query.update(exec_time__gt=start)
        exec_query.update(exec_time__gt=start)

        if instance_id:
            event_query.update(task__distributions__instance__id=instance_id)
            exec_query.update(dist__instance__id=instance_id)
            log_query.update(log__version__instance_id=instance_id)
            worker_query.update(instance_id=instance_id)
            alert_query.update(instance_id=instance_id)

        if settings_id:
            event_query.update(task_id=settings_id)
            exec_query.update(event__task_id=settings_id)
            log_query.update(job__execution__event__task_id=settings_id)
            worker_query.update(task_distributions__task_id=settings_id)
            alert_query = None

        if service_id:
            # by default the db only store one service's log, but add a condition for other case
            event_query.update(task__base__application__service_id=service_id)
            log_query.update(log__version__instance__service_id=service_id)
            exec_query.update(event__task__base__application__service_id=service_id)
            worker_query.update(instance__service_id=service_id)
            if alert_query:
                alert_query.update(type__service_id=service_id)

        events = MetaQuerySet(model=TaskEvent).filter(**event_query).order_by('exec_time').distinct()
        if not events.exists():
            # no events for this task, abort
            return

        alerts = MetaQuerySet(model=AlertLog).filter(**alert_query).order_by('time').distinct()\
            if alert_query else MetaQuerySet(model=AlertLog).none()

        executions = MetaQuerySet(model=TaskExecution).filter(**exec_query).distinct()
        happens = executions.exclude(exec_time=None)
        fulfills = executions.exclude(done_time=None).exclude(duration=None).order_by('-duration')
        timeouts = happens.filter(timeout=True)
        fails = happens.filter(success=False)

        workers = MetaQuerySet(model=TaskWorker).filter(**worker_query).distinct()
        ful_num = fulfills.count()

        total_jobs = fulfills.aggregate(v=exp.Sum('total_jobs'))['v'] or 0
        if not total_jobs:
            return

        last_event = events.last()
        executed_events = events.exclude(executions=None).count()
        abandoned_events = events.filter(status=EventStatus.abandoned).count()
        executed_executions = happens.count()
        failed_executions = fails.count()
        timeout_executions = timeouts.count()
        mean_time = fulfills[ful_num // 2].duration if ful_num else 0
        p95_time = fulfills[ful_num // 20].duration if ful_num else 0
        p99_time = fulfills[ful_num // 100].duration if ful_num else 0
        p999_time = fulfills[ful_num // 1000].duration if ful_num else 0
        jobs_data = replace_null(fulfills.aggregate(
            failed_jobs=exp.Sum('failed_jobs'),
            timeout_jobs=exp.Sum('timeout_jobs'),
            retried_jobs=exp.Sum('retried_jobs'),
            job_min_time=exp.Min('job_min_time'),
            job_max_time=exp.Max('job_max_time'),
            job_avg_time=exp.Sum(exp.F('job_avg_time') * exp.F('total_jobs')) / total_jobs,
            jobs_per_sec=exp.Sum('total_jobs') / seconds,
        ))

        if instance_id and settings_id:
            dist: TaskDistribution = TaskDistribution.objects.filter(
                task_id=settings_id,
                instance_id=instance_id
            ).first()

            latest = replace_null(fulfills.aggregate(
                latest_avg_time=exp.Avg('duration'),
                latest_time_stddev=exp.StdDev('duration'),
            ))

            avg_time = latest.get('latest_avg_time') or 0
            if dist and dist.executed_executions:
                total_duration = fulfills.aggregate(v=exp.Sum('duration'))['v'] or 0
                avg_time = (dist.executed_executions * dist.avg_time + total_duration) / \
                           (dist.executed_executions + executed_executions)

            TaskDistribution.objects.update_or_create(
                task_id=settings_id,
                instance_id=instance_id,
                defaults=dict(
                    avg_time=avg_time,
                    latest_executed_events=executed_events,
                    latest_abandoned_events=abandoned_events,
                    latest_executed_executions=executed_executions,
                    latest_failed_executions=failed_executions,
                    latest_timeout_executions=timeout_executions,
                    latest_mean_time=mean_time,
                    latest_p95_time=p95_time,
                    latest_p99_time=p99_time,
                    latest_p999_time=p999_time,
                    latest_total_jobs=total_jobs,
                    **{'latest_' + key: val for key, val in jobs_data.items()},
                    **latest
                )
            )

            return

        return TaskAggregate(
            time=current,
            service_id=service_id,
            instance_id=instance_id,
            task_id=settings_id,
            task_settings=self.task_settings,
            event_cursor=last_event.pk if last_event else None,
            mean_time=mean_time,
            p95_time=p95_time,
            p99_time=p99_time,
            p999_time=p999_time,
            alerts=alerts.count(),
            executed_events=executed_events,
            abandoned_events=abandoned_events,
            executed_executions=executed_executions,
            failed_executions=failed_executions,
            timeout_executions=timeout_executions,
            avg_workers=workers.count(),
            **replace_null(fulfills.aggregate(
                avg_time=exp.Avg('duration'),
                time_stddev=exp.StdDev('duration'),
            )),
            total_jobs=total_jobs,
            **jobs_data,
        )

    def reduce(self, jobs):
        super().reduce(jobs)
        if self.utc_day_begin:
            TaskAggregateTask(
                source_layer=0,
                interval=timedelta(days=1),
                time=self.time
            ).execute()


class TaskAggregateTask(TaskAggregateBase):
    def __init__(self, source_layer: int, interval: timedelta, time: datetime, **kwargs):
        self.source_layer = source_layer
        self.layer = source_layer + 1
        self.layer_interval = interval
        self.time = time
        kwargs.update(
            source_layer=source_layer,
            interval=interval,
            time=time
        )
        super().__init__(**kwargs)

    def __call__(self, service_id: str = None, instance_id: str = None, settings_id: str = None):
        seconds = self.layer_interval.total_seconds()
        current = self.time
        start = current - timedelta(seconds=seconds)

        aggregates = MetaQuerySet(model=TaskAggregate).filter(
            service_id=service_id,
            instance_id=instance_id,
            task_id=settings_id,
            layer=self.source_layer,
            time__gt=start,
            time__lte=current
        )
        if not aggregates.exists():
            return

        p50, p95, p99, p999 = get_percent_times(list(aggregates.values_list(
            'executed_executions',
            'mean_time',
            'p95_time',
            'p99_time',
            'p999_time',
        )))

        total_jobs = aggregates.aggregate(v=exp.Sum('total_jobs'))['v'] or 0
        if not total_jobs:
            return 
        
        executed_executions = aggregates.aggregate(v=exp.Sum('executed_executions'))['v'] or 0
        avg_time = (aggregates.aggregate(
            v=exp.Sum(exp.F('avg_time') * executed_executions) / exp.Sum('executed_executions')
        )['v'] or 0) if executed_executions else 0

        return TaskAggregate(
            time=current,
            service_id=service_id,
            instance_id=instance_id,
            task_id=settings_id,
            task_settings=self.task_settings,
            layer=self.layer,
            mean_time=p50,
            p95_time=p95,
            p99_time=p99,
            p999_time=p999,
            time_stddev=None,
            avg_time=avg_time,
            total_jobs=total_jobs,
            **replace_null(aggregates.aggregate(
                failed_jobs=exp.Sum('failed_jobs'),
                timeout_jobs=exp.Sum('timeout_jobs'),
                retried_jobs=exp.Sum('retried_jobs'),
                job_min_time=exp.Min('job_min_time'),
                job_max_time=exp.Max('job_max_time'),
                job_avg_time=exp.Sum(exp.F('job_avg_time') * total_jobs) / total_jobs,
                jobs_per_sec=exp.Sum('total_jobs') / seconds,
                avg_workers=exp.Avg('avg_workers'),
                executed_events=exp.Sum('executed_events'),
                abandoned_events=exp.Sum('abandoned_events'),
                timeout_executions=exp.Sum('timeout_executions'),
                executed_executions=exp.Sum('executed_executions'),
                failed_executions=exp.Sum('failed_executions'),
                alerts=exp.Sum('alerts'),
            )),
        )


class UserAggregateTask(Task):
    @property
    def time(self):
        return self.current_event.exec_time if self.current_event else closest_hour(self.exec_time)

    def __init__(self, layer_interval: timedelta, layer: int = 1, **kwargs):
        self.layer = layer
        self.layer_interval = layer_interval
        kwargs.update(
            layer_interval=layer_interval,
            layer=layer
        )
        super().__init__(**kwargs)

    @property
    def logs(self):
        return MetaQuerySet(model=ServiceLog).filter(
            log__version__instance__service_id=config.name,
            log__time__lt=self.time,
            log__time__gte=self.time - self.layer_interval
        )

    def __iter__(self):
        try:
            users = list(self.logs.order_by('user_id').distinct('user_id').values_list('user_id', flat=True))
        except exc.DatabaseError:
            users = list(set(self.logs.values_list('user_id', flat=True)))
        if not users:
            return
        for user_id in users:
            if user_id:
                yield self(user_id)

    def __call__(self, user_id):
        violate_logs = MetaQuerySet(model=ViolateLog).filter(
            time__lt=self.time,
            time__gte=self.time - self.layer_interval
        )
        logs = self.logs.filter(user_id=user_id)
        requests = logs.count()
        if not requests:
            return

        relates = {}
        if config.auth.UserModel:
            user = MetaQuerySet(model=config.auth.UserModel).fetch(pk=user_id)
            if not user:
                return

            for field in config.auth.relate_fields:
                cnt = getattr(user, field).count()
                if cnt:
                    relates[field] = cnt

        levels = {}
        for level in constant.LOG_LEVELS:
            cnt = logs.filter(log__level=level).count()
            if cnt:
                levels[level] = cnt
        try:
            ips = list(logs.order_by('ip').distinct('ip').values_list('ip', flat=True))
            agents = list(logs.exclude(log__http_log__user_agent=None).order_by('log__http_log__user_agent')
                          .distinct('log__http_log__user_agent').values_list('log__http_log__user_agent', flat=True))
        except exc.DatabaseError:
            ips = list(set(logs.values_list('ip', flat=True)))
            log = logs.exclude(log__http_log__user_agent=None).first()
            agents = [log.log.http_log.user_agent] if log else None

        service_logs = logs.order_by('-log__duration')
        endpoints = {}
        for e in logs.values_list('endpoint', flat=True):
            if e:
                inst = Endpoint.objects.filter(id=e).first()
                if inst:
                    endpoints[inst.ident] = logs.filter(endpoint_id=e).count()

        sessions = None
        if config.session and config.session.use_db:
            from utilmeta.utils import Auth
            sessions = Auth.get_user_sessions_num(user_id=user_id)

        return UserAggregate(
            time=self.time,
            layer=self.layer,
            user_id=user_id,
            service_id=config.name,
            requests=requests,
            ips=ips,
            agents=agents,
            levels=levels,
            mean_time=service_logs[requests // 2].log.duration,
            p95_time=service_logs[requests // 20].log.duration,
            p99_time=service_logs[requests // 100].log.duration,
            p999_time=service_logs[requests // 1000].log.duration,
            relations=relates,
            violates=violate_logs.filter(log__user_id=user_id).count(),
            endpoints=endpoints,
            sessions=sessions,
            active_time=self.get_active_time(list(logs.order_by('log__time').values_list('log__time', flat=True))),
            **replace_null(service_logs.aggregate(
                avg_time=exp.Sum('log__duration') / requests,
                time_stddev=exp.StdDev('log__duration'),
            )),
            **replace_null(logs.filter(log__public=True).aggregate(
                in_traffic=exp.Sum('log__in_traffic'),
                out_traffic=exp.Sum('log__out_traffic'),
            ))
        )

    @classmethod
    def get_active_time(cls, times: List[datetime]) -> timedelta:
        if not times:
            return timedelta(seconds=0)
        period = timedelta(seconds=0)
        start = times[0]
        for i, t in enumerate(times):
            if not i:
                continue
            delta = t - times[i - 1]
            if delta.total_seconds() > config.ops.user_inactive_interval:
                period += max(times[i - 1] - start, timedelta(seconds=config.ops.user_inactive_interval))
                start = t
        return period

    def reduce(self, jobs: List[BaseJob]):
        objs = []
        for job in jobs:
            if isinstance(job.result, UserAggregate):
                objs.append(job.result)
        if not objs:
            return

        avg_time: timedelta = sum([obj.active_time.total_seconds() for obj in objs]) / len(objs)
        MetaQuerySet(model=UserAggregate).bulk_create(objs)

        ServiceAggregate.objects.filter(
            service=config.name,
            instance=None,
            endpoint=None,
            time__date=self.time.date(),
            layer=1
        ).update(avg_user_active_time=avg_time)
