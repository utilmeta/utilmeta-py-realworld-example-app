from utilmeta.core.task import Task
from ..module.admin import SupervisorMain
from ..schema.service import ServiceInstanceSchema, InstanceAlterable
from utilmeta.conf import config
from utilmeta.util.common import time_now
from ..sdk import ClusterSDK, ActionSDK
from typing import Optional, List
from utilmeta.ops.models.service import ServiceInstance, Server, ServiceWorker, BaseInstance
from utilmeta.ops.models.task import TaskWorker, TaskInstance
from utilmeta.util.task.backends.base import BaseJob
from utilmeta.util.alert import Alert
from datetime import timedelta
import subprocess
import psutil
import sys


__all__ = ['ClusterHealthCheckTask', 'InstanceHealthCheckTask']

manager = config.cluster_manager


class ClusterHealthCheckTask(Task):
    def __iter__(self):
        services = manager.get_dependency_services()
        for service in services:
            for instance in service.instances:
                if instance.task:
                    continue
                yield self(
                    instance=instance,
                    ops_route=service.ops_route,
                    action_token=service.action_token if service.name != config.name else None
                )

    def __call__(self, instance: ServiceInstanceSchema, ops_route: str, action_token: str)\
            -> Optional[InstanceAlterable]:
        alter = InstanceAlterable(
            id=instance.id,
            service=instance.service,
            connected=False
        )
        conf = config.deploy if instance.service == config.name else config.cluster

        sdk = ClusterSDK(
            base_url=instance.get_request_url(),
            prepend_route=ops_route,
            action_token=action_token,
            timeout=conf.health_check_timeout,
            max_retries=conf.health_check_max_retries,
            retry_interval=conf.health_check_retry_interval
        )

        try:
            resp = sdk.status()
            connected = resp.success and resp.valid(service=instance.service)
            message = resp.status
        except TimeoutError:
            resp = None
            connected = False
            message = 'timeout'

        alter.connected = connected
        data = dict(connected=connected)
        if connected and resp:
            if resp.result.server:
                data.update(server=Server.load(ip=resp.result.server.ip, metrics=resp.result.server))
            if resp.result.metrics:
                data.update(resp.result.metrics)
        changed = connected != alter.connected
        inst = ServiceInstance.get(id=instance.id)
        if not inst:
            return alter

        inst.update(**data)
        manager.update_service(service=instance.service)
        alert_data = dict(
            subcategory='service_instance_unavailable',
            name=f'service instance: [{instance.ip}] unavailable',
            message=f'Service instance: {instance.id}[{instance.ip}] '
                    f'unavailable: {message} at {str(self.exec_time)}',
            ident=f'service_instance_unavailable:{instance.ip}',
            level=Alert.Level.CRITICAL,
            category=Alert.Category.service_unavailable,
            alarm=False,
            instance=True
        )

        if not connected:
            Alert.log(**alert_data)
            if instance.id == config.deploy.instance_id:
                InstanceHealthCheckTask(task=False).restart_service(inst)

        if changed:
            if connected:
                Alert.log(**alert_data, trigger=False)
            return alter
        return None

    def reduce(self, jobs: List[BaseJob]):
        alters = []
        for job in jobs:
            if isinstance(job.result, InstanceAlterable):
                alters.append(job.result)
        if config.cluster:
            # deploy for proxy after instance health check
            config.cluster.deploy(routine=True)
        if not alters or not config.is_proxy:
            return
        for sp in SupervisorMain.filter(service_id=config.name, disabled=False):
            sp: SupervisorMain.model
            if not sp.instance_sync_enabled:
                continue
            resp = ActionSDK(to=sp.id).alter_inst(instances=alters)
            if not resp.success:
                self.alert_error(
                    type='supervisor_alter_inst_error',
                    ident=sp.id,
                    message=f'Report disconnect: {alters} failed with error: {resp.message}'
                )


class InstanceHealthCheckTask(Task):
    def __init__(self, task: bool = False, **kwargs):
        super().__init__(task=task, **kwargs)
        self.task = task
        self.config = config.task if task else config.deploy
        self.instance_cls = TaskInstance if task else ServiceInstance
        self.worker_cls = TaskWorker if task else ServiceWorker

    def restart_service(self, inst):
        if not self.check_window(inst):
            return
        self.record(
            inst,
            unavailable=True,
            return_code=self.restart(force_restart=True)
        )

    def __call__(self):
        inst = self.instance_cls.current()

        if not inst:
            return

        if not inst.connected:
            if not self.check_window(inst):
                return
            if self.task:
                self.record(
                    inst,
                    unavailable=True,
                    return_code=None
                )
                # during restart, this instance will be gone
                return self.restart(force_restart=True)

        if self.config.max_instance_lifetime:
            restart = inst.last_restart or inst.init_time
            if self.check(
                inst,
                value=(self.exec_time - restart).total_seconds(),
                threshold=self.config.max_instance_lifetime + self.config.get_instance_lifetime_delta(),
                index='lifetime',
            ):
                return

        if self.task:
            from utilmeta.ops.models.task import TaskExecution
            if self.config.max_instance_executions:
                if self.check(
                    inst,
                    value=TaskExecution.objects.filter(dist__instance=inst).count(),
                    threshold=self.config.max_instance_executions,
                    index='executions',
                ):
                    return
        else:
            if self.config.max_instance_requests:
                if self.check(
                    inst,
                    value=inst.requests,
                    threshold=self.config.max_instance_requests,
                    index='requests',
                ):
                    return

        mem_bytes = inst.used_memory
        mem_percent = inst.memory_percent

        if self.config.max_instance_memory_percent:
            if self.check(
                inst,
                value=mem_percent,
                threshold=self.config.max_instance_memory_percent,
                index='memory_percent',
                force_restart=self.config.instance_memory_exceed_force_restart
            ):
                return

        if self.config.max_instance_memory_bytes:
            if self.check(
                inst,
                value=mem_bytes,
                threshold=self.config.max_instance_memory_bytes,
                index='memory_bytes',
                force_restart=self.config.instance_memory_exceed_force_restart
            ):
                return

    def check_health(self, inst: BaseInstance):
        if self.task:
            if not inst:
                return True
            master: TaskWorker = self.worker_cls.objects.filter(instance=inst, master=None).first()
            if not master:
                return True
            if not master.connected:
                return False
            try:
                psutil.Process(master.pid)
            except psutil.NoSuchProcess:
                return False
            except psutil.Error:
                return True
            return True

        from utilmeta.service import UtilMeta
        service = UtilMeta(config=config)
        return service.check(internal=True)

    def check(self, inst: BaseInstance = None, index: str = None,
              value: float = None, threshold: float = None, force_restart: bool = False):
        if value is None or threshold is None or not inst:
            return
        if value > threshold:
            if not self.check_min_lifetime(inst):
                return True
            print('CHECK FAILED:', index, value, threshold)
            if not config.production:
                return
            if self.task:
                # restart will abort the process and not record this restart to db
                self.record(
                    inst, index=index, value=value,
                    unavailable=force_restart,
                    threshold=threshold,
                    reload=not force_restart
                )
                self.restart(force_restart=force_restart)
            else:
                self.record(
                    inst, index=index, value=value,
                    threshold=threshold,
                    unavailable=force_restart,
                    return_code=self.restart(force_restart=force_restart),
                    reload=not force_restart
                )
            return True
        return False

    def check_window(self, inst: BaseInstance):
        from utilmeta.ops.models.service import RestartRecord
        base = RestartRecord.objects.filter(instance=inst)
        if base.filter(time__gte=time_now() - timedelta(seconds=self.config.instance_restart_window)).exists():
            return False
        # if self.config.instance_max_consecutive_restarts and base.filter(
        #     time__gte=self.exec_time - timedelta(
        #         seconds=(self.config.instance_restart_window + config.ops.health_check_interval)
        #                 * self.config.instance_max_consecutive_restarts
        #     )
        # ).count() >= self.config.instance_max_consecutive_restarts:
        #     pass
        return True

    def check_min_lifetime(self, inst: BaseInstance):
        if not self.config.min_instance_lifetime:
            return True
        if (self.exec_time - inst.last_restart).total_seconds() < self.config.min_instance_lifetime:
            return False
        return True

    @classmethod
    def record(cls, inst: BaseInstance = None, unavailable: bool = False, return_code: int = None,
               index: str = None, value: float = None, threshold: float = None, reload: bool = False):
        if not inst:
            return
        from utilmeta.ops.models.service import RestartRecord
        RestartRecord(
            instance_id=inst.pk,
            unavailable=unavailable,
            trigger_index=index,
            trigger_value=value,
            threshold=threshold,
            return_code=return_code,
            success=not return_code,
            reload=reload
        ).save()

    @property
    def systemd(self):
        return config.deploy.get_task_systemd() if self.task else config.deploy.get_systemd()

    def restart(self, force_restart: bool = False):
        if not config.production:
            proc = subprocess.Popen([sys.executable, config.service.main_file], cwd=config.service.path)
            print('POPEN:', proc.pid)
            # do not wait, test dev server main process never return unless it's been killed
            return None

        if self.config.system_daemon:
            if force_restart:
                return self.systemd.restart()
            return self.systemd.reload()

        if self.task:
            cmd = ['meta', 'task', 'restart']
        elif force_restart:
            cmd = ['meta', 'restart']
        else:
            cmd = ['meta', 'reload']

        p = subprocess.Popen(cmd, cwd=config.service.path)
        p.wait()
        return p.returncode
