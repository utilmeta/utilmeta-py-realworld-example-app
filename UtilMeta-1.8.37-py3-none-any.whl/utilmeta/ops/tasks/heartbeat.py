from utilmeta.core.task import Task
from ..module.admin import SupervisorView
from ..module.service import ServiceInstanceMain
from ..models.admin import Supervisor
from ..models.service import ServiceInstance
from utilmeta.conf import config
from ..schema.action import InitHeartbeatSchema, CommonHeartbeatSchema
from ..schema.service import InstanceAlterable
from utilmeta.util.common import exp, convert_time
from ..sdk import ActionSDK

__all__ = ['HeartbeatTask']

manager = config.cluster_manager


class HeartbeatTask(Task):
    module = SupervisorView
    query = dict(service=config.name, disabled=False, heartbeat=True)

    @classmethod
    def init_heartbeat_data(cls, supervisor: Supervisor):
        """
            unified heartbeat data (for any architecture)
            this is a cycle health check heartbeat, instances here just report load index to platform
            instance version update or initialized (including service) or disconnected
            will send a once heartbeat in OperationsAPI
        """
        instances = []
        for inst in ServiceInstanceMain.filter(service=config.name):
            inst: ServiceInstance
            instances.append(InstanceAlterable(
                id=inst.id,
                service=inst.service,
                utilmeta_version=inst.utilmeta_version,
                version=inst.version,
                version_id=inst.version_id,
                production=inst.production,
                weight=inst.weight,
                ip=inst.server.ip,
                connected=inst.connected,
                document=inst.document
            ))

        return InitHeartbeatSchema(
            id=supervisor.pk,
            name=config.name,
            action_url=supervisor.action_url,
            proxy_url=config.public_base_url if config.is_proxy else None,
            ops_route=config.ops.route,
            description=config.description,
            instances=instances
        )

    def __call__(self, sp: module.model):
        try:
            resp = ActionSDK(to=sp).heartbeat(
                data=CommonHeartbeatSchema(
                    instances=list(ServiceInstanceMain.all().values('id', 'service', 'connected').result())
                )
            )
            if not resp.success:
                raise ValueError(resp.message)
            if str(resp.result.id) != str(sp.id):
                raise ValueError(f'Inconsistent node_id: {resp.result.node_id}')
            self.module(id=sp.id).update(
                last_heartbeat=convert_time(self.exec_time),
                latency=((exp.F('latency') * exp.F('heartbeat_times') + resp.duration_ms) /
                         (exp.F('heartbeat_times') + 1)) if sp.latency else resp.duration_ms,
                heartbeat_times=exp.F('heartbeat_times') + 1
            )
        except Exception as e:
            self.alert_error(
                type='supervisor_heartbeat_error',
                message=f'ERROR: heartbeat to {sp.id} failed: {e}',
                ident=sp.id
            )
