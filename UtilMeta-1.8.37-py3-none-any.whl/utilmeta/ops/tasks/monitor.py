from utilmeta.core.task import Task
from utilmeta.ops.models.log import BaseLog
from utilmeta.ops.models.metrics import ServerMonitor, DataMonitor, TaskAggregate, UserAggregate,  \
    ServiceAggregate, CacheMonitor, DatabaseMonitor, WorkerMonitor,\
    ServiceInstanceMonitor, InstanceMonitor
from utilmeta.ops.module.log import AlertSettingsMain
from utilmeta.ops.models.log import ServiceLog, AlertLog, AlertType
from utilmeta.ops.models.service import ServiceInstance, Server, ServiceWorker, Worker
from utilmeta.ops.models.task import TaskEvent, TaskSettings, TaskInstance
from utilmeta.ops.models.utils import DataModel
from utilmeta.ops.models.admin import Session
from utilmeta.ops.module.service import ServerList, DatabaseMain, CacheList
from utilmeta.ops.schema.service import DatabaseConnectionSchema
from utilmeta.conf import config, Database
from utilmeta.util.alert import Alert
from utilmeta.conf.operations import Monitor
from utilmeta.util.common import get_system_fds, exp, get_system_open_files, \
    get_field_name, DB, get_max_open_files, TaskFailure, \
    get_max_socket_conn, get_many_field_names, get_sql_type, get_sql_tables
from utilmeta.util.query import MetaQuerySet
from utilmeta.util.log import Logger
import psutil
import os
from utilmeta.types import *
from django.db.models import Model
from ..log import MetricsLogger

__all__ = ['DataMonitorTask', 'WorkerMonitorTask', 'ClearTask', 'DatabaseMonitorTask', 'CacheMonitorTask',
           'ServerMonitorTask', 'ServerMonitorAggregateTask', 'AlertTask', 'SessionTask']


class DataMonitorTask(Task):
    def __iter__(self):
        config_list = config.monitor.task_models_config.get(self.name)
        if not config_list:
            return
        for cfg in config_list:
            yield self(cfg)

    def __call__(self, cfg: Monitor.ModelConfig):
        model: Type[Model] = cfg.get_model()
        _model = DataModel.get(model)
        if not _model:
            return
        qs = MetaQuerySet(model=model)
        relations = {}
        for field in get_many_field_names(model):
            if cfg.relations is None or field in cfg.relations:
                relations[field] = qs.aggregate(v=exp.Count(field))['v']
        aggregates = qs.aggregate(**cfg.aggregates) if cfg.aggregates else {}
        count = qs.count()
        DataMonitor.objects.create(
            time=self.exec_time,
            task_settings=self.task_settings,
            model=_model,
            service_id=config.name,
            count=count,
            relations=relations,
            aggregates=aggregates
        )


class WorkerMonitorTask(Task):
    def __init__(self, master: bool = False, **kwargs):
        super().__init__(master=master, **kwargs)
        self.master = master

    def __call__(self):
        """
        * monitor current worker (process) status (when use non-root user only process itself has the permission)
        * use local memory as log cache (instead of redis) requires each process to save log every once in a while
        * cluster services status will be used by every internal invoke requests, process cache need to stay updated
        """
        server = Server.current()
        if not server:
            # server data not loaded
            return
        worker = ServiceWorker.load(os.getpid(), parent=True)
        if self.master:
            if worker:
                return worker.update()
            return

        config.sync_caches(retrieve_only=True)
        # sync cluster caches for every worker process
        # so when worker handling requests, it can lookup for cache instances & client
        # right in the process memory
        if config.log:
            config.log.manager_cls.consume_api_queue(worker=worker)
            config.log.manager_cls.consume_context_queue()
            Logger.expire_timeout_context()

        if config.cluster and config.cluster.is_proxy:
            if config.cluster.proxy_config.native:
                config.utilmeta.load_proxy()
        if worker:
            worker.update()


class AlertTask(Task):
    module = AlertSettingsMain

    @property
    def query(self) -> dict:
        return dict(service=config.name, disabled=False, task_settings=self.task_settings.pk)

    def __call__(self, settings: module.model):
        alert = Alert.deserialize(settings)
        trigger, index = alert.trigger()
        type = alert.generate_type()
        Alert.save(
            alert_type=type,
            message=f'{alert.full_index_name} = {index}',
            latest_time=self.exec_time,
            latest_value=index,
            trigger=trigger,
            # kwargs
            server=alert.server,
            instance=alert.instance
        )


class ServerMonitorTask(Task):
    """
    Server Monitor Task can only monitor this server
    """

    @classmethod
    def get_sys_metrics(cls):
        from utilmeta.ops.schema.metrics import SystemMetricsMixin
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage(os.getcwd())
        return SystemMetricsMixin(
            cpu_percent=psutil.cpu_percent(interval=config.monitor.cpu_percent_interval),
            used_memory=mem.used,
            memory_percent=100 * mem.used / mem.total,
            disk_percent=100 * disk.used / disk.total,
            file_descriptors=get_system_fds(),
            open_files=get_system_open_files(),
            active_net_connections=len([c for c in psutil.net_connections() if c.status != 'CLOSE_WAIT']),
            total_net_connections=len(psutil.net_connections())
        )

    @classmethod
    def get_server_statics(cls):
        import platform
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage(os.getcwd())

        devices = {}
        for device in psutil.disk_partitions():
            if 'loop' in device.device:
                continue
            try:
                disk_usage = psutil.disk_usage(device.mountpoint)
            except PermissionError:
                continue
            devices[device.device] = dict(
                mountpoint=device.mountpoint,
                fstype=device.fstype,
                opts=device.opts,
                total=disk_usage.total,
                used=disk_usage.used
            )

        return dict(
            cpu_num=os.cpu_count(),
            memory_total=mem.total,
            disk_total=disk.total,
            utcoffset=config.time.server_utcoffset,
            hostname=platform.node(),
            system=str(platform.system()).lower(),
            devices=devices,
            max_open_files=get_max_open_files(),
            max_socket_conn=get_max_socket_conn(),
            platform=dict(
                platform=platform.platform(),
                version=platform.version(),
                release=platform.release(),
                machine=platform.machine(),
                processor=platform.processor(),
                bits=platform.architecture()[0]
            )
        )

    @classmethod
    def get_loads_data(cls):
        try:
            l1, l5, l15 = psutil.getloadavg()
        except (AttributeError, OSError):
            l1, l5, l15 = 0, 0, 0
        return dict(
            load_index=config.monitor.load_index,
            load_avg_1=l1,
            load_avg_5=l5,
            load_avg_15=l15
        )

    def __call__(self):
        # also apply for stats
        # delete disconnected workers
        # workers = WSGIWorkerList.workers()
        server = Server.current()
        if not server:
            return

        metrics = self.get_sys_metrics()
        statics = self.get_server_statics()
        loads = self.get_loads_data()

        config.sync_caches()
        inst = ServiceInstance.current()
        task = TaskInstance.current()

        if inst and inst.connected:
            # only update if instance is connected, or there might be no workers
            sys_metrics = inst.sys_metrics
            try:
                MetricsLogger().save(inst, **sys_metrics)  # save data for current instance
            except Exception as e:
                self.alert_error(type=TaskFailure.runtime_error, message=str(e))
            inst = ServiceInstance.current()    # refresh
            ServiceInstanceMonitor.objects.create(
                time=self.exec_time,
                task_settings=self.task_settings,
                instance=inst,
                **inst.data,
                **sys_metrics,
            )

            ServiceInstance.objects.filter(
                server=server,
                service_id=config.name,
                # for proxy: do not delete other service's instances
                time__lte=self.exec_time - timedelta(seconds=2 * config.monitor.server_monitor_interval)
            ).exclude(pk=inst.pk).delete()

        if task:
            sys_metrics = task.sys_metrics
            task.update(**sys_metrics)
            InstanceMonitor.objects.create(
                time=self.exec_time,
                task_settings=self.task_settings,
                instance=task,
                # **task.data,
                **sys_metrics
            )

        ServerList(instance=server).update(**statics, **metrics, **loads)
        ServerMonitor.objects.create(
            server=server,
            task_settings=self.task_settings,
            time=self.exec_time,
            **metrics,
            **loads
        )
        # retrieve cluster caches, collect cache stats and sync to database

    def reduce(self, jobs):
        if self.exec_time.minute == 0:
            ServerMonitorAggregateTask(source_layer=0).execute()
            if self.exec_time.hour == 0:
                ServerMonitorAggregateTask(source_layer=1).execute()


class DatabaseMonitorTask(Task):
    @classmethod
    def get_db_connections(cls, db: Database, current_connections: List[DatabaseConnectionSchema]):
        db_sql = {
            DB.PostgreSQL: "select pid, usename, client_addr, client_port, state,"
                           " backend_start, query_start, state_change, query"
                           " from pg_stat_activity WHERE datname = '%s';",
            DB.MySQL: "select * from information_schema.processlist where db = '%s';",
            DB.Oracle: "select status from v$session where username='%s';"
        }
        if db.type not in db_sql:
            return []
        from django.db import connections
        with connections[db.alias].cursor() as cursor:
            db_type: str = str(cursor.db.display_name).lower()
            db_name: str = db.name
            if db_type == DB.Oracle:
                db_name = db.user
            cursor.execute(db_sql[db_type] % db_name)
            result = cursor.fetchall()
            values = []
            if db.type == DB.PostgreSQL:
                for pid, usename, client_addr, client_port, state,\
                        backend_start, query_start, state_change, query in result:
                    if usename != db.user:
                        continue
                    if not pid or not usename or not client_addr or not client_port or not state:
                        continue
                    find = False
                    for conn in current_connections:
                        if str(conn.pid) == str(pid):
                            values.append(conn)
                            find = True
                            break
                    if find:
                        continue
                    values.append(DatabaseConnectionSchema(
                        status=state,
                        active=state == 'active',
                        client_addr=client_addr,
                        client_port=client_port,
                        pid=pid,
                        backend_start=backend_start,
                        query_start=query_start,
                        state_change=state_change,
                        query=query,
                        type=get_sql_type(query),
                        tables=get_sql_tables(query)
                    ))
            return values

    @classmethod
    def get_db_server_connections(cls, db: Database):
        db_sql = {
            DB.PostgreSQL: "select count(*) from pg_stat_activity",
            DB.MySQL: "select count(*) from information_schema.processlist",
            DB.Oracle: "select count(*) from v$session"
        }
        if db.type not in db_sql:
            return []
        from django.db import connections
        with connections[db.alias].cursor() as cursor:
            db_type: str = str(cursor.db.display_name).lower()
            cursor.execute(db_sql[db_type])
            return int(cursor.fetchone()[0])

    @classmethod
    def get_db_connections_num(cls, using: str) -> Tuple[Optional[int], Optional[int]]:
        from django.db import connections
        from utilmeta.conf import config
        db = config.databases.get(using)
        if not db:
            return None, None
        db_sql = {
            DB.PostgreSQL: "select state from pg_stat_activity WHERE datname = '%s';",
            DB.MySQL: "select command from information_schema.processlist where db = '%s';",
            DB.Oracle: "select status from v$session where username='%s';"
        }
        if db.type not in db_sql:
            return None, None
        with connections[using].cursor() as cursor:
            db_type: str = str(cursor.db.display_name).lower()
            db_name: str = db.name
            if db_type == DB.Oracle:
                db_name = db.user
            cursor.execute(db_sql[db_type] % db_name)
            status = [str(result[0]).lower() for result in cursor.fetchall()]
            # for MySQL, command=Query means active, for others, state/status = active means active
            active_count = len([s for s in status if s in ('active', 'query')])
            conn_count = len(status)
            return conn_count, active_count

    @classmethod
    def clear_invalid_connections(cls, using: str, timeout: int = 60,
                                  include_idle: bool = True, include_active: bool = False):
        from django.db import connections
        from utilmeta.conf import config
        db = config.databases.get(using)
        if not db:
            return
        db_sql = {
            DB.PostgreSQL: """
    WITH inactive_connections AS (
        SELECT
            pid,
            rank() over (partition by client_addr order by backend_start) as rank
        FROM 
            pg_stat_activity
        WHERE
            -- Exclude the thread owned connection (ie no auto-kill)
             pid <> pg_backend_pid()
        AND
            -- Exclude known applications connections
            application_name !~ '(?:psql)|(?:pgAdmin.+)|(?:python)'
        AND
            -- Include connections to the same database the thread is connected to
            datname = '%s'
        AND
            -- Include inactive connections only
            state in (%s) 
        AND
            -- Include old connections (found with the state_change field)
            current_timestamp - state_change > interval '%s seconds' 
    )
    SELECT
        pg_terminate_backend(pid)
    FROM
        inactive_connections 
    WHERE
        rank > 1
            """
        }
        sql = db_sql.get(db.type)
        if not sql:
            return
        states = []
        if include_active:
            states.append('active')
        if include_idle:
            states.extend(['idle', 'idle in transaction', 'idle in transaction (aborted)', 'disabled'])
        state = ', '.join([repr(s) for s in states])
        with connections[using].cursor() as cursor:
            cursor.execute(sql % (db.name, state, timeout))

    @classmethod
    def get_db_size(cls, using: str) -> int:
        from django.db import connections
        from utilmeta.conf import config
        db_sql = {
            DB.PostgreSQL: "select pg_database_size('%s');",
            DB.MySQL: "select sum(DATA_LENGTH)+sum(INDEX_LENGTH) "
                      "from information_schema.tables where table_schema='%s';",
            DB.Oracle: "select sum(bytes) from dba_segments where owner='%s'"
        }
        db = config.databases[using]
        with connections[using].cursor() as cursor:
            db_type: str = str(cursor.db.display_name).lower()
            if db_type == DB.SQLite:
                file = db.file
                return os.path.getsize(file)
            if db_type not in db_sql:
                return 0
            db_name: str = db.name
            if db_type == DB.Oracle:
                db_name = f'{db.user}/{db.name}'
            cursor.execute(db_sql[db_type] % db_name)
            return int(cursor.fetchone()[0])

    @classmethod
    def get_db_server_size(cls, using: str) -> int:
        from django.db import connections
        from utilmeta.conf import config
        db_sql = {
            DB.PostgreSQL: "select sum(pg_database_size(pg_database.datname)) from pg_database;",
            DB.MySQL: "select sum(DATA_LENGTH)+sum(INDEX_LENGTH) from information_schema.tables;",
            DB.Oracle: "select sum(bytes) from dba_segments;"
        }
        db = config.databases[using]
        with connections[using].cursor() as cursor:
            db_type: str = str(cursor.db.display_name).lower()
            if db_type == DB.SQLite:
                file = db.file
                return os.path.getsize(file)
            if db_type not in db_sql:
                return 0
            cursor.execute(db_sql[db_type])
            return int(cursor.fetchone()[0])

    @classmethod
    def get_db_max_connections(cls, using: str) -> int:
        from django.db import connections
        db_sql = {
            DB.PostgreSQL: "SHOW max_connections;",
            DB.MySQL: 'SHOW VARIABLES LIKE "max_connections";'
        }
        with connections[using].cursor() as cursor:
            db_type: str = str(cursor.db.display_name).lower()
            if db_type not in db_sql:
                return 0
            cursor.execute(db_sql[db_type])
            return int(cursor.fetchone()[0])

    def __call__(self, *args, **kwargs):
        from utilmeta.util.log import pop_queries
        db_values = []
        monitors = []
        for val in DatabaseMain(query=dict(service=config.name)).serialize():
            val: DatabaseMain.schema
            db = config.databases.get(val.alias)
            if not db:
                continue
            queries, val.qps = pop_queries(db.alias)
            if val.max_qps < val.qps:
                val.max_qps = val.qps
                val.max_qps_time = self.exec_time

            if db.clear_threshold and val.current_connections > db.clear_threshold:
                if db.active_connection_timeout:
                    self.clear_invalid_connections(
                        using=val.alias, timeout=db.active_connection_timeout, include_active=True, include_idle=False)
                if db.idle_connection_timeout:
                    self.clear_invalid_connections(
                        using=val.alias, timeout=db.idle_connection_timeout, include_active=False, include_idle=True)

            val.used_space = self.get_db_size(val.alias)
            val.server_used_space = self.get_db_server_size(val.alias)
            val.server_connections = self.get_db_server_connections(db)
            val.server_connections_limit = self.get_db_max_connections(db.alias)
            val.connections = self.get_db_connections(db, val.connections)
            val.current_connections = len(val.connections)
            val.active_connections = len([conn for conn in val.connections if conn.active])

            monitors.append(DatabaseMonitor(
                time=self.current_time,
                task_settings=self.task_settings,
                database_id=val.id,
                used_space=val.used_space,
                server_used_space=val.server_used_space,
                active_connections=val.active_connections,
                current_connections=val.current_connections,
                server_connections=val.server_connections,
                queries_num=queries,
                qps=val.qps
            ))
            db_values.append(val)
        DatabaseMain(data=db_values, method='put')()
        DatabaseMonitor.objects.bulk_create(monitors)


class CacheMonitorTask(Task):
    @classmethod
    def get_cache_size(cls, using: str) -> int:
        from utilmeta.util.common import sys_deployable, get_redis_info
        from utilmeta.conf import config
        cache = config.caches[using]
        if cache.type == 'db':
            return DatabaseMonitorTask.get_db_size(using)
        elif cache.type == 'file':
            loc = cache.location
            return os.path.getsize(loc)
        elif cache.type == 'redis':
            info = get_redis_info(using)
            return info.get('used_memory', 0)
        elif cache.type == 'memcached':
            if sys_deployable:
                # echo only apply to unix systems
                try:
                    host, port = cache.location.split(':')
                    cmd = "echo \'stats\' | nc - w 1 %s %s | awk \'$2 == \"bytes\" { print $3 }\'" % (host, port)
                    res = os.popen(cmd).read()
                    return int(res)
                except (OSError, TypeError):
                    return 0
        return 0

    def __call__(self, *args, **kwargs):
        # from utilmeta.util.log import pop_queries
        monitors = []
        for val in CacheList(query=dict(service=config.name)).serialize():
            val: CacheList.schema
            cache = config.caches.get(val.alias)
            if not cache or not val.total_connections:
                continue
            monitors.append(CacheMonitor(
                time=self.current_time,
                task_settings=self.task_settings,
                cache_id=val.id,
                used_memory=val.used_memory,
                current_connections=val.current_connections,
                total_connections=val.total_connections,
                qps=val.qps
            ))
        CacheMonitor.objects.bulk_create(monitors)


class ServerMonitorAggregateTask(Task):
    module = ServerList

    def __init__(self, source_layer: int = 0, **kwargs):
        self.source_layer = source_layer
        self.layer = source_layer + 1
        kwargs.update(source_layer=source_layer)
        super().__init__(**kwargs)

    def __call__(self, data: module.model):
        base = MetaQuerySet(model=ServerMonitor).filter(server=data)

        query = base.filter(layer=self.source_layer)
        start = base.filter(task_settings=self.task_settings).first()
        if start:
            query = query.filter(time__gt=start.time)

        if not query.exists():
            return
        fields = [
            ServerMonitor.cpu_percent,
            ServerMonitor.memory_percent,
            ServerMonitor.disk_percent,
            ServerMonitor.file_descriptors,
            ServerMonitor.active_net_connections,
            ServerMonitor.total_net_connections,
            ServerMonitor.load_index,
        ]
        ServerMonitor.objects.create(
            task_settings=self.task_settings,
            server=data,
            time=self.exec_time,
            layer=self.layer,
            **query.aggregate(
                **{get_field_name(field): exp.Avg(get_field_name(field)) for field in fields}
            )
        )


class SessionTask(Task):
    def __call__(self, *args, **kwargs):
        interval = (self.interval or 0) + config.task.min_interval
        current = self.current_time
        logs = ServiceLog.objects.filter(
            log__version__instance__service=config.name,
            log__time__gte=current - timedelta(seconds=interval),
        )

        if config.session and config.session.use_db:
            base = logs.exclude(session=None)
            case = exp.Case(*[exp.When(
                    pk=val['session_id'], then=val['last_activity'])
                    for val in base.values('session_id').annotate(last_activity=exp.Max('log__time'))])
            Session.objects.filter(logs__in=base).update(last_activity=case)

        if config.auth.UserModel and config.auth.last_activity_field:
            base = logs.exclude(user_id=None)
            users = list(set(base.values_list('user_id', flat=True)))
            case = exp.Case(*[exp.When(
                    pk=val['user_id'], then=val['last_activity'])
                    for val in base.values('user_id').annotate(last_activity=exp.Max('log__time'))])
            MetaQuerySet(model=config.auth.UserModel).filter(
                pk__in=users).update(
                **{config.auth.last_activity_field: case}
            )


class ClearTask(Task):
    def __call__(self, *args, **kwargs):
        if config.session and config.session.use_db:
            Session.objects.exclude(
                expiry_time__gt=self.current_time,
                delete_time=None
            ).delete()

        if config.log.volatile_maintain:
            BaseLog.objects.filter(
                time__lt=self.exec_time - timedelta(seconds=config.log.volatile_maintain),
                volatile=True
            ).delete()

        if config.log.maintain:
            BaseLog.objects.filter(
                time__lt=self.exec_time - timedelta(seconds=config.log.maintain),
            ).delete()

        if config.alert and config.alert.maintain:
            AlertLog.objects.filter(
                latest_time__lt=self.exec_time - timedelta(seconds=config.alert.maintain)
            ).delete()
            AlertType.objects.filter(alert_logs=None).delete()
            # clear unrelated types

        if config.monitor.worker_monitor_maintain:
            WorkerMonitor.objects.filter(
                time__lt=self.exec_time - timedelta(seconds=config.monitor.worker_monitor_maintain)
            ).delete()

        if config.monitor.server_monitor_maintain:
            ServerMonitor.objects.filter(
                time__lt=self.exec_time - timedelta(seconds=config.monitor.server_monitor_maintain)
            ).delete()

            InstanceMonitor.objects.filter(
                time__lt=self.exec_time - timedelta(seconds=config.monitor.server_monitor_maintain)
            ).delete()

        if config.monitor.data_monitor_maintain:
            DataMonitor.objects.filter(
                time__lt=self.exec_time - timedelta(seconds=config.monitor.data_monitor_maintain)
            ).delete()

        if config.monitor.db_monitor_maintain:
            DatabaseMonitor.objects.filter(
                time__lt=self.exec_time - timedelta(seconds=config.monitor.db_monitor_maintain)
            ).delete()

        if config.monitor.cache_monitor_maintain:
            CacheMonitor.objects.filter(
                time__lt=self.exec_time - timedelta(seconds=config.monitor.cache_monitor_maintain)
            ).delete()

        if config.ops.user_aggregate_maintain:
            UserAggregate.objects.filter(
                time__lt=self.exec_time - timedelta(seconds=config.ops.user_aggregate_maintain)
            ).delete()

        if config.ops.hourly_aggregate_maintain:
            TaskAggregate.objects.filter(
                layer=0,
                time__lt=self.exec_time - timedelta(seconds=config.ops.hourly_aggregate_maintain)
            ).delete()
            ServiceAggregate.objects.filter(
                layer=0,
                time__lt=self.exec_time - timedelta(seconds=config.ops.hourly_aggregate_maintain)
            ).delete()

        if config.ops.daily_aggregate_maintain:
            TaskAggregate.objects.filter(
                layer=1,
                time__lt=self.exec_time - timedelta(seconds=config.ops.daily_aggregate_maintain)
            ).delete()
            ServiceAggregate.objects.filter(
                layer=1,
                time__lt=self.exec_time - timedelta(seconds=config.ops.daily_aggregate_maintain)
            ).delete()

        if config.ops.monthly_aggregate_maintain:
            TaskAggregate.objects.filter(
                layer=2,
                time__lt=self.exec_time - timedelta(seconds=config.ops.monthly_aggregate_maintain)
            ).delete()
            ServiceAggregate.objects.filter(
                layer=2,
                time__lt=self.exec_time - timedelta(seconds=config.ops.monthly_aggregate_maintain)
            ).delete()

        if config.task and config.task.preserve_events:
            events = set()
            for settings in TaskSettings.objects.all():
                events.update(list(TaskEvent.objects.filter(
                    task=settings, volatile=True,
                    exec_time__lt=self.exec_time - timedelta(seconds=config.task.volatile_event_maintain),
                ).order_by('-exec_time')[config.task.preserve_events:].values_list('pk', flat=True)))

                if config.task.max_preserve_events:
                    events.update(list(TaskEvent.objects.filter(
                        task=settings,
                        exec_time__lt=self.exec_time - timedelta(seconds=config.task.volatile_event_maintain),
                    ).order_by('-exec_time')[config.task.max_preserve_events:].values_list('pk', flat=True)))

            events.update(list(TaskEvent.objects.filter(
                exec_time__lt=self.exec_time - timedelta(seconds=config.task.event_maintain)
            ).values_list('pk', flat=True)))

            TaskEvent.objects.filter(pk__in=events).delete()

        Worker.objects.filter(
            connected=False
        ).delete()
