
class Patcher:
    """
    Patch key and function, needed to be call as early as possible
    """
    def __init__(self, *patches: str):
        for key in patches:
            func = getattr(self, key, None)
            if func:
                func()

    @classmethod
    def gevent(cls, subprocess: bool = False):
        from gevent import monkey
        monkey.patch_all(subprocess=subprocess)

    @classmethod
    def gevent_postgresql(cls):
        from psycogreen.gevent import patch_psycopg
        patch_psycopg()
