import os
import sys
import time

import django
from django.core.handlers.wsgi import WSGIHandler
from django.core.handlers.asgi import ASGIHandler
from django.core.management import execute_from_command_line
from utilmeta.util.common import Env, BLUE, RED, http_methods, close_connections, omit
from typing import TYPE_CHECKING
from django.urls import re_path
from utilmeta.util.base import Util
from utilmeta.util.error import Error

if TYPE_CHECKING:
    from utilmeta.conf import Config


class UtilMeta(Util):
    def __init__(self, config: 'Config'):
        """
            ! THERE MUST BE NO IMPORT BEFORE THE CONFIG IS ASSIGNED PROPERLY !
            if there is, the utils will use the incorrect initial settings Config and cause the
            runtime error (hard to find)
        """
        if not config.resolved:
            raise TypeError(f'config not net')
        super().__init__(locals())
        self.document = None
        self.root = None
        # mutual hold
        if not config.utilmeta:
            try:
                config.utilmeta = self
            except AttributeError:
                pass

        self.config = config
        self.root_routes = []
        self._loaded = False

        self.background = False
        self.asynchronous = None

    @property
    def loaded(self):
        return self._loaded

    @classmethod
    def load_service(cls, background: bool = False) -> 'UtilMeta':
        """
        This function is often called by a raw process who run in the project (cwd) but have not configured
        :return:
        """
        from utilmeta.conf import config
        from utilmeta.bin.meta import MetaManagement
        if not config.resolved:
            srv = MetaManagement().service
            srv.load_config()
            config = srv.config
        if config.utilmeta:
            service = config.utilmeta
        else:
            service = cls(config=config)
        if service.loaded:
            return service
        service.background = background
        service.setup()
        # config.load_metadata()
        return service

    def resolve(self):
        from utilmeta import conf
        config = self.config

        if not conf.BACKGROUND and not self.background and not self.config.production:
            # not self.background, which is only set in run()
            from utilmeta.patch import Patcher
            Patcher(*config.deploy.get_patches())

        from utilmeta.conf import Config
        assert isinstance(config, Config), f"UtilMeta config must be Config instance, got {config}"
        from utilmeta import conf
        conf.config = config
        # set config before other import
        if hasattr(config.module, Env.ROOT_API):
            from utilmeta.core.api import API
            root = getattr(config.module, Env.ROOT_API)
            assert issubclass(root, API), f'UtilMeta root_api must be subclass of API, got {root}'
            return root
        else:
            os.environ[Env.SETTINGS] = config.settings_module
            # not using setdefault to prevent IDE set the wrong value by default
            django.setup(set_prefix=False)
            root = config.load(background=self.background)
            from utilmeta.core.api import API
            # import API after setup config and load models
            # import API will load almost ALL utils
            assert issubclass(root, API) and root is not API,\
                f'UtilMeta root_api must be subclass of API, got {root}'
            urls = self.generate_urls(root)
            setattr(config.module, Env.URL, urls)
            return root

    def check(self, internal: bool = False):
        if not self.config.ops:
            return True
        if not internal and not self.config.deploy.check_deployed:
            return True
        from utilmeta.ops.sdk import ClusterSDK

        retries = self.config.deploy.check_deployed_max_reties
        wait = self.config.deploy.check_deployed_retry_interval
        ops_api = self.config.ops_api
        for i in range(retries):
            try:
                resp = ClusterSDK(base_url=ops_api, timeout=self.config.deploy.check_deployed_timeout).status()
                status = resp.status
            except TimeoutError:
                status = 504
            else:
                if resp.success and resp.valid(service=self.config.name):
                    if internal:
                        return True
                    if self.config.production:
                        print(f'UtilMeta service deployed successfully,'
                              f' view your service at {BLUE % self.config.public_origin}')
                    return
            msg = f'UtilMeta service check failed, response {status}'
            if i == retries - 1:
                raise RuntimeError(msg)
            else:
                if not internal:
                    print(msg)
                    print(f'Waiting for next ({i+2}/{retries}) retry in {wait} seconds...')
                import time
                time.sleep(wait)

    def generate(self):
        from . import __version__, __spec_version__
        if self.root:
            return
        root = self.resolve()
        root.make_root()
        # import Schema after resolve
        from utilmeta.core.sdk import DocumentSchema
        self.config.app.assign_all()
        self.document = DocumentSchema(
            name=self.config.name,
            description=self.config.description,
            version=str(self.config.version),
            base_url=self.config.public_base_url,
            api=root.generate(root=True),
            models=self.config.app.generate(),
            meta=DocumentSchema.MetaData(
                utilmeta_version=__version__,
                spec_version=__spec_version__
            ),
        )
        # Util.insert_root(root)
        self.root = root
        self.root_routes = self.get_routes(root)
        self._loaded = True

    @property
    def is_worker(self):
        return os.getpid() != self.config.deploy.main_pid
        # import psutil
        # return psutil.Process(os.getpid()).children()

    @property
    def worker_load(self):
        if self.background:
            return False
        if self.config.production:
            return self.config.deploy.worker_load_app
        return self.is_worker

    def setup(self):
        """
        1. development: only load by master
        2. production1: master load & fork
            master call setup() and get WSGIHandler()
        3. production2: worker_load_apps

        4. tasks: Process -> new Process (load_service)
        :return:
        """
        if self.is_worker:
            if self.worker_load:
                self.generate()
                with self.config.deploy.acquire_worker_lock('setup') as lock:
                    if lock.acquired:
                        self.load()
                    if not self.background:
                        omit(self.config.deploy.worker_post_fork)()
            return
        print('setting up %s...' % ('tasks' if self.background else 'service'))
        # self.resolve(setup_only=True)
        if not self.worker_load:
            self.load()
        # do not introduce db connections here

        if self.background:
            print(f'Tasks for service: <{self.config.name}> successfully initialized')
            return

        if self.config.production and not self.worker_load:
            # call from wsgi (not shell)
            self.config.deploy.wsgi_server.apply_fork()
            # self.config.monitor.get_worker_task(master=True).start(block=False)
            # forked new Process inheriting the memory of parent process will occur error when setting attrs
            # self._lock_all()

        if self.config.deploy.deployed_callback:
            self.config.deploy.deployed_callback()
        if self.config.master_cycle_required:
            omit(self.start_master_task)()
        if self.config.production and not self.is_worker:
            close_connections()
        print(f'service: <{self.config.name}> successfully initialized')

    def start_master_task(self):
        # run master with worker cycle
        if not self.config.monitor.worker_monitor_interval:
            return
        time.sleep(self.config.monitor.worker_monitor_interval)
        self.config.monitor.get_worker_task(master=True).start(block=True)

    def wsgi(self):
        try:
            self.asynchronous = False
            self.setup()
        except Exception as e:
            print(RED % f'Load service with {e.__class__.__name__}:')
            print(RED % Error().variable_info)
            raise Error().throw()
        return WSGIHandler()

    def asgi(self):
        try:
            self.asynchronous = True
            self.setup()
        except Exception as e:
            print(RED % f'Load service with {e.__class__.__name__}:')
            print(RED % Error().variable_info)
            raise Error().throw()
        return ASGIHandler()

    def run(self):
        try:
            self.background = True
            self.load()
            self.config.task.run()
        except Exception as e:
            print(RED % f'Run tasks with {e.__class__.__name__}:')
            print(RED % Error().variable_info)
            raise Error().throw()

    def load(self):
        # import logging
        self.generate()
        self.load_cache()
        self.load_ops()
        # self.load_cluster()

    def load_ops(self):
        if not self.config.ops:
            return
        print('loading operations data...')
        from utilmeta.ops.load import Loader
        Loader(self, background=self.background, asynchronous=self.asynchronous)()

    def load_cache(self):
        config = self.config.auto_cache
        if not config:
            return
        print('loading cache data...')
        try:
            config.load_models()
            if config.model_cache_cls:
                config.model_cache_cls.init_service()
            for cache in config.caches:
                if config.init_load:
                    cache.load_data()
        except Exception as e:
            if config.fail_silently:
                print(f'load cache data failed with error: {e}')
            else:
                raise e

    def load_proxy(self):
        if not self.config.cluster:
            return
        config = self.config.cluster.proxy_config
        if not config:
            return
        root = self.root or self.resolve()
        root.load_proxy()
        if not config.native:
            if config.representative_only:
                if not self.config.cluster_manager.is_representative:
                    return
            self.config.cluster.deploy(routine=True)

    def get_routes(self, root=None, api_only: bool = False):
        root = root or self.root
        if not root:
            self.generate()
            root = self.root
        api_routes = set(root.routes).difference(http_methods)
        deploy_routes = self.config.deploy.root_routes
        if self.config.root_url:
            if api_only:
                return [self.config.root_url]
            return deploy_routes
        inter = api_routes.intersection(deploy_routes)
        if inter:
            raise ValueError(f'Service root_routes conflict at {inter}')
        if api_only:
            return api_routes
        return sorted([*api_routes, *self.config.deploy.root_routes])

    def generate_urls(self, root=None):
        root = root or self.root
        if not root:
            self.generate()
            root = self.root
        api_path = re_path(self.config.root_pattern, root.api())
        if self.config.root_url:
            return [api_path, *self.config.deploy.url_resolver, self.config.deploy.default_handler]
        return [*self.config.deploy.url_resolver, api_path]

    def serve(self):
        argv = [sys.argv[0], 'runserver', self.config.host] if len(sys.argv) == 1 else sys.argv
        migrate_all = False

        if argv[1] == 'migrate':
            if argv[-1] == '*':
                migrate_all = True
                argv.pop()
            else:
                sub_pkg = set([p for p in [b + c for a, b, c in os.walk(os.getcwd())][0] if not p.startswith('.')])
                if sub_pkg.issubset(argv):
                    # adapt to linux input: use [meta migrate *] will pass all packages in this dir
                    migrate_all = True
                    argv = [argv[0], 'migrate']

        self.resolve()
        try:
            if migrate_all:
                execute_from_command_line(argv)
                for app in self.config.app_labels:
                    db = self.config.get_db(app)
                    for d in db.dbs:
                        # include master and replicas
                        if d.alias == 'default':
                            continue
                        execute_from_command_line([*argv, app, f'--database={d.alias}'])
                return
            execute_from_command_line(argv)
        except Exception as e:
            print(f'Execute command: {argv} failed with error: {Error(e).full_info}')
            exit(1)
