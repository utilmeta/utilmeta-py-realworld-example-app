import os
from typing import Dict, Any, Type, TypeVar
from utilmeta.util.common import SEG, PY, class_func, return_type, \
    assign_return_type, import_util, INIT_FILE
from .parser import Options
from utilmeta.conf import config
T = TypeVar('T')


class AdaptorMeta(type):
    def __init__(cls, _name: str, bases: tuple, attrs: Dict[str, Any], **kwargs):
        super().__init__(_name, bases, attrs)
        if not bases:
            return

        if not issubclass(cls, Adaptor):
            raise TypeError('AdaptorMeta instances should inherit from Adaptor')
        for base in bases:
            if not issubclass(base, Adaptor):
                raise TypeError(f'Adaptor subclass should only inherit from base Adaptor, got: {base}')
            if base is not Adaptor and not base.__route__:
                if not cls.__route__:
                    raise ValueError('Adaptor subclass inherit from base Adaptor should define name '
                                     f'with class {cls.__name__}({base.__name__}, name=<name>):')

        cls.__kwargs__ = kwargs
        methods = {}
        for key, val in attrs.items():
            if key.startswith(SEG) and key.endswith(SEG):
                continue
            if not class_func(val):
                continue
            if isinstance(val, (staticmethod, classmethod)):
                continue
            if cls.__route__:
                for base in bases:
                    base: Type[Adaptor]
                    method = base.__methods__.get(key)
                    if method:
                        if not return_type(val):
                            assign_return_type(val, method.return_type)
                        continue

            methods[key] = config.preference.function_parser_cls(val, from_class=cls, options=cls.__options__)
        cls.__methods__ = methods
        for key, method in cls.__methods__.items():
            setattr(cls, key, method.wrapper)


class Adaptor(metaclass=AdaptorMeta):
    __router__: Dict[str, Type['Adaptor']] = {}
    __route__: str = None
    __options__: Options = Options()

    def __init_subclass__(cls, **kwargs):
        base = cls.__base__
        if not issubclass(base, Adaptor):
            raise TypeError(f'Adaptor subclasses should inherit only from Adaptor, got {base}')
        name = kwargs.get('name')
        if name:
            cls.__route__ = name
            cls.__router__[name] = cls
        if base is not Adaptor and not base.__route__:
            if not cls.__route__:
                raise ValueError('Adaptor subclass inherit from base Adaptor should define name '
                                 f'with class {cls.__name__}({base.__name__}, name=<name>):')

    @classmethod
    def get(cls: Type[T], name: str) -> Type[T]:
        if name not in cls.__router__:
            raise ValueError(f'Invalid adaptor name: {name}, must in {list(cls.__router__)}')
        return cls.__router__[name]

    @classmethod
    def load_implementations(cls, *dirs):
        for dir in dirs:
            if os.path.exists(dir):
                path = dir
            else:
                path = import_util(dir).__path__[0]
            root, dirs, files = list(os.walk(path))[0]
            for file in files:
                if file.endswith(PY):
                    if file == INIT_FILE:
                        continue
                    if os.path.exists(dir):
                        import_path = os.path.join(path, file)
                    else:
                        import_path = f'{dir}.{file.rstrip(PY)}'
                    try:
                        import_util(import_path)
                    except Exception as e:
                        from .error import Error
                        import warnings
                        warnings.warn(f'Load implementation: {file} failed with error: {Error(e).full_info}')
