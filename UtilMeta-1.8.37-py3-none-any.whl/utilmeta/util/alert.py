from utilmeta.util.base import Util
from utilmeta.util.common import exp, AlertLevel, LogLevel, ignore_errors, get_interval, \
    COMMON_ERRORS, Attr, time_now, AlertCategory, import_util, ProblemTarget, get_system_fds
from utilmeta.types import *
from datetime import timedelta
from utilmeta.conf import config
import os
if not config.resolved:
    raise ImportError('Utils should load after service resolve')


class Alert(Util):
    Level = AlertLevel
    Category = AlertCategory

    def get_instances(self):
        from utilmeta.conf import config
        from utilmeta.ops.module.service import InstanceMain
        from utilmeta.ops.models.service import Server
        if self.instance:
            return InstanceMain.filter(pk=config.deploy.instance_id)
        if self.server:
            return InstanceMain.filter(server=Server.current())
        return InstanceMain.filter(service_id=config.name)

    def get_logs(self):
        from utilmeta.conf import config
        from utilmeta.ops.module.log import LogList
        from utilmeta.ops.models.service import ServiceInstance, Server
        if self.instance:
            return LogList.filter(version__instance=ServiceInstance.current())
        if self.server:
            return LogList.filter(version__instance__server=Server.current())
        return LogList.filter(version__instance__service_id=config.name)

    def get_servers(self):
        from utilmeta.conf import config
        from utilmeta.ops.module.service import ServerList
        from utilmeta.ops.models.service import ServiceInstance
        if self.server:
            return ServerList.filter(pk=ServiceInstance.current().server.pk)
        return ServerList.filter(instances__service_id=config.name).distinct()

    def get_databases(self):
        from utilmeta.conf import config
        from utilmeta.ops.module.service import DatabaseMain
        from utilmeta.ops.models.service import Server
        if self.server:
            return DatabaseMain.filter(server=Server.current())
        return DatabaseMain.filter(service_id=config.name)

    def get_caches(self):
        from utilmeta.conf import config
        from utilmeta.ops.module.service import CacheList
        from utilmeta.ops.models.service import Server
        if self.server:
            return CacheList.filter(server=Server.current())
        return CacheList.filter(service_id=config.name)

    @property
    @ignore_errors(default=0)
    def rps(self) -> float:
        return float(self.get_instances().aggregate(v=exp.Sum('req_per_sec'))['v'] or 0)
    rps.fget.__category__ = AlertCategory.load_uprush
    rps.fget.__target__ = ProblemTarget.service

    @property
    @ignore_errors(default=0)
    def fds(self) -> int:
        return get_system_fds()

    fds.fget.__category__ = AlertCategory.resource_saturated
    fds.fget.__target__ = ProblemTarget.server

    @property
    @ignore_errors(default=0)
    def cpu_percent(self) -> float:
        import psutil
        return psutil.cpu_percent(interval=config.monitor.cpu_percent_interval)

    cpu_percent.fget.__category__ = AlertCategory.resource_saturated
    cpu_percent.fget.__target__ = ProblemTarget.server

    @property
    @ignore_errors(default=0)
    def memory_percent(self) -> float:
        import psutil
        mem = psutil.virtual_memory()
        return 100 * mem.used / mem.total

    memory_percent.fget.__category__ = AlertCategory.resource_saturated
    memory_percent.fget.__target__ = ProblemTarget.server

    @property
    @ignore_errors(default=0)
    def used_memory(self) -> float:
        import psutil
        mem = psutil.virtual_memory()
        return mem.used

    used_memory.fget.__category__ = AlertCategory.resource_saturated
    used_memory.fget.__target__ = ProblemTarget.server

    @property
    @ignore_errors(default=0)
    def disk_percent(self) -> float:
        import psutil
        disk = psutil.disk_usage(os.getcwd())
        return 100 * disk.used / disk.total

    disk_percent.fget.__category__ = AlertCategory.resource_saturated
    disk_percent.fget.__target__ = ProblemTarget.server

    @classmethod
    def db_connections(cls, alias: str = 'default') -> property:
        @property
        @ignore_errors(default=0)
        def wrapper(self: Alert) -> float:
            db = self.get_databases().filter(alias=alias).first()
            if not db:
                return 0
            return db.current_connections

        wrapper.fget.kwargs = dict(alias=alias)
        wrapper.fget.__name__ = 'db_connections_%s' % alias
        wrapper.fget.__origin__ = cls.db_connections.__name__
        wrapper.fget.__category__ = AlertCategory.resource_saturated
        wrapper.fget.__target__ = ProblemTarget.database
        return wrapper

    @classmethod
    def db_qps(cls, alias: str = 'default') -> property:
        @property
        @ignore_errors(default=0)
        def wrapper(self: Alert) -> float:
            db = self.get_databases().filter(alias=alias).first()
            if not db:
                return 0
            return db.qps

        wrapper.fget.kwargs = dict(alias=alias)
        wrapper.fget.__name__ = 'db_qps_%s' % alias
        wrapper.fget.__origin__ = cls.db_qps.__name__
        wrapper.fget.__category__ = AlertCategory.load_uprush
        wrapper.fget.__target__ = ProblemTarget.database
        return wrapper

    @classmethod
    def db_server_connections_percent(cls, alias: str = 'default') -> property:
        @property
        @ignore_errors(default=0)
        def wrapper(self: Alert) -> float:
            from utilmeta.ops.models.service import DatabaseStorage
            db: DatabaseStorage = self.get_databases().filter(alias=alias).first()
            if not db or not db.server_connections_limit:
                return 0
            return round(db.server_connections * 100 / db.server_connections_limit, 2)

        wrapper.fget.kwargs = dict(alias=alias)
        wrapper.fget.__name__ = 'db_server_connections_percent_%s' % alias
        wrapper.fget.__origin__ = cls.db_server_connections_percent.__name__
        wrapper.fget.__category__ = AlertCategory.resource_saturated
        wrapper.fget.__target__ = ProblemTarget.database
        return wrapper

    @classmethod
    def cache_qps(cls, alias: str = 'default') -> property:
        @property
        @ignore_errors(default=0)
        def wrapper(self: Alert) -> float:
            cache = self.get_caches().filter(alias=alias).first()
            if not cache:
                return 0
            return cache.qps

        wrapper.fget.kwargs = dict(alias=alias)
        wrapper.fget.__name__ = 'cache_qps_%s' % alias
        wrapper.fget.__origin__ = cls.cache_qps.__name__
        wrapper.fget.__category__ = AlertCategory.load_uprush
        wrapper.fget.__target__ = ProblemTarget.cache
        return wrapper

    @classmethod
    def cache_memory_percent(cls, alias: str = 'default') -> property:
        @property
        @ignore_errors(default=0)
        def wrapper(self: Alert) -> float:
            from utilmeta.ops.models.service import CacheStorage
            cache: CacheStorage = self.get_caches().filter(alias=alias).first()
            if not cache or not cache.memory_limit:
                return 0
            return round(100 * cache.used_memory / cache.memory_limit, 2)

        wrapper.fget.kwargs = dict(alias=alias)
        wrapper.fget.__name__ = 'cache_memory_percent_%s' % alias
        wrapper.fget.__origin__ = cls.db_qps.__name__
        wrapper.fget.__category__ = AlertCategory.resource_saturated
        wrapper.fget.__target__ = ProblemTarget.cache
        return wrapper

    @property
    @ignore_errors(default=0)
    def net_connections(self) -> int:
        import psutil
        return len(psutil.net_connections())

    net_connections.fget.__category__ = AlertCategory.resource_saturated
    net_connections.fget.__target__ = ProblemTarget.server

    @property
    @ignore_errors(default=0)
    def idle_net_connections(self) -> int:
        import psutil
        return len([c for c in psutil.net_connections() if c.status == 'CLOSE_WAIT'])

    idle_net_connections.fget.__category__ = AlertCategory.resource_saturated
    idle_net_connections.fget.__target__ = ProblemTarget.server

    @property
    @ignore_errors(default=0)
    def error_requests_percent(self) -> float:
        return round(float(self.get_instances().aggregate(
            v=exp.Sum('errors') / exp.Sum('requests'))['v'] or 0) * 100, 2)
    error_requests_percent.fget.__category__ = AlertCategory.service_downgrade
    error_requests_percent.fget.__target__ = ProblemTarget.service

    @classmethod
    def error_percent_in_requests(cls, requests: int = 100) -> property:
        @property
        @ignore_errors(default=0)
        def wrapper(self: Alert) -> float:
            from utilmeta.ops.module.log import LogList
            values = self.get_logs().order_by('-time')[:requests].values_list('pk', flat=True)
            if not values:
                return 0
            return round(100 * LogList.filter(pk__in=values, level=LogLevel.ERROR).count() / len(values), 2)

        wrapper.fget.kwargs = dict(requests=requests)
        wrapper.fget.__name__ = 'error_percent_in_%s_requests' % requests
        wrapper.fget.__origin__ = cls.error_percent_in_requests.__name__
        wrapper.fget.__category__ = AlertCategory.service_downgrade
        wrapper.fget.__target__ = ProblemTarget.service
        return wrapper

    @classmethod
    def error_percent_in_seconds(cls, seconds: int = 3600) -> property:
        @property
        @ignore_errors(default=0)
        def wrapper(self: Alert) -> float:
            base = self.get_logs().order_by('-time').filter(time__gte=time_now() - timedelta(seconds=seconds))
            count = base.count()
            if not count:
                return 0
            return round(100 * base.filter(level=LogLevel.ERROR).count() / count, 2)

        wrapper.fget.kwargs = dict(seconds=seconds)
        wrapper.fget.__name__ = 'error_percent_in_%s_seconds' % seconds
        wrapper.fget.__origin__ = cls.error_percent_in_seconds.__name__
        wrapper.fget.__category__ = AlertCategory.service_downgrade
        wrapper.fget.__target__ = ProblemTarget.service
        return wrapper

    @classmethod
    def warn_percent_in_requests(cls, requests: int = 100) -> property:
        @property
        @ignore_errors(default=0)
        def wrapper(self: Alert) -> float:
            from utilmeta.ops.module.log import LogList
            values = self.get_logs().order_by('-time')[:requests].values_list('pk', flat=True)
            if not values:
                return 0
            return round(100 * LogList.filter(pk__in=values, level=LogLevel.WARN).count() / len(values), 2)

        wrapper.fget.kwargs = dict(requests=requests)
        wrapper.fget.__name__ = 'warn_percent_in_%s_requests' % requests
        wrapper.fget.__origin__ = cls.warn_percent_in_requests.__name__
        wrapper.fget.__category__ = AlertCategory.service_downgrade
        wrapper.fget.__target__ = ProblemTarget.service
        return wrapper

    @classmethod
    def warn_percent_in_seconds(cls, seconds: int = 3600) -> property:
        @property
        @ignore_errors(default=0)
        def wrapper(self: Alert) -> float:
            base = self.get_logs().order_by('-time').filter(time__gte=time_now() - timedelta(seconds=seconds))
            count = base.count()
            if not count:
                return 0
            return round(100 * base.filter(level=LogLevel.WARN).count() / count, 1)

        wrapper.fget.kwargs = dict(seconds=seconds)
        wrapper.fget.__name__ = 'warn_percent_in_%s_seconds' % seconds
        wrapper.fget.__origin__ = cls.warn_percent_in_seconds.__name__
        wrapper.fget.__category__ = AlertCategory.service_downgrade
        wrapper.fget.__target__ = ProblemTarget.service
        return wrapper

    @classmethod
    def deserialize(cls, settings) -> 'Alert':
        from utilmeta.ops.models.log import AlertSettings
        assert isinstance(settings, AlertSettings)
        if settings.service.name != config.name:
            raise ValueError(f'Alert service: {settings.service.name} is not current service: {config.name}')
        if not settings.custom:
            raise ValueError(f'Alert: {settings.name} from datasource cannot be deserialize')

        alert_cls = import_util(settings.index_class)
        if settings.index_params is None:
            index = getattr(alert_cls, settings.index_name)
        else:
            index = getattr(alert_cls, settings.index_name)(**settings.index_params)

        return alert_cls(
            index=index, name=settings.name,
            server=bool(settings.server),
            instance=bool(settings.instance),
            threshold=settings.threshold,
            level=settings.level,
            exceed=settings.exceed,
        )

    def __init__(self, index: Union[property, str], *,
                 name: str = None,
                 # TARGET --
                 instance: bool = False,
                 server: bool = False,
                 # --
                 level: str = config.alert.default_level if config.alert else AlertLevel.WARNING,
                 threshold: Union[int, float] = None,
                 exceed: bool = True,
                 disabled: bool = False,
                 min_times: int = config.alert.index_trigger_min_times,
                 compress_window: Union[float, timedelta] = config.alert.default_compress_window,
                 ):

        if isinstance(index, str):
            index = getattr(self.__class__, index)
        assert isinstance(index, property)
        # assert isinstance(type, _type)
        assert level.upper() in AlertLevel.gen()
        if threshold:
            assert isinstance(threshold, (int, float)), \
                f'Alert threshold must be an int or float object, got: {threshold}'
        if instance and server:
            raise ValueError(f'Alert target can only choose one of instance or server')
        self.index_getter = getattr(index, 'fget')
        self.level = level.upper()
        self.index_name = getattr(self.index_getter, Attr.ORIGIN, self.index_getter.__name__)
        self.category = getattr(self.index_getter, Attr.CATEGORY, AlertCategory.custom)
        if self.category not in AlertCategory.gen():
            self.category = AlertCategory.custom
        self.target = getattr(self.index_getter, Attr.TARGET, None)
        self.min_times = min_times

        self.compress_window = get_interval(compress_window, null=True)
        self.threshold = threshold
        self.exceed = exceed
        self.params = getattr(self.index_getter, 'kwargs', None)
        if self.params and not isinstance(self.params, dict):
            raise TypeError(f'Alert index: {self.index_name} params must be a dict, got {self.params}')

        self.name = name or self.default_name
        index = self.index_name     # use name instead or property to init super for better repr

        super().__init__(locals())
        # self.trigger_callback = trigger_callback
        self.instance = instance
        self.server = server
        self.disabled = disabled
        self.task = None
        # self.expression = expression

    @property
    def class_path(self):
        return f'{self.__class__.__module__}.{self.__class__.__name__}'

    @property
    def label(self):
        return f'{self.__class__.cls_path}.{self.index_name}'

    @property
    def default_name(self):
        index = self.full_index_name
        note = '>' if self.exceed else '<'
        return f'{index} {note} {self.threshold}'

    @property
    def full_index_name(self):
        index = self.index_name
        if self.params:
            index += '(%s)' % ', '.join(f'{key}={val}' for key, val in self.params.items())
        return index

    @property
    def subcategory(self):
        return f'{self.index_name}_%s' % ('exceed' if self.exceed else 'low')

    @property
    def ident(self):
        return f'{self.subcategory}:{self.threshold}'

    @ignore_errors(default=True)    # return true if function failed
    def trigger(self) -> Tuple[bool, Optional[float]]:
        index = None
        if self.threshold:
            index = self.index_getter(self)
            trigger = index > self.threshold if self.exceed else index < self.threshold
        else:
            try:
                index = self.index_getter(self)
                trigger = bool(index)
            except COMMON_ERRORS:
                trigger = True
        return trigger, index

    @property
    def alert_settings(self):
        from utilmeta.ops.models.log import AlertSettings
        return AlertSettings.get(self.name)

    @property
    def alert_type(self):
        from utilmeta.ops.models.log import AlertType
        return AlertType.get(self.ident)

    def generate_type(self):
        from utilmeta.ops.models.log import AlertType
        type = self.alert_type
        if type:
            return type

        settings = self.alert_settings
        if not settings:
            return

        settings_type = AlertType.objects.filter(settings=settings).first()
        if settings_type:
            return settings_type

        return AlertType.objects.create(
            settings=settings,
            category=self.category,
            level=self.level,
            subcategory=self.subcategory,
            service_id=config.name,
            name=self.name,
            ident=self.ident,
            target=self.target,
            min_times=self.min_times,
            compress_window=timedelta(seconds=self.compress_window) if self.compress_window else None
        )

    @classmethod
    @ignore_errors
    def log(cls, *, category: str = AlertCategory.custom,
            level: Union[str, int] = None,
            subcategory: str,
            name: str,
            message: str = '',
            ident: str = None,
            alarm: bool = True,
            trigger: bool = True,
            min_times: int = None,
            threshold: float = None,
            compress_window: timedelta = None,
            trigger_value: Union[int, float] = None,
            trigger_time: datetime = None,
            request: bool = False, task: bool = False,
            server: bool = False, instance: bool = False,
            task_id: str = None, endpoint_id: str = None,
            request_user_id: str = None, request_ip: str = None,
            data: dict = None
            ):

        """
        Trigger Alert from request
        :return:
        """
        from utilmeta.conf import config
        if not config.ops or not config.alert:
            return

        if category not in AlertCategory.gen():
            category = AlertCategory.custom

        from utilmeta.ops.models.log import AlertType
        from utilmeta.ops.models.log import AlertLog, ServiceLog

        ident = ident or f'{category}.{subcategory}.{name}'
        target = ProblemTarget.service
        if endpoint_id:
            target = ProblemTarget.endpoint
        elif task_id:
            target = ProblemTarget.task

        if min_times is None:
            min_times = {
                AlertCategory.task_error: config.alert.task_error_trigger_min_times,
                AlertCategory.service_downgrade: config.alert.downgrade_trigger_min_times,
                AlertCategory.task_downgrade: config.alert.downgrade_trigger_min_times,
                AlertCategory.service_error: config.alert.service_error_trigger_min_times
            }.get(category, 1)

        if compress_window is None:
            compress_window = config.alert.default_compress_window
        else:
            compress_window = get_interval(compress_window, null=True)

        alert_type = AlertType.objects.filter(ident=ident).first()
        if not alert_type:
            if not trigger:
                # no alert in this type
                return
            alert_type = AlertType.objects.create(
                ident=ident,
                category=category,
                level=level or config.alert.default_level,
                subcategory=subcategory,
                service_id=config.name,
                name=name,
                task_id=task_id,
                endpoint_id=endpoint_id,
                target=target,
                min_times=min_times or 1,
                threshold=threshold,
                compress_window=timedelta(seconds=compress_window) if compress_window else None
            )

        impact_requests = impact_users = impact_ips = None
        if request:
            log: AlertLog = AlertLog.objects.filter(type=alert_type, relieved_time=None).first()
            if log:
                logs = ServiceLog.objects.filter(log__alert=log)
                impact_requests = logs.count() + 1
                impact_users = logs.exclude(user_id=None).exclude(
                    user_id=request_user_id).distinct('user_id').count() + 1
                impact_ips = logs.exclude(ip=request_ip).distinct('ip').count() + 1
            else:
                impact_requests = 1
                impact_users = 1 if request_user_id else 0
                impact_ips = 1 if request_ip else 0

        return cls.save(
            alert_type=alert_type,
            message=message,
            latest_time=trigger_time,
            latest_value=trigger_value,
            alarm=alarm,
            data=data,
            server=server,
            instance=instance,
            task=task,
            trigger=trigger,
            compress_window=compress_window,
            # kwargs
            impact_requests=impact_requests,
            impact_users=impact_users,
            impact_ips=impact_ips
        )

    @classmethod
    def get_cause(cls):
        # get cause of the alert
        return None

    @classmethod
    def save(cls, *, alert_type, message: str,
             latest_time: datetime = None,
             compress_window: float = None,
             server: bool = False, instance: bool = False, task: bool = False,
             latest_value: float = None, data: dict = None,
             trigger: bool = True, alarm: bool = True,
             **kwargs):
        from utilmeta.util.common import exp, exc
        from utilmeta.ops.models.log import AlertLog, VersionLog
        from utilmeta.ops.models.task import TaskInstance
        from utilmeta.ops.models.service import Server, ServiceInstance

        latest_time = latest_time or time_now()
        log: Optional[AlertLog] = None
        if compress_window:
            log = AlertLog.objects.filter(
                type=alert_type, latest_time__gte=latest_time - timedelta(seconds=compress_window)
            ).first()

        base_data = dict(
            type=alert_type,
            relieved_time=None
        )
        if not log:
            log = AlertLog.objects.filter(**base_data).order_by('-time').first()

        if not trigger:
            if log:
                # there is an opening alert for this index and it is now relieved
                if log.relieve():
                    # unstable, not report
                    return
                if config.alert.notify_supervisor(alert_type.level) and alarm:
                    # this alert's level is not enough for supervisor record
                    # so it's not required to notify supervisor
                    cls.notify_supervisor(log)  # notify relieve
            return

        common_data = dict(
            message=message,
            latest_time=latest_time,
            version=VersionLog.current(),
            data=data,
            server=Server.current() if server else None,
            instance=(TaskInstance.current() if task else ServiceInstance.current()) if instance else None,
        )
        common_data.update(kwargs)

        if log:
            try:
                from utilmeta.fields import FloatField
                values = dict(
                    trigger_timesr=exp.Func(exp.F('tigger_times'),
                                            exp.Value(latest_time), function='array_append'),
                    count=exp.F('count') + 1,
                    **base_data,
                    **common_data
                )
                if log.relieved_time:
                    values.update(
                        relieve_times=exp.Func(exp.F('relieve_times'),
                                               exp.Value(log.relieved_time), function='array_append')
                    )

                if latest_value:
                    values.update(
                        trigger_values=exp.Func(exp.F('trigger_values'), exp.Cast(
                            latest_value, output_field=FloatField()), function='array_append'),
                    )
                AlertLog.objects.filter(id=log.pk).update(**values)

            except exc.DatabaseError:
                values = dict(
                    trigger_times=log.trigger_times + [latest_time],
                    count=exp.F('count') + 1,
                    **base_data,
                    **common_data
                )
                if log.relieved_time:
                    values.update(relieve_times=log.relieve_times + [log.relieved_time])

                if latest_value:
                    values.update(trigger_values=log.trigger_values + [latest_value])
                AlertLog.objects.filter(id=log.pk).update(**values)

            log = AlertLog.objects.filter(id=log.pk).first()    # refresh log
        else:
            log = AlertLog.objects.create(
                trigger_times=[latest_time],
                trigger_values=[latest_value] if latest_value else [],
                **base_data,
                **common_data,
            )

        if config.alert.notify_supervisor(alert_type.level) and alarm:
            if config.alert.min_notify_interval and log.latest_alarm_time:
                if (time_now() - log.latest_alarm_time).total_seconds() < config.alert.min_notify_interval:
                    return log

            cls.notify_supervisor(log)
        return log

    @classmethod
    @ignore_errors
    def inform(cls, type: str, message: str, name: str, data: dict = None, event_time: datetime = None):
        event_time = event_time or time_now()
        from utilmeta.ops.module.admin import SupervisorMain
        from utilmeta.ops.schema.action import EventInformSchema
        from utilmeta.ops.sdk import ActionSDK
        for sp in SupervisorMain.filter(
            service_id=config.name, disabled=False
        ):
            sp: SupervisorMain.model
            if not sp.notify_enabled:
                continue

            resp = ActionSDK(to=sp).inform(data=EventInformSchema(
                time=event_time,
                type=type,
                message=message,
                data=data,
                name=name
            ))
            if not resp.success:
                cls.log(
                    subcategory='event_inform_failed', category=AlertCategory.task_error,
                    name=f'event inform failed at supervisor: {sp.pk}',
                    ident=f'event_inform_failed:{sp.pk}', message=resp.message, alarm=False
                )

    @classmethod
    def notify_supervisor(cls, alert_log):
        # report this alert to supervisor
        from utilmeta.ops.module.admin import SupervisorMain
        from utilmeta.ops.models.log import AlertLog
        from utilmeta.ops.schema.action import AlertReportSchema
        from utilmeta.ops.sdk import ActionSDK
        alert_log: AlertLog

        if not config.alert.notify_supervisor(alert_log.type.level):
            # this alert's level is not enough for supervisor record
            # so it's not required to notify supervisor
            return

        for sp in SupervisorMain.filter(
            service_id=config.name, disabled=False
        ):
            sp: SupervisorMain.model
            if not sp.notify_enabled:
                continue

            resp = ActionSDK(to=sp).alert(data=AlertReportSchema(
                level=alert_log.type.level,
                ident=alert_log.type.ident,
                type=alert_log.type.name,
                category=alert_log.type.category,
                subcategory=alert_log.type.subcategory,
                impact=AlertReportSchema.impact(
                    users=alert_log.impact_users,
                    ips=alert_log.impact_ips,
                    requests=alert_log.impact_requests,
                ),
                target=AlertReportSchema.target(
                    name=alert_log.type.target,
                    server_ip=alert_log.server.ip if alert_log.server else None,
                    instance_id=alert_log.instance.pk if alert_log.instance else None,
                    instance_ip=alert_log.instance.server.ip if alert_log.instance else None
                ),
                message=alert_log.message,
                count=alert_log.count,
                alert_id=alert_log.pk,
                data=alert_log.data,
                time=alert_log.time,
                latest_time=alert_log.latest_time,
                relieved_time=alert_log.relieved_time
            ))
            if not resp.success:
                cls.log(
                    subcategory='alert_notify_failed', category=AlertCategory.task_error,
                    name=f'alert notify failed at supervisor: {sp.pk}',
                    ident=f'alert_notify_failed:{sp.pk}', message=resp.message, alarm=False
                )

        if not alert_log.relieved_time:
            alert_log.latest_alarm_time = time_now()
            alert_log.save(update_fields=['latest_alarm_time'])

    # @classmethod
    # def detect_unstable(cls, window: timedelta = timedelta(days=1)):
    #     if not config.alert.unstable_times:
    #         return
    #     from utilmeta.ops.models.log import AlertLog, AlertType
    #
    #     logs = AlertLog.objects.values('type').annotate(
    #         avg_count=exp.Avg('count'),
    #         times=exp.Count('type')
    #     ).filter(
    #         type__service=config.name,
    #         type__unstable=False,
    #         latest_time__gte=time_now() - window,
    #         #
    #         avg_count__lte=config.alert.unstable_avg_count,
    #         times__gte=config.alert.unstable_times
    #     )
    #
    #     for log in logs:
    #         type_id = log['type']
    #         AlertType.objects.filter(id=type_id).update(unstable=True)
    #         alerts = AlertLog.objects.filter(type_id=type_id).order_by('time')
    #         first: AlertLog = alerts.first()
    #         if not first:
    #             continue
    #         last: AlertLog = alerts.last()
    #         first.relieved_time = None
    #         first.count = alerts.aggregate(sum=exp.Sum('count'))['sum']
    #         first.latest_time = last.latest_time
    #         first.relieve_times = list(alerts.exclude(relieved_time=None).values_list('relieved_time', flat=True))
    #         first.save()
    #         cls.notify_supervisor(first)
    #         alerts.exclude(id=first.id).delete()
    #         # compress logs
