from django.db.models import Q, Model, Field
from django.apps import apps
from django.middleware.csrf import rotate_token
from django.contrib.auth.hashers import check_password
from django.contrib.sessions.backends.base import SessionBase

from .common import gen_key, get_field, exc, Logic, SELF, UTF_8, \
    SHA_256, Key, add_field_id, get_field_name, utc_ms_ts, AuthScheme, \
    multi, ReqType, SEG, COMMON_ERRORS, model_tag, time_now, get_interval, \
    ignore_errors, CommonMethod, one_to, error_convert, ip_belong_networks, \
    static_require, handle_parse, represent
from .query import MetaQuerySet
from utilmeta.conf import config
from utilmeta.conf.auth import Auth as AuthConfig
from .base import LogicUtil
from typing import List, Tuple, Callable, Union, Any, Type
from .request import Request
import hmac
import inspect


REQ_TYPE = Union[ReqType, Request]
if not config.resolved:
    raise ImportError('Utils should not be load before service resolve')

conf = config.auth
REQUIRE = Union[List[Callable], Callable]

__all__ = ['Auth']


class Auth(LogicUtil):
    @classmethod
    @static_require(lambda: conf.login_fields)
    def get(cls, val) -> Union[Model, Any]:
        q = Q()
        for f in conf.login_fields:
            q |= Q(**{f: val})
        return MetaQuerySet(model=conf.UserModel).filter(q).first()

    @classmethod
    @ignore_errors(default=False, log=False)
    def admin(cls, user):
        from utilmeta.models import BaseUser
        if isinstance(user, BaseUser):
            return user.admin
        return False

    @classmethod
    def config(cls, user_model: Type[Model] = None, admin_validator: Callable[[Model], bool] = None,
               auth_model: Type[Model] = None, access_model: Type[Model] = None,
               access_user_field: Union[str, Field] = None,
               login_fields: Union[List[str], str, tuple, Field, List[Field]] = None,
               password_field: Union[str, Field] = None,
               active_field: Union[str, Field] = None,
               signup_time_field: Union[str, Field] = None,
               last_login_time_field: Union[str, Field] = None,
               last_login_ip_field: Union[str, Field] = None,
               last_activity_field: Union[str, Field] = None,
               access_key_field: Union[str, Field] = None,
               secret_key_field: Union[str, Field] = None,
               allowed_addresses: Union[str, List[str], Callable] = None,
               ):

        access_user_field = get_field_name(access_user_field)
        access_key_field = get_field_name(access_key_field)
        login_fields = get_field_name(login_fields)
        if login_fields and not multi(login_fields):
            login_fields = [login_fields]
        password_field = get_field_name(password_field)
        active_field = get_field_name(active_field)
        signup_time_field = get_field_name(signup_time_field)
        last_login_time_field = get_field_name(last_login_time_field)
        last_login_ip_field = get_field_name(last_login_ip_field)
        last_activity_field = get_field_name(last_activity_field)
        secret_key_field = get_field_name(secret_key_field)
        UserModel = user_model
        user_model = model_tag(user_model)
        AuthModel = auth_model
        auth_model = model_tag(auth_model)
        AccessModel = access_model
        access_model = model_tag(access_model)
        for key, val in locals().items():
            if not val:
                continue
            if not hasattr(conf, key):
                continue
            attr = getattr(conf, key)
            if attr:
                if attr != val:
                    raise ValueError(f'Conflict auth config at attr: {key}')
            else:
                setattr(conf, key, val)
        if apps.models_ready:
            conf.load_models(admin=bool(config.ops))
        if admin_validator and callable(admin_validator):
            cls.admin = ignore_errors(default=False, log=False)(admin_validator)

    @classmethod
    @static_require(lambda: conf.login_fields)
    def exists(cls, val) -> bool:
        return bool(cls.get(val))

    @classmethod
    @error_convert(errors=COMMON_ERRORS, target=exc.PermissionDenied)
    def valid_signature(cls, request: Request, defaulted: bool = False,
                        model=None, ignore_invalid_key: bool = False):
        model = model or conf.UserModel
        cfg = AuthConfig() if defaulted else conf
        access_key = request.headers.get(cfg.access_key_header)
        if not access_key:
            return None
        timestamp = int(float(request.headers.get(cfg.timestamp_header)))
        sign = request.headers.get(cfg.signature_header)
        if not sign:
            raise exc.PermissionDenied('Signature required')

        access_model = cfg.AccessModel or model
        access = MetaQuerySet(model=access_model).filter(
            **{cfg.access_key_field: access_key}
        ).first()
        if not access:
            if ignore_invalid_key:
                return None
            raise exc.PermissionDenied('invalid Access Key')

        secret_key = getattr(access, cfg.secret_key_field)
        user_id = getattr(access, cfg.access_user_field or 'pk')
        user = access if cfg.user_as_access else MetaQuerySet(model=model).filter(pk=user_id).first()
        if not user:
            raise exc.NotFound('User not found')

        timeout = None
        if conf.AdminModel is model:
            timeout = user.supervisor.operation_timeout
        elif isinstance(conf.auth_timeout, int):
            timeout = conf.auth_timeout
        elif callable(conf.auth_timeout):
            pn = len(inspect.signature(conf.auth_timeout).parameters)
            args = (user,)[:pn]
            timeout = conf.auth_timeout(*args)

        if timeout:
            utc_now = utc_ms_ts()
            if abs((utc_now - timestamp) / 1000) > timeout:
                raise exc.PermissionDenied('Timestamp expired')

        tag = f'{timestamp}{request.METHOD}{request.full_path}'.encode(UTF_8) + (request.raw_body or b'')
        _sign = hmac.new(key=secret_key.encode(UTF_8), msg=tag, digestmod=SHA_256).hexdigest()
        if sign != _sign:
            raise exc.PermissionDenied('Invalid Signature')
        return user

    @classmethod
    def basic_auth(cls, request: Request):
        try:
            param = request.auth_params
            import base64
            user_pwd = base64.decodebytes(str(param).encode()).decode()
            username, password = user_pwd.split(':')
        except COMMON_ERRORS:
            return
        user = MetaQuerySet(model=conf.UserModel).filter(
            {conf.basic_auth_username_field: username}).first()
        if not user:
            raise exc.PermissionDenied(f'invalid basic auth user')
        if not cls.check_password(user, password=password):
            raise exc.PermissionDenied(f'invalid basic auth user')
        request.user = user

    @classmethod
    def gen_jwt_token(cls, request: Request, user, expire_time=None):
        # payload
        import time
        inv = get_interval(expire_time, null=True)
        iat = time.time()
        token_dict = {
            'iat': iat,
            'iss': config.origin,
            'uid': user.pk
        }
        if inv:
            token_dict['exp'] = iat + inv
        try:
            from jwt import JWT
            from jwt.jwk import OctetJWK
            jwt = JWT()
            key = None
            if conf.jwt_secret_key:
                key = OctetJWK(key=conf.jwt_secret_key.encode())
            jwt_token = jwt.encode(token_dict, key=key, alg=conf.jwt_encode_algorithm)
        except ImportError:
            # jwt 1.7
            import jwt
            jwt_token = jwt.encode(
                token_dict, conf.jwt_secret_key,
                algorithm=conf.jwt_encode_algorithm
            ).decode('ascii')

        if conf.jwt_token_field:
            setattr(user, conf.jwt_token_field, jwt_token)
            user.save(update_fields=[conf.jwt_token_field])
        request.jwt_token = jwt_token
        return jwt_token

    @classmethod
    def parse_jwt_token(cls, request: Request):
        auth_param = request.auth_params
        if not auth_param:
            return
        try:
            from jwt import JWT
            from jwt.exceptions import JWTDecodeError
            from jwt.jwk import OctetJWK
            jwt = JWT()
            key = None
            if conf.jwt_secret_key:
                key = OctetJWK(key=conf.jwt_secret_key.encode())
        except ImportError:
            import jwt
            from jwt.exceptions import DecodeError as JWTDecodeError
            key = conf.jwt_secret_key

        try:
            jwt_params = jwt.decode(auth_param, key)
        except JWTDecodeError:
            raise exc.BadRequest(f'invalid jwt token')

        request.user_id = jwt_params['uid']
        request.jwt_token = auth_param
        request.jwt_params = jwt_params

    @classmethod
    def authorize(cls, request: Request, strategy: str = AuthConfig.SESSION):
        if strategy == AuthConfig.SESSION:
            request.user_id = request.session.get(Key.USER_ID)
        elif strategy == AuthConfig.SIGNATURE:
            request.user = cls.valid_signature(request, ignore_invalid_key=True)  # access key may be admin
            # may be user or admin, depend on super_id
        elif strategy == AuthConfig.BASIC:
            if request.auth_scheme == AuthScheme.BASIC:
                cls.basic_auth(request)
        elif strategy == AuthConfig.JWT:
            cls.parse_jwt_token(request)
        return request.user_id is not None

    @classmethod
    @ignore_errors
    def _allowed_addresses(cls, user, login: bool = False):
        if not conf.allowed_addresses:
            return []
        if not user:
            return []
        if callable(conf.allowed_addresses):
            pn = len(inspect.signature(conf.allowed_addresses).parameters)
            args = (user, login)[:pn]
            return conf.allowed_addresses(*args)
        if isinstance(conf.allowed_addresses, str):
            return [conf.allowed_addresses]
        return conf.allowed_addresses

    @classmethod
    @ignore_errors
    def _session_expiry_age(cls, user):
        if not config.session:
            return None
        ret = config.session.expiry_age
        if not ret or isinstance(ret, (int, float)):
            return ret
        if not callable(ret):
            return None
        if not user:
            return []
        import inspect
        pn = len(inspect.signature(ret).parameters)
        args = (user,)[:pn]
        return ret(*args)

    @classmethod
    @ignore_errors
    def _session_verify_ip(cls, user):
        if not config.session:
            return False
        ret = config.session.verify_ip_identical
        if not ret or isinstance(ret, bool):
            return bool(ret)
        if not callable(ret):
            return False
        if not user:
            return []
        import inspect
        pn = len(inspect.signature(ret).parameters)
        args = (user,)[:pn]
        return ret(*args)

    @classmethod
    @ignore_errors
    def _session_verify_ua(cls, user):
        if not config.session:
            return False
        ret = config.session.verify_ua_identical
        if not ret or isinstance(ret, bool):
            return bool(ret)
        if not callable(ret):
            return False
        if not user:
            return []
        import inspect
        pn = len(inspect.signature(ret).parameters)
        args = (user,)[:pn]
        return ret(*args)

    @classmethod
    @ignore_errors
    def _session_limit(cls, user):
        if not config.session:
            return None
        ret = config.session.limit_per_user
        if not ret or isinstance(ret, int):
            return ret
        if not callable(ret):
            return None
        if not user:
            return []
        import inspect
        pn = len(inspect.signature(ret).parameters)
        args = (user,)[:pn]
        return ret(*args)

    @classmethod
    @ignore_errors
    def _session_preemptive(cls, user):
        if not config.session:
            return None
        ret = config.session.user_preemptive
        if not ret or isinstance(ret, bool):
            return ret
        if not callable(ret):
            return None
        if not user:
            return []
        import inspect
        pn = len(inspect.signature(ret).parameters)
        args = (user,)[:pn]
        return ret(*args)

    @classmethod
    def get_user_sessions_num(cls, user_id):
        if not config.session or not config.session.use_db:
            return 0
        if not config.ops or not user_id:
            return 0
        from utilmeta.ops.models.admin import Session
        return Session.objects.filter(
            user_id=user_id,
            expiry_time__gt=time_now(),
            delete_time=None
        ).count()

    @classmethod
    def flush_user_sessions(cls, user_id=None, session_id=None, num: int = 1):
        if not config.session or not config.session.use_db:
            return
        if not config.ops or not user_id or not num:
            return
        session_cls = config.session.engine_cls
        if not session_cls:
            return
        from utilmeta.ops.models.admin import Session
        query = dict(
            expiry_time__gt=time_now(),
            delete_time=None
        )
        if user_id:
            query.update(user_id=user_id)
        if session_id:
            query.update(id=session_id)
        for session_inst in Session.objects.filter(**query).order_by('setup_time')[:num]:
            session_inst: Session
            session: SessionBase = session_cls(session_inst.session_key)
            session.flush()

    @classmethod
    def load_session(cls, request: Request):
        if not config.session:
            return

        if config.session.public_ip_only:
            if not request.ip:
                return None
            if not request.ip_address.is_global:
                return

        if config.session.human_ua_only:
            ua = request.user_agent
            if not ua:
                return None
            if ua and ua.is_bot:
                return None

        session = request.session
        if cls._session_verify_ip(request.user):
            if session.session_key:
                ip = session.get(Key.IP_KEY)
                if ip:
                    if request.ip != ip:
                        return True
            session.setdefault(Key.IP_KEY, request.ip)
        elif config.session.use_db:
            session.setdefault(Key.IP_KEY, request.ip)

        if cls._session_verify_ua(request.user):
            if session.session_key:
                ua = session.get(Key.UA_KEY)
                if ua:
                    if request.ua_string != ua:
                        return True

            session.setdefault(Key.UA_KEY, request.ua_string)
        elif config.session.use_db:
            session.setdefault(Key.UA_KEY, request.ua_string)

        expiry_age = cls._session_expiry_age(request.user)
        if expiry_age is not None:
            session.set_expiry(expiry_age)

    @classmethod
    def load(cls, request: Request):
        request.user_id = None

        for strategy in conf.auth_strategies:
            if cls.authorize(request, strategy=strategy):
                break

        addresses = cls._allowed_addresses(request.user, login=False)
        if addresses:
            if not ip_belong_networks(request.ip_address, addresses):
                return cls.logout(request)

        if conf.session_auth:
            if cls.load_session(request):
                return cls.logout(request)

        if not config.ops:
            return

        from utilmeta.ops.auth import load_admin
        load_admin(request)

    @classmethod
    @static_require(lambda: conf.UserModel, lambda: conf.password_field)
    def change_password(cls, user: Model, password: str):
        password = cls.get_prep_password(password)
        if conf.AuthModel:
            auth = getattr(user, conf.auth_user_relate)
            setattr(auth, conf.password_field, password)
            auth.save()
        else:
            setattr(user, conf.password_field, password)
            user.save()

    @classmethod
    @static_require(lambda: conf.UserModel, lambda: conf.password_field)
    def get_password(cls, user: Model) -> str:
        auth = user
        if conf.AuthModel:
            auth = getattr(user, conf.auth_user_relate)
        return getattr(auth, conf.password_field)

    @classmethod
    def make_session(cls, session: SessionBase, user: Model, time: int = None):
        user_id = session.get(Key.USER_ID)
        if user_id is None:
            if config.session.cycle_key_at_login:
                session.cycle_key()
        else:
            if str(user_id) != str(user.pk):
                session.flush()
        session[Key.USER_ID] = user.pk
        if time is None:
            time = cls._session_expiry_age(user)
        if time is not None:
            session.set_expiry(time)

    @classmethod
    def get_prep_password(cls, value):
        if conf.not_apply_prep:
            return value
        from django.contrib.auth.hashers import make_password
        return make_password(value, gen_key(32))

    @classmethod
    @static_require(lambda: conf.UserModel, lambda: conf.password_field)
    def check_password(cls, user: Model, password: str):
        if not password:
            return False
        _password = cls.get_password(user)
        if not _password:
            return False
        return check_password(password, _password)

    @classmethod
    def check_login(cls, user: Model, request: Request):
        if conf.active_field:
            if not getattr(user, conf.active_field):
                raise exc.PermissionDenied('Login denied for disabled user')

        addresses = cls._allowed_addresses(user, login=True)
        if addresses and request:
            if not ip_belong_networks(request.ip_address, addresses):
                raise exc.PermissionDenied('Login denied for invalid origin')

        if conf.session_auth:
            max_sessions = cls._session_limit(user)
            if max_sessions:
                sessions = cls.get_user_sessions_num(user.pk)
                exceeds = max(0, sessions - max_sessions)
                if exceeds:
                    # current sessions hit the limit
                    # 1. session_preemptive=True: this login is blocked
                    # 2. session_preemptive=False: this login is done, and the earliest session will be revoked
                    if cls._session_preemptive(user):
                        cls.logout(request)
                        raise exc.PermissionDenied(f'Login denied for exceed sessions')
                    cls.flush_user_sessions(user_id=user.pk, num=exceeds)

    @classmethod
    @static_require(lambda: conf.UserModel, lambda: conf.password_field)
    def login(cls, token: str, password: str, request: Request = None, time: int = None) -> Union[Model, Any]:
        user = cls.get(token)
        if not user:
            return None

        if not cls.check_password(user=user, password=password):
            return None

        if request:
            cls.check_login(user, request)
            cls.do_login(user, request, time=time)

        return user

    @classmethod
    def do_login(cls, user, request: Request, time: int = None) -> Union[Model, Any]:
        if conf.session_auth:
            cls.make_session(request.session, user=user, time=time)
        if conf.jwt_auth:
            cls.gen_jwt_token(request, user=user, expire_time=time)

        cls.update_fields(request, user=user)
        rotate_token(request)  # reset CSRF token for security purposes
        request.user = user
        return user

    @classmethod
    @static_require(lambda: conf.UserModel)
    def update_fields(cls, request: Request, user):
        fields = []
        if conf.last_login_time_field:
            setattr(user, conf.last_login_time_field, request.time)
            fields.append(conf.last_login_time_field)
        if conf.last_login_ip_field:
            setattr(user, conf.last_login_ip_field, str(request.ip))
            fields.append(conf.last_login_ip_field)
        if conf.last_activity_field:
            setattr(user, conf.last_activity_field, request.time)
            fields.append(conf.last_activity_field)
        if not fields:
            return
        user.save(update_fields=fields)

    @classmethod
    @static_require(lambda: conf.UserModel, lambda: conf.password_field)
    @handle_parse
    def register(cls, data: dict, *, auth_data: dict = None, request: Request = None) -> Union[Model, Any]:
        if not isinstance(data, dict):
            raise TypeError(f'Invalid register data with type {type(data)}')
        if conf.password_field not in data:
            raise ValueError(f'Auth.register should contains password_field: {repr(conf.password_field)}')
        password = None
        data = dict(data)
        if conf.AuthModel:
            password = data.pop(conf.password_field)
        parser_cls = config.preference.base_parser_cls
        data = parser_cls.parse(data, conf.user_template)
        try:
            user = MetaQuerySet(model=conf.UserModel).create(**data)
        except exc.IntegrityError as e:
            raise exc.BadRequest(e)
        if conf.AuthModel:
            auth_data = auth_data or {}
            auth_data.update({
                add_field_id(conf.auth_user_field): user.pk,
                conf.password_field: cls.get_prep_password(password)
            })
            auth_data = parser_cls.parse(auth_data, conf.auth_template)
            MetaQuerySet(model=conf.AuthModel).create(**auth_data)
        if request:
            cls.do_login(user=user, request=request)
        return user

    @classmethod
    @static_require(lambda: conf.UserModel)
    def logout(cls, request: REQ_TYPE):
        request.session.flush()
        request.user_id = None

    @classmethod
    @static_require(lambda: conf.UserModel)
    def get_user(cls, request: REQ_TYPE):
        if not conf.UserModel:
            return None
        pk = getattr(request, 'user_id', None)
        if pk is None:
            if not hasattr(request, 'session'):
                return None
            pk = request.session.get(Key.USER_ID)
        if pk is None:
            return None
        user = MetaQuerySet(model=conf.UserModel).fetch(pk)
        if not user:
            return None
        return user

    def __and__(self, other: 'Auth'):
        if not self._operator and not other._operator:
            if self.login_required is other.login_required is None:
                login = None
            else:
                login = self.login_required | other.login_required
            relate = self.relate + other.relate
            require = self.require + other.require
            validator = self.validator + other.validator
            return Auth(
                login=login or None,
                relate=relate or None,
                require=list(require) or None,
                validator=list(validator) or None
            )
        return self._combine(other, Logic.AND)

    def __bool__(self):
        if self._conditions:
            return True
        return not self._vacuum

    def __init__(self, login: bool = None, relate=None, require: REQUIRE = None, validator: REQUIRE = None):
        if relate:
            relate = get_field_name(relate)
        else:
            relate = None
        super().__init__(locals())
        # Condition is one Auth instance is combine by relation <and>
        self.relate = ()
        self.require = ()
        self.validator = ()
        self._model = None
        self.admin_auth = None
        self.login_required = login
        self.method = None
        # self.backwards = {}

        if relate:
            self.login_required = True
            assert isinstance(relate, str) or multi(relate), \
                f"Auth relate must be field/str or list/tuple of it, got [{type(relate)}]"
            self.relate = tuple(relate) if multi(relate) else (relate,)

        if require:
            parser_cls = config.preference.function_parser_cls
            self.login_required = True
            if multi(require):
                req_list = []
                for r in require:
                    req_list.append(parser_cls(r).wrapper)
                require = req_list
            else:
                self.admin_auth = getattr(require, 'admin', False)
                require = (parser_cls(require).wrapper,)
            self.require: Tuple[Callable] = tuple(require)

        if validator:
            parser_cls = config.preference.function_parser_cls
            if multi(validator):
                validators = []
                for r in validator:
                    validators.append(parser_cls(r).wrapper)
                validator = validators
            else:
                validator = (parser_cls(validator).wrapper, )
            self.validator: Tuple[Callable] = tuple(validator)

    @property
    def model(self):
        return self._model

    @model.setter
    def model(self, m):
        if self._operator:
            for auth in self._conditions:
                auth.model = m
        self._model = m

    def check(self, method: str) -> bool:
        from utilmeta.fields import CrossServiceKey, CharField, IntegerField, TextField
        self.method = method
        if self._operator:
            for auth in self._conditions:
                auth: Auth
                auth.check(method)

        if self.relate:
            if not self.model:
                raise ValueError("Auth relate must provide a model "
                                 "(which automatically append when Auth declare in Module) "
                                 "when using Auth out of module, plus model param to specify a Model")
            admin_auth = None
            relates = []

            for r in self.relate:
                if r == SELF:
                    assert method != CommonMethod.POST, "Auth 'self' relate not support for native POST method"
                    model = self.model
                else:
                    field = get_field(self.model, r, cascade=True)
                    if isinstance(field, CrossServiceKey):
                        if not conf.auth_service:
                            raise ValueError(f'Auth relate to CrossServiceKey must specify auth_service')
                        assert field.service_name == conf.auth_service, \
                            f'Auth relate to CrossServiceKey(service={field.service_name}) ' \
                            f'must consistent to auth_service: {conf.auth_service}'
                        continue

                    if one_to(field):
                        r = add_field_id(r)
                    elif r.endswith('_id') and isinstance(field, (IntegerField, CharField, TextField)):
                        # consider an implicit foreign key point to the target model and leave for runtime judgement
                        continue

                    model = field.related_model

                if not model:
                    raise TypeError(f'Auth relate: {repr(r)} must be a relate field')

                if conf.AdminModel and issubclass(model, conf.AdminModel):
                    if admin_auth is False:
                        raise ValueError(f'Auth relate: {repr(r)} is '
                                         f'admin_auth, which not consist to other relates')
                    admin_auth = True
                elif conf.UserModel and issubclass(model, conf.UserModel):
                    if admin_auth:
                        raise ValueError(f'Auth relate: {repr(r)} is not'
                                         f' admin_auth, which not consist to other relates')
                    admin_auth = False
                elif not conf.auth_service:
                    raise ValueError(f"Auth relate: {repr(r)} related_model must be user model "
                                     f"or it's subclass, got {model}")

                relates.append(r)

            self.relate = relates
            if self.admin_auth is None:
                self.admin_auth = admin_auth
            elif admin_auth is not None:
                assert self.admin_auth is admin_auth, f'Auth relate and require is not consist for admin_auth'
            # use backward to validate many_to relations
        return True

    def find_relate(self, r, model=None):
        if not model:
            model = self.model
        if hasattr(model, r):
            _field = get_field(model, r)
            if _field.related_model:
                _model = _field.related_model
            else:
                raise ValueError(f"Auth [{r}] field must be a relate field "
                                 f"relate to user model or it's superclass")
            return _model
        else:
            raise ValueError(f"Auth relate [{r}] is not self or an attribute of model[{self.model}]")

    def relate_to(self, relate: str, user_id, data: dict = None) -> bool:
        # for post data, check if related pk in data is related to user
        if not data:
            return False
        if isinstance(data, list):
            for d in data:
                if not self.relate_to(relate, user_id, d):
                    return False
            return True
        rel, *lookups = relate.split(SEG)
        rel_pk = data.get(rel, data.get(add_field_id(rel)))
        if not rel_pk:
            return False
        if not lookups:
            return str(user_id) == str(rel_pk)
        lookup = add_field_id(SEG.join(lookups))
        model = get_field(self.model, rel).related_model
        pk_set = set(MetaQuerySet(model=model).filter(pk=rel_pk).values_list(lookup, flat=True))
        return user_id in pk_set

    @classmethod
    @ignore_errors
    def get_admin(cls, request: Request, for_admin: bool = False):
        if request.admin:
            if not for_admin:
                # admin request for service APIs, use endpoint auth
                from utilmeta.ops.auth import valid_request
                if valid_request(request)(request.admin):
                    return request.admin
                return None
            return request.admin
        if for_admin:
            return None
        if request.user_id:
            if Auth.admin(request.user):
                return request.user
        return None

    @property
    def target_model(self):
        return conf.AdminModel if self.admin_auth else conf.UserModel

    def apply(self, request: REQ_TYPE, resource: MetaQuerySet = None, data: Union[dict, list] = None) -> bool:
        # resource is instance of self.model
        if not self:
            return True

        user_id = request.user_id
        result = False

        if self.login_required is not None:
            if self.login_required ^ request.login:
                if not self.login_required:
                    e = exc.PermissionDenied
                    msg = 'Auth: login not required'
                else:
                    e = exc.Unauthorized
                    msg = conf.login_required_message or 'Auth: login required'
                raise e(msg)

        if self.validator:
            for validator in self.validator:
                try:
                    result = validator(request, resource)
                except COMMON_ERRORS as e:
                    raise exc.PermissionDenied(f'Auth: validator <{validator.__name__}> validate failed with error: {e}')
                if not result:
                    raise exc.PermissionDenied(f'Auth: validator <{validator.__name__}> not satisfied')

        if not self.relate and not self.require:
            return True

        admin = self.get_admin(request, for_admin=self.admin_auth)

        if self.admin_auth:
            if not admin:
                raise exc.PermissionDenied('Auth: admin required')
        else:
            if admin:
                return True
            if not user_id:
                raise exc.PermissionDenied(conf.login_required_message or f'Auth: login required')

        # relates require a non-empty resource to valid
        # is resource is none, this access is granted (lead to an empty result)
        for relate in self.relate:
            if relate == SELF:
                if self.target_model and not issubclass(resource.model, self.target_model):
                    result = False
                else:
                    result = not resource.exclude(pk=user_id).exists()
            elif request.method == CommonMethod.POST:
                result = self.relate_to(relate, user_id, data=data)
            else:
                result = not resource.exclude(**{relate: user_id}).exists()
            if not result:
                raise exc.PermissionDenied(f'Auth: relate {repr(relate)} not satisfied')

        # auth for require --------------------------------------------------
        user = admin if self.admin_auth else request.user
        for require in self.require:
            require: Callable
            try:
                result = require(user)
            except COMMON_ERRORS as e:
                raise exc.PermissionDenied(f'Auth: require <{require.__name__}> validate failed with error: {e}')
            if not result:
                raise exc.PermissionDenied(f'Auth: require <{require.__name__}> not satisfied')
        if not result:
            raise exc.PermissionDenied
        return True

    @property
    def dict(self):
        if self._operator:
            return dict(
                operator=self._operator,
                conditions=[cond.dict for cond in self._conditions]
            )
        data = dict()
        if self.login_required is not None:
            data.update(login=self.login_required)
        if self.relate:
            data.update(relate=list(self.relate))
        if self.require:
            data.update(require=[represent(f) for f in self.require])
        if self.admin_auth:
            data.update(admin=True)
        return data
