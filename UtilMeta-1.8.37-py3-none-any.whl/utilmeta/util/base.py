from .common import multi, merge_attrs, represent, \
    dict_diff, get_root_base, pop, gen_key, import_util, \
    Attr, SEG, Logic, JSON_TYPES, SECRET, RuntimeImmutable, ImmutableDict, exc

from typing import Dict, Any, TypeVar, List, Optional, Union, Type
from datetime import timedelta, datetime
# import copy
import inspect

T = TypeVar('T')

__all__ = ['Util', 'Meta', 'LogicUtil']


class UtilKey:
    CLS = '@'
    PATH = '@path'
    ARGS = '@args'
    OPERATOR = '@operator'
    CONDITIONS = '@conditions'


class Meta(type):
    UTIL_CLASS_MAP = {}

    def __init__(cls, name, bases: tuple, attrs: dict, **kwargs):
        super().__init__(name, bases, attrs)

        __init = getattr(cls, Attr.INIT)

        cls._kwargs = kwargs
        cls._pos_var = None
        cls._key_var = None
        cls._pos_keys = set()
        cls._kw_keys = set()
        cls._defaults = {}
        cls._requires = set()

        if bases == (RuntimeImmutable,):
            return

        defaults = {}
        requires = set()
        for base in bases:
            if isinstance(base, Meta):
                defaults.update(base._defaults)
                requires.update(base._requires)
                cls._kw_keys.update(base._kw_keys)
                cls._pos_keys.update(base._pos_keys)

        if __init:
            _self, *parameters = inspect.signature(__init).parameters.items()
            for k, v in parameters:
                v: inspect.Parameter
                if k.startswith(SEG) and k.endswith(SEG):
                    continue
                if v.default is not v.empty:
                    defaults[k] = v.default
                elif v.kind not in (v.VAR_KEYWORD, v.VAR_POSITIONAL):
                    requires.add(k)

                if v.kind == v.VAR_POSITIONAL:
                    cls._pos_var = k
                elif v.kind == v.POSITIONAL_ONLY:
                    cls._pos_keys.add(k)
                elif v.kind == v.VAR_KEYWORD:
                    cls._key_var = k
                else:
                    cls._kw_keys.add(k)

        cls._defaults = ImmutableDict(defaults)
        cls._requires = requires
        # cls._init_kwargs = kwargs

        Meta.UTIL_CLASS_MAP[name] = cls

    @property
    def cls_path(cls):
        return f'{cls.__module__}.{cls.__name__}'

    @property
    def kw_keys(cls):
        return cls._kw_keys

    @property
    def pos_slice(cls) -> slice:
        if cls._pos_var:
            return slice(0, None)
        return slice(0, len(cls._pos_keys))


class Util(RuntimeImmutable, metaclass=Meta):
    Key = UtilKey
    _util_slots = []
    _secret_names = []

    def __init__(self, __params__: Dict[str, Any]):
        super().__init__()
        if inspect.isclass(self):   # class utility
            pass
        self._id = gen_key(6, alnum=True)

        args = []
        kwargs = {}
        vacuum = True
        for key, val in __params__.items():
            if key.startswith(SEG) and key.endswith(SEG):
                continue
            if val is self:
                continue
            if key == self._pos_var:
                args += list(val)
                continue
            elif key == self._key_var:
                kwargs.update(val)
                continue
            elif key in self._pos_keys:
                args.append(key)
            elif key in self._kw_keys:
                kwargs[key] = val
            else:
                continue
            if val != self._defaults.get(key):   # for key_var or pos_var the default is None
                vacuum = False

        self._vacuum = vacuum
        self._app_id = None
        self._original_kwargs = None
        self.__args__ = tuple(args)
        self.__kwargs__ = ImmutableDict(kwargs)
        spec = dict_diff(self._defaults, kwargs)
        spec.update({k: kwargs[k] for k in self._requires})
        self.__spec_kwargs__ = ImmutableDict(spec)
        if inspect.isclass(self):
            self.__declare_path__ = f'{self.__module__}.{self.__name__}'
        else:
            self.__declare_path__ = None

    @property
    def _origin(self):
        target = self
        if self._original_kwargs is not None:
            target = self.__class__(**self._original_kwargs)
        return target

    def _make_path(self, path):
        if not self.__declare_path__:
            self.__declare_path__ = path

    @classmethod
    def merge_util(cls: Type[T], util: T, target: T) -> T:
        if not isinstance(util, cls) or not isinstance(target, cls):
            raise TypeError(f'{cls.__name__} must merge with another same class util, got {util}')
        return util._merge(target)

    def _merge(self, util: T) -> T:
        assert isinstance(util, self.__class__),\
            f'{self.__class__.__name__} must merge with another same class util, got {util}'
        if self is util or util._vacuum:
            return self.__copy__()
        if self._vacuum:
            return util.__copy__()
        kwargs = merge_attrs(self.__spec_kwargs__, util.__spec_kwargs__)
        args = merge_attrs(self.__args__, util.__args__)
        # just merge the specific kwargs
        return self.__class__(*args, **kwargs)
    # @property
    # def util_path(self):
    #     return f'{self.__declare_path__ or self.__class__.__module__}:{self.__class__.__name__}'

    def __hash__(self):
        return hash(self._id)

    def __eq__(self, other: 'Util'):
        if inspect.isclass(self):
            return super().__eq__(other)
        if not isinstance(other, self.__class__):
            return False
        return self.__spec_kwargs__ == other.__spec_kwargs__ and self.__args__ == other.__args__

    def __bool__(self):
        # !! return not self.vacuum
        # prevent use <not self.vacuum> as bool (causing lots of recessive errors)
        # let sub utils define there own way of bool
        return True

    def __str__(self):
        return self._repr()

    def __repr__(self):
        return self._repr()

    @classmethod
    def _copy(cls, data, copy_class: bool = False):
        if multi(data):
            return type(data)([cls._copy(d) for d in data])
        if isinstance(data, dict):
            return {key: cls._copy(val) for key, val in data.items()}
        if inspect.isclass(data) and not copy_class:
            # prevent class util that carry other utils cause RecursiveError
            return data
        if isinstance(data, Util):
            return data.__copy__()
        return data

    def __deepcopy__(self, memo):
        return self.__copy__()

    def __copy__(self):
        # use copied version of sub utils
        # return self.__class__(*self._args, **self._kwargs)
        if inspect.isclass(self):
            bases = getattr(self, Attr.BASES, ())
            attrs = dict(self.__dict__)
            pop(attrs, Attr.LOCK)       # pop __lock__
            cls: type = self.__class__
            return cls(self.__name__, bases, self._copy(attrs))
        return self.__class__(*self._copy(self.__args__), **self._copy(self.__spec_kwargs__))

    @property
    def _util_path(self):
        return f'{self.__module__}.{self.__name__}' if inspect.isclass(self) \
            else f'{self.__module__}.{self.__class__.__name__}'

    def _repr(self, params: List[str] = None, excludes: List[str] = None):
        if inspect.isclass(self):
            return f'<{self.__class__.__name__} class {repr(self._util_path)}>'
        attrs = []
        for k, v in self.__spec_kwargs__.items():
            for sk in self._secret_names:
                if sk in str(k).lower() and not isinstance(v, bool):
                    v = SECRET
            if params is not None and k not in params:
                continue
            if excludes is not None and k in excludes:
                continue
            attrs.append(k + '=' + represent(v))     # str(self.display(v)))
        s = ', '.join([represent(v) for v in self.__args__] + attrs)
        return f'{self.__class__.__name__}({s})'

    # @property
    # def _kwargs(self) -> dict:
    #     print('SPEC:', dict(self.__spec_kwargs__))
    #     try:
    #         return copy.deepcopy(dict(self.__spec_kwargs__))
    #     except (TypeError, AttributeError):
    #         return dict(self.__spec_kwargs__)
    #
    # @property
    # def _args(self) -> tuple:
    #     try:
    #         return copy.deepcopy(self.__args__)
    #     except (TypeError, AttributeError):
    #         return tuple(self.__args__)

    def _deconstruct(self) -> dict:
        return {
            UtilKey.CLS: get_root_base(self),
            UtilKey.PATH: self.__declare_path__,
            UtilKey.ARGS: self.clean_kwargs(self.__args__),
            **self.clean_kwargs(self.__spec_kwargs__)
        }

    @classmethod
    def construct(cls, kwargs: dict):
        if not isinstance(kwargs, dict):
            return kwargs
        _cls = pop(kwargs, UtilKey.CLS)
        if not _cls:
            return kwargs
        _path = pop(kwargs, UtilKey.PATH)
        _class = import_util(_path) if _path else Meta.UTIL_CLASS_MAP.get(_cls)
        if not issubclass(_class, Util):
            raise TypeError(f'Invalid util class: {_class}')
        _args = pop(kwargs, UtilKey.ARGS, ())
        _operator = pop(kwargs, UtilKey.OPERATOR)
        _conditions = pop(kwargs, UtilKey.CONDITIONS)
        if not _class:
            return None
        _util: cls = _class(
            *[cls.construct(arg) for arg in _args[_class.pos_slice]],
            **{k: cls.construct(v) for k, v
               in kwargs.items() if k in _class.kw_keys}
        )
        if _operator or _conditions:
            if not issubclass(_class, LogicUtil):
                raise TypeError(f'only LogicUtil can construct with logic '
                                f'operator: {_operator} and conditions: {_conditions}. got: {_class}')
            _util: LogicUtil
            _util._operator = _operator
            _util._conditions = [cls.construct(cond) for cond in _conditions]
        return _util

    @classmethod
    def clean_kwargs(cls, data):
        if multi(data):
            # convert to list for json save
            return [cls.clean_kwargs(val) for val in data]
        elif isinstance(data, dict):
            result = {}
            for key, val in data.items():
                if not isinstance(key, str):
                    continue
                for sk in cls._secret_names:
                    if sk.lower() in key and not isinstance(val, bool):
                        result[key] = SECRET
                        break
                if key not in result:
                    result[key] = cls.clean_kwargs(val)
            return result
        elif isinstance(data, Util):
            if not data._secret_names:
                data.__class__._secret_names = cls._secret_names
            return data._deconstruct()
        if isinstance(data, timedelta):
            return data.total_seconds()
        if isinstance(data, datetime):
            return str(data)
        if data is None:
            return None
        for t in JSON_TYPES:
            if isinstance(data, t):
                return t(data)
        return represent(data)
    

class LogicUtil(Util):
    def __init__(self, params: Dict[str, Any] = None):
        super().__init__(params)
        self._conditions: List[Union[LogicUtil, Any]] = []
        self._operator: Optional[str] = None
        # self._call = self.__call__
        # self.__call__ = self.__class__._apply_logic

    def apply(self, *args, **kwargs):
        raise NotImplementedError
    
    @property
    def _negate(self):
        return self._operator == Logic.NOT
    
    @property
    def _logic_applied(self):
        return bool(self._operator and self._conditions)

    def __call__(self, *args, **kwargs):
        result = None
        errors = []
        if not self._logic_applied:
            try:
                result = self.apply(*args, **kwargs)
            except Exception as e:
                errors.append(e)
        else:
            if self._operator == Logic.OR:
                for con in self._conditions:
                    try:
                        result = con(*args, **kwargs)
                    except Exception as e:
                        errors.append(e)
                    else:
                        errors = []     # one condition is satisfied in OR
                        break
            elif self._operator == Logic.AND:
                for con in self._conditions:
                    try:
                        result = con(*args, **kwargs)
                    except Exception as e:
                        errors.append(e)
                        break
            elif self._operator == Logic.XOR:
                xor = None
                for con in self._conditions:
                    try:
                        result = con(*args, **kwargs)
                        if xor is None:
                            xor = con
                        else:
                            errors.append(ValueError(
                                f'More than 1 conditions ({xor}, {con}) is True in XOR conditions'))
                            break
                    except Exception as e:
                        errors.append(e)
                if xor is not None:
                    # only one condition is satisfied in XOR
                    errors = []

            elif self._operator == Logic.NOT:
                try:
                    con = self._conditions[0]
                    result = con(*args, **kwargs)
                    errors.append(ValueError(f'Negate condition: {con} is violated'))
                except Exception as e:
                    # use error as result
                    result = e

        if errors:  # apply negate
            from .error import Error
            err = exc.CombinedError(*errors) if len(errors) > 1 else errors[0]
            raise Error(err).throw()
        return result

    def _combine(self, other, operator):
        name = self.__class__.__name__
        assert isinstance(other, self.__class__), \
            f"{name} instance must combine with other {name} instance, got {other}"
        util = self.__class__()
        util._operator = operator
        if self._operator == operator:
            util._conditions += self._conditions
        else:
            util._conditions.append(self)
        if other._operator == operator:
            util._conditions += other._conditions
        else:
            util._conditions.append(other)
        return util

    def _deconstruct(self):
        data = super()._deconstruct()
        if self._logic_applied:
            data[UtilKey.OPERATOR] = self._operator
            data[UtilKey.CONDITIONS] = [con._deconstruct() for con in self._conditions]
        return data

    def _repr(self, params: List[str] = None, excludes: List[str] = None):
        if self._logic_applied:
            return self._operator.join([(f'({str(c)})' if c._logic_applied else str(c)) for c in self._conditions])
        return f'{Logic.NOT if self._negate else ""}{super()._repr(params=params, excludes=excludes)}'

    def __copy__(self):
        util = super(LogicUtil, self).__copy__()
        if self._operator:
            util._operator = self._operator
        if self._conditions:
            util._conditions = self._copy(self._conditions)
        return util

    def __hash__(self):
        return hash(self._id)

    def __eq__(self, other: 'LogicUtil'):
        if not isinstance(other, self.__class__):
            return False
        if self._operator:
            if self._operator != other._operator:
                return False
        if self._conditions:
            if self._conditions != other._conditions:
                return False
        return super(LogicUtil, self).__eq__(other)

    def _merge(self, util: T) -> T:
        assert isinstance(util, self.__class__), \
            f'{self.__class__.__name__} must merge with another same class util, got {util}'
        if self._negate or util._negate:
            # not merge negate util
            return util.__copy__()
        if self._logic_applied:
            if util._logic_applied:
                return self & util
            conditions = []
            for con in self._conditions:
                con: LogicUtil
                conditions.append(con._merge(util))
            return self.__copy__()
        else:
            if util._logic_applied:
                util._conditions = [self._merge(con) for con in util._conditions]
                return util.__copy__()
            return super()._merge(util)

    def __or__(self, other: 'LogicUtil'):
        return self._combine(other, Logic.OR)

    def __xor__(self, other: 'LogicUtil'):
        return self._combine(other, Logic.XOR)

    def __and__(self, other: 'LogicUtil'):
        return self._combine(other, Logic.AND)

    def __invert__(self):
        util = self.__copy__()
        if self._logic_applied:  # like (A AND B) -> NOT (A AND B)
            util._conditions = [self]
        util._operator = Logic.NOT
        return util
