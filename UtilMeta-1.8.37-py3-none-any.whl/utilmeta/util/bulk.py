from .base import Util
from .common import MAX_ENTRIES, get_pk, exc, add_field_id, ID, PK, multi
from .query import MetaQuerySet, Lookup
from .field import Field
from utilmeta.fields import OneToOneField
from typing import Optional


class Bulk(Util):
    def __init__(self, replace=False, model=None, post=False, ignore_conflicts: bool = False):
        super().__init__(locals())
        self.model = model
        self.post = post
        # post method mode create=True
        # put/patch method mode create=False
        self.replace = replace
        self.ignore = ignore_conflicts

    @property
    def inherited(self) -> bool:
        return isinstance(get_pk(self.model), OneToOneField)

    @property
    def valid_pk_name(self):
        if self.inherited:
            return add_field_id(self.pk_name)
        return self.pk_name

    @property
    def pk_name(self):
        return get_pk(self.model).name if self.model else None

    @property
    def root_pk_name(self):
        return get_pk(self.model, root=True).name if self.model else None

    def feed_data(self, data: dict):
        pk = self.get_pk(data)
        kwargs = Field.parse_kwargs(self.model, kwargs=data, restrict_key=True, include_many=False)
        if pk is not None:
            kwargs[PK] = pk
        return self.model(**kwargs)

    def get_pk(self, data: dict):
        keys = {self.pk_name, self.valid_pk_name, self.root_pk_name, ID, PK}
        for key in keys:
            if key in data:
                return data[key]
        return None

    def __call__(self, data: list, query: bool = False, using: str = None,
                 domain: list = None) -> Optional[MetaQuerySet]:
        """
        For further relation update, the return queryset should stay the order of the data
        """
        if not data:
            return
        if isinstance(data, dict):
            data = [data]
        if not multi(data):
            raise TypeError(f'Bulk one task multiple data: got {data}')

        q = MetaQuerySet(model=self.model).using(using)
        if self.post:
            objs = [self.feed_data(d) for d in data]
            # return self.model.objects.bulk_create(objs)
            objs = q.bulk_create(objs, ignore_conflicts=self.ignore)
            if not query:
                return
            return q.fetch_pk_list(*[obj.pk for obj in objs])
        if domain is None:
            domain = q.pk_list

        pk_list = []
        creates = []
        updates = []
        fields = set()
        fields_union = set()
        model_fields = Field.all_fields(self.model, redundant=True)
        update_data = {}

        objs = []
        for i, d in enumerate(data):
            d: dict
            pk = self.get_pk(d)
            if pk in pk_list:
                raise exc.BadRequest(f'Bulk data item: [{i}] pk: {pk} is duplicated')
            if pk is None:
                if not self.replace:
                    raise exc.BadRequest(f'Bulk data item: [{i}] should specify a unique pk')
            else:
                pk_list.append(pk)
                # d[self.valid_pk_name] = pk

            inst = self.feed_data(d)
            if pk is None or not Lookup.IN(pk, domain):
                # when the replace routine code is inited without domain, nothing will be created if
                # only check pk not in domain
                creates.append(inst)
                objs.append(None)
            else:
                if not fields:
                    fields = set(d.keys())
                else:
                    fields.intersection_update(d.keys())
                fields_union.update(d.keys())
                update_data[str(pk)] = d
                updates.append(inst)
                objs.append(inst)

        pk_fields = {self.pk_name, self.valid_pk_name, self.root_pk_name, 'pk', 'id'}
        fields_union = fields_union.difference(pk_fields).intersection(model_fields)
        fields = fields.difference(pk_fields).intersection(model_fields)

        if fields_union != fields:
            # this inner bulk data don't have consistent fields structure, use union strategy
            values = list(MetaQuerySet(model=self.model).filter(
                pk__in=list(update_data.keys())).values('pk', *fields_union).result())
            updates = []
            for val in values:
                val: dict
                val.update(update_data.get(str(val['pk'])))
                updates.append(self.feed_data(val))
            fields = fields_union

        if updates:
            q.pk_list = list(update_data.keys())
            q.bulk_data = update_data
            q.bulk_update(updates, fields=fields, batch_size=MAX_ENTRIES)
        if creates:
            news = q.bulk_create(creates)
            if query:
                j = 0
                for i, obj in enumerate(objs):
                    if obj is None:
                        objs[i] = news[j]
                        j += 1
            # replace the new objects in the None of the objs list to make sure the
            # order stay same as data
        if self.replace:
            deletes = [d for d in domain if not Lookup.IN(d, pk_list)]
            if deletes:
                q.pk_list = deletes
                q.filter(pk__in=deletes).delete()

        if not query:
            return
        return q.fetch_pk_list(*[obj.pk for obj in objs])
