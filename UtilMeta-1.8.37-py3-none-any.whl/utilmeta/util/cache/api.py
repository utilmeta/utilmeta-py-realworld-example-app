from .base import Locker
from ..base import Util
from ..common import ignore_errors, Format, type_transform, multi, \
    exc, Header, etag, dump_kwargs, get_mark, map_dict, keys_or_args, time_now
from utilmeta.conf import config
from typing import Union, Callable, Optional, Dict, Any, List
from datetime import datetime, timedelta
from django.core.cache.backends.base import BaseCache as BaseBackend

NUM_TYPES = (int, float)
NUM = Union[int, float]
VAL = Union[str, bytes, list, tuple, dict]

__all__ = ['Cache', 'CacheEntity']


class CacheEntity:
    SUPPORT_MAX_ENTRIES = False
    SUPPORT_KEYS = False

    def __init__(self, src: 'Cache', local: bool = True, readonly: bool = False):
        assert isinstance(src, Cache)
        self.src = src
        self.readonly = readonly
        self.local = local

    @classmethod
    def last_update_key(cls, key):
        if isinstance(key, bytes):
            key = key.decode()
        if isinstance(key, str):
            return f'{key}@update'
        elif multi(key):
            return [cls.last_update_key(k) for k in key]
        return []

    @property
    def count_key(self):
        return self.src.encode('count')

    @property
    def cache(self):
        return self.src.cache_instance

    @property
    def config(self):
        return self.src.config

    def update(self, data: Dict[str, Any], timeout: float = None):
        if not data:
            return
        if self.readonly:
            raise PermissionError(f'Attempt to set val ({data}) to a readonly cache')
        last_modified = self.src.last_modified or time_now()
        updates = {k: last_modified for k in self.last_update_key(list(data))}

        if self.src.from_api:
            if not self.src.no_cache:
                self.src.etag = data
                self.src.last_modified = last_modified
        if self.src.no_store:
            # when no_store, only set cache attrs in setter
            return
        self.cache.set_many(data=data)
        self.cache.set_many(updates, timeout=timeout)

    def set(self, key: str, val, *, timeout: float = None,
            exists_only: bool = False, not_exists_only: bool = False):
        cache = self.src.cache_instance
        if not cache:
            raise ValueError(f'Cache instance not exist')
        if self.readonly:
            print(f'Attempt to set val ({key} -> {repr(val)}) to a readonly cache, '
                  f'(maybe from other scope), ignoring...')
            return
        last_modified = self.src.last_modified or time_now()

        if self.src.from_api:
            if not self.src.no_cache:
                self.src.etag = val
                self.src.last_modified = last_modified
        if self.src.no_store:
            # when no_store, only set cache attrs in setter
            return

        if exists_only:
            if not cache.has_key(key):
                return
        if not_exists_only:
            if cache.has_key(key):
                return
        cache.set(key, val, timeout=timeout)
        cache.set(self.last_update_key(key), last_modified)
        cache.incr(self.count_key, 1)

    def get(self, *keys: str, single: bool = False):
        from utilmeta.conf import config
        if not keys:
            if single:
                return None
            return []

        if self.src.expiry_time == 0:
            if config.version_id is not None:
                self.src.etag = config.version_id
                # set etag to service_id instead of response
                # cause expire_time = 0 means the result will
                # be constant in current service runtime
        if single:
            result = self.cache.get(keys[0])
            if result is None:
                return result
        else:
            result = self.cache.get_many(keys)
            if not result:
                return result

        if self.src.from_api:
            last_update = max(self.cache.get_many(self.last_update_key(keys)).values() or [time_now()])
            if not self.src.etag:
                self.src.etag = result
            if not self.src.last_modified:
                self.src.last_modified = last_update
        return result

    def keys(self):
        raise NotImplementedError(f'{self.__class__} not support keys query')

    def delete(self, *keys: str):
        if not keys:
            return
        if self.readonly:
            raise RuntimeError(f'Attempt to delete key ({keys}) at a readonly cache')
        self.cache.delete_many(keys)

    def expire(self, *keys: str, timeout: float):
        for key in keys:
            self.cache.touch(key, timeout=timeout)

    def count(self) -> int:
        return self.cache.get(self.count_key) or 9

    def exists(self, *keys: str) -> int:
        exists = 0
        for key in keys:
            if self.cache.has_key(key):
                exists += 1
        return exists

    def alter(self, key: str, amount: Union[int, float], limit: int = None):
        pass

    def lock(self, *keys: str, block: bool = False):
        raise NotImplementedError(f'{self.__class__} not support lock acquire')

    def lpush(self, key: str, *values):
        raise NotImplementedError(f'{self.__class__} not support lpush')

    def rpush(self, key: str, *values):
        raise NotImplementedError(f'{self.__class__} not support rpush')

    def lpop(self, key: str):
        raise NotImplementedError(f'{self.__class__} not support lpop')

    def rpop(self, key: str):
        raise NotImplementedError(f'{self.__class__} not support rpop')


class Cache(Util):
    NO_CACHE = 'no-cache'
    NO_STORE = 'no-store'
    NO_TRANSFORM = 'no-transform'
    PUBLIC = 'public'
    MAX_AGE = 'max-age'
    MAX_STALE = 'max-stale'
    PRIVATE = 'private'
    MUST_REVALIDATE = 'must-revalidate'

    def __init__(self, expiry_time: Union[int, datetime, timedelta] = 0,
                 cache_alias: str = 'default',
                 allow_global: bool = False, allow_cross: bool = False,
                 cache_control: str = None, client_cache: bool = False,
                 max_entries: int = None, api_cache: bool = False):
        super().__init__(locals())
        from utilmeta.conf import config
        assert config.auto_cache, f'Cache util require to enable auto_cache system'
        if max_entries:
            assert isinstance(max_entries, int) and max_entries >= 0, \
                f'Invalid expose Cache max_entries: {max_entries}' \
                f', must be an int >= 0 (max_entries=0 means no store)'
        if expiry_time:
            assert isinstance(expiry_time, (int, datetime, timedelta)), \
                f'Invalid Cache expiry_time: {expiry_time}, must be instance of int/datetime/timedelta'

        self.client_cache = client_cache
        self.api_cache = api_cache  # when api_cache=True, Unit will wrap the call into the executor
        self.max_entries = max_entries

        self.expiry_time = expiry_time or None
        self.cache_control: Optional[str] = cache_control  # response cache control

        self._if_modified_since: Optional[datetime] = None
        self._if_none_match: Optional[str] = None
        self._if_notmodified_since: Optional[datetime] = None
        self._if_match: Optional[str] = None
        self._cache_control: Optional[str] = None  # request cache control
        self._etag: Optional[str] = None
        self._last_modified: Optional[datetime] = None
        self._for_write = False
        self._allow_global = allow_global
        self._allow_cross = allow_cross

        self._from_api = False
        self.cache_alias = cache_alias

        self.config = config.auto_cache
        if self.max_entries and not self.config.entity_cls.SUPPORT_MAX_ENTRIES:
            raise ValueError(f'Entity class {self.config.entity_cls} not support max_entries: {self.max_entries}')

        self.requests = 0
        self.not_mods = 0
        self.misses = 0

    @property
    def from_api(self):
        return self._from_api

    @property
    def scope_key(self) -> str:
        # if isinstance(self.from_cache, Cache):
        #     return self.from_cache.__declare_path__ or ''
        return self.__declare_path__ or ''

    @property
    def redis_con(self):
        from redis.client import Redis
        if self.cache_config and self.cache_config.is_redis:
            from django_redis import get_redis_connection
            client: Redis = get_redis_connection(alias=self.cache_alias)
            return client
        return None

    def encode(self, key: VAL, _con: str = '-'):
        if isinstance(key, bytes):
            key = key.decode()
        elif multi(key):
            return [self.encode(k, _con) for k in key]
        elif isinstance(key, dict):
            return {self.encode(k, _con): v for k, v in key.items()}
        else:
            key = str(key)
        if not isinstance(_con, str) or not len(_con) == 1:
            _con = '-'
        if key.startswith(self.scope_key):
            return key
        return f'{self.scope_key}{_con}{key}'

    def decode(self, key: VAL):
        if isinstance(key, bytes):
            key = key.decode()
        elif multi(key):
            return [self.decode(k) for k in key]
        elif isinstance(key, dict):
            return {self.decode(k): v for k, v in key.items()}
        else:
            key = str(key)
        if key.startswith(self.scope_key):
            return key[len(self.scope_key) + 1:]
        return key

    @property
    def cache_config(self):
        from utilmeta.conf import config
        return config.caches.get(self.cache_alias)

    @property
    @ignore_errors(default=None)
    def cache_instance(self) -> BaseBackend:
        from django.core.cache import caches
        return caches[self.cache_alias]

    @property
    def no_store(self):
        return self.max_entries == 0

    @property
    def no_cache(self):
        return not self.expiry_time and not self.last_modified and not self.etag

    @property
    def expires_header(self) -> Optional[str]:
        dt = self.expire_datetime
        if not dt:
            return None
        utc_dt = dt - config.utcoffset
        return utc_dt.strftime(Format.DATETIME_GMT)

    @property
    def last_modified(self):
        return self._last_modified

    @last_modified.setter
    def last_modified(self, val):
        if val is None:
            return
        self._last_modified = type_transform(val, datetime)

    @property
    def etag(self):
        return self._etag

    @etag.setter
    def etag(self, val):
        self._etag = etag(val)

    @property
    @ignore_errors(default=False, log=False)
    def not_modified(self) -> bool:
        # priority: etag/match > modified/since
        if self._for_write:
            if self.etag and self._if_match:
                return self.etag == self._if_match
            if self.last_modified and self._if_notmodified_since:
                return self.last_modified <= self._if_notmodified_since
        else:
            if self.etag and self._if_none_match:
                return self.etag == self._if_none_match
            if self.last_modified and self._if_modified_since:
                return self.last_modified <= self._if_modified_since
        return False

    def check_precondition(self):
        if self._for_write:
            if not self._if_notmodified_since and not self._if_match:
                raise exc.PreconditionRequired()

    @property
    def max_age(self):
        if not self.expiry_time:
            return None
        if isinstance(self.expiry_time, int):
            return self.expiry_time
        if isinstance(self.expiry_time, timedelta):
            return self.expiry_time.total_seconds()

        if isinstance(self.expiry_time, datetime):
            now = time_now(self.expiry_time)
            if self.expiry_time > now:
                return (self.expiry_time - now).total_seconds()
        return None

    @property
    def request_cache_control(self):
        return self._cache_control

    @property
    def response_cache_control(self):
        if self.cache_control:
            return self.cache_control
        if self.etag or self.last_modified:
            return self.NO_CACHE
        max_age = self.max_age
        if max_age:
            return f'{self.MAX_AGE}={max_age}'
        return None

    @response_cache_control.setter
    def response_cache_control(self, val):
        self.cache_control = val

    @property
    def if_modified_since(self):
        return self._if_modified_since

    @property
    def if_none_match(self):
        return self._if_none_match

    @property
    def if_match(self):
        return self._if_match

    @property
    def if_notmodified_since(self):
        return self._if_notmodified_since

    @property
    def headers(self) -> dict:
        if not self.client_cache:
            return {}
        return {
            Header.ETAG: self.etag,
            Header.LAST_MODIFIED: self.last_modified,
            Header.CACHE: self.response_cache_control,
            Header.EXPIRES: self.expires_header
        }

    @property
    def expire_datetime(self) -> datetime:
        return self.expiry_time if isinstance(self.expiry_time, datetime) else None \
            if not isinstance(self.expiry_time, int) else time_now() + timedelta(seconds=self.expiry_time)

    @classmethod
    def expire_seconds(cls, timeout):
        if isinstance(timeout, datetime):
            timeout = timeout - time_now()
        if isinstance(timeout, timedelta):
            timeout = timeout.total_seconds()
        if isinstance(timeout, int) and timeout > 0:
            return timeout
        return None

    def get_timeout(self, timeout: Union[int, timedelta, datetime, float] = ...):
        if timeout is ...:
            timeout = self.expire_seconds(self.expiry_time)
        elif timeout is not None:
            timeout = self.expire_seconds(timeout)
        return timeout

    def __call__(self, func: Callable, *args, **kwargs):
        """
        This method is used for cache common function or API function
        when api_cache=True Unit will auto wrap partial(util.cache, executor) to call this method
        this method will also apply etag/last-modified assign and not_modified check
        !!it should call when the result is directly return!!
        eg:

        @api.get(cache=Cache(client_cache=True))
        def md(self, name: str, version: str, lang: str):
            path = self.media.get(f'{lang}/{version}/{name}.md')
            self.cache.last_modified = os.path.getmtime(path)
            return self.cache(render, path)

        because the result maybe a HttpResponse(status=304), so use it as a middle value will cause exception
        if you just want to cache a function with Cache
        use self.cache.apply(func, *args, **kwargs) or @api.cache to decorate the target function
        """
        from django.http.response import HttpResponseNotModified, HttpResponseBase
        assert callable(func), f'Cache.apply must apply to a callable function, got {func}'
        self.requests += 1
        if self.not_modified:
            self.not_mods += 1
            return HttpResponseNotModified()
        key = self.encode(f'{get_mark(func)}({dump_kwargs(args, kwargs)})', ':')
        result = self.get(key, _api_key=self.scope_key)
        # use _api_key to confirm this
        if self.not_modified:
            self.not_mods += 1
            return HttpResponseNotModified()
        if result is not None:
            return result
        self.misses += 1
        result = func(*args, **kwargs)
        if isinstance(result, HttpResponseBase):
            if result.status_code < 200 or result.status_code >= 300:
                return result
        self.set(key, result)
        return result

    def apply(self, func: Callable, *args, **kwargs):
        """
        this function result used as a middle value instead of API return value
        just cache the function
        """
        assert callable(func), f'Cache.apply must apply to a callable function, got {func}'
        self.requests += 1
        key = self.encode(f'{get_mark(func)}({dump_kwargs(args, kwargs)})', ':')
        result = self[key]
        if result is not None:
            return result
        self.misses += 1
        result = func(*args, **kwargs)
        self[key] = result
        return result

    def __getitem__(self, item):
        return self.get(item)

    def __setitem__(self, key, value):
        return self.set(key, value)

    def __eq__(self, other: 'Cache'):
        if not isinstance(other, Cache):
            return False
        return self.scope_key == other.scope_key

    def get(self, key, default=None, *, scope=..., _api_key: str = None):
        entity = self.get_entity(scope)
        v = entity.get(self.encode(key), single=True)
        if v is None:
            return default
        return v

    def fetch(self, args=None, *keys, scope=..., named: bool = False) -> Union[list, Dict[str, Any]]:
        keys = keys_or_args(args, *keys)
        entity = self.get_entity(scope)
        values = entity.get(*self.encode(keys))
        return map_dict(values, *keys) if named else values

    def get_entity(self, scope=...) -> CacheEntity:
        if scope is ... or scope is self:
            entity = self.config.entity_cls(self)
        elif isinstance(scope, self.__class__):
            if not self._allow_cross or not scope._allow_cross:
                text = 'this' if not self._allow_cross else 'target'
                raise ValueError(f'{text} Cache instance not allow cross-scope access, '
                                 'if you need cross-scope access, turn both Cache allow_cross=True')
            entity = self.config.entity_cls(scope, readonly=True)
            # cache from other scope is readonly
        elif scope is None:
            if not self._allow_global:
                raise ValueError('this Cache instance is not allow global key, '
                                 'if you need to manipulate global keys, turn allow_global=True')
            entity = self.config.entity_cls(self, local=True)
        else:
            raise ValueError(f'Invalid cache scope: {scope}')
        return entity

    def set(self, key, value, *, timeout: Union[int, timedelta, datetime] = ...,
            exists_only: bool = False, not_exists_only: bool = False):
        entity = self.get_entity()
        entity.set(self.encode(key), value, timeout=self.get_timeout(timeout),
                   exists_only=exists_only, not_exists_only=not_exists_only)

    def pop(self, key):
        val = self[key]
        del self[key]
        return val

    def delete(self, args=None, *keys):
        keys = keys_or_args(args, *keys)
        if not keys:
            return
        entity = self.get_entity()
        entity.delete(*self.encode(keys))

    def __delitem__(self, key):
        self.delete(key)

    def has(self, key, scope=...) -> bool:
        return bool(self.exists(key, scope=scope))

    @property
    # @ignore_errors(default=list)
    def keys(self) -> List[str]:
        entity = self.get_entity()
        return self.decode(entity.keys())

    # @ignore_errors(default=0, log=False)
    def __len__(self) -> int:
        entity = self.get_entity()
        return entity.count()

    # @ignore_errors(default=0, log=False)
    def exists(self, args=None, *keys, scope=...) -> int:
        keys = keys_or_args(args, *keys)
        if not keys:
            return 0
        entity = self.get_entity(scope)
        return entity.exists(*self.encode(keys))

    def __contains__(self, key) -> bool:
        return self.has(key)

    def expire(self, *keys: str, timeout: float):
        entity = self.get_entity()
        entity.expire(*self.encode(keys), timeout=self.get_timeout(timeout))

    def update(self, data: Dict[str, Any], timeout: Union[int, timedelta, datetime] = ...):
        if not data:
            return
        entity = self.get_entity()
        entity.update(data=self.encode(data), timeout=self.get_timeout(timeout))

    def incr(self, key: str, amount: NUM = 1, high_bound: int = None) -> Optional[NUM]:
        """
        Increase key by amount > 0, you can set a high_bound number
        return the altered number (float/int) if successfully modified, elsewhere return None
        """
        if not amount:
            return self[key]
        if amount < 0:
            raise ValueError(f'Cache incr amount should > 0, got {amount}')
        return self.alter(key=key, amount=amount, limit=high_bound)

    def decr(self, key: str, amount: NUM = 1, low_bound: int = None) -> Optional[NUM]:
        """
           Decrease key by amount > 0, you can set a low_bound number
           return the altered number (float/int) if successfully modified, elsewhere return None
        """
        if not amount:
            return self[key]
        if amount < 0:
            raise ValueError(f'Cache decr amount should > 0, got {amount}')
        return self.alter(key=key, amount=-amount, limit=low_bound)

    def alter(self, key: str, amount: Union[int, float], limit: int = None) -> Optional[NUM]:
        entity = self.get_entity()
        return entity.alter(self.encode(key), amount=amount, limit=limit)

    def lock(self, args=None, *keys, block: bool = False) -> Locker:
        keys = keys_or_args(args, *keys)
        entity = self.get_entity()
        return entity.lock(*keys, block=block)

    def make_cache(self, request):
        cache = self.__copy__()
        # keep in the same scope
        from ..request import Request
        assert isinstance(request, Request), f'Invalid request: {request}, must be Request object'
        headers = request.headers
        write = request.write

        from utilmeta.conf import config
        if not config.auto_cache or not config.auto_cache.client_cache:
            return cache
        modified_since = headers.get(Header.IF_MODIFIED_SINCE)
        notmodified_since = headers.get(Header.IF_NOTMODIFIED_SINCE)
        cache._if_modified_since = type_transform(modified_since, datetime) if modified_since else None
        cache._if_notmodified_since = type_transform(notmodified_since, datetime) if notmodified_since else None
        cache._if_none_match = headers.get(Header.IF_NONE_MATCH)
        cache._if_match = headers.get(Header.IF_MATCH)
        cache._cache_control = headers.get(Header.CACHE)
        cache._for_write = write
        cache._from_api = True
        return cache
