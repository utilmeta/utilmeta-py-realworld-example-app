from django.core.cache import caches
from django.core.cache.backends.base import BaseCache as CacheBase
from django.db.models import Count, Model, ManyToManyField
from django.db.models.fields.reverse_related import ForeignObjectRel
from django.db.models import Field as FieldBase
from django.db.models.fields.related_descriptors import ManyToManyDescriptor
from django.db.models.expressions import BaseExpression

from utilmeta.util.common import get_fields, get_field, SEG, \
    del_field_id, ValuesType, ignore_errors, \
    is_pk, one_to, CACHE_ASIDE, many_to, dict_list, parse_list, \
    add_field_id, merge_query, multi, get_exp_field, \
    merge_list, WRITE_BACK, setval, Key, merge_fields, PK
from utilmeta.util.base import Util

from typing import List, Union, Dict, Callable, Optional, Set, Type, Tuple
from datetime import timedelta, datetime
NUM = Union[int, float]


class Locker:
    def __init__(self, *keys, key_func: Callable[[str], str] = lambda x: x + '!', block: bool = False,
                 timeout: int = None, blocking_timeout: int = None, sleep: int = 0.1):
        self.key_func = key_func
        self.timeout = timeout
        self.blocking_timeout = blocking_timeout
        self.sleep = sleep
        self.scope = keys
        self.targets = []
        self.block = block

    def __enter__(self) -> 'Locker':
        raise NotImplementedError

    def __exit__(self, exc_type, exc_val, exc_tb):
        raise NotImplementedError


class BaseModelCache(Util):
    # ---- settings
    COUNTS_RESOLVE = False
    PROCESS_NAME = None

    def __init__(self, model: Type[Model], *, load: bool = True,
                 exclude_relates: List[str] = (), load_orders: tuple = (),
                 entry_timeout: Union[int, timedelta] = None, lock_timeout: Union[int, timedelta] = 5,
                 lock_blocking_timeout: Union[int, timedelta] = 5, client_cache: bool = False,
                 max_entries: int = None, update_strategy: str = CACHE_ASIDE):

        super().__init__(locals())
        from utilmeta.conf import config
        self.config = config.auto_cache
        assert self.config, f'utilmeta.util.cache.BaseCache instance require to set config.auto_cache'

        self.alias = self.config.master_alias
        self.cache: CacheBase = caches[self.alias]

        self.max_entries = int(max_entries) if max_entries else None
        self.orders = tuple(load_orders)
        self.model = model
        self.update_strategy = update_strategy
        self.relate_cache: Dict[str, BaseModelCache] = {}
        self.base_cache: Dict[str, BaseModelCache] = {}

        self.cross_fields = []
        self.value_fields = [PK]
        self.main_fields = []
        self.update_fields = []
        self.base_fields = []
        self.relate_fields = []
        self.relate_through = {}
        self.key_type: Dict[str, type] = {}

        self.through_data: List[Tuple[Type[Model], str, str, str]] = []
        # [(<model>, <m2m_field>, <from_field>, <to_field>)]

        self.exclude_relates = exclude_relates

        self.entry_timeout: int = entry_timeout.total_seconds() if \
            isinstance(entry_timeout, timedelta) else int(entry_timeout) \
            if isinstance(entry_timeout, int) else None
        self.lock_timeout: int = lock_timeout.total_seconds() if \
            isinstance(lock_timeout, timedelta) else int(lock_timeout) \
            if isinstance(lock_timeout, int) else None
        self.lock_blocking_timeout: int = lock_blocking_timeout.total_seconds() if \
            isinstance(lock_blocking_timeout, timedelta) else int(lock_blocking_timeout) \
            if isinstance(lock_blocking_timeout, int) else None

        self.client_cache = client_cache
        self.table = getattr(self.model, '_meta').db_table
        self.init_load = load
        self.fields_loaded = False
        self.data_loaded = False

    @property
    def pk_type(self) -> type:
        return self.key_type.get(PK, str)

    @property
    def bases(self) -> Set['BaseModelCache']:
        return {v for v in self.base_cache.values() if v}

    @property
    def key_alias(self):
        from utilmeta.util.parser import Alias
        return Alias([Alias.Field(alias_from=f, alias_for=add_field_id(f)) for f in self.main_fields])

    @property
    def keys(self) -> List[str]:
        raise NotImplementedError

    @property
    def query_db(self):
        from ..query import MetaQuerySet
        # from django.db.models import QuerySet
        # return QuerySet(model=self.model)
        return MetaQuerySet(model=self.model, hints={Key.DISABLE_CACHE: True})

    def query_pk(self, *pk_list):
        if not pk_list:
            return self.query_db.none()
        if len(pk_list) == 1:
            return self.query_db.filter(pk=pk_list[0])
        return self.query_db.filter(pk__in=pk_list)

    @property
    def pk_list(self):
        return []

    @pk_list.setter
    def pk_list(self, values):
        pass

    @property
    def cache_rate(self):
        from ..common import make_percent
        cnt = len(self.keys)
        tot = self.total_key_count
        return f'{cnt} ({make_percent(cnt, tot)}% cached)'

    @property
    def total(self):
        return len(self.pk_list)

    @property
    def total_key_count(self) -> int:
        return self.total

    def backward_field(self, field) -> Union[ForeignObjectRel, FieldBase]:
        return get_field(self.model, field).remote_field

    def load_fields(self):
        from ..field import Field

        if self.fields_loaded:
            return

        for f in get_fields(self.model):
            if is_pk(f):
                continue
            name = add_field_id(f.name) if one_to(f) else f.name
            self.update_fields.append(name)

        for f in get_fields(self.model, many=True):
            if is_pk(f):
                self.key_type[PK] = Field.get_type(f)
                continue
            if f.model is not self.model:
                self.base_fields.append(f.name)
                self.base_cache[f.name] = self.config.get(f.model)
                continue

            if not f.related_model:
                self.value_fields.append(f.name)
                if one_to(f):
                    # CrossServiceKey
                    self.cross_fields.append(f.name)
                continue

            if one_to(f):
                self.main_fields.append(f.name)
                self.value_fields.append(f.name)
            elif many_to(f):
                self.key_type[f.name] = Field.get_type(f.related_model)
                if f.many_to_many:
                    name = f.name if isinstance(f, ManyToManyField) else f.get_cache_name()
                    desc: ManyToManyDescriptor = getattr(self.model, name)
                    through_fields = list(desc.rel.through_fields or
                                     [desc.field.m2m_field_name(),
                                      desc.field.m2m_reverse_field_name()])

                    if not isinstance(f, ManyToManyField):
                        through_fields.reverse()

                    thr_cache = self.config.get(desc.through)
                    if thr_cache:
                        thr_cache.through_data.append((self.model, f.name, *through_fields))
                        self.relate_through[f.name] = (
                            get_field(desc.through, through_fields[0]).remote_field.name,
                            get_field(desc.through, through_fields[1]).remote_field.name,
                        )

                self.relate_fields.append(f.name)
            self.relate_cache[f.name] = self.config.get(f.related_model)
        self.fields_loaded = True

    def load_data(self):
        if not self.init_load or self.data_loaded:
            return
        # from utilmeta.conf import config
        # if not config.deploy.acquire_worker_lock('cache'):
        #     return
        import time
        start = time.time()
        queryset = self.query_db.order_by(*self.orders)
        self.pk_list = list(queryset.values_list(PK, flat=True))
        if self.max_entries:
            queryset = queryset[:self.max_entries]
        # print(self.model, self.value_fields)
        values: ValuesType = list(queryset.values(*self.value_fields))
        mapping = {str(v.get(PK)): v for v in values}
        pks = list(mapping.keys())
        self.set_values(mapping)
        self.load_relates({field: pks for field in self.relate_fields})
        self.clear_queue()
        self.refresh_sequence()
        self.data_loaded = True
        cost = round(time.time() - start, 3)
        if self.update_strategy == WRITE_BACK:
            self.sync_to_db(init=True)
        print(f'load data to cache for <{self.model.__name__}>: fetch {len(values)} entries in {cost} s')

    def clear_data(self):
        raise NotImplementedError

    def clear_queue(self):
        raise NotImplementedError

    def clear_relates(self, field: str, pk_list: list):
        raise NotImplementedError

    def relate_modified_list(self, pk_list: List[str], domain: dict) -> Optional[List[datetime]]:
        if not pk_list:
            return None
        # main_keys = set(self.main_fields).intersection(domain)
        val_keys = []
        for field, val in domain.items():
            if val is not None:     # need to validate the related values
                val_keys.append(field)
        time_list = []
        values = self.get_values(pk_list, fields=val_keys) if val_keys else []
        for key in val_keys:
            rel_cache = self.relate_cache.get(key)
            if not rel_cache:
                return None
            rel_pks = parse_list([val[key] for val in values or []], merge=True)
            time = rel_cache.last_modified(rel_pks, domain=domain[key])
            if not isinstance(time, datetime):
                return None
            time_list.append(time)
        return time_list

    def refresh_sequence(self):
        raise NotImplementedError

    def last_modified(self, pk_list: List[str], domain: dict, seq: bool = False) -> Optional[datetime]:
        raise NotImplementedError

    def load_from_db(self, pk_list: list):
        if not pk_list:
            return
        if None in pk_list:
            pk_list.remove(None)
        with self.lock(pk_list):
            db_values: ValuesType = list(self.query_pk(*pk_list).values(*self.value_fields))
            pk_values = {str(val.get(PK)): val for val in db_values}
            # pk is also a value field need to be set, so not use pop here
            self.set_values(pk_values)
            # bypass the max_entries policy
            for base in self.bases:
                base.load_from_db(pk_list)
            return pk_values

    def load_relates(self, relate_pks: Dict[str, list]):
        # self.relates = super().load_relates(pk_list)
        """
        :param relate_pks: {<relate_field>: [<pk>]}
        """
        # it can imply directly like merge_multiple(self.query_db.values(PK, self.relate_fields))
        # but the inner joined query result when relations is too much will overflow the memory
        # (the raw result is joined, so there is O(N^M) of space redundant)
        # for that reason, all relate fields are load one-by-one
        if not relate_pks:
            return
        for relate, pks in relate_pks.items():
            if not pks:
                continue
            values = merge_query(self.query_pk(*pks), fields=[PK, relate])
            pk_relates = {}
            for val in values:
                rel = val[relate]
                if rel is not None and not multi(rel):
                    rel = [rel]
                pk_relates[val.pop(PK)] = rel
            self.set_relates(field=relate, pk_relates=pk_relates)

    def exist_pks(self, pk_list: list):
        _pk_list = self.pk_list
        if _pk_list is None:
            return None
        if not pk_list or not _pk_list:
            return []
        if not multi(pk_list):
            pk_list = [pk_list]
        pk_type = type(_pk_list[0])
        pks = [pk_type(pk) for pk in pk_list]
        exists = list(set(pks).intersection(_pk_list))
        exists.sort(key=lambda x: pks.index(x))
        return exists

    @ignore_errors
    def resolve_pk_list(self, lookup: str, value, func: Callable) -> Optional[list]:
        from ..query import Lookup
        field, *lookups = lookup.split(SEG)
        f = get_field(self.model, field)
        if one_to(f):
            field = del_field_id(field)

        relate_cache = self.relate_cache.get(field)
        if lookups:
            relate_field = SEG.join(lookups)
            if not relate_cache:
                return None
            value = relate_cache.resolve_pk_list(relate_field, value, func)
            if value is None:
                return None
            elif not value:
                # if a long query lookup chain shows up empty in one lookup, the rest will
                # all be empty
                return []
            # trivial cases optimize
            if len(value) == 1:
                func = Lookup.exact
                value = value[0]
            else:
                func = Lookup.IN

        pk_list = []
        if is_pk(f, model=self.model):
            # directly query pk
            if Lookup.common(func):  # in / exact
                pk_list = self.exist_pks(value)
            else:
                pks = self.pk_list
                if pks is None:
                    # usually pk cache is never expired, so it will not be None (@pk not exists)
                    # when it happen, most likely the cache could not be working
                    return None
                for pk in pks:
                    if func(pk, value):
                        pk_list.append(pk)
            return pk_list

        if not relate_cache:
            # query non-relate fields or relate_model is not cached, query DB
            return None

        backward = self.backward_field(field)
        if one_to(backward):  # one-to-one / many-to-one
            if not Lookup.common(func):
                return None
            values = relate_cache.get_values(value, fields=[backward.name])
            return [val.get(backward.name) for val in values]
        if func == Lookup.IN:
            return relate_cache.get_union_relates(field=backward.name, pk_list=value)
        elif func == Lookup.exact:
            return relate_cache.get_relates(field=backward.name, pk=value)
        # cache resolve cannot handle relate query other than in / exact
        return None

    def append_pk_list(self, pk_list: list):
        raise NotImplementedError

    def delete_pk_list(self, pk_list: list):
        raise NotImplementedError

    def append_key_relates(self, pk_relates: Dict[str, dict]):
        fk_relates: Dict[str, Dict[str, list]] = {}
        for pk, relates in pk_relates.items():
            for key, val in relates.items():
                if val is None:
                    continue
                if key not in fk_relates:
                    fk_relates[key] = {val: [pk]}
                elif val not in fk_relates[key]:
                    fk_relates[key][val] = [pk]
                else:
                    fk_relates[key][val].append(pk)

        if not fk_relates:
            return

        # consider a through relationship
        # class StudentCourse(Model):
        #     course = ForeignKey(Course, related_name='course_students')
        #     student = ForeignKey(Account, related_name='student_courses')
        #     ...
        # and Course -> (students)[through=StudentCourse] -> Account is a m2m relation
        # if a new StudentCourse(pk=1, course_id=3, student_id=5) is created
        # the following relations need to be update
        #
        # course:3@course_students += 1
        # course:3@students += 5
        # account:5@student_courses += 1
        # account:5@courses += 3

        for data in self.through_data:
            model, relate, from_key, to_key = data
            rel_cache = self.config.get(model)
            if not rel_cache:
                continue
            key_relates: Dict[str, list] = {}
            for pk, relates in pk_relates.items():
                from_val, to_val = relates.get(from_key), relates.get(to_key)
                setval(key_relates, key=from_val, v=to_val, array=True)
            rel_cache.set_relates(field=relate, pk_relates=key_relates, add=True)

        for key, relates in fk_relates.items():
            rel_cache = self.relate_cache.get(key)
            if not rel_cache:
                continue
            backward = self.backward_field(key)
            rel_cache.set_relates(field=backward.name, pk_relates=relates, add=True)  # , backward=True)

    def update_queue(self, pk_list: list = None, relate_pks: Dict[str, list] = None):
        raise NotImplementedError

    def cascade_clear(self, pk_list: list):
        # DO CASCADE CLEAR AFTER DEL_VALUES OTHERWISE WILL CAUSE ENDLESS RECURSIVE
        # -----------
        # delete values for all (CASCADE and SET_NULL strategy)
        # when instance of this model is deleted. despite of fk delete policy, delete related instances
        # class Article:
        #       account = FK(Account, on_delete=CASCADE, related_name='articles')
        #
        if not pk_list:
            return
        for field, cache in self.relate_cache.items():
            if cache.model is self.model:
                continue
            if one_to(self.backward_field(field)):
                # backward field is Fk or one-to-one field
                cascade_relates = []
                for item in self.get_batch_relates([field], pk_list=pk_list):
                    cascade_relates.extend(item[field])
                if not cascade_relates:
                    continue
                print('CASCADE RELATES:', field, cache, cascade_relates)
                cache.del_values(cascade_relates, delete=True)
                # prevent endless recursive

    def del_values(self, pk_list: list, delete: bool = False):
        """
                Delete cache values of pk_list, maybe for two reason
                1. db values is updated
                2. db values is deleted, need del_relates=True to delete all relates
                """
        if not pk_list:
            return
        if not delete:
            return

        many_relates = self.get_batch_relates(fields=self.relate_fields, pk_list=pk_list)
        fk_relates = self.get_values(fields=self.main_fields, pk_list=pk_list) or []
        # use fk values before del_values

        # notice that if multiple through relates on same (from, to) pair
        # and remove one of the through instance the relate won't change
        # say that
        # id  |  course_id | student_id
        # 1       3             5
        # 2       3             5
        # and remove StudentCourse(id=2) the course:3@students / account:5@courses won't change
        # so a simple solution here is just clear the target relates
        # next time when it is queried will be load form db
        for data in self.through_data:
            model, relate, from_key, to_key = data
            rel_cache = self.config.get(model)
            if not rel_cache:
                continue
            fks = list({relates.get(from_key) for relates in fk_relates})
            if None in fks:
                fks.remove(None)
            rel_cache.clear_relates(field=relate, pk_list=fks)

        # ------------
        # delete relates (relate to deleted pks) for all the many-to and one-to values
        for field in self.relate_fields + self.main_fields:
            rel_cache = self.relate_cache.get(field)
            if not rel_cache:
                continue
            backward = self.backward_field(field)
            src = fk_relates if field in self.main_fields else many_relates
            if not src:
                continue
            pk_relates = {pk: src[i][field] for i, pk in enumerate(pk_list)}
            relate_pks = {}
            for rel, pks in pk_relates.items():
                if not multi(pks):
                    pks = [pks]
                for pk in pks:
                    if pk not in relate_pks:
                        relate_pks[pk] = [rel]
                    else:
                        relate_pks[pk].append(rel)
            rel_cache.del_relates(field=backward.name, pk_relates=relate_pks)
        self.delete_pk_list(pk_list)

    def del_relates(self, field: str, pk_relates: Dict[str, list]):
        raise NotImplementedError

    def set_relates(self, field: str, pk_relates: Dict[str, list],
                    add: bool = False, remove: bool = False, backward: bool = False, clear_through: bool = False):
        raise NotImplementedError

    def main_key(self, key) -> Optional[str]:
        # example: course_id is a non-pk field of Course
        #          but teacher_id is a main_key (teacher is pk field)
        if key in self.main_fields:
            return key
        if key in self.value_fields:
            return None
        key = del_field_id(key)
        if key in self.main_fields:
            return key
        return None

    def update_keys(self, pk_relates: Dict[str, dict], current_values: List[dict] = None):
        """
        if update_strategy is CACHE_ASIDE, delete all related updates
        """
        if not self.main_fields:
            return
        if not pk_relates:
            return
        pk_list = list(pk_relates.keys())
        pk_relates = {str(key): {self.main_key(k): v for k, v in val.items() if self.main_key(k)}
                      for key, val in pk_relates.items()}

        with self.lock(pk_list):
            # lock pk_list in case that fk changed during update
            if not current_values:
                current_values = self.get_values(pk_list, fields=[PK] + self.main_fields, preload=False) or []
            for values in current_values:  # old
                pk = str(values[PK])
                relates = pk_relates[pk]  # new
                for k, v in relates.items():
                    rel_cache = self.relate_cache.get(k)
                    if not rel_cache:
                        continue
                    if str(values[k]) == str(v):
                        continue
                    backward = self.backward_field(k)
                    rel_cache.del_relates(field=backward.name, pk_relates={values[k]: [pk]})
                    rel_cache.set_relates(field=backward.name, pk_relates={v: [pk]}, add=True)

    def update_values(self, pk_data: Dict[str, dict], append: bool = False):
        """
        update proxy for manager to abstract the real set_values
        only set within self.value_fields and apply to bases
        """
        pk_relates = {}
        for pk, data in pk_data.items():
            relates = {}
            for field in list(data.keys()):
                value = data[field]
                main_key = self.main_key(field)
                if main_key:
                    relates[main_key] = value
                    data[main_key] = data.pop(field)
                    continue
                elif field not in self.value_fields:
                    data.pop(field)
            pk_relates[pk] = relates

        if not append:
            # when create values (from _insert, append=True) keys in append using append_key_relates
            # don't update keys here, SELECT after INSERT might cause slow query

            self.preload(list(pk_data.keys()), self.ParsedFields(values=set(self.value_fields)))
            self.update_keys(pk_relates)
        # update_keys need to know current values, so before set_values
        self.set_values(pk_data, prep=True)
        for base in self.bases:
            # if data is from _update in manager, base model will have no values to update
            # still call, but prevent hmset empty values
            base.update_values(pk_data, append=append)

    def lock(self, keys: list, block: bool = True):
        return Locker(*keys, block=block)

    def sync_to_db(self, init: bool = False, once: bool = False):
        raise NotImplementedError

    @classmethod
    def init_service(cls):
        pass

    class ParsedFields(Util):
        def __init__(self, values: Set[str] = None, lookups: Dict[str, list] = None,
                     relates: List[str] = None, keys: List[str] = None, dbs: List[str] = None,
                     bases: Dict['BaseModelCache', list] = None, annotates: Dict[str, BaseExpression] = None,
                     counts: Dict[str, Count] = None, outputs: List[str] = None,
                     relate_annotates: Dict[str, dict] = None, aliased_keys: list = None):

            super().__init__(locals())
            self.dbs = dbs or []
            self.values = list(values) if values else []
            self.lookups = lookups or {}
            self.keys = keys or []
            self.relates = relates or []
            self.bases = bases or {}
            self.counts = counts or {}
            self.annotates = annotates or {}
            self.outputs = outputs or []
            self.relate_annotates = relate_annotates or {}
            self.aliased_keys = aliased_keys or []

        @property
        def expressions(self):
            annotates = dict(self.annotates)
            annotates.update(self.counts)
            return annotates

        def gen_relates(self, relate_fields: list, exclude_relates: list):
            result = [r for r in self.relates if r not in exclude_relates]
            for key, exp in self.expressions.items():
                field = get_exp_field(exp)
                if field in relate_fields and field not in exclude_relates:
                    result.append(field)
            return result

    def parse_fields(self, fields: List[str], expressions: Dict[str, BaseExpression] = None):
        expressions = expressions or {}
        if isinstance(fields, str):
            fields = [fields]

        def gen_fields(exps: dict, b: str = ''):
            lst = []
            for _k, _v in exps.items():
                name = f'{b}{SEG}{_k}' if b else _k
                if isinstance(_v, dict):
                    lst += gen_fields(_v, b=name)
                else:
                    lst.append(name)
            return lst

        output_fields = list(set(fields).union(gen_fields(expressions)))
        values = set()
        bases = {}
        lookups = {}
        counts = {}
        annotates = {}
        relate_annotates = {}
        aliased_keys = []

        for key, exp in expressions.items():
            if isinstance(exp, dict) and exp:
                if key in self.relate_cache:
                    relate_annotates[key] = exp
            elif isinstance(exp, BaseExpression):
                field: str = get_exp_field(exp)
                if isinstance(exp, Count) and SEG not in field:
                    counts[key] = exp
                    if self.COUNTS_RESOLVE:
                        continue
                fields.append(field)
                # append field to fields (but not to the outputs)
                # expressions other than Count need the full result
                annotates[key] = exp

        for f in set(fields):
            _f = del_field_id(f)
            if f in self.value_fields:
                if f in self.main_fields:
                    if f in lookups:
                        lookups[f].append(PK)
                    else:
                        lookups[f] = [PK]
                values.update({f})
                continue

            elif _f in self.main_fields + self.cross_fields:
                # like 'creator_id' , fk+'_id' field
                values.update({_f})
                aliased_keys.append(_f)
                continue

            if SEG in f:
                k, *lookup_list = f.split(SEG)
                if k in self.base_fields:
                    base = self.base_cache.get(k)
                    if base in bases:
                        bases[base].append(f)
                    else:
                        bases[base] = [f]
                    continue
                if k not in self.relate_cache:
                    continue
                val = SEG.join(lookup_list)
                if k in lookups:
                    lookups[k].append(val)
                else:
                    lookups[k] = [val]

            elif _f in self.base_fields:
                # maybe it's main_fields in base model, but need to append the raw field
                # to make sure get the correct base get_values result
                base = self.base_cache.get(_f)
                if base in bases:
                    bases[base].append(f)
                else:
                    bases[base] = [f]

            elif f in self.relate_fields:
                if f in lookups:
                    lookups[f].append(PK)
                else:
                    lookups[f] = [PK]

        dbs = []
        relates = []
        for key in tuple(lookups.keys()):
            val = lookups[key]
            if key in self.main_fields:
                if not val:
                    lookups.pop(key)
            elif not self.relate_cache.get(key):
                dbs += [key] + [f'{key}{SEG}{v}' for v in val]
            else:
                relates.append(key)

        if None in bases:
            dbs += bases[None]

        return self.ParsedFields(
            values=values,
            relates=relates,
            lookups=lookups,
            keys=[key for key in lookups if key in self.main_fields],
            bases=bases,
            dbs=dbs,
            counts=counts,
            annotates=annotates,
            outputs=output_fields,
            relate_annotates=relate_annotates,
            aliased_keys=aliased_keys
        )

    @classmethod
    @ignore_errors(default=dict, log=True)
    def unresolved_expressions(cls, values: List[dict], expressions: dict) -> dict:
        if values is None:
            # values is None means that the get_values raised an exception
            return expressions
        if not values or not expressions:
            return {}
        sample = values[0]

        def recursive(exps: dict, base: str = ''):
            items = {}
            for key, val in exps.items():
                name = f'{base}{SEG}{key}' if base else key
                if isinstance(val, dict):
                    i = recursive(val, base=name)
                    if i:
                        items[key] = i
                elif sample.get(name) is ...:
                    items[key] = val
            return items
        return recursive(expressions)

    def preload(self, pk_list: list, parsed: ParsedFields):
        raise NotImplementedError

    def set_values(self, data: Dict[str, dict], prep: bool = False):
        raise NotImplementedError

    def get_relates(self, field: str, pk, page: slice = slice(0, -1)) -> list:
        raise NotImplementedError

    def get_union_relates(self, field: str, pk_list: list, page: slice = slice(None, None)) -> list:
        parsed = self.ParsedFields(relates=[field])
        self.preload(pk_list, parsed)
        relates = set()
        for pk in pk_list:
            relates.update(self.get_relates(field=field, pk=pk, page=page))
        return list(relates)

    def get_batch_relates(self, fields: List[str], pk_list: list, pages: Dict[str, slice] = None) -> List[dict]:
        return [{field: self.get_relates(field=field, pk=pk,
            page=pages.get(field, slice(None, None) if pages else None))
            for field in fields} for pk in pk_list]

    def get_common_values(self, pk_list: list, fields: List[str]) -> List[dict]:
        """
        this method should make sure the result values length and position match pk_list arg
        the exist checking is in the upper layer (get_values)
        """
        raise NotImplementedError

    def get_relate_values(self, pk_list: list, parsed: ParsedFields, pages: Dict[str, slice]) -> List[dict]:
        if not pk_list:
            return []

        values = dict_list(len(pk_list))
        pages = pages or {}

        for base, lst in parsed.bases.items():
            cache_values = base.get_values(pk_list=pk_list, fields=lst) or []
            for value, base_value in zip(values, cache_values):
                value.update(base_value)

        main_values = []
        relate_values = []
        if parsed.keys:
            main_values = self.get_common_values(pk_list=pk_list, fields=parsed.keys)

        if parsed.relates:
            # Note: avoid iterate for pk_list and run query for each item
            # this complexity will be O(N) , convert it to a batch query at one time if possible
            relate_values = self.get_batch_relates(
                fields=parsed.relates, pk_list=pk_list, pages=pages)

        if parsed.dbs:
            db_values = merge_query(self.query_pk(*pk_list), fields=[PK, *parsed.dbs])
            for val in db_values:
                pk = val.pop(PK)
                values[pk_list.index(pk)].update(val)

        for key, fields in parsed.lookups.items():
            proxy = self.relate_cache.get(key)
            if not proxy:
                continue
            merge = PK not in fields
            # there is not an key field to aggregate the result, so the multiples will be merged
            # like 'problems__tags': [[1, 6], [], [1, 7, 13]] -> [1, 6, 7, 13]
            if merge:
                fields.append(PK)

            if key in self.main_fields:
                fks = list({val.get(key) for val in main_values})
                if None in fks:
                    fks.remove(None)
                fk_values = {str(val.get(PK)): val for val in
                    proxy.get_values(pk_list=fks, fields=fields,
                    expressions=parsed.relate_annotates.get(key)) or []}
                for i, pk in enumerate(pk_list):
                    fk = main_values[i].get(key)
                    if not fk:
                        continue
                    values[i].update(merge_fields(key=key, values=fk_values.get(str(fk), {}), fields=fields))
                    # for field in fields:
                    #     k = key if field == PK else f'{key}{SEG}{field}'
                    #     values[i][k] = fk_values.get(str(fk), {}).get(field)
                continue

            if not fields:
                # many relates, only query pks
                for i, pk in enumerate(pk_list):
                    values[i][key] = relate_values[i].get(key)
                continue

            rel_pks = parse_list([rel[key] for rel in relate_values],
                merge=True, merge_type=self.key_type.get(key, str))
            rel_values = {str(val.get(PK)): val for val in
                proxy.get_values(pk_list=rel_pks, fields=fields,
                expressions=parsed.relate_annotates.get(key)) or []}
            for i, pk in enumerate(pk_list):
                relates = relate_values[i].get(key)
                if not relates:
                    values[i][key] = []
                    continue
                for field in fields:
                    k = key if field == PK else f'{key}{SEG}{field}'
                    key_values = []
                    for rel in relates:
                        val = rel_values.get(str(rel))
                        if not val or field not in val:
                            # empty value
                            continue
                        key_values.append(val[field])
                    if merge:
                        key_values = parse_list(key_values, merge=True)
                    values[i][k] = key_values
        return values

    def get_expression_values(self, values: List[dict], parsed: ParsedFields) -> List[dict]:
        """
        try to resolve the expressions in pk_list,
        pop the expression that already been resolved
        the upper layer will get the remain expressions
        """
        from ..query import resolve_expression
        if not parsed.expressions or not values:
            return []
        result = dict_list(len(values))
        for key, exp in parsed.annotates.items():
            field: str = get_exp_field(exp)
            for res, val in zip(result, values):
                value = val.get(field)
                res[key] = resolve_expression(expression=exp, value=value)
        return result

    @classmethod
    def make_values(cls, values: List[dict], keys: list):
        if not keys:
            return values
        for val in values:
            for key in keys:
                val[add_field_id(key)] = val.get(key)
        return values

    # def alter_value(self, key: str, amount: Union[int, float], limit: int = None):
    #     raise NotImplementedError

    @ignore_errors(log=True)
    def get_values(self, pk_list: list, fields: List[str], expressions: Dict[str, BaseExpression] = None,
                   pages: dict = None, preload: bool = True) -> ValuesType:
        """
        in last version I use load_miss strategy to load the missed pk,
        but in this version, it change to preload strategy
        preload all queried data and directly retrieve them in cache ,
        """
        pk_list = self.exist_pks(pk_list)
        if not pk_list:
            # pk_list might be None or []
            # if pk_list is None. means data is not loaded yet, query should go to db
            return pk_list
        parsed = self.parse_fields(fields, expressions)
        if preload:
            self.preload(pk_list, parsed)
        values = self.make_values(self.get_common_values(
            pk_list=pk_list, fields=parsed.values), keys=parsed.aliased_keys)
        rel_values = self.get_relate_values(pk_list, parsed=parsed, pages=pages)
        exp_values = self.get_expression_values(merge_list(values, rel_values),
            parsed=parsed) if parsed.expressions else []
        result = merge_list(values, rel_values, exp_values, keys=parsed.outputs)
        while {} in result:
            result.remove({})
        return result
