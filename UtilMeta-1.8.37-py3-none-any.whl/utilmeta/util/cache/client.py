from ..base import Util


class CacheClient(Util):
    """
    Cache Client Utility that implements Web standard http cache (GET-only)
    * 304 Not Modified
    * Cache-Control
    * Expires
    * Last-Modified
    * Etag

    used in micro-service cluster, service can cache invoked result to reduce latency
    data structure:
    {
        'path/to/resource1': {
            'response': <bytes>,
            'headers': {
            }
        }
    }
    this is the cached data share between instances (among one service) using cluster cache
    so every instance can use other instances's cached response
    """
    pass
