from django.core.cache.backends.base import BaseCache, DEFAULT_TIMEOUT
from django.contrib.sessions.backends.cache import KEY_PREFIX as SESSION_KEY_PREFIX
import json
from utilmeta.util.common import LOCAL_IP, Static, list_or_args, time_now, task, \
    dumps, loads, json_dumps, BroadcastCacheType, ignore_errors, make_hash, COMMON_ERRORS, get_number
from typing import TYPE_CHECKING, List, Optional, Dict, Tuple, Union
if TYPE_CHECKING:
    from utilmeta.ops.schema.service import CacheInstanceSchema
from utilmeta.util.error import Error
from django.utils.module_loading import import_string


INST_DICT = Dict['CacheInstanceSchema', List[str]]

_instance_values = {}        # global instances
_logs = {}
# _clients = {}


def get_cluster_cache():
    from utilmeta.conf import config
    return BaseClusterCache(
        server=None,
        params=dict(
            KEY_FUNCTION=lambda key, *_: key,  # cluster scope, need to unify
            KEY_PREFIX=None,
            CACHE_ALIAS=config.session.cache_alias,
            SOURCE_SERVICE=config.session.from_service
        )
    ).assign(load_on_empty=True)


def globally_init_client(instance: 'CacheInstanceSchema'):
    from utilmeta.conf import config
    cache = config.caches.get(instance.alias)
    if cache and cache.clustered:
        params = cache.node_gen()
    else:
        params = dict(
            KEY_FUNCTION=lambda key, *_: key,  # cluster scope, need to unify
            KEY_PREFIX=None,
            CACHE_ALIAS=instance.alias,
            SOURCE_SERVICE=instance.service,
            OPTIONS=dict(PASSWORD=instance.password)
        )
    if instance.backend == SupportedBackend.redis:
        from django_redis.cache import RedisCache
        if instance:
            # should keep the original key_func / key_prefix settings
            params.update(OPTIONS=dict(PASSWORD=instance.password))
        return RedisCache(
            server=instance.location,
            params=params
        ).client
    elif instance.backend == SupportedBackend.memcached:
        from django.core.cache.backends.memcached import MemcachedCache
        return MemcachedCache(
            server=instance.location,
            params=params
        )
    return None


@ignore_errors(log=True)
def globally_retrieve_instances():
    from utilmeta.ops.module.service import CacheList
    from utilmeta.ops.schema.service import CacheInstanceSchema
    global _instance_values
    instances: Dict[str, List[CacheInstanceSchema]] = {}
    values: List[CacheInstanceSchema] = CacheList(query=dict(connected=True)).serialize()
    for val in values:
        if val.alias_key in instances:
            instances[val.alias_key].append(val)
        else:
            instances[val.alias_key] = [val]
        # if val.id not in _clients:
        # _clients[val.id] = globally_init_client(val)    # reload client periodically to prevent buffer memory leak
    _instance_values = instances


@ignore_errors
def globally_sync_to_db():
    global _logs
    global _instance_values
    if _logs:
        # SAVE LOGS
        from utilmeta.util.common import exp
        from utilmeta.ops.models.log import CacheLog
        new_logs = []
        for (inst_id, err_type, error), (time, latest, targets, count) in _logs.items():
            log = CacheLog.objects.filter(cache_id=inst_id, type=err_type, error=error).first()
            if log:
                log.latest_time = latest
                log.count = exp.F('count') + count
                log.save()
            else:
                new_logs.append(CacheLog(
                    time=time, latest_time=latest, count=count, targets=json.loads(json_dumps(targets)),
                    cache_id=inst_id, type=err_type, error=error,
                ))
        CacheLog.objects.bulk_create(new_logs)
        _logs = {}

    # SAVE INSTANCES
    from utilmeta.util.bulk import Bulk
    from utilmeta.ops.models.service import CacheStorage
    from utilmeta.ops.schema.service import CacheStatus
    from utilmeta.ops.module.service import CacheList

    instances = []
    for inst in CacheList().serialize():
        inst: 'CacheInstanceSchema'
        conn = inst.connected
        try:
            status = CacheStatus(get_instance_stats(inst))
            inst.used_memory = status.used_memory
            inst.current_connections = status.current_connections
            inst.total_connections = status.total_connections
            inst.qps = status.qps
            if status.qps:
                inst.max_qps = max(inst.max_qps, status.qps)
                inst.max_qps_time = time_now()
            inst.pid = status.pid
            inst.connected = True
        except Exception as e:
            print('DISCONNECTED for:', e)
            if conn:
                log_instance_error(inst, error=Error(e), disconnect=True)
        instances.append(inst)
    Bulk(model=CacheStorage, ignore_conflicts=True)(instances)


def log_instance_error(inst: 'CacheInstanceSchema', error: Error, info: dict = None, disconnect: bool = False):
    global _logs
    if disconnect:
        inst.connected = False
    meta = (inst.id, error.type.__name__, str(error.exc))
    now = time_now()
    target = dict(
        time=now,
        message=error.full_info,
    )
    if isinstance(info, dict):
        target.update(info)

    if meta in _logs:
        time, latest, targets, count = _logs[meta]
        latest = time_now()
        count += 1
        targets.append(target)
        _logs[meta] = time, latest, targets, count
    else:
        _logs[meta] = time_now(), time_now(), [target], 1
     
        
def get_instance_stats(instance: 'CacheInstanceSchema') -> dict:
    client = globally_init_client(instance)
    if not client:
        raise ValueError(f'Cache instance: {instance.id} client not initialized')
    if instance.backend == SupportedBackend.redis:
        return client.get_client().info()
    elif instance.backend == SupportedBackend.memcached:
        return getattr(client, '_client').get_stats()
    return {}


class SupportedBackend(Static):
    redis = 'redis'
    memcached = 'memcached'


class KeyInfo:
    ALL = '*'
    FLAG = '!'
    SEG = '|'
    SPLIT = '/'
    DEFAULT = '.'

    def __init__(self, key: str, version=None):
        self.key = key
        self.version = version
        self.name = key
        self.sync_nodes = ...
        self.block_nodes = 1
        self.local_only = False

        if key.endswith(self.FLAG):
            if self.SEG not in key:
                self.name = key.rstrip(self.FLAG)
                self.local_only = True
            else:
                i1 = key.index(self.SEG)
                i2 = key.index(self.SPLIT)
                name, block_nodes, sync_nodes = key[:i1], key[i1+1:i2], key[i2+1:-1]
                if block_nodes.isdigit():
                    block_nodes = int(block_nodes)
                if sync_nodes.isdigit():
                    sync_nodes = int(sync_nodes)
                elif sync_nodes == self.DEFAULT:
                    sync_nodes = ...
                self.name = name
                self.sync_nodes = sync_nodes
                self.block_nodes = block_nodes
        if self.local_only:
            self.block_nodes = 1
            self.sync_nodes = 1

    def __str__(self):
        return self.name

    @property
    def broadcast_type(self) -> Optional[str]:
        from utilmeta.conf import config
        if self.key.startswith(SESSION_KEY_PREFIX) and config.session.cluster_scope:
            return BroadcastCacheType.session
        return None

    @property
    def sync_all(self) -> bool:
        return self.sync_nodes == self.ALL

    @property
    def sync_default(self) -> bool:
        return self.sync_nodes is ...

    @property
    def block_all(self) -> bool:
        return self.block_nodes == self.ALL

    @classmethod
    def make(cls, name: str, *, sync_nodes: Union[str, int] = ...,
             block_nodes: Union[str, int] = 1, local_only: bool = False):
        if cls.SEG in name or name.endswith(cls.FLAG):
            raise ValueError(f'Invalid cluster cache key name,'
                             f' a valid key shall not contains SEG({cls.SEG}) '
                             f'or endswith FLAG({cls.FLAG}) ')
        tag = cls.FLAG
        if not local_only:
            tag = ''.join([
                cls.SEG,
                str(block_nodes),
                cls.SPLIT,
                str(sync_nodes) if isinstance(sync_nodes, (int, str)) else cls.DEFAULT,
                cls.FLAG
            ])
        return name + tag


class BaseClusterCache(BaseCache):
    SUPPORTED_BACKENDS = SupportedBackend.gen()
    BACKEND = None
    # store in-memory, per-process caches info

    def __init__(self, server, params: dict):
        super().__init__(params)
        self._server = server
        self._params = params
        self._options = params.get('OPTIONS', {})
        self._partition_level = 1
        # print('PARAMS:', params)
        self.interval = int(params.get('UPDATE_INTERVAL', 30))
        self.task_timeout = int(params.get('TASK_TIMEOUT', 3))
        self.alias = params.get('CACHE_ALIAS') or 'default'
        from utilmeta.conf import config
        self.service = params.get('SOURCE_SERVICE') or config.name

        serializer_path = self._options.get("SERIALIZER", "django_redis.serializers.pickle.PickleSerializer")
        serializer_cls = import_string(serializer_path)

        compressor_path = self._options.get("COMPRESSOR", "django_redis.compressors.identity.IdentityCompressor")
        compressor_cls = import_string(compressor_path)

        self._serializer = serializer_cls(options=self._options)
        self._compressor = compressor_cls(options=self._options)

    def get_task_executor(self):
        from utilmeta.conf import config
        return config.task.concurrent_executor(
            timeout=self.task_timeout,
            silent_timeout=True
        )

    @property
    def alias_key(self):
        return f'{self.service}.{self.alias}'

    @property
    def instances(self) -> List['CacheInstanceSchema']:
        global _instance_values
        return _instance_values.get(self.alias_key, [])

    @instances.setter
    def instances(self, values):
        global _instance_values
        _instance_values[self.alias_key] = values

    def assign(self, load_on_empty: bool = False):
        if not self.instances:
            if not load_on_empty:
                return
            backends = list(set(self.queryset.values_list('backend', flat=True)))
        else:
            backends = list(set([inst.backend for inst in self.instances]))
        if not backends:
            return self
        if len(backends) > 1:
            raise TypeError(f'Multiple backends: {backends} in one cluster detected, which is not allowed')
        types = {
            SupportedBackend.redis: RedisClusterCache,
            SupportedBackend.memcached: MemcachedClusterCache
        }
        return types[backends[0]](server=self._server, params=self._params)

    def construct_key(self, name: str, *, sync_nodes: Union[str, int] = ...,
                      block_nodes: Union[str, int] = 1, local_only: bool = False):
        """
        construct key from a given name
        to fully utilize the ClusterCache features whiling stay compat with other backends
        use it in this way
        >>> cache = BaseClusterCache()
        >>> key = cache.construct_key('key1', partition=True, sync_nodes=2, version=3)
        >>> cache.set(key, 123)
        >>> value = cache.get(key)
        >>> KeyInfo(key=key)
        :param name
        :param sync_nodes: the nodes need to sync write, default is ... which will depend on the
                           partition_level of the current cluster, set to a number to specify
                           set to '*' means sync to all nodes, set to 1 means only write to 1 nodes
        :param block_nodes: the nodes need to block (wait until success) when writing
                            usually be 1, set 0 to make whole writing async
                            set to '*' means block all write nodes (waiting for every writes complete)
        :param local_only: if set to True, will ignore all previous params, this key will not implement
                            the cluster cache features and will be write & read locally (no sync and no replicas)

        constraints: block_nodes <= sync_nodes <= total nodes
        """
        if not local_only and sync_nodes is ... and block_nodes == 1:
            # default settings
            return name

        if not local_only:
            if isinstance(sync_nodes, str):
                assert sync_nodes == KeyInfo.ALL
            elif isinstance(sync_nodes, int):
                self.check_empty()
                assert sync_nodes <= self.count, \
                    f'Params must satisfy constraints: sync_nodes {sync_nodes} <= total nodes {self.count}'
            else:
                assert sync_nodes is ...
            if isinstance(block_nodes, str):
                assert block_nodes == KeyInfo.ALL
            else:
                assert isinstance(block_nodes, int)
            if isinstance(block_nodes, int) and isinstance(sync_nodes, int):
                assert block_nodes <= sync_nodes,\
                    f'Params must satisfy constraints: block_nodes ({block_nodes}) <= sync_nodes {sync_nodes}'
        return KeyInfo.make(
            name=name, sync_nodes=sync_nodes,
            block_nodes=block_nodes, local_only=local_only
        )

    @property
    def count(self) -> int:
        return len(self.instances)

    def check_empty(self):
        if not self.instances:
            globally_retrieve_instances()
            if not self.instances:
                raise RuntimeError(f'No available cache, please check your cache status')

    @property
    def queryset(self):
        from utilmeta.ops.module.service import CacheList
        return CacheList.filter(
            connected=True, alias=self.alias,
            service_id=self.service
        )

    @classmethod
    def get_client(cls, instance: 'CacheInstanceSchema', *, raw: bool = False, write: bool = False):
        # try:
        #     return _clients[instance.id]
        # except (KeyError, AttributeError):
        return globally_init_client(instance)

    def migrate(self):
        """
        when instances change (new node added, some node disconnected / reconnected)
        :return:
        """
        pass

    def iterate_from(self, entry_point: int):
        """
        generate an infinite loop of hash ring
        """
        entry = entry_point
        while True:
            for inst in self.instances:
                # instances is pre-sorted by id hash
                if inst.id_hash >= entry:
                    yield inst
            entry = 0

    def extend_consistent_hash(self, key: str, n: int) -> List['CacheInstanceSchema']:
        """
        Extended Consistent Hash Algorithm
        :param key: target key that need to be calculated
        :param n: violation threshold which means if arbitrary N nodes is alive,
                  all data is accessible
                  set n=None simply means split data to every nodes differently
                  set n=1 means that every node contains same data
        """
        if n == 1:
            return self.instances
        key_hash = make_hash(key)
        count = self.count - n + 1
        # instances = sorted(_instances, key=lambda x: 123)
        instances = []
        for inst in self.iterate_from(key_hash):
            if not count:
                break
            instances.append(inst)
            count -= 1
        return instances

    def get_read_instances(self, info: KeyInfo) -> List['CacheInstanceSchema']:
        self.check_empty()
        if info.local_only:
            inst = self.local_instance
            return [inst] if inst else []
        if info.sync_all:
            n = 1
        elif info.sync_default:
            n = self._partition_level
        else:
            n = min(self.count - info.sync_nodes + 1, 1)
        return self.extend_consistent_hash(info.name, n)

    def get_write_instances(self, info: KeyInfo) \
            -> Tuple['CacheInstanceSchema', List['CacheInstanceSchema']]:
        instances = self.get_read_instances(info)
        return instances[0], instances[1:]

    def load_data(self):
        """
        local cache instance initially connected to the cluster and need to fetch & load data
        when loading is done, this instance will inform all other instances to s
        :return:
        """
        pass

    @property
    def local_instance(self) -> Optional['CacheInstanceSchema']:
        """
        get cache instance in local host
        :return:
        """
        from utilmeta.conf import config
        for inst in self.instances:
            if inst.host in (LOCAL_IP, config.private_ip):
                return inst
        return None

    @staticmethod
    def select_optimum_instances(keys, instance_keys: INST_DICT, reduce: bool = False) -> INST_DICT:
        """
        Set cover problem: get minimum instances for given keys to reduce latency
        :return: instance and target keys
        """
        if len(instance_keys) <= 1:
            return instance_keys
        all_keys = set(keys)
        instances = set()
        while all_keys:
            target = None
            max_covered = set()
            for inst, inst_keys in instance_keys.items():
                covered = all_keys.intersection(inst_keys)
                if len(covered) > len(max_covered):
                    max_covered = covered
                    target = inst
            all_keys.difference_update(max_covered)
            instances.add(target)
        covered_keys = set()
        instance_map = {}
        if reduce:
            for inst in instances:
                inst_keys = set(instance_keys[inst])
                uncovered_keys = inst_keys.difference(covered_keys)
                instance_map[inst] = list(uncovered_keys)
                covered_keys.update(uncovered_keys)
        else:
            for inst in instances:
                instance_map[inst] = instance_keys[inst]
        return instance_map

    def apply_multiple_alter(self, data: dict, func=lambda cli: cli.set_many, **kwargs):
        write_instances: Dict['CacheInstanceSchema', dict] = {}
        sync_instances: Dict['CacheInstanceSchema', dict] = {}

        for key, val in data.items():
            info = KeyInfo(key)
            write_instance, readonly_instances = self.get_write_instances(info)
            if write_instance in write_instances:
                write_instances[write_instance][info.name] = val
            else:
                write_instances[write_instance] = {info.name: val}
            for inst in readonly_instances:
                if inst in sync_instances:
                    sync_instances[inst][info.name] = val
                else:
                    sync_instances[inst] = {info.name: val}

        def sync_to(instance: 'CacheInstanceSchema', _data, raise_exc: bool = False):
            client = self.get_client(instance, write=True)
            try:
                return func(client)(_data, **kwargs)
            except Exception as e:
                log_instance_error(instance, error=Error(e), info=dict(
                    func=func(client).__name__,
                    data=loads(_data)
                ))
                if raise_exc:
                    raise e

        with self.get_task_executor() as executor:
            for inst, values in write_instances.items():
                executor[inst] = executor.submit(sync_to, inst, values)

            for inst, values in sync_instances.items():
                task.omit(sync_to)(inst, values)
                # self._executor.submit(sync_to, inst, values)

            errors = {}
            for job in executor.get_results():
                key = getattr(job.key, 'loc', None)
                if not key:
                    continue
                if job.success:
                    continue
                errors[key] = job.message

        if errors:
            raise RuntimeError(','.join([f'{key}: {val}' for key, val in errors.items()]))

    def apply_multiple_query(self, keys, func=lambda client: client.get_many,
                             reduce: bool = False, exclude_instances=(), **kwargs):
        """
        Multiple query can only executed from non-raw client, so make_key is not required here
        """
        instance_keys: INST_DICT = {}
        result = {}
        if isinstance(keys, str):
            keys = [keys]
        for key in keys:
            info = KeyInfo(key)
            for inst in self.get_read_instances(info):
                if inst in exclude_instances:
                    continue
                elif inst in instance_keys:
                    instance_keys[inst].append(info.name)
                else:
                    instance_keys[inst] = [info.name]
        if reduce:
            instance_keys = self.select_optimum_instances(keys, instance_keys, reduce=True)

        def apply(instance: 'CacheInstanceSchema', *_keys):
            client = self.get_client(instance)
            try:
                res = func(client)(_keys, **kwargs)
                if isinstance(res, dict):
                    result.update(res)
            except Exception as e:
                log_instance_error(inst=inst, error=Error(e), info=dict(
                    func=func(client).__name__,
                    keys=_keys
                ))
                raise e

        with self.get_task_executor() as executor:
            for inst, inst_keys in instance_keys.items():
                executor[(inst, inst_keys)] = executor.submit(apply, inst, *inst_keys)

            if reduce and not exclude_instances:
                # forbid endless recursive call
                exclude_instances = []
                require_keys = []

                for job in executor.get_results():
                    if job.success:
                        continue
                    try:
                        inst, keys = job.key
                    except TypeError:
                        continue
                    exclude_instances.append(inst)
                    require_keys.extend(keys)

                if exclude_instances:
                    result.update(self.apply_multiple_query(
                        keys, func=func, reduce=reduce,
                        exclude_instances=exclude_instances, **kwargs)
                    )

        return result

    def apply_query(self, key, *args, func,
                    raw=False, version=None, **kwargs):
        """
        read from the closest (usually local) cache which stored the key
        try other backups
        """
        info = KeyInfo(key, version=version)
        if not raw:
            kwargs.update(version=version)

        def sort(instance: 'CacheInstanceSchema'):
            if instance == self.local_instance:
                # local first
                return 0
            # until a better resort (such as load index or latency) use this
            return instance.used_memory + 1

        for inst in sorted(self.get_read_instances(info), key=sort):
            if not inst.connected:
                continue
            client = self.get_client(inst, raw=raw, write=False)
            try:
                cache_key = self._make_key(info, instance=inst, raw=raw)
                return func(client)(cache_key, *args, **kwargs)
            except Exception as e:
                # with multiple read instances, error can simply logged and continue
                # to provide stronger availability
                log_instance_error(inst, error=Error(e), info=dict(
                    func=func(client).__name__,
                    key=info.name
                ))
                continue
        return None

    def apply_alter(self, key, *args, func=lambda client: client.set,
                    raw=False, delete=False, version=None, **kwargs):
        info = KeyInfo(key, version=version)
        if not raw:
            kwargs.update(version=version)
        write_instance, sync_instances = self.get_write_instances(info)

        def sync_to(instance: 'CacheInstanceSchema', raise_exc: bool = False):
            client = self.get_client(instance, raw=raw, write=True)
            try:
                cache_key = self._make_key(info, instance=instance, raw=raw)
                return func(client)(cache_key, *args, **kwargs)
            except Exception as e:
                log_instance_error(instance, error=Error(e), info=dict(
                    func=func(client).__name__,
                    key=info.name, args=loads(args, bulk_data=True)
                ))
                if raise_exc:
                    raise e
        res = sync_to(write_instance, raise_exc=True)
        if info.broadcast_type:
            # this key need to broadcast among all cluster backward dependencies
            from utilmeta.conf import config
            config.cluster_manager.broadcast_cache(
                key, *args[:1], type=info.broadcast_type,
                delete=delete, kwargs=kwargs, block=True
            )
        if not sync_instances:
            return res

        with self.get_task_executor() as executor:
            for inst in sync_instances:
                executor[inst] = executor.submit(sync_to, inst)

            errors = {}
            for job in executor.get_results():
                key = getattr(job.key, 'loc', None)
                if not key:
                    continue
                if job.success:
                    continue
                errors[key] = job.message

        if errors:
            raise RuntimeError(','.join([f'{key}: {val}' for key, val in errors.items()]))
        return res

    def _make_key(self, info: KeyInfo, instance: 'CacheInstanceSchema' = None, raw: bool = False):
        """
        common cache methods wrapped by a client has it's make_key function
        but some raw methods (such as redis hXX, hmXX, lXX)'s key is original
        so
        """
        if raw and instance:
            client = self.get_client(instance)
            return client.make_key(info.name, version=info.version)
        return info.name

    def get_many(self, keys, *args, version=None):
        """
        select instances from keys (as least as possible to reduce latency)
        must wait until all keys retrieved
        """
        return self.apply_multiple_query(list_or_args(keys, args), version=version, reduce=True)

    def set_many(self, data: dict, timeout=DEFAULT_TIMEOUT, version=None):
        return self.apply_multiple_alter(data, timeout=timeout, version=version)

    def delete_many(self, keys, *args, version=None):
        return self.apply_multiple_query(list_or_args(keys, args), func=lambda cli: cli.delete_many, version=version)

    def get(self, key, default=None, version=None):
        return self.apply_query(key, default=default, version=version, func=lambda cli: cli.get)

    def set(self, key, value, timeout=DEFAULT_TIMEOUT, version=None):
        return self.apply_alter(key, value, func=lambda cli: cli.set, timeout=timeout, version=version)

    def add(self, key, value, timeout=DEFAULT_TIMEOUT, version=None):
        return self.apply_alter(key, value, func=lambda cli: cli.add, timeout=timeout, version=version)

    def incr(self, key, delta=1, version=None):
        return self.apply_alter(key, delta, func=lambda cli: cli.incr, version=version)

    def touch(self, key, timeout=DEFAULT_TIMEOUT, version=None):
        return self.apply_alter(key, func=lambda cli: cli.touch, timeout=timeout, version=version)

    def delete(self, key, version=None):
        return self.apply_alter(key, func=lambda cli: cli.delete, version=version, delete=True)

    # def __contains__(self, item):
    #     pass

    def clear(self):
        local_inst = self.local_instance
        if not local_inst:
            return
        client = self.get_client(local_inst)
        client.clear()

    def hmset(self, name, mapping):
        raise NotImplementedError

    def hget(self, name, key):
        raise NotImplementedError

    def hmget(self, name, keys, *args):
        raise NotImplementedError

    def hset(self, name, key, value):
        raise NotImplementedError

    def hgetall(self, name):
        raise NotImplementedError

    def hdel(self, name, keys):
        raise NotImplementedError

    def hkeys(self, name) -> List[str]:
        raise NotImplementedError

    def hlen(self, name) -> int:
        raise NotImplementedError

    def hexists(self, name, key) -> bool:
        raise NotImplementedError

    # def zadd(self):
    #     raise NotImplementedError
    #
    # def zrange(self):
    #     raise NotImplementedError
    #
    # def smembers(self):
    #     raise NotImplementedError
    #
    # def lpush(self):
    #     raise NotImplementedError
    #
    # def rpush(self):
    #     raise NotImplementedError
    #
    # def rpop(self):
    #     raise NotImplementedError


class RedisClusterCache(BaseClusterCache):
    BACKEND = SupportedBackend.redis

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def has_key(self, key, version=None):
        info = KeyInfo(key, version=version)
        for inst in self.get_read_instances(info):
            client = self.get_client(inst, raw=True, write=False)
            cache_key = self._make_key(info, instance=inst, raw=True)
            if client.exists(cache_key):
                return True
        return False

    @classmethod
    def get_client(cls, instance: 'CacheInstanceSchema', *, raw: bool = False, write: bool = False):
        from django_redis.client.default import DefaultClient
        client: DefaultClient = super().get_client(instance)
        if raw:
            return client.get_client(write)
        return client

    @property
    def client(self):
        # duck support for get_redis_connection feature
        from django_redis.cache import RedisCache

        return RedisCache(
            server=self._server,
            params=self._params
        ).client

    # @property
    # def default_client(self):
    #     from django_redis.client import DefaultClient
    #     return DefaultClient(
    #         server=self._server,
    #         params=self._params
    #     )

    def hmset(self, name, mapping):
        return self.apply_alter(name, dumps(mapping, bulk_data=True), raw=True, func=lambda cli: cli.hmset)

    def hset(self, name, key=None, value=None, mapping=None):
        return self.apply_alter(name, key, dumps(value), dumps(mapping, bulk_data=True),
                                raw=True, func=lambda cli: cli.hset)

    def hgetall(self, name) -> dict:
        return loads(self.apply_query(name, raw=True, func=lambda cli: cli.hgetall), bulk_data=True)

    def hget(self, name, key):
        return loads(self.apply_query(name, key, raw=True, func=lambda cli: cli.hget))

    def hmget(self, name, keys, *args) -> dict:
        return loads(self.apply_query(name, list_or_args(keys, args),
                                      raw=True, func=lambda cli: cli.hmget), bulk_data=True)

    def hdel(self, name, keys):
        return self.apply_alter(name, keys, raw=True, func=lambda cli: cli.hdel, delete=True)

    def hkeys(self, name) -> List[str]:
        return loads(self.apply_query(name, raw=True, func=lambda cli: cli.hkeys), bulk_data=True)

    def hlen(self, name) -> int:
        return self.apply_query(name, raw=True, func=lambda cli: cli.hlen)

    def hexists(self, name, key) -> bool:
        return self.apply_query(name, key, raw=True, func=lambda cli: cli.hexists)

    def incr(self, key, delta=1, version=None):
        return self.apply_alter(key, delta, func=lambda cli: cli.incrbyfloat, version=version, raw=True)

    def get(self, key, default=None, version=None):
        value = self.apply_query(key, func=lambda cli: cli.get, raw=True)
        if value is None:
            return default
        try:
            return get_number(value)
        except COMMON_ERRORS:
            from django_redis.exceptions import CompressorError
            try:
                value = self._compressor.decompress(value)
            except CompressorError:
                # Handle little values, chosen to be not compressed
                pass
            value = self._serializer.loads(value)
        return value

    def raw_set(self, key, value, **kwargs):
        return self.apply_alter(key, self._serializer.dumps(value), func=lambda cli: cli.set, raw=True, **kwargs)


class MemcachedClusterCache(BaseClusterCache):
    BACKEND = SupportedBackend.memcached

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def init_client(self, instance: 'CacheInstanceSchema' = None) -> BaseCache:
        from django.core.cache.backends.memcached import MemcachedCache
        return MemcachedCache(
            server=instance.location if instance else self._server,
            params={} if instance else self._params
        )

    # def check_clients(self):
    #     from utilmeta.ops.schema import CacheStatus
    #     from memcache import Client
    #     for inst in self.instances:
    #         cli: Client = self.get_client(inst, raw=True)
    #         try:
    #             status = CacheStatus(cli.get_stats())
    #             inst.used_memory = status.used_memory
    #             inst.current_connections = status.current_connections
    #             inst.total_connections = status.total_connections
    #             inst.req_per_sec = status.req_per_sec
    #             inst.pid = status.pid
    #             inst.connected = True
    #         except Exception as e:
    #             log_instance_error(inst, error=Error(e), disconnect=True)

    @classmethod
    def get_client(cls, instance: 'CacheInstanceSchema', *, raw: bool = False, write: bool = False):
        from django.core.cache.backends.memcached import MemcachedCache
        from memcache import Client
        client: MemcachedCache = super().get_client(instance)
        if raw:
            _client: Client = getattr(client, '_client')
            return _client
        return client

    @classmethod
    def hkeys_key(cls, name):
        return f'KEYS@{name}'

    @classmethod
    def combine_key(cls, name, key):
        # not affect the flags in the end of the name
        return f'{key}-{name}'

    @classmethod
    def split_key(cls, key: str):
        return key.split('-')

    def hmset(self, name, mapping: dict):
        # inst = self.get_write_instances(KeyInfo(name))[0]
        # if name in self:
        #     self.get_client(inst, raw=True).append(name)
        return self.set_many({self.combine_key(name, key): val for key, val in mapping.items()})

    def hmget(self, name, keys, *args):
        result = {}
        for key, val in self.get_many(keys=[self.combine_key(name, key) for key in list_or_args(keys, args)]):
            _n, _k = self.split_key(key)
            result[_k] = val
        return result

    def hget(self, name, key):
        return self.get(self.combine_key(name, key))

    def hset(self, name, key, value):
        return self.set(self.combine_key(name, key), value)

    def hdel(self, name, keys):
        return self.delete_many(keys=[self.combine_key(name, key) for key in keys])

    def hexists(self, name, key):
        return self.hget(name, key) is not None

    def hgetall(self, name):
        raise NotImplementedError('Unsupported temporarily')

    def hkeys(self, name) -> List[str]:
        raise NotImplementedError('Unsupported temporarily')

    def hlen(self, name) -> int:
        raise NotImplementedError('Unsupported temporarily')
