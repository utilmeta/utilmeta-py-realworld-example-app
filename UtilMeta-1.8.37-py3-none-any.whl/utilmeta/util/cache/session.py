from .cluster import BaseClusterCache
from django.contrib.sessions.backends.base import (
    CreateError, SessionBase, UpdateError,
)


class SessionStore(SessionBase):
    KEY_PREFIX = "utilmeta.util.cache.session"

    def __init__(self, session_key=None):
        from utilmeta.conf import config
        self._cache = BaseClusterCache(
            server=None,
            params=dict(
                KEY_FUNCTION=lambda key, *_: key,   # cluster scope, need to unify
                KEY_PREFIX=None,
                CACHE_ALIAS=config.session.cache_alias,
                SOURCE_SERVICE=config.session.from_service
            )
        ).assign(load_on_empty=True)
        self._key = session_key
        super().__init__(session_key)

    @property
    def cache_key(self):
        return self.KEY_PREFIX + self._get_or_create_session_key()

    # def is_empty(self):
    #     pass

    def load(self):
        session_data = self._cache.get(self.cache_key)
        if isinstance(session_data, dict):
            return session_data
        self._session_key = None
        return {}

    def create(self):
        self._session_key = self._get_new_session_key()
        try:
            self.save(must_create=True)
        except CreateError:
            return
        self.modified = True
        return

    def save(self, must_create=False):
        if self.session_key is None:
            return self.create()
        if must_create:
            func = self._cache.add
        elif self.cache_key in self._cache:
            func = self._cache.set
        else:
            raise UpdateError
        result = func(self.cache_key,
                      self._get_session(no_load=must_create),
                      self.get_expiry_age())
        if must_create and not result:
            raise CreateError

    def exists(self, session_key):
        return bool(session_key) and (self.KEY_PREFIX + session_key) in self._cache

    def delete(self, session_key=None):
        if session_key is None:
            if self.session_key is None:
                return
            session_key = self.session_key
        self._cache.delete(self.KEY_PREFIX + session_key)

    @classmethod
    def clear_expired(cls):
        pass
