import json
from utilmeta.util.common import SCHEME, Scheme, SCHEMES, Header, \
    RequestType, METHODS, HTTPMethod, HAS_BODY_METHODS, dumps, Key, utc_ms_ts, \
    url_join, json_dumps, gen_key, UTF_8, SHA_256, MetaHeader, task, DNS_ERRNO,\
    encode_multipart_form, file_like, encode_query, time_now, get_interval, convert_time
from utilmeta.util.common.encoder import MetaJSONEncoder
from urllib.request import Request, urlopen
from http.client import HTTPResponse
from urllib.error import URLError, HTTPError
from urllib.parse import urlparse, ParseResult
from typing import Union, Any, Dict
from django.http.request import HttpHeaders, QueryDict
from datetime import timedelta, datetime
from .base import Util
from typing import Optional
import mimetypes
import hmac
import ssl
from .log import Logger

RESP_TYPE = Union[HTTPResponse, Any, None]    # compat to different response types

__all__ = ['Call']


class Call(Util):
    class Agent:
        pass

    class Host:
        def __init__(self, host: str, scheme: str = 'http', port: int = None):
            self.host = host
            if scheme not in SCHEMES:
                raise ValueError(f'Invalid scheme: {scheme}')
            self.scheme = scheme
            self.port = port
            res = urlparse(host)
            if res.scheme:
                self.scheme = res.scheme
            else:
                self.host = scheme + SCHEME + host
            if res.port:
                self.port = res.port
            elif port:
                self.host = f'{self.host}:{port}'

        def __call__(self, url, **kwargs) -> 'Call':
            return Call(url=url_join(self.host, url), **kwargs)

    def __init__(self, url: str, query: dict = None, data=None, form: Dict[str, Any] = None,
                 logger: Logger = None, headers: Dict[str, str] = None, cls=Request, method: str = None,
                 scheme: str = Scheme.HTTP, timeout: Union[int, float, timedelta] = None, block: bool = True):
        super().__init__(locals())
        assert scheme in SCHEMES, f'Invalid request scheme: {scheme}'
        if not url or not isinstance(url, str):
            raise TypeError(f'Invalid url: {repr(url)}')

        self.parse: ParseResult = urlparse(url)
        self.scheme = self.parse.scheme or scheme
        if not self.parse.scheme:
            url = SCHEME.join([scheme, url])

        self.url = url
        if query:
            assert isinstance(query, (dict, QueryDict)),\
                f'Call params must be instance of dict, got {query}'
        if headers:
            assert isinstance(headers, (dict, HttpHeaders)),\
                f'Call headers must be instance of dict, got {headers}'
        self.query = dict(query) if query else {}
        self.headers = dict(headers) if headers else {}
        self.pop_header(Header.LENGTH)
        # there are difference between JSON.stringify in js and json.dumps in python
        # while JSON.stringify leave not spaces and json.dumps leave space between a comma and next key
        # difference like {"a":1,"b":2} and {"a": 1, "b": 2}
        # so these different encode standard gives a different Content-Length
        # and reuse the original Content-Length may cause decode error on target server parsing the request body
        self.data = data
        self.form = form
        self.body: Optional[bytes] = None
        # self.form_data = None
        # self.json_data = None

        if data:
            if isinstance(data, (dict, list, tuple, set)):
                self.content_type = RequestType.JSON
                self.body = json.dumps(
                    self.data, ensure_ascii=False,
                    cls=MetaJSONEncoder,
                ).encode('utf-8', 'ignore')
            elif file_like(data):
                name = getattr(data, 'name', None)
                self.content_type = mimetypes.guess_type(name)[0] if name else RequestType.OCTET_STREAM
                data.seek(0)
                content = data.read()
                if not isinstance(content, bytes):
                    content = str(content).encode()
                self.body = content
            elif isinstance(data, bytes):
                self.body = data
            else:
                self.body = str(data).encode()
                self.content_type = RequestType.PLAIN

        elif form:
            if isinstance(form, dict):
                self.body, self.content_type = encode_multipart_form(form)
            else:
                raise TypeError(f'Invalid form type: {type(form)}, must be dict object')

        self.timeout = get_interval(timeout, null=True)
        self.timeout_error = False
        self.dns_error = False
        self.ssl_error = False

        self.block = block
        self.req_cls = cls
        self.method = str(method or HTTPMethod.GET).upper()
        self.send_utc_timestamp = None
        self.req_info = {}
        if not isinstance(logger, Logger) or not logger.invoke:
            # reject invalid logger
            logger = None
        self.log = logger

        self._time = None
        if not self.block:
            # non-blocking, start a thread to send request
            self.send = task.omit(self.send)

    @property
    def duration(self):
        # in ms
        return self.req_info.get(Key.DURATION)

    def set_duration(self, val):
        # in ms
        self.req_info[Key.DURATION] = val

    def pop_header(self, key: str):
        for name in list(self.headers):
            if str(name).lower() == key.lower():
                self.headers.pop(name)

    def get_header(self, key: str):
        for name, value in self.headers.items():
            if str(name).lower() == key.lower():
                return value
        return None

    @property
    def content_type(self) -> str:
        return self.get_header(Header.TYPE) or RequestType.PLAIN

    @content_type.setter
    def content_type(self, val: str):
        self.pop_header(Header.TYPE)
        self.headers[Header.TYPE] = val

    @property
    def user_agent(self):
        from user_agents.parsers import UserAgent
        return UserAgent(self.ua_string) if self.ua_string else None

    @property
    def ua_string(self):
        return self.headers.get(Header.USER_AGENT)

    @property
    def content_length(self) -> int:
        if self.method not in HAS_BODY_METHODS:
            return 0
        length = self.headers.get(Header.LENGTH)
        if length is not None:
            return int(length)
        return len(dumps(self.data))

    def set_signature(self, access_key: str, secret_key: str):
        timestamp = utc_ms_ts()
        secret = bytes(secret_key or gen_key(32), encoding=UTF_8)
        tag = f'{timestamp}{self.method.upper()}{self.encoded_path}{json_dumps(self.data)}'.encode(UTF_8)
        sign = hmac.new(key=secret, msg=tag, digestmod=SHA_256).hexdigest()
        self.headers[MetaHeader.ACCESS_KEY] = access_key
        self.headers[MetaHeader.TIMESTAMP] = str(timestamp)
        self.headers[MetaHeader.SIGNATURE] = sign

    @property
    def is_http(self):
        return self.scheme in (Scheme.HTTP, Scheme.HTTPS)

    @property
    def encoded_path(self):
        return urlparse(self.url).path + self.query_suffix

    @property
    def encoded_url(self):
        return self.url + self.query_suffix

    @property
    def query_suffix(self):
        encoded = encode_query(self.query)
        if not encoded:
            return ''
        return '?' + encoded

    @classmethod
    def json_type(cls, fp: HTTPResponse):
        tp = fp.headers.get(Header.TYPE, '')
        return RequestType.JSON in tp or 'javascript' in tp

    @property
    def time(self) -> datetime:
        if self._time:
            return self._time
        if self.log:
            return convert_time(datetime.fromtimestamp(self.log.init_time))
        return time_now()

    def send(self, method: str = None, load: bool = False) -> RESP_TYPE:
        from socket import timeout
        if method:
            self.method = method.upper()
        assert self.method.lower() in METHODS, f'Invalid Request method: {self.method}'
        self.headers = {str(key): str(val) for key, val in self.headers.items()
                        if key and val} if self.headers else {}
        request = Request(url=self.encoded_url, headers=self.headers, method=self.method, data=self.body)
        res = None
        self.send_utc_timestamp = utc_ms_ts()
        self._time = time_now()
        try:
            res = urlopen(request, timeout=self.timeout)
        except timeout as e:
            self.timeout_error = True
            raise TimeoutError(e)
        except HTTPError as e:
            res = getattr(e, 'fp')
        except URLError as e:
            for arg in e.args:
                if isinstance(arg, timeout):
                    self.timeout_error = True
                    raise TimeoutError(f'request timed out for more than {self.timeout}s')

            if any([no in str(e) for no in DNS_ERRNO]):
                self.dns_error = True

            raise e
        except ssl.SSLError as e:
            self.ssl_error = True
            raise e
        finally:
            recv_timestamp = utc_ms_ts()
            self.set_duration(recv_timestamp - self.send_utc_timestamp)
            if self.log:
                self.log.save_api(request=self, response=res)
        if load:
            if self.json_type(res):
                data = json.load(res)
            else:
                data = res.read()
            res.close()     # close response to prevent from socket file descriptors leak
            return data
        return res

    def get(self, *args, **kwargs) -> RESP_TYPE:
        return self.send(HTTPMethod.GET, *args, **kwargs)

    def put(self, *args, **kwargs) -> RESP_TYPE:
        return self.send(HTTPMethod.PUT, *args, **kwargs)

    def post(self, *args, **kwargs) -> RESP_TYPE:
        return self.send(HTTPMethod.POST, *args, **kwargs)

    def patch(self, *args, **kwargs) -> RESP_TYPE:
        return self.send(HTTPMethod.PATCH, *args, **kwargs)

    def delete(self, *args, **kwargs) -> RESP_TYPE:
        return self.send(HTTPMethod.DELETE, *args, **kwargs)

    def trace(self, *args, **kwargs) -> RESP_TYPE:
        return self.send(HTTPMethod.TRACE, *args, **kwargs)

    def head(self, *args, **kwargs) -> RESP_TYPE:
        return self.send(HTTPMethod.HEAD, *args, **kwargs)

    def options(self, *args, **kwargs) -> RESP_TYPE:
        return self.send(HTTPMethod.OPTIONS, *args, **kwargs)

    def connect(self, *args, **kwargs) -> RESP_TYPE:
        return self.send(HTTPMethod.CONNECT, *args, **kwargs)
