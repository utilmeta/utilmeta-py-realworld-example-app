"""
constant: defining Static constant class and constants
NAMING RULES:
Static class: CamelCase
constants: UPPER_CASE

"""
from django.core.files import File
from .datastructure import Static, ImmutableDict, ImmutableList
from typing import Union, List, Dict, Any, Tuple, Type
from django.http.request import HttpRequest
from django.core.handlers.wsgi import WSGIRequest
from django.core.handlers.asgi import ASGIRequest
from datetime import date, datetime, time, timedelta
from uuid import UUID
from decimal import Decimal
import multiprocessing
from ipaddress import IPv4Address, IPv6Address, IPv4Network, IPv6Network
from . import exc
import sys

ValuesType = List[Dict[str, Any]]
IPType = Union[IPv4Address, IPv6Address]
NetworkType = Union[IPv4Network, IPv6Network]
ReqType = Union[WSGIRequest, ASGIRequest, HttpRequest]

# import user_agents
# import datetime
# import uuid

SECRET = '*' * 8
INF = float('inf')
BUF = 1024 * 4
MAX_ENTRIES = 1660

MANY_WEIGHT = 10   # an average constant weight to evaluate many-relations ship without query
SC_THRESHOLD = MANY_WEIGHT ** 4   # Threshold to turn the joined query to separate queries

PY = '.py'
ID = 'id'
PK = 'pk'
ALL = '__all__'
SEG = '__'
SCHEME = '://'
LOCAL = 'localhost'
LOCAL_IP = '127.0.0.1'
ALL_IP = '0.0.0.0'
UTF_8 = 'utf-8'
SHA_256 = 'sha256'
SELF = 'self'
LINUX = 'linux'
BSD = 'bsd'
WIN = 'win'
TEMP_FILES = ['conf.py']
META_INI = 'meta.ini'
INIT_FILE = '__init__.py'
UWSGI = 'uwsgi'
GUNICORN = 'gunicorn'
NGINX = 'nginx'
APACHE = 'apache'
AUTO_WORKERS = multiprocessing.cpu_count() * 2 + 1
DOT = '●'
PRODUCTION = 'PRODUCTION'
DEBUG = 'DEBUG'
PYTHON = 'python'
SPACE_4 = ' ' * 4
JOINER = '\n' + SPACE_4
JOINER2 = JOINER + SPACE_4
PY_NAMES = (UWSGI, GUNICORN, PYTHON, '%s.exe' % PYTHON)
ELEMENTS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
MAX_BASE = len(ELEMENTS)
GREEN = '\033[1;32m%s\033[0m'
RED = '\033[1;31m%s\033[0m'
BLUE = '\033[1;34m%s\033[0m'
YELLOW = '\033[1;33m%s\033[0m'
BANNER = '\033[1;30;47m%s\033[0m'

LINE_WIDTH = 100
if sys.platform != LINUX:
    # window not support color print
    try:
        import colorama
        colorama.init(autoreset=True)
    except ModuleNotFoundError:
        # DOWN GRADE
        GREEN = '%s'
        RED = '%s'
        BLUE = '%s'
        YELLOW = '%s'
        BANNER = '%s'

WRITE_THROUGH = 'WRITE_THROUGH'
CACHE_ASIDE = 'CACHE_ASIDE'
WRITE_BACK = 'WRITE_BACK'

MAIN_HOST = 'utilmeta.com'


class CaseStyle(Static):
    camelCase = 'camel'
    PascalCase = 'pascal'
    snake_case = 'snake'
    kebab_case = 'kebab'
    CAP_KEBAB_CASE = 'cap_kebab'
    CAP_SNAKE_CASE = 'cap_snake'


class DB(Static):
    PostgreSQL = 'postgresql'
    MySQL = 'mysql'
    Oracle = 'oracle'
    SQLite = 'sqlite'


class LogType(Static):
    service = 'service'
    request = 'request'
    # task = 'task'


class TaskStatus(Static):
    idle = 'idle'
    pause = 'pause'
    down = 'down'
    busy = 'busy'


class TaskFailure(Static):
    failed = 'failed'
    error = 'error'
    runtime_error = 'runtime_error'
    sync_error = 'sync_error'
    timeout = 'timeout'
    all_failed = 'all_failed'
    partial_failed = 'partial_failed'
    all_timeout = 'all_timeout'
    partial_timeout = 'partial_timeout'


class EventStatus(Static):
    # upcoming = 'upcoming'
    # executing = 'executing'
    # success = 'success'
    # failed = 'failed'
    # timeout = 'timeout'
    pending = 'pending'
    normal = 'normal'
    redundant = 'redundant'
    omitted = 'omitted'
    recovered = 'recovered'
    abandoned = 'abandoned'


class ServerRole(Static):
    wsgi = 'wsgi'
    asgi = 'asgi'
    task = 'task'
    file = 'file'
    cache = 'cache'
    db = 'db'   # database
    web = 'web'   # web server


class TaskType(Static):
    native = 'native'
    script = 'script'
    request = 'request'


class TaskConditionType(Static):
    finish = 'finish'
    success = 'success'
    error = 'error'
    timeout = 'timeout'


class ScriptLanguage(Static):
    shell = 'shell'
    python = 'python'
    java = 'java'
    go = 'go'
    js = 'js'


class ResourceType(Static):
    api = 'api'
    model = 'model'
    task = 'task'


class TokenType(Static):
    ops = 'ops'
    init = 'init'
    access = 'access'
    action = 'action'

    @classmethod
    def get_ops_type(cls, ops: str):
        for act, (m, p, t) in ACTION_INFO.items():
            if act == ops:
                return t
        return cls.ops

    # @classmethod
    # def get_req_type(cls, path: str, method: str):
    #     for act, (m, p, t, n) in ACTION_INFO.items():
    #         if str(m).upper() == str(method).upper() and path.endswith(p):
    #             return t
    #     return cls.ops


class AgentDevice(Static):
    pc = 'pc'
    mobile = 'mobile'
    bot = 'bot'
    tablet = 'tablet'
    email = 'email'


class AgentBrowser(Static):
    chrome = 'chrome'
    firefox = 'firefox'
    safari = 'safari'
    edge = 'edge'
    opera = 'opera'
    ie = 'ie'   # Internet Explorer


class AgentOS(Static):
    mac = 'mac'
    windows = 'windows'
    linux = 'linux'


class BroadcastCacheType(Static):
    session = 'session'


class ServiceAction(Static):
    # HEARTBEAT = 'heartbeat'
    # RETRIEVE = 'retrieve'
    BACKUP = 'backup'   # service is disconnected with node server and call for a backup

    ADD_ADMIN = 'add_admin'
    ADD_NODE = 'add_node'

    RENEW_ADMIN = 'renew_admin'
    RENEW_NODE = 'renew_node'

    DELETE_ADMIN = 'delete_admin'
    DELETE_NODE = 'delete_node'

    ALTER_ADMIN = 'alter_admin'  # alter permissions for specified admin
    ALTER_NODE = 'alter_node'


# Action: (<method>, <path>, <token type>, <token times>)
ACTION_INFO = {
    ServiceAction.ADD_NODE: ('POST', '/', TokenType.init),
    ServiceAction.ADD_ADMIN: ('POST', 'admin', TokenType.access),

    ServiceAction.RENEW_ADMIN: ('PUT', 'admin/token', TokenType.access),
    ServiceAction.RENEW_NODE: ('PUT', 'supervisor/token', TokenType.action),

    ServiceAction.ALTER_ADMIN: ('PATCH', 'admin', TokenType.ops),
    ServiceAction.ALTER_NODE: ('PATCH', 'supervisor', TokenType.ops),

    ServiceAction.DELETE_ADMIN: ('DELETE', 'admin', TokenType.ops),
    ServiceAction.DELETE_NODE: ('DELETE', 'supervisor', TokenType.ops)
}


class Hint(Static):
    STREAMING_CONTENT = '<streaming_content>'
    MESSAGE = "<error_message>"
    STATE = "<action_state>"
    STATUS_CODE = "<http_status_code>"
    COUNT = '<query_result_count>'
    RESULT = "<result_data>"


class Reg(Static):
    META = '.^$#~&*+?{}[]\\|()'
    IP = '((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3}'
    IPv6 = '^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}' \
           '|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:)' \
           '{5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]' \
           '?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|' \
           '2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}' \
           '(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]' \
           '|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]' \
           '{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|' \
           '(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]' \
           '\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|' \
           '((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]' \
           '\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$'
    ALNUM = '[0-9a-zA-Z]+'
    ALNUM_SCORE = '[0-9a-zA-Z_]+'
    ALNUM_SEP = '[0-9a-zA-Z-]+'
    ALNUM_SCORE_SEP = '[0-9a-zA-Z_-]+'

    ALL = '.+'
    URL_ALL = '[^/]+'       # match all string except /
    PATH_REGEX = '{(%s)}' % ALNUM_SCORE
    EMAIL_FULL = '^(?:[a-zA-Z0-9!#$%&\'*+/=?^_`{|}~-]+(?:\\.[a-zA-Z0-9!#$%&\'' \
            '*+/=?^_`{|}~-]+)*|(?:[\x01-\x08\x0b\x0c\x0e-\x1f!#-[]-' \
            '\x7f]|\\[\x01-\t\x0b\x0c\x0e-\x7f])*)@(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]' \
            '*[a-zA-Z0-9])?\\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?|\\[(?:(?:(2(5[0-5]|' \
            '[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\\.){3}(?:(2(5[0-5]|[0-4][0-9])' \
            '|1[0-9][0-9]|[1-9]?[0-9])|[a-zA-Z0-9-]*[a-zA-Z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f' \
            '!-ZS-\x7f]|\\[\x01-\t\x0b\x0c\x0e-\x7f])+)\\])&'
    EMAIL_ALNUM = '^[a-zA-Z0-9]+@[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)+[a-z0-9A-Z]+$'
    EMAIL = '^[a-z0-9A-Z]+[a-z0-9A-Z._-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+[a-z0-9A-Z]+$'

    must_contains_letter_number = '(?=.*[0-9])(?=.*[a-zA-Z]).+'
    must_contains_letter_number_special = '(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9]).+'
    must_contains_hybrid_letter_number_special = '(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[^a-zA-Z0-9]).+'


class Format(Static):
    DATETIME = "%Y-%m-%d %H:%M:%S"
    DATETIME_DF = '%Y-%m-%d %H:%M:%S.%f'
    DATETIME_F = '%Y-%m-%d %H:%M:%S %f'
    DATETIME_P = '%Y-%m-%d %I:%M:%S %p'
    DATETIME_T = "%Y-%m-%dT%H:%M:%S"
    DATETIME_TZ = "%Y-%m-%dT%H:%M:%SZ"
    DATETIME_TFZ = "%Y-%m-%dT%H:%M:%S.%fZ"
    DATETIME_TF = "%Y-%m-%dT%H:%M:%S.%f"
    DATETIME_ISO = "%Y-%m-%dT%H:%M:%S.%f+%H:%M"
    DATETIME_GMT = '%a, %d %b %Y %H:%M:%S GMT'
    DATETIME_PS = '%a %b %d %H:%M:%S %Y'
    DATETIME_GMT2 = '%b %d %H:%M:%S %Y GMT'
    DATE = '%Y-%m-%d'
    TIME = '%H:%M:%S'


class Key(Static):
    EXECUTOR_THREAD_ID = '_executor_thread_id'
    EXECUTOR_PROCESS_ID = '_executor_process_id'
    EXECUTOR_THREAD_ID_REQUIRED = '_executor_thread_id_required'
    EXECUTOR_PROCESS_ID_REQUIRED = '_executor_process_id_required'

    RELATE_REQUEST_MAKER = '_relate_request_maker'
    # ORIGINAL_ANNOTATIONS = '_original_annotations'
    # VALUES_FIELDS = '_values_fields'
    # VALUES_EXPRESSIONS = '_values_expressions'
    # ORIGINAL_QUERYSET = '_original_queryset'

    PROXY = '_proxy'
    USER_ID = '_user_id'
    IP_KEY = '_ip'
    UA_KEY = '_ua'

    USER_HASH = '_user_hash'
    USER_CACHE = '_cached_user'
    PK_LIST = '_pk_list'
    ORDER_REQUIRED = '_order_required'
    PK_IN = 'pk__in'
    DATA = '_data'
    QUERY_IN_ANNOTATE = '_query_in_annotate'
    SPLIT_MANY_RELATIONS = '_split_many_relations'
    HINTS = '_hints'
    Q = '_q'
    QUERY_CHAIN = '_query_chain'
    ID = '_id'
    POOLED = '_pooled'
    MERGE = '_merge'
    META = '_meta'
    META_MANAGER = '_meta_manager'
    ROUTER = '_Router'
    DISABLE_CACHE = '_disable_cache'
    DECONSTRUCT = '_deconstruct'
    REGISTER = '_register'
    PRIVATE = '_private'
    ROUTE = '_route'
    INSTANCE = '_instance'
    DURATION = '_duration'


class LogLevel(Static):
    DEBUG = 'DEBUG'
    INFO = 'INFO'
    WARN = 'WARN'
    ERROR = 'ERROR'
    URGENT = 'URGENT'


class AlertLevel(Static):
    WARNING = 'WARNING'
    CRITICAL = 'CRITICAL'
    DISASTER = 'DISASTER'


class HTTPMethod(Static):
    GET = 'GET'
    PUT = 'PUT'
    POST = 'POST'
    PATCH = 'PATCH'
    DELETE = 'DELETE'
    HEAD = 'HEAD'
    TRACE = 'TRACE'
    OPTIONS = 'OPTIONS'
    CONNECT = 'CONNECT'


class CommonMethod(Static):
    GET = 'get'
    PUT = 'put'
    POST = 'post'
    PATCH = 'patch'
    DELETE = 'delete'


class MetaMethod(Static):
    HEAD = 'head'
    TRACE = 'trace'
    OPTIONS = 'options'
    CONNECT = 'connect'


class RequestType(Static):
    PLAIN = 'text/plain'
    JSON = 'application/json'
    FORM_URLENCODED = 'application/x-www-form-urlencoded'
    FORM_DATA = 'multipart/form-data'
    XML = 'text/xml'
    OCTET_STREAM = 'application/octet-stream'


class ParamHolderType(Static):
    function = 'function'
    schema = 'schema'
    model = 'model'


class UnitAttr(Static):
    main = 'main'
    unit = 'unit'

    before_hook = 'before_hook'
    after_hook = 'after_hook'
    error_hook = 'error_hook'
    errors = 'errors'
    accept_hook = 'accept_hook'
    excludes = 'excludes'

    transaction = 'transaction'
    using = 'using'
    assign = 'assign'

    route = 'route'
    alias = 'alias'
    method = 'method'
    timeout = 'timeout'
    log = 'log'
    block = 'block'
    idempotent = 'idempotent'
    max_retries = 'max_retries'
    parser_cls = 'parser_cls'
    path_unit = 'path_unit'
    cache = 'cache'
    request = 'request'
    response = 'response'
    option = 'option'
    auth = 'auth'
    # regex = 'regex'

    pre = 'pre'
    end = 'end'
    aggregate = 'aggregate'


class GeneralType(Static):
    JSON = 'json'
    TEXT = 'text'
    IMAGE = 'image'
    AUDIO = 'audio'
    VIDEO = 'video'
    HTML = 'html'
    OCTET_STREAM = 'octet-stream'

    @classmethod
    def get(cls, content_type: str):
        if not content_type:
            return None
        if '/' not in content_type:
            return content_type
        if ';' in content_type:
            content_type = content_type.split(';')[0]
        per, suf = content_type.split('/')
        if suf in GENERAL_TYPES:
            return suf
        elif per in GENERAL_TYPES:
            return per
        return cls.OCTET_STREAM

    @classmethod
    def content_type(cls, type: str):
        if ';' in type:
            type = type.split(';')[0]
        if '/' in type:
            return type
        content_map = {
            cls.HTML: 'text/html',
            cls.JSON: 'application/json',
            # cls.AUDIO: 'audio/*',
            # cls.VIDEO: 'video/*',
            # cls.IMAGE: 'image/*',
            # cls.TEXT: 'text/*',
            cls.OCTET_STREAM: 'application/octet-stream',
        }
        return content_map.get(type)


class Scheme(Static):
    HTTP = 'http'
    HTTPS = 'https'
    FTP = 'ftp'
    FTPS = 'ftps'
    SFTP = 'sftp'
    SSH = 'ssh'
    WS = 'ws'
    WSS = 'wss'
    MQTT = 'mqtt'
    SMTP = 'smtp'
    POP = 'pop'
    UDP = 'udp'


class WebSocketEventType(Static):
    open = 'open'
    close = 'close'
    error = 'error'
    message = 'message'


class MetaHeader(Static):
    INVOKE_TOKEN = 'X-Meta-Invoke-Token'
    INSTANCE = 'X-Meta-Instance-ID'
    ACCEPT_VERSION = 'X-Meta-Accept-Version'

    LOG = 'X-Meta-Log-ID'
    CONFIRM_TOKEN = 'X-Meta-Confirm-Token'
    SERVICE_NAME = 'X-Meta-Service-Name'
    MODEL_TAG = 'X-Meta-Model-Tag'
    ACTION_TOKEN = 'X-Meta-Action-Token'
    SUPERVISE_TOKEN = 'X-Meta-Supervise-Token'
    # Action token for supervisor

    SERVICE_TOKEN = 'X-Meta-Service-Token'
    SUPERVISOR = 'X-Meta-Supervisor-ID'
    SUPERVISOR_ORIGIN = 'X-Meta-Supervisor-Origin'
    SERVICE = 'X-Meta-Service-ID'
    CLUSTER = 'X-Meta-Cluster-ID'
    NODE = 'X-Meta-Node-ID'
    USER = 'X-Meta-User-ID'
    PROJECT = 'X-Meta-Project-ID'
    OPERATION = 'X-Meta-Operation-Token'

    TEST_TOKEN = 'X-Meta-Test-Token'
    ACCESS_ID = 'X-Meta-Access-ID'
    ACCESS_KEY = 'X-Meta-Access-Key'
    SIGNATURE = 'X-Meta-Signature'
    TIMESTAMP = 'X-Meta-Timestamp'

    CASE_STYLE = 'X-Meta-Preference-Case'

    RECV_TIMESTAMP = 'Recv-Timestamp'
    SERVER_VERSION = 'Server-Version'
    RESPONSE_NAME = 'Response-Name'


class AuthScheme(Static):
    BASIC = 'basic'
    DIGEST = 'digest'
    BEARER = 'bearer'
    TOKEN = 'token'
    HOBA = 'hoba'
    MUTUAL = 'mutual'


class Header(Static):
    CONNECTION = 'Connection'
    COOKIE = 'Cookie'

    REMOTE_ADDR = 'REMOTE_ADDR'
    FORWARDED_FOR = "HTTP_X_FORWARDED_FOR"
    AUTHORIZATION = 'Authorization'

    WWW_AUTH = 'WWW-Authenticate'

    ACCEPT = 'Accept'
    ACCEPT_LANGUAGE = 'Accept-Language'
    CONTENT_LANGUAGE = 'Content-Language'

    UPGRADE = 'Upgrade'

    SET_COOKIE = 'Set-Cookie'
    USER_AGENT = 'User-Agent'

    EXPIRES = 'Expires'
    CACHE = 'Cache-Control'
    ETAG = 'Etag'
    LAST_MODIFIED = 'Last-Modified'

    IF_NOTMODIFIED_SINCE = 'If-Notmodified-Since'
    IF_MODIFIED_SINCE = 'If-Modified-Since'
    IF_NONE_MATCH = 'If-None-Match'
    IF_MATCH = 'If-Match'

    LENGTH = 'Content-Length'
    TYPE = 'Content-Type'
    ALLOW = 'Allow'
    ORIGIN = 'Origin'
    ALLOW_ORIGIN = 'Access-Control-Allow-Origin'
    ALLOW_CREDENTIALS = 'Access-Control-Allow-Credentials'
    ALLOW_METHODS = 'Access-Control-Allow-Methods'
    EXPOSE_HEADERS = 'Access-Control-Expose-Headers'
    ALLOW_HEADERS = 'Access-Control-Allow-Headers'
    OPTIONS_METHOD = 'Access-Control-Request-Method'
    OPTIONS_HEADERS = 'Access-Control-Request-Headers'

    @classmethod
    def attr_name(cls, key: str):
        return key.replace('-', '_').lower()


class Level(Static):
    REGULAR = 'regular'
    CAUTION = 'caution'
    DANGER = 'danger'
    CRUCIAL = 'crucial'
    
    
class Attr(Static):
    GT = '__gt__'
    GE = '__ge__'
    LT = '__lt__'
    LE = '__le__'

    COMMAND = '__command__'
    SPEC = '__spec__'
    LEN = '__len__'
    DOC = '__doc__'
    HASH = '__hash__'
    CODE = '__code__'
    MODULE = '__module__'
    BASES = '__bases__'
    NAME = '__name__'
    FUNC = '__func__'
    CALL = '__call__'
    ARGS = '__args__'
    INIT = '__init__'
    DICT = '__dict__'
    MAIN = '__main__'
    ITER = '__iter__'
    LOCK = '__locked__'
    INNER = '__inner__'
    PROXY = '__proxy__'
    RELATED = '__related__'
    STATUS = '__status__'
    ORIGIN = '__origin__'
    TARGET = '__target__'
    CATEGORY = '__category__'
    PARENTS = '__parents__'
    CLS = '__class__'
    PARSER = '__parser__'
    BUILTINS = '__builtins__'
    ANNOTATES = '__annotations__'
    ISOLATE = '__isolate__'
    CONFIG = '__config__'
    OPTIONS = '__options__'
    CACHE = '__cache__'
    VACUUM = '__vacuum__'
    VALIDATE = '__validate__'
    TEMPLATE = '__template__'
    IGNORE_GENERATE = '__ignore_generate__'
    DATA = '__data__'
    EXTRA = '__extra__'
    ADD = '__ADD__'
    MOD = '__MOD__'
    REM = '__REM__'


class Env(Static):
    SETTINGS = 'DJANGO_SETTINGS_MODULE'
    PRODUCTION = 'META_PRODUCTION'
    ROOT_API = 'ROOT_API'
    URL = 'urlpatterns'


class Logic(Static):
    ALL = '*'
    AND = '&'
    OR = '|'
    XOR = '^'
    NOT = '~'


class WorkerStatus(Static):
    IDLE = 'idle'
    BUSY = 'busy'
    PAUSE = 'pause'
    CHEAP = 'cheap'
    SIG = 'sig'
    DOWN = 'down'


# ---------- define by UtilMeta standard, using lower case property as name
class Param(Static):
    dataframe = '@dataframe'
    template = '@template'
    exclude = '@exclude'
    offset = '@offset'
    limit = '@limit'
    field = '@field'
    order = '@order'
    page = '@page'
    rows = '@rows'
    key = '@key'
    query = '@query'


class OperatorOption(Static):
    equ = '='
    add = '+'
    min = '-'
    mul = '*'
    div = '/'
    mod = '%'
    pow = '^'


class FilterNote(Static):
    exact = '='
    iexact = '~'
    startswith = '*%'
    istartswith = '~%'
    endswith = '%*'
    iendswith = '%~'
    contains = '%'
    icontains = '*'
    gt = '>'
    lt = '<'
    gte = '>='
    lte = '<='
    regex = '$'
    iregex = '~$'
    isnull = '-'

    IN = '^'
    NOT = '!'

    contained_by = '<@'
    overlap = '@'
    len = '|'

    fully_lt = '<<'
    fully_gt = '>>'
    not_lt = '!<'
    not_gt = '!>'
    adjacent_to = '|-'

    @classmethod
    def get_option(cls, key):
        if not key or key == cls.exact:
            return ''
        mp = cls.reverse_map()
        return mp.get(key, '')

    @classmethod
    def options(cls):
        opt = list(cls.gen())
        for v in tuple(opt):
            if v not in ('>', '<', '>=', '<=', '=', '!'):
                opt += f'!{v}'
        return opt

    @classmethod
    def lookups(cls):
        lks = []
        for k, v in cls.__dict__.items():
            if isinstance(v, str):
                lks.append(k)
        return lks

    @classmethod
    def reverse_map(cls):
        reverse_map = {}
        for k, v in cls.__dict__.items():
            if isinstance(v, str):
                reverse_map[v] = str(k).lower()
        return reverse_map


class APIOperation(Static):
    view_doc = 'view_doc'
    view_log = 'view_log'
    safe_call = 'safe_call'
    sudo_call = 'sudo_call'
    develop = 'develop'
    deploy = 'deploy'


class ModelOperation(Static):
    query = 'query'
    create = 'create'
    modify = 'modify'
    delete = 'delete'


class TaskOperation(Static):
    start = 'start'
    pause = 'pause'
    alter = 'alter'


class WorkerType(Static):
    service = 'service'
    task = 'task'
    common = 'common'


class Opt(Static):
    """
    Need to be backward compat
    """
    # TEAM ----------
    admin_audit = 'admin_audit'
    admin_add = 'admin_add'
    admin_alter = 'admin_alter'     # alter permissions
    admin_remove = 'admin_remove'

    # DATA ---------
    data_query = 'data_query'
    data_create = 'data_create'     # grant all models create permission
    data_modify = 'data_modify'     # grant all models modify permission
    data_delete = 'data_delete'     # grant all models delete permission
    data_import = 'data_import'
    data_export = 'data_export'
    data_backup = 'data_backup'
    data_replicate = 'data_replicate'
    data_sql_execute = 'data_sql_execute'

    file_upload = 'file_upload'
    file_download = 'file_download'

    session_view = 'session_view'
    session_delete = 'session_delete'
    # DEV -----
    code_view = 'code_view'     # view service development code
    conf_view = 'conf_view'     # view service deployment config

    develop = 'develop'         # permission to online develop service
    deploy = 'deploy'           # permission to config service and deploy service code to server

    # LOG ----
    log_query = 'log_query'
    log_trace = 'log_trace'
    log_delete = 'log_delete'

    # ALERT ----
    alert_query = 'alert_query'
    alert_add = 'alert_add'
    alert_disable = 'alert_disable'
    alert_relieve = 'alert_relieve'

    # API -----
    api_view = 'api_view'
    api_metrics_view = 'api_metrics_view'
    api_safe_call = 'api_safe_call'               # grant safe methods (GET/HEAD/OPTIONS) call permissions
    api_sudo_call = 'api_sudo_call'               # grant all api call permission (bypass auth)

    # TEST -----
    unit_test = 'unit_test'
    stress_test = 'stress_test'

    # MONITOR ---
    service_view = 'service_view'
    metrics_view = 'metrics_view'

    # TASK ---
    task_view = 'task_view'
    task_control = 'task_control'
    task_add = 'task_add'
    script_add = 'script_add'
    task_disable = 'task_disable'
    task_arrange = 'task_arrange'


class ProblemTarget(Static):
    dns = 'dns'
    cdn = 'cdn'
    network = 'network'
    page = 'page'
    endpoint = 'endpoint'
    service = 'service'
    task = 'task'
    server = 'server'
    database = 'database'
    cache = 'cache'
    vendor = 'vendor'


class AlertCategory(Static):
    service_error = 'service_error'     # for service
    task_error = 'task_error'     # for tasks / jobs

    service_downgrade = 'service_downgrade'
    task_downgrade = 'task_downgrade'
    # request_downgrade = 'request_downgrade'

    service_unavailable = 'service_unavailable'     # timeout / failed
    task_unavailable = 'task_unavailable'

    load_uprush = 'load_uprush'     # rps / qps suddenly rise
    resource_saturated = 'resource_saturated'

    # availability = 'availability'
    security = 'security'
    custom = 'custom'


class ServiceInfo(Static):
    document = 'document'
    updates = 'updates'
    migrations = 'migrations'
    utils = 'utils'
    nodes = 'nodes'
    config = 'config'
    models = 'models'


SERVICE_INFO_PERMISSION = {
    ServiceInfo.document: Opt.api_view,
    ServiceInfo.updates: Opt.api_view,
    ServiceInfo.utils: Opt.code_view,
    ServiceInfo.nodes: Opt.code_view,
    ServiceInfo.config: Opt.conf_view,
    ServiceInfo.models: Opt.data_query,
    ServiceInfo.migrations: Opt.data_query
}
# ----------


class Language(Static):
    af = "af"
    ar = "ar"
    az = "az"
    be = "be"
    bg = "bg"
    bs = "bs"
    ca = "ca"
    cs = "cs"
    cy = "cy"
    da = "da"
    de = "de"
    dv = "dv"
    el = "el"
    en = "en"
    eo = "eo"
    es = "es"
    et = "et"
    eu = "eu"
    fa = "fa"
    fi = "fi"
    fo = "fo"
    fr = "fr"
    gl = "gl"
    gu = "gu"
    he = "he"
    hi = "hi"
    hr = "hr"
    hu = "hu"
    hy = "hy"
    id = "id"
    it = "it"
    ja = "ja"
    ka = "ka"
    kk = "kk"
    kn = "kn"
    ko = "ko"
    ky = "ky"
    lt = "lt"
    lv = "lv"
    mi = "mi"
    mk = "mk"
    mn = "mn"
    mr = "mr"
    ms = "ms"
    mt = "mt"
    nb = "nb"
    nl = "nl"
    nn = "nn"
    ns = "ns"
    pa = "pa"
    pl = "pl"
    pt = "pt"
    qu = "qu"
    ro = "ro"
    ru = "ru"
    sa = "sa"
    se = "se"
    sk = "sk"
    sl = "sl"
    sq = "sq"
    sr = "sr"
    sv = "sv"
    sw = "sw"
    ta = "ta"
    te = "te"
    th = "th"
    tl = "tl"
    tn = "tn"
    tr = "tr"
    ts = "ts"
    tt = "tt"
    uk = "uk"
    ur = "ur"
    uz = "uz"
    vi = "vi"
    xh = "xh"
    zh = "zh"
    zu = "zu"


class Locale(Static):
    ZA = "ZA"
    AE = "AE"
    BH = "BH"
    DZ = "DZ"
    EG = "EG"
    IQ = "IQ"
    JO = "JO"
    KW = "KW"
    LB = "LB"
    LY = "LY"
    MA = "MA"
    OM = "OM"
    QA = "QA"
    SA = "SA"
    SY = "SY"
    TN = "TN"
    YE = "YE"
    AZ = "AZ"
    BY = "BY"
    BG = "BG"
    BA = "BA"
    ES = "ES"
    CZ = "CZ"
    GB = "GB"
    DK = "DK"
    AT = "AT"
    CH = "CH"
    DE = "DE"
    LI = "LI"
    LU = "LU"
    MV = "MV"
    GR = "GR"
    AU = "AU"
    BZ = "BZ"
    CA = "CA"
    CB = "CB"
    IE = "IE"
    JM = "JM"
    NZ = "NZ"
    PH = "PH"
    TT = "TT"
    US = "US"
    ZW = "ZW"
    AR = "AR"
    BO = "BO"
    CL = "CL"
    CO = "CO"
    CR = "CR"
    DO = "DO"
    EC = "EC"
    GT = "GT"
    HN = "HN"
    MX = "MX"
    NI = "NI"
    PA = "PA"
    PE = "PE"
    PR = "PR"
    PY = "PY"
    SV = "SV"
    UY = "UY"
    VE = "VE"
    EE = "EE"
    IR = "IR"
    FI = "FI"
    FO = "FO"
    BE = "BE"
    FR = "FR"
    MC = "MC"
    IN = "IN"
    IL = "IL"
    HR = "HR"
    HU = "HU"
    AM = "AM"
    ID = "ID"
    IS = "IS"
    IT = "IT"
    JP = "JP"
    GE = "GE"
    KZ = "KZ"
    KR = "KR"
    KG = "KG"
    LT = "LT"
    LV = "LV"
    MK = "MK"
    MN = "MN"
    BN = "BN"
    MY = "MY"
    MT = "MT"
    NO = "NO"
    NL = "NL"
    PL = "PL"
    BR = "BR"
    PT = "PT"
    RO = "RO"
    RU = "RU"
    SE = "SE"
    SK = "SK"
    SI = "SI"
    AL = "AL"
    SP = "SP"
    KE = "KE"
    TH = "TH"
    TR = "TR"
    UA = "UA"
    PK = "PK"
    UZ = "UZ"
    VN = "VN"
    CN = "CN"
    HK = "HK"   # HongKong (China)
    MO = "MO"
    SG = "SG"
    TW = "TW"   # Taiwan (China)

    @classmethod
    def language(cls, locale: str, single: bool = True) -> Union[List[str], str]:
        result = []
        for key, values in LANGUAGE_LOCALE_MAP.items():
            if locale in values:
                if single:
                    return key
                result.append(key)
        return result


class TimeZone(Static, ignore_duplicate=True):
    UTC = 'UTC'
    GMT = 'UTC'
    WET = 'WET'
    CET = 'CET'
    MET = 'CET'
    ECT = 'CET'
    EET = 'EET'
    MIT = 'Pacific/Apia'
    HST = 'Pacific/Honolulu'
    AST = 'America/Anchorage'
    PST = 'America/Los_Angeles'
    LOS_ANGELES = 'America/Los_Angeles'
    MST = 'America/Denver'
    PNT = 'America/Phoenix'
    CST = 'America/Chicago'
    CHICAGO = 'America/Chicago'
    EST = 'America/New_York'
    NEW_YORK = 'America/New_York'
    IET = 'America/Indiana/Indianapolis'
    PRT = 'America/Puerto_Rico'
    CNT = 'America/St_Johns'
    AGT = 'America/Argentina/Buenos_Aires'
    BET = 'America/Sao_Paulo'
    ART = 'Africa/Cairo'
    CAT = 'Africa/Harare'
    EAT = 'Africa/Addis_Ababa'
    NET = 'Asia/Yerevan'
    PLT = 'Asia/Karachi'
    IST = 'Asia/Kolkata'
    BST = 'Asia/Dhaka'
    VST = 'Asia/Ho_Chi_Minh'
    CTT = 'Asia/Shanghai'
    SHANGHAI = 'Asia/Shanghai'
    JST = 'Asia/Tokyo'
    TOKYO = 'Asia/Tokyo'
    ACT = 'Australia/Darwin'
    DARWIN = 'Australia/Darwin'
    AET = 'Australia/Sydney'
    SYDNEY = 'Australia/Sydney'
    SST = 'Pacific/Guadalcanal'
    NST = 'Pacific/Auckland'


LANGUAGE_LOCALE_MAP = {
    'af': ['ZA'],
    'ar': ['AE', 'BH', 'DZ', 'EG', 'IQ', 'JO', 'KW', 'LB', 'LY', 'MA', 'OM',
           'QA', 'SA', 'SY', 'TN', 'YE'],
    'az': ['AZ', 'AZ'],
    'be': ['BY'],
    'bg': ['BG'],
    'bs': ['BA'],
    'ca': ['ES'],
    'cs': ['CZ'],
    'cy': ['GB'],
    'da': ['DK'],
    'de': ['AT', 'CH', 'DE', 'LI', 'LU'],
    'dv': ['MV'],
    'el': ['GR'],
    'en': ['AU', 'BZ', 'CA', 'CB', 'GB', 'IE', 'JM', 'NZ', 'PH', 'TT', 'US', 'ZA', 'ZW'],
    'es': ['AR', 'BO', 'CL', 'CO', 'CR', 'DO', 'EC', 'ES', 'ES', 'GT', 'HN', 'MX', 'NI',
           'PA', 'PE', 'PR', 'PY', 'SV', 'UY', 'VE'],
    'et': ['EE'],
    'eu': ['ES'],
    'fa': ['IR'],
    'fi': ['FI'],
    'fo': ['FO'],
    'fr': ['BE', 'CA', 'CH', 'FR', 'LU', 'MC'],
    'gl': ['ES'],
    'gu': ['IN'],
    'he': ['IL'],
    'hi': ['IN'],
    'hr': ['BA', 'HR'],
    'hu': ['HU'],
    'hy': ['AM'],
    'id': ['ID'],
    'is': ['IS'],
    'it': ['CH', 'IT'],
    'ja': ['JP'],
    'ka': ['GE'],
    'kk': ['KZ'],
    'kn': ['IN'],
    'ko': ['KR'],
    'ky': ['KG'],
    'lt': ['LT'],
    'lv': ['LV'],
    'mi': ['NZ'],
    'mk': ['MK'],
    'mn': ['MN'],
    'mr': ['IN'],
    'ms': ['BN', 'MY'],
    'mt': ['MT'],
    'nb': ['NO'],
    'nl': ['BE', 'NL'],
    'nn': ['NO'],
    'ns': ['ZA'],
    'pa': ['IN'],
    'pl': ['PL'],
    'pt': ['BR', 'PT'],
    'qu': ['BO', 'EC', 'PE'],
    'ro': ['RO'],
    'ru': ['RU'],
    'sa': ['IN'],
    'se': ['FI', 'NO', 'SE'],
    'sk': ['SK'],
    'sl': ['SI'],
    'sq': ['AL'],
    'sr': ['BA', 'SP'],
    'sv': ['FI', 'SE'],
    'sw': ['KE'],
    'ta': ['IN'],
    'te': ['IN'],
    'th': ['TH'],
    'tl': ['PH'],
    'tn': ['ZA'],
    'tr': ['TR'],
    'tt': ['RU'],
    'uk': ['UA'],
    'ur': ['PK'],
    'uz': ['UZ', 'UZ'],
    'vi': ['VN'],
    'xh': ['ZA'],
    'zh': ['CN', 'HK', 'MO', 'SG', 'TW'],
    'zu': ['ZA'],
}

FIELDS_TYPE = {
    ('CharField', 'ImageField', 'ChoiceField', 'PasswordField',
     'EmailField', 'FilePathField', 'FileField', 'URLField',
     'GenericIPAddressField', 'IPAddressField', 'TextField',
     'RichTextField',): str,
    ('UUIDField',): UUID,
    ('TimeField',): time,
    ('DateField',): date,
    ('DurationField',): timedelta,
    ('DateTimeField',): datetime,
    ('AutoField', 'BigAutoField', 'SmallAutoField', 'BigIntegerField',
     'IntegerField', 'PositiveIntegerField', 'PositiveBigIntegerField',
     'SmallIntegerField', 'PositiveSmallIntegerField', 'SmallIntegerField',): int,
    ('FloatField',): float,
    ('DecimalField',): Decimal,
    ('BooleanField', 'NullBooleanField',): bool,
    ('CommaSeparatedIntegerField', 'ArrayField', 'ManyToManyField',
     'ManyToOneRel', 'ManyToManyRel'): list,
    ('JSONField', 'HStoreField'): dict,
    ('BinaryField',): bytes
}

datetime_lookups = ['date', 'time']
date_lookups = ['year', 'iso_year', 'month', 'day', 'week', 'week_day', 'quarter']
time_lookups = ['hour', 'minute', 'second']
option_allowed_lookups = [*datetime_lookups, *date_lookups, *time_lookups, 'len']

ADDON_FIELD_LOOKUPS = {
    'DateField': date_lookups,
    'TimeField': time_lookups,
    'DateTimeField': [*date_lookups, *time_lookups, *datetime_lookups],

    'ArrayField': ['contains', 'contained_by', 'overlap', 'len'],
    'HStoreField': ['contains', 'contained_by', 'has_key', 'has_any_keys', 'has_keys', 'keys', 'values'],
    'RangeField': ['contains', 'contained_by', 'overlap', 'fully_lt', 'fully_gt', 'not_lt',
                   'not_gt', 'adjacent_to', 'isempty', 'lower_inc', 'lower_inf', 'upper_inc', 'upper_inf']
}


TYPES_NOTE = {
    str: 'string',
    int: 'number:integer',
    float: 'number:float',
    bool: 'boolean',
    list: 'array',
    tuple: 'array:tuple',
    set: 'array:set',
    dict: 'object',
    bytes: 'string',
    File: 'file',
    Decimal: 'number:decimal',
    date: 'string:date',
    time: 'string:time',
    datetime: 'string:datetime',
    UUID: 'string:uuid'
}

TYPE_NAME = {
    list: 'List',
    dict: 'Dict',
    set: 'Set',
    tuple: 'Tuple'
}

METHOD_DEFAULT_STATUS = {
    CommonMethod.GET: 200,
    CommonMethod.PUT: 200,
    CommonMethod.PATCH: 200,
    CommonMethod.POST: 201,
    CommonMethod.DELETE: 200
}

METHOD_IDEMPOTENCY = {
    CommonMethod.GET: True,
    CommonMethod.PUT: True,
    CommonMethod.POST: False,
    CommonMethod.PATCH: None,   # it depends
    CommonMethod.DELETE: True,
}

ERROR_STATUS = {
    NotImplementedError: 501,
    Exception: 500,
    FileNotFoundError: 404,
    PermissionError: 403,
    TimeoutError: 503,
    **{v: k for k, v in exc.HttpError.STATUS_EXCEPTIONS.items()}
}

# OPERATION_DATA = [
#     (0, Opt.admin_manage, Level.CRUCIAL),
#     (1, Opt.utils_read, Level.REGULAR),  # read
#     (2, Opt.utils_config, Level.CRUCIAL),
#     (3, Opt.log_read, Level.REGULAR),
#     (4, Opt.log_delete, Level.CAUTION),   # read and wri
#     (5, Opt.api_read, Level.CAUTION),   # read
#     (6, Opt.api_test, Level.DANGER),
#     (7, Opt.stress_test, Level.DANGER),
#     (8, Opt.data_read, Level.CAUTION),
#     (9, Opt.data_write, Level.DANGER),
#     (10, Opt.data_delete, Level.CRUCIAL),
#     (11, Opt.monitor, Level.REGULAR)
# ]

NOTE_MAP = {
    '@': 'at',
    '!': 'not',
    '$': 'reg',
    '&': 'and',
    '|': 'or',
    '=': 'e',
    '?': 'q',
    '^': 'pow',
    '*': 'mul',
    '-': 'min',
    '+': 'add',
    '/': 'div',
    '%': 'mod',
    '>': 'gt',
    '<': 'lt',
    '.': 'dot'
}

ALIAS_FILE_SUFFIX = [
    ('jpg', 'jpeg', 'jfif', 'pjpeg', 'pjp'),
    ('wav', 'wave'),
    ('doc', 'docx'),
    ('htm', 'html'),
]

HTTP = Scheme.HTTP + SCHEME
HTTPS = Scheme.HTTPS + SCHEME
COMMON_ERRORS = (AttributeError, TypeError, ValueError, IndexError, KeyError, UnicodeDecodeError)
WSGI_STATUS = WorkerStatus.gen()
REQUEST_TYPES = RequestType.gen()
CONTENT_TYPE = Header.attr_name(Header.TYPE)
DICT_TYPES = (RequestType.JSON, RequestType.XML, RequestType.FORM_URLENCODED, RequestType.FORM_DATA)
GENERAL_TYPES = GeneralType.gen()
STREAM_TYPES = (GeneralType.IMAGE, GeneralType.AUDIO, GeneralType.VIDEO, GeneralType.OCTET_STREAM)
OPERATIONS = Opt.gen()
OPERATION_LEVELS = Level.gen()
SCHEMES = Scheme.gen()
ALERT_LEVELS = AlertLevel.gen()
LOG_LEVELS = LogLevel.gen()
HOOK_TYPES = (UnitAttr.before_hook, UnitAttr.after_hook, UnitAttr.error_hook)
UNIT_TYPES = (UnitAttr.main, *HOOK_TYPES)

API_OPERATIONS = APIOperation.gen()
MODEL_OPERATIONS = ModelOperation.gen()
MODEL_OPERATION_MAP = {
    ModelOperation.query: Opt.data_query,
    ModelOperation.create: Opt.data_create,
    ModelOperation.modify: Opt.data_modify,
    ModelOperation.delete: Opt.data_delete,
}

ATOM_TYPES = (str, int, bool, float, type(None))
JSON_TYPES = (*ATOM_TYPES, list, dict, ImmutableList, ImmutableDict)
# types thar can directly dump to json
VENDOR_TYPES = (datetime, date, time, timedelta, UUID, Decimal)
COMMON_TYPES = (*JSON_TYPES, set, tuple, bytes, *VENDOR_TYPES)
LANGUAGES = Language.gen()
LOCALES = Locale.gen()
LOOKUPS = ('exact', 'iexact', 'startswith', 'istartswith', 'endswith', 'iendswith', 'in',
           'contains', 'icontains', 'gt', 'gte', 'lt', 'lte', 'regex', 'iregex')

DATETIME_FORMATS = [f for k, f in Format.dict().items() if str(k).startswith('DATETIME')]
HAS_BODY_METHODS = (CommonMethod.POST, CommonMethod.PUT, CommonMethod.PATCH)
FALSE_VALUES = ('0', 'false', 'null', 'no', 'off', 'f', 'nan', 'none', ' ')
OPERATORS = OperatorOption.gen()
ALLOW_HEADERS = (Header.TYPE, Header.LENGTH, Header.ORIGIN)
ADMIN_HEADERS = (MetaHeader.SERVICE_TOKEN, MetaHeader.SUPERVISOR, MetaHeader.OPERATION, MetaHeader.ACCEPT_VERSION)
HTTP_METHODS = HTTPMethod.gen()
ISOLATED_HEADERS = {Header.LENGTH, Header.TYPE, Header.CONNECTION}
SAFE_METHODS = (HTTPMethod.GET, HTTPMethod.OPTIONS, HTTPMethod.HEAD, HTTPMethod.TRACE)
ALTER_METHODS = (CommonMethod.POST, CommonMethod.PUT, CommonMethod.PATCH, CommonMethod.DELETE)
http_methods = [m.lower() for m in HTTP_METHODS]

MESSAGE_STATUSES = list(range(100, 103))
SUCCESS_STATUSES = list(range(200, 208))
REDIRECT_STATUSES = list(range(300, 308))
REQUEST_ERROR_STATUSES = list(range(400, 419)) + list(range(421, 427)) + [449, 451]
SERVER_ERROR_STATUSES = list(range(500, 511)) + [600]

COMMON_METHODS = CommonMethod.gen()
META_METHODS = MetaMethod.gen()
METHODS = COMMON_METHODS + META_METHODS
SECURE_SCHEMES = {
    'http': 'https',
    'ws': 'wss',
    'ftp': 'ftps'
}
FRAMEWORKS = ['django', 'utilmeta']
STATUS_WITHOUT_BODY = (204, 205, 304)
SUPPORTED_SCHEMES = (Scheme.HTTP, Scheme.HTTPS)
LOGICAL_OPERATORS = ('AND', 'OR', 'XOR', 'NOT')
ADMIN_PERMISSIONS = {
    'admin': [Opt.admin_add, Opt.admin_alter, Opt.admin_remove, Opt.admin_audit],
    'data': [Opt.data_query, Opt.data_create, Opt.data_modify, Opt.data_delete, Opt.file_download, Opt.file_upload],
    'log': [Opt.log_query, Opt.log_trace, Opt.log_delete],
    'api': [Opt.api_view, Opt.api_safe_call, Opt.api_sudo_call],
    'metrics': [Opt.service_view, Opt.metrics_view],
    'develop': [Opt.code_view, Opt.develop],
    'deploy': [Opt.conf_view, Opt.deploy],
    'alert': [Opt.alert_query, Opt.alert_add, Opt.alert_disable, Opt.alert_relieve],
    'task': [Opt.task_view, Opt.task_add, Opt.script_add, Opt.task_disable, Opt.task_control, Opt.task_arrange],
    'test': [Opt.unit_test, Opt.stress_test]
}
OPERATORS_DEPENDENCIES = {
    Opt.data_query: [Opt.data_create, Opt.data_modify, Opt.data_delete],
    Opt.api_view: [Opt.api_safe_call, Opt.api_sudo_call],
    Opt.alert_query: [Opt.alert_add, Opt.alert_disable, Opt.alert_relieve],
    Opt.task_view: [Opt.task_add, Opt.script_add, Opt.task_disable, Opt.task_control, Opt.task_arrange],
}
# TIME_ZONES = tuple(set(TimeZone.gen()))
# in future versions will support more schemes like ws/wss, mqtt, udp and will add them to list
DNS_ERRNO = ["[Errno 8]", "[Errno 11001]", "[Errno -2]"]
