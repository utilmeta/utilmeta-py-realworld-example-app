import inspect

_IMMUTABLE = []
_LOCKED = False


class ImmutableDict(dict):
    def __error__(self, *args, **kwargs):
        raise AttributeError("ImmutableDict can not modify value")

    __delitem__ = __error__
    __setitem__ = __error__

    def __str__(self):
        return f'{self.__class__.__name__}({super().__repr__()})'

    def __repr__(self):
        return f'{self.__class__.__name__}({super().__repr__()})'

    setdefault = __error__
    pop = __error__
    popitem = __error__
    clear = __error__
    update = __error__


# class ImmutableOrderedDict(OrderedDict):
#     def __error__(self, *args, **kwargs):
#         raise AttributeError("ImmutableOrderedDict can not modify value")
#
#     __delitem__ = __error__
#     __setitem__ = __error__
#
#     def __str__(self):
#         return f'{self.__class__.__name__}({super().__repr__()})'
#
#     def __repr__(self):
#         return f'{self.__class__.__name__}({super().__repr__()})'
#
#     setdefault = __error__
#     pop = __error__
#     popitem = __error__
#     clear = __error__
#     update = __error__


class ImmutableList(list):
    def error(self, *args, **kwargs):
        raise AttributeError("ImmutableList can not modify value")

    def __str__(self):
        return f'{self.__class__.__name__}({super().__repr__()})'

    def __repr__(self):
        return f'{self.__class__.__name__}({super().__repr__()})'

    append = error
    clear = error
    extend = error
    insert = error
    pop = error
    remove = error
    reverse = error
    sort = error
    __iadd__ = error
    __imul__ = error
    __setitem__ = error
    __delitem__ = error


class RuntimeImmutable:
    """
    RunTime Immutable mixin apply to classes and instances
    apply to class (API/Module/Schema)    : let it's metaclass inherit this class
    apply to instance (Utils)             : let it's class inherit this class

    when the service is setuped, it's consider runtime
    and will call ._lock_all() method, then all the targets
    instances and classes will be locked

    and all the instances created after setuped is consider
    user defined and will not be locked unless you manually called _lock()

    take the first lock operation as valid
    """
    _MUTABLE = False

    def _lock(self):
        try:
            self.__locked__ = True
        except AttributeError:
            pass

    @classmethod
    def _lock_all(cls):
        try:
            global _LOCKED, _IMMUTABLE
            for child in _IMMUTABLE:
                child: cls
                child._lock()
            _LOCKED = True
            _IMMUTABLE = []
        except AttributeError:
            pass

    def __setattr__(self, key: str, value):
        if getattr(self, '__locked__', None):
            raise AttributeError(f'{self.__class__.__name__} is readonly and'
                                 f' cannot be set attribute ({key} -> {repr(value)}) during runtime')
        return super().__setattr__(key, value)

    def __delattr__(self, item):
        if getattr(self, '__locked__', None):
            raise AttributeError(f'{self.__class__.__name__} is readonly and'
                                 f' cannot be delete attribute ({item}) during runtime')
        return super().__delattr__(item)

    def __init__(self):
        try:
            if not _LOCKED and not self._MUTABLE:
                global _IMMUTABLE
                _IMMUTABLE.append(self)
        except AttributeError:
            pass


class Static(RuntimeImmutable):
    def __init_subclass__(cls, ignore_duplicate: bool = False, **kwargs):
        attrs = []
        for name, attr in cls.__dict__.items():
            if '__' in name:
                continue
            if attr in attrs and not ignore_duplicate:
                raise ValueError(f'Static value cannot be duplicated, got {attr}')
            attrs.append(attr)

    @classmethod
    def gen(cls) -> tuple:
        attrs = []
        for name, attr in cls.__dict__.items():
            if '__' in name:
                continue
            if callable(attr) or inspect.isfunction(attr) or inspect.ismethod(attr) or\
                    isinstance(attr, classmethod) or isinstance(attr, staticmethod):
                continue
            attrs.append(attr)
        return tuple(attrs)

    @classmethod
    def dict(cls, reverse: bool = False, lower: bool = False):
        attrs = {}
        for name, attr in cls.__dict__.items():
            if '__' in name:
                continue
            if callable(attr) or inspect.isfunction(attr) or inspect.ismethod(attr) or \
                    isinstance(attr, classmethod) or isinstance(attr, staticmethod):
                continue
            name = name.lower() if lower else name
            if reverse:
                attrs[attr] = name
            else:
                attrs[name] = attr
        return attrs
