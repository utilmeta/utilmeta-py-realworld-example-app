import time
from functools import wraps, partial
import threading
import inspect
import multiprocessing.pool
from typing import Dict, List, Callable, TypeVar, Union, Type
from .constant import METHODS, Attr, Param, COMMON_ERRORS, HTTPMethod, \
    HOOK_TYPES, UnitAttr, CommonMethod
from .functional import pop, get_single_value, multi, close_connections
from .exc import BadRequest, CombinedError
from datetime import timedelta
from utilmeta.util.error import Error
import warnings


T = TypeVar('T')

__all__ = ['api', 'omit', 'task', 'error_convert', 'handle_retries',
           'handle_parse', 'handle_timeout', 'ignore_errors', 'static_require']


def set_hook(f, hook_type: str, value):
    assert hook_type in HOOK_TYPES
    for t in HOOK_TYPES:
        if hasattr(f, t):
            if t != hook_type:
                raise AttributeError(f'Function: {f.__name__} is already '
                                     f'hook for <{t}>, cannot hook for {hook_type}')
            else:
                return
    setattr(f, hook_type, value)
    return f


def set_excludes(f, excludes):
    if not excludes:
        return f
    if hasattr(f, UnitAttr.excludes):
        return

    def proc(ex):
        return ex if isinstance(ex, str) else ex.__name__
    if multi(excludes):
        excludes = [proc(e) for e in excludes]
    else:
        excludes = [proc(excludes)]
    setattr(f, UnitAttr.excludes, excludes)
    return f


def get_hook_type(f):
    for t in HOOK_TYPES:
        if getattr(f, t, None):
            return t
    return None


def ignore_errors(_f=None, *, default=None, log: bool = True,
                  log_detail: bool = True, errors=(Exception,), on_finally=None):
    if on_finally:
        assert callable(on_finally), f'@ignore_errors on_finally must be a callable, got {on_finally}'

    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            try:
                return f(*args, **kwargs)
            except errors as e:
                if log:
                    warnings.warn(f'IGNORED ERROR for {f.__name__}: {e}')
                    if log_detail:
                        Error(e).log(console=True)
                # to avoid a public mutable value (like dict) cause unpredictable result
                # allow to pass a value like dict or list and call it at runtime
                return default() if callable(default) else default
            finally:
                if on_finally:
                    on_finally()
        return wrapper
    if _f:
        return decorator(_f)
    return decorator


def static_require(*args_func: Callable, runtime: bool = True):
    def not_implement(*_, **__):
        raise NotImplementedError('you current settings does not support this method')

    @ignore_errors(default=False, log=False)
    def satisfied():
        for arg_func in args_func:
            if not arg_func():
                return False
        return True

    def decorator(f):
        if not runtime:
            if satisfied():
                return f
            else:
                return not_implement
        else:
            @wraps(f)
            def wrapper(*args, **kwargs):
                if satisfied():
                    return f(*args, **kwargs)
                return not_implement()
            return wrapper
    return decorator


def error_convert(errors: List[Type[Exception]], target: Type[Exception]):
    def deco(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            try:
                return f(*args, **kwargs)
            except errors:
                raise Error().throw(target)
            except CombinedError as e:
                for err in e.errors:
                    if not isinstance(err, tuple(errors)):
                        raise Error().throw()
                raise Error().throw(target)
        return wrapper
    return deco


handle_parse = error_convert(errors=COMMON_ERRORS, target=BadRequest)


def handle_timeout(timeout: timedelta):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            pool = multiprocessing.pool.ThreadPool(processes=1)
            async_result = pool.apply_async(f, args, kwargs)
            try:
                r = async_result.get(timeout.total_seconds())
            except multiprocessing.context.TimeoutError:
                # pool.terminate()
                raise TimeoutError(f"function <{f.__name__}> execute beyond expect"
                                   f" time limit {timeout.total_seconds()} seconds")
            finally:
                pool.close()
            return r
        return wrapper
    return decorator


def handle_retries(retries: int = 2, retry_interval: float = None):
    assert retries > 1

    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            errors = []
            for i in range(0, retries):
                try:
                    if i and retry_interval:
                        time.sleep(retry_interval)
                    return f(*args, **kwargs)
                except Exception as e:
                    errors.append(e)
            if not errors:
                raise RuntimeError('Invalid retry status')
            if len(errors) == 1:
                raise Error(errors[0]).throw()
            raise CombinedError(*errors)
        return wrapper
    return decorator


def omit(f):
    """
    @omit
    this decorator is for log save
    as the operation system saving log to database, usually cost 50ms~200ms
    letting request to wait for save is done while result doesn't affect the response is unwise
    so it's function is to execute a async thread task to "fire and forget" the save mission

    further: in next generation, with cache system, the log will be sync load to memory cache
            and batch save to database
    """

    @ignore_errors(on_finally=close_connections)
    @wraps(f)
    def handler(func, *args, **kwargs):
        func(*args, **kwargs)

    @wraps(f)
    def wrapper(*args, **kwargs):
        args = [f] + [a for a in args]
        threading.Thread(target=handler, args=args, kwargs=kwargs).start()
    return wrapper


class APIDecorator:
    def __init__(self):
        pass

    @classmethod
    def query(cls, _f=None, *, filter_with_rules: bool = False):    # , block: bool = False):
        """
        decorated query API for all self-defined query logic
        filter_with_rules: filter the db result with rules (result only include instances that pass the rule)
                           for some cases that need to define more complicated filter that database don't support

        block: whether the query is async / sync, current version (v1.6) not support
               will be implement at next version which fully support async / asgi
        """
        from django.db.models import QuerySet, Model
        from django.db.models.base import ModelBase
        from utilmeta.util.query import MetaQuerySet
        from utilmeta.util.query.schema import SchemaGenerator
        from utilmeta.core.schema import SchemaMeta, Schema
        from utilmeta.conf import config

        querydict: Dict[str, MetaQuerySet] = {}
        schemas: Dict[str, Callable] = {}
        singles = []

        def decorator(f):
            parser = config.preference.function_parser_cls(f)
            for k in parser.arg_names:
                assert k in parser.defaults, f"@api.query param: {k} must have a QuerySet as default"
                assert k in parser.annotates, f"@api.query param: {k} must have a Schema as annotate"
                d = parser.defaults[k]
                if isinstance(d, QuerySet):
                    querydict[k] = MetaQuerySet(query=d.query, model=d.model)
                elif isinstance(d, ModelBase):
                    querydict[k] = MetaQuerySet(model=d)
                elif isinstance(d, Model):
                    querydict[k] = MetaQuerySet(model=d.__class__).filter(pk=d.pk)
                else:
                    raise ValueError(f"Invalid @api.query value {d}, should be a queryset or a model instance")
                a = parser.annotates[k]
                if inspect.isclass(a) and issubclass(a, Schema):
                    schema = a
                    singles.append(k)
                else:
                    schema: Type[Schema] = SchemaMeta.__retrieve__(a, schema=True)
                assert isinstance(schema, SchemaMeta), \
                    f"@api.query param: {k} must have a Schema or List[Schema] as annotate"
                schemas[k] = SchemaGenerator(schema=schema, model=d.model).query(with_rules=filter_with_rules)

            @wraps(f)
            def wrapper(*_, **__):
                params = {}
                for key in parser.arg_names:
                    result = schemas[key](querydict[key])
                    if k in singles:
                        result = get_single_value(result)
                    params[key] = result
                res = f(**params)
                if parser.return_type:
                    res = parser.parse(res, parser.return_type)
                return res
            return wrapper
        if _f:
            return decorator(_f)
        return decorator

    @classmethod
    def before(cls, *units, excludes: list = None):
        if '*' in units:
            assert len(units) == 1, f'@api.before("*") means hook all units, remove the redundant units'
        elif excludes:
            raise ValueError('@api.before excludes only affect when @api.before("*") is applied')

        def wrapper(f: T) -> T:
            return set_hook(set_excludes(f, excludes), UnitAttr.before_hook, units)
        return wrapper

    @classmethod
    def after(cls, *units, excludes: list = None):
        if '*' in units:
            assert len(units) == 1, f'@api.after("*") means hook all units, remove the redundant units'
        elif excludes:
            raise ValueError('@api.after excludes only affect when @api.after("*") is applied')

        def wrapper(f: T) -> T:
            return set_hook(set_excludes(f, excludes), UnitAttr.after_hook, units)
        return wrapper

    @classmethod
    def handle(cls, *unit_and_errors, excludes: list = None):
        errors = []
        units = []
        for e in unit_and_errors:
            if inspect.isclass(e) and issubclass(e, BaseException):
                errors.append(e)
            else:
                units.append(e)

        if '*' in units:
            assert len(units) == 1, f'@api.accept("*") means hook all units, remove the redundant units'
        if not errors:
            errors = (Exception,)

        def wrapper(f: T) -> T:
            assert len(inspect.signature(f).parameters) <= 2, \
                f'@api.handle function: {f.__name__} signature should look like ' \
                f'<def f(self, e: Error)>, got redundant args'
            setattr(f, UnitAttr.errors, errors)
            return set_hook(
                set_excludes(f, excludes),
                UnitAttr.error_hook,
                units
            )
        return wrapper

    @classmethod
    def accept(cls, *units, excludes: list = None):
        if '*' in units:
            assert len(units) == 1, f'@api.accept("*") means hook all units, remove the redundant units'
        elif excludes:
            raise ValueError('@api.accept excludes only affect when @api.after("*") is applied')

        def wrapper(f: T) -> T:
            return set_hook(set_excludes(f, excludes), UnitAttr.accept_hook, units)

        return wrapper

    class Wrapper:
        def __init__(self, method: str = None):
            self.method = method.lower() if isinstance(method, str) else None

        def decorator(self, func: Callable, **kwargs):
            if isinstance(func, (staticmethod, classmethod)):
                raise TypeError(f'@api can only decorate instance method, got {func}')
            name = func.__name__.lower()
            if name in METHODS:
                if self.method:
                    assert self.method == name, f'HTTP Method: {self.method} ' \
                                                f'must not decorate another Http Method named function: {name}'
                self.method = name

            if kwargs.get(UnitAttr.alias) == func.__name__:
                raise ValueError(f'Unit alias is same as function name: {func.__name__},'
                                 f' remove redundant params of decorators')

            kwargs.update(method=self.method)
            for k, v in kwargs.items():
                setattr(func, k, v)

            return func

        def __call__(self, f=None, *,
                     regex: bool = None,
                     path: str = None,
                     path_unit: str = None,
                     alias: str = None,
                     log: bool = None,
                     block: bool = None,
                     timeout: Union[int, float, timedelta] = None,
                     transaction: bool = None,
                     cache=None, request=None,
                     response=None,
                     option=None, auth=None,
                     depreciated: bool = None,
                     idempotent: bool = None,
                     public: bool = None,
                     max_retries: int = None,
                     parser_cls: str = None,
                     **kwargs,
                     ):

            if callable(f):   # no parameter @api.get will wrap a callable as this param
                if getattr(f, UnitAttr.method, None):
                    # already decorated
                    if not alias:
                        alias = getattr(f, UnitAttr.alias, f.__name__)
                else:
                    return self.decorator(f)
            if isinstance(f, str):
                alias = f
            del f
            for key, val in locals().items():
                if key == 'self':
                    continue
                if val is None:
                    continue
                else:
                    kwargs[key] = val
            return partial(self.decorator, **kwargs)

    get = Wrapper(HTTPMethod.GET)
    put = Wrapper(HTTPMethod.PUT)
    post = Wrapper(HTTPMethod.POST)
    patch = Wrapper(HTTPMethod.PATCH)
    delete = Wrapper(HTTPMethod.DELETE)
    # below is SDK-only method
    head = Wrapper(HTTPMethod.HEAD)
    options = Wrapper(HTTPMethod.OPTIONS)
    trace = Wrapper(HTTPMethod.TRACE)

    def __call__(self, f=None, *,
                 regex: bool = None,
                 path: str = None,
                 path_unit: str = None,
                 alias: str = None,
                 log: bool = None,
                 block: bool = None,
                 timeout: Union[int, float, timedelta] = None,
                 transaction: bool = None,
                 cache=None, request=None,
                 response=None,
                 option=None, auth=None,
                 idempotent: bool = None,
                 depreciated: bool = None,
                 public: bool = None,
                 max_retries: int = None,
                 parser_cls: str = None,
                 **kwargs):
        kwargs.update(**locals())
        pop(kwargs, 'self', pop(kwargs, Attr.CLS, pop(kwargs, 'kwargs')))
        return self.Wrapper()(**kwargs)

    @classmethod
    def search(cls, proxy, key: str, use_template: bool = True, request=None):
        from utilmeta.core.unit import Unit
        from utilmeta.util.rule import Rule
        from utilmeta.util.search import Search
        from utilmeta.core.schema import SchemaMeta

        if isinstance(proxy, SchemaMeta):
            proxy = dict(proxy.__data__)

        rules = {}
        default = {}
        for k, search in proxy.items():
            assert isinstance(search, Search), \
                ValueError(f'@api.search proxy must be a dict with Search type value, got {search}')
            rules[k] = Rule(require=False)
            default[k] = []

        _temp = {key: str}
        if use_template:
            _temp.update({Param.template: Rule(require=False, template=rules)})

        def search_func(self, *_, **__) -> default:
            keys = tuple(proxy.keys())
            val = self.request.query.get(key)
            if not val:
                return default
            temp = self.request.query.get(Param.template)
            if temp:
                keys = tuple(temp.keys())
            result = {}
            for _k, s in proxy.items():
                s: Search
                if _k in keys:
                    result[_k] = s(val)
            return result
        unit = Unit(f=search_func, method=CommonMethod.GET, request=request)
        unit.parser.query = dict(_temp)
        return unit


class TaskDecorator:
    def __call__(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            finally:
                close_connections()
        return wrapper

    @classmethod
    def transaction(cls, alias):
        from django.db import transaction
        if callable(alias):
            return transaction.atomic(alias)

        def deco(f):
            @wraps(f)
            def wrapper(*args, **kwargs):
                with transaction.atomic(alias):
                    return f(*args, **kwargs)
            return wrapper
        return deco

    @classmethod
    def handle(cls, f, *errors: List[Type[Exception]]):
        if inspect.isclass(f) and issubclass(f, Exception):
            errors = (f, *errors)

            @wraps(f)
            def deco(func):
                setattr(func, UnitAttr.error_hook, errors)
                return func
            return deco
        setattr(f, UnitAttr.error_hook, errors)
        return ignore_errors(f, default=None)

    @classmethod
    def omit(cls, f, result=None):
        from utilmeta.conf import config
        job_cls = config.task.get_job_cls()

        @wraps(f)
        def wrapper(*args, **kwargs):
            job_cls(f, args=args, kwargs=kwargs).execute(block=False)
            if callable(result):
                return result(*args, **kwargs)
            return result
        return wrapper

    @classmethod
    def timeout(cls, f):
        setattr(f, UnitAttr.timeout, True)
        return f

    @classmethod
    def before(cls, f):
        setattr(f, UnitAttr.before_hook, True)
        return f

    @classmethod
    def after(cls, f):
        setattr(f, UnitAttr.after_hook, True)
        return f

    @classmethod
    def pre_condition(cls, f):
        setattr(f, UnitAttr.pre, True)
        return ignore_errors(f, default=True)

    @classmethod
    def end_condition(cls, f):
        setattr(f, UnitAttr.end, True)
        return ignore_errors(f, default=True)

    @classmethod
    def aggregate(cls, f):
        setattr(f, UnitAttr.aggregate, True)
        return f


api = APIDecorator()
# mod = ModuleDecorator()
# call = CallDecorator()
task = TaskDecorator()
