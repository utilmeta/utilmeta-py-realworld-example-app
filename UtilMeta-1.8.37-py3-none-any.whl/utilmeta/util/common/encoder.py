import json
import datetime
from django.utils.duration import duration_iso_string
import decimal
import uuid
import math

from .constant import COMMON_TYPES
from .functional import represent, type_note


Json = None
try:
    from psycopg2._json import Json
except (ImportError, ModuleNotFoundError):
    pass


# for encode json response, use user configured format
class MetaJSONEncoder(json.JSONEncoder):
    def __init__(self, *, skipkeys=None, ensure_ascii=None,
                 check_circular=None, allow_nan=None, sort_keys=None,
                 indent=None, separators=None, default=None):
        from utilmeta.conf import config
        if skipkeys is None:
            skipkeys = config.preference.json_encoder_skip_keys
        if ensure_ascii is None:
            ensure_ascii = config.preference.json_encoder_ensure_ascii
        if allow_nan is None:
            allow_nan = config.preference.json_encoder_allow_nan
        if sort_keys is None:
            sort_keys = config.preference.json_encoder_sort_keys
        kwargs = {}
        # for key, val in locals().items():
        for key in ('skipkeys', 'ensure_ascii', 'check_circular', 'allow_nan',
                    'sort_keys', 'indent', 'separators', 'default'):
            val = locals().get(key)
            if val is None:
                continue
            kwargs[key] = val
        super().__init__(**kwargs)

    def default(self, o):
        from utilmeta.conf import config
        from utilmeta.util.base import Util
        datetime_format = config.time.datetime_format
        date_format = config.time.date_format
        time_format = config.time.time_format
        # See "Date Time String Format" in the ECMA-262 specification.
        # if isinstance(o, float):
        #     if math.isnan(o):
        #         return config.preference.nan_json_value or 'null'
        #     if math.isinf(o):
        #         neg = str(o).startswith('-')
        #         if config.preference.inf_json_value:
        #             return ('-' if neg else '') + config.preference.inf_json_value
        #         return 'null'
        #     return o
        if isinstance(o, datetime.datetime):
            return o.strftime(datetime_format)
        elif isinstance(o, datetime.date):
            if date_format:
                return o.strftime(date_format)
            return o.isoformat()
        elif isinstance(o, datetime.time):
            if time_format:
                return o.strftime(time_format)
            r = o.isoformat()
            if o.microsecond:
                r = r[:12]
            return r
        elif isinstance(o, datetime.timedelta):
            return duration_iso_string(o)
        elif isinstance(o, uuid.UUID):
            return str(o)
        elif isinstance(o, decimal.Decimal):
            return float(o) if o.is_normal() else str(o)
        elif isinstance(o, (tuple, set)):
            return list(o)
        elif Json and isinstance(o, Json):
            return o.adapted
        elif isinstance(o, Util):
            from utilmeta.util.rule import Rule
            if isinstance(o, Rule):
                return o.dict
            return str(o)
        elif o in COMMON_TYPES:
            return type_note(o)
        else:
            from django.db.models import QuerySet
            if isinstance(o, QuerySet):
                return list(o)
            if type(o) not in COMMON_TYPES:
                return represent(o)
        return super().default(o)


# for inner con
class CommonJSONEncoder(MetaJSONEncoder):
    def default(self, o):
        if isinstance(o, datetime.datetime):
            return o.isoformat()
        elif isinstance(o, datetime.date):
            return o.isoformat()
        elif isinstance(o, datetime.time):
            r = o.isoformat()
            if o.microsecond:
                r = r[:12]
            return r
        return super().default(o)


class JSONSerializer:
    """
    Simple wrapper around json to be used in signing.dumps and
    signing.loads.
    """
    def dumps(self, obj):
        return json.dumps(obj, separators=(',', ':'), cls=MetaJSONEncoder).encode('utf-8')

    def loads(self, data):
        return json.loads(data.decode('utf-8'))
