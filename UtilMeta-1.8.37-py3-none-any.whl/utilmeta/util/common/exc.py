from http.client import HTTPResponse
from typing import List, Union
from django.core.exceptions import *
from django.db.utils import DataError, DatabaseError, NotSupportedError, \
    IntegrityError, InterfaceError, InternalError, OperationalError, ProgrammingError


class HttpError(Exception):
    status: int
    append_headers: dict = None
    STATUS_EXCEPTIONS = {}

    def __str__(self):
        msg = str(self.message or '')
        head = self.__class__.__name__
        if msg.startswith(head):
            return msg
        return f'{head}: {self.message}'

    def __init__(self, message: str = None, *, state: Union[str, int] = None):
        self.message = str(message)
        self.state = state

    def __init_subclass__(cls, **kwargs):
        try:
            HttpError.STATUS_EXCEPTIONS[cls.status] = cls
        except AttributeError:
            pass


class RequestError(HttpError):
    pass


class BadRequest(RequestError):
    status = 400


class Unauthorized(RequestError):
    status = 401

    def __init__(self, message: str = None, *, state: Union[str, int] = None,
                 auth_scheme: str = None, auth_params: dict = None):
        self.message = str(message)
        self.state = state
        from utilmeta.conf import config
        if config.auth:
            auth_scheme = auth_scheme or config.auth.auth_scheme_name
        if not auth_scheme:
            return
        value = auth_scheme.capitalize()
        if isinstance(auth_params, dict):
            value += ' ' + ','.join([f'{k}={v}' for k, v in auth_params.items()])
        from .constant import Header
        self.append_headers = {Header.WWW_AUTH: value}


class PermissionDenied(RequestError):
    status = 403


class NotFound(RequestError):
    status = 404

    def __init__(self, message: str = None, *, path: str = None, query: dict = None):
        from urllib.parse import urlencode
        msg = [message] if message else []
        if path:
            msg.append(f'path: <{path}> not found')
        if query:
            msg.append('query: <%s> not found' % urlencode(query))
        if not msg:
            msg = ['not found']
        super().__init__(';'.join(msg))


class MethodNotAllowed(RequestError):
    status = 405

    def __init__(self, message: str = None, method: str = None, allows: List[str] = None):
        from .constant import Header
        self.message = message or f'Method: {method} is not allowed (use methods in {allows})'
        self.forbid = method
        self.allows = ', '.join([str(a) for a in allows]) if allows else ''
        self.append_headers = {Header.ALLOW: self.allows}
        super().__init__(self.message)


class NotAcceptable(RequestError):
    status = 406


class RequestTimeout(RequestError):
    status = 408


class Conflict(RequestError):
    status = 409


class Gone(RequestError):
    status = 410


class PreconditionFailed(RequestError):
    status = 412


class PreconditionRequired(RequestError):
    status = 428


class RequestEntityTooLarge(RequestError):
    status = 413


class RequestURITooLong(RequestError):
    status = 414


class UnsupportedMediaType(RequestError):
    status = 415


class UnprocessableEntity(RequestError):
    status = 422


class Locked(RequestError):
    status = 423


class TooEarly(RequestError):
    status = 425


class UpgradeRequired(RequestError):
    status = 426

    def __init__(self, message: str = None, scheme: str = None):
        from .constant import Header, Scheme
        self.message = message
        self.scheme = scheme
        if scheme == Scheme.WS:
            scheme = 'websocket'
        elif isinstance(scheme, str):
            scheme = scheme.upper()
        else:
            scheme = Scheme.HTTPS.upper()
        self.append_headers = {
            Header.UPGRADE: scheme,
            Header.CONNECTION: Header.UPGRADE
        }
        super().__init__(message)


class TooManyRequests(RequestError):
    status = 429


class ServerError(HttpError):
    status = 500

    def __init__(self, message=None, response=None):
        self.message = message
        self.response = response


class BadResponse(ServerError):
    status = 500

    # def __init__(self, error: str = None, response: HTTPResponse = None):
    #     self.response = response
    #     self.error = error


def http_error(status: int = 400, message: str = None):
    if status < 400 or status > 600:
        raise ValueError(f'Invalid HTTP error status: {status} must in 400~600')
    error = HttpError.STATUS_EXCEPTIONS.get(status)
    if not error:
        class error(HttpError):
            pass
        error.status = status
    return error(message=message)


class NoAvailableInstances(Exception):
    pass


class InvalidCommand(Exception):
    pass


class CombinedError(Exception):
    """
    This is an special error, when using max_retries policy in request/service/task process
    there can be more than 1 exception raised during process
    this error class will record all these exceptions and provide an unify interface for error handling
    Error util will recognize this class and derive it's children errors (along with there traceback)
    so developer can do a much better logging and self-defined handling in error hooks
    """
    def __init__(self, *errors: Exception):
        self.errors = []
        messages = []
        for err in errors:
            if not isinstance(err, Exception):
                continue
            if isinstance(err, CombinedError):
                self.errors.extend(err.errors)
                continue
            if str(err) not in messages:
                messages.append(str(err))
                self.errors.append(err)
        self.message = ';'.join(messages)

    def __str__(self):
        return self.message
