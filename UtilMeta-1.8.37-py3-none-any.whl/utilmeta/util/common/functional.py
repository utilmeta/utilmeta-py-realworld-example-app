import decimal
import inspect
import typing
import string
import importlib
import json
import re
import os
import sys
import math
import hashlib
from typing import TypeVar, List, Dict, Tuple, Callable, Union, Any, Set, Type, Optional
from django.core.exceptions import FieldDoesNotExist
from django.db.models import Field
from django.db.models import QuerySet
from django.db.models.fields.reverse_related import ForeignObjectRel
from django.http.request import HttpHeaders
from django.http.response import HttpResponseBase
from .datastructure import ImmutableDict, ImmutableList
from .constant import Header, TYPES_NOTE, Reg, COMMON_ERRORS, NOTE_MAP, \
    SEG, Attr, LOCAL, Scheme, SCHEME, FALSE_VALUES, HTTP, HTTPS, LOCAL_IP, \
    SCHEMES, COMMON_TYPES, UTF_8, LINUX, BSD, WIN, BUF, PK, PY, INF, ID, \
    DATETIME_FORMATS, ELEMENTS, IPType, ATOM_TYPES, ADDON_FIELD_LOOKUPS, FilterNote, AgentDevice
from urllib.parse import urlparse, ParseResult
from django.db.models.fields.related import ManyToManyField, ManyToManyRel, ManyToOneRel,\
    ForeignKey, OneToOneField, OneToOneRel
from datetime import datetime, date, time, timedelta, timezone
from django.utils.functional import cached_property
from xml.etree.ElementTree import Element
from collections import OrderedDict
from functools import wraps
from ipaddress import ip_address, ip_network
from http.client import HTTPResponse
import shutil
import pickle
import copy
import socket
import binascii
import pytz

__all__ = [
    'repeat', 'return_type', 'multi', 'param_type', 'duplicate', 'allow_cors', 'file_like', 'cached_property',
    'pop', 'pop_key', 'retrieve', 'get_calls', 'distinct', 'http_header', 'add_field_id', 'print_time',
    'get_field', 'gen_key', 'order_dict', 'parse_list', 'type_transform', 'merge_attrs', 'keys_or_args',
    'import_util', 'order_list', 'setval', 'get_fields', 'dump_request', 'dict_list', 'get_mark',
    'type_note', 'del_field_id', 'get_field_name', 'parse_query_dict', 'immutable', 'regular', 'sub_regs',
    'stream_content', 'gen_file_name', 'full_match_reg', 'gen_meta', 'form_content', 'readable', 'closest_hour',
    'load_form_data', 'make_header', 'print_dict', 'readable_size', 'file_path', 'merge_query',
    'make_percent', 'merge_multiple', 'dir_getsize', 'file_num', 'model_tag', 'struct_dict', 'restrict_keys',
    'map_list', 'map_dict', 'struct_retrieve', 'retrieve_path', 'get_ip', 'get_domain', 'parse_user_agents',
    'get_single_value', 'unique_field', 'copy_value', 'iterable', 'is_number', 'class_func',
    'path_merge', 'dump_kwargs', 'value_str', 'get_origin', 'get_exp_field', 'get_value', 'get_python_type',
    'is_pk', 'get_pk', 'one_to', 'many_to', 'to_one', 'to_many', 'analyze_func', 'temp_diff', 'temp_patch',
    'normalize', 'load_ini', 'search_file', 'get_arg', 'clear', 'kill', 'write_config', 'path_join',
    'running', 'url_join', 'key_normalize', 'represent', 'clean_line', 'valid_attr', 'camel_case',
    'distinct_add', 'localhost', 'etag', 'clean_pks', 'merge_list', 'get_backward', 'merge_fields',
    'dumps', 'loads', 'sys_deployable', 'port_using', 'check_requirement', 'run', 'get_used_memory',
    'dict_diff', 'class_dict', 'get_redis_info', 'get_real_file', 'read_from_socket', 'dict_number_add',
    'sys_user_exists', 'sys_user_add', 'find_port', 'parse_socket', 'process_url', 'get_processes',
    'make_dict_by', 'get_root_base', 'get_code', 'function_pass', 'function_not_implemented', 'assign_return_type',
    'dict_overflow', 'get_number', 'is_sub_dict', 'get_content_tag', 'get_closest_to', 'handle_json_float',
    'parse_raw_url', 'extract_date', 'convert_data_frame', 'pretty_name', 'json_dumps', 'current_master',
    'get_system_fds', 'get_limit_fds', 'get_hostname', 'get_request_ip', 'include_many_relates',
    'based_number', 'get_based_number', 'local_time_offset', 'get_server_ip', 'request_length', 'response_length',
    'common_representable', 'get_real_ip', 'list_or_args', 'get_reverse_lookup', 'encode_multipart_form',
    'valid_url', 'encode_query', 'bi_search', 'get_interval', 'close_connections', 'write_to', 'get_doc',
    'replace_null', 'make_hash', 'avg', 'remove_file', 'time_now', 'time_local', 'convert_time', 'get_netloc',
    'utc_ms_ts', 'is_origin', 'get_field_addon', 'get_relate_model', 'add_filter_base', 'field_in_query',
    'get_max_socket_conn', 'get_max_open_files', 'get_many_field_names', 'get_sql_type', 'get_sql_tables',
    'ip_belong_networks', 'pop_null', 'guess_mime_type', 'print_queries', 'get_system_open_files'
]

linux = sys.platform.startswith(LINUX)
bsd = BSD in sys.platform
win = sys.platform.startswith(WIN)
sys_deployable = linux or bsd
T = TypeVar('T')
utc = pytz.utc


def utc_ms_ts() -> int:
    return int(datetime.now().timestamp() * 1000)


def time_now(relative: datetime = None) -> datetime:
    from utilmeta.conf import config
    local_now = time_local()
    tz_now = datetime.utcnow().replace(tzinfo=utc)
    if relative:
        if relative.tzinfo:
            return tz_now
        return local_now
    if config.time.use_tz:
        return tz_now
    return local_now


def time_local(dt: datetime = None) -> datetime:
    dt = dt or datetime.now()
    # if not dt.tzinfo:
    #     return dt
    from utilmeta.conf import config
    return dt.astimezone(config.time.timezone).replace(tzinfo=None)


def convert_time(dt: datetime) -> datetime:
    from utilmeta.conf import config
    if config.time.use_tz:
        if not dt.tzinfo:
            return dt.astimezone(tz=utc)
        return dt
    if dt.tzinfo:
        return time_local(dt)
    return dt


def avg(values: Union[list, set, tuple], default=0):
    if not values:
        return default
    return sum(values) / len(values)


def like_false(val: str):
    if isinstance(val, str):
        return val.lower() in FALSE_VALUES
    return not val


def iterable(value):
    return hasattr(value, Attr.ITER)


def repeat(lst):
    return len(lst) != len(set(lst))


def dict_list(length):
    values = []
    while length:
        values.append({})
        length = length - 1
    return values


def remove_file(file: str, ignore_not_found: bool = True):
    try:
        os.remove(file)
    except FileNotFoundError as e:
        if ignore_not_found:
            return
        raise e
    except PermissionError as e:
        if not sys_deployable:
            raise e
        os.system(f'sudo rm {file}')


def write_to(file: str, content: str, mode: str = 'w'):
    try:
        with open(file, mode) as f:
            f.write(content)
    except (PermissionError, FileNotFoundError) as e:
        if not sys_deployable:
            raise e
        note = '-a' if mode == 'a' else ''
        # use single quote here to apply $ escape
        os.system(f"echo \'{content}\' | sudo tee {note} {file} >> /dev/null")    # ignore file content output


def guess_mime_type(path: str, strict: bool = False):
    if not path:
        return None, None
    dots = path.split('.')
    if dots:
        suffix = dots[-1]
        type_map = {
            'js': 'text/javascript',
            'woff2': 'font/woff2',
            'ts': 'text/typescript',
        }
        if suffix in type_map:
            return type_map[suffix], None
    import mimetypes
    return mimetypes.guess_type(path, strict=strict)


def bi_search(targets: list, val, key=lambda x: x, sort: bool = False, start: int = 0, end: int = None):
    """
    as small as possible
    """
    if not targets:
        return -1
    if sort:
        targets = sorted(targets, key=key)
    if end is None:
        end = len(targets) - 1
    if end < start:
        return -1
    v = key(val)
    if key(targets[start]) > v:
        return start - 1
    elif key(targets[end]) < v:
        return end + 1
    mid = int(start + (end - start) / 2)
    m = key(targets[mid])
    if m < v:
        if key(targets[mid + 1]) >= v:
            return mid + 1
        return bi_search(targets, val=val, key=key, start=mid + 1, end=end)
    elif m == v:
        return mid
    return bi_search(targets, val=val, key=key, start=start, end=mid - 1)


def get_interval(interval: Union[int, float, decimal.Decimal, timedelta], null: bool = False,
                 ge: Optional[Union[int, float, decimal.Decimal, timedelta]] = 0, silent: bool = False,
                 le: Optional[Union[int, float, decimal.Decimal, timedelta]] = None) -> Optional[float]:
    if interval is None:
        if null:
            return interval
        raise TypeError(f'interval is not null')
    if isinstance(interval, (int, float, decimal.Decimal)):
        interval = float(interval)
    elif isinstance(interval, timedelta):
        interval = interval.total_seconds()
    else:
        if silent:
            return 0
        raise TypeError(f'Invalid interval: {interval}, must be int, float or timedelta object')
    if ge is not None:
        if not isinstance(ge, (int, float)):
            ge = get_interval(ge)
        if interval < ge:
            if silent:
                return ge
            raise ValueError(f'Invalid interval: {interval}, must greater than {ge}')
    if le is not None:
        if not isinstance(le, (int, float)):
            le = get_interval(le)
        if interval > le:
            if silent:
                return le
            raise ValueError(f'Invalid interval: {interval}, must less than {le}')
    return interval


def handle_json_float(data):
    if multi(data):
        return [handle_json_float(d) for d in data]
    elif isinstance(data, dict):
        return {key: handle_json_float(val) for key, val in data.items()}
    elif isinstance(data, float):
        if math.isnan(data):
            return None
        if data == INF:
            return "Infinity"
        if data == -INF:
            return '-Infinity'
    return data


def etag(data) -> str:
    if isinstance(data, str):
        if len(data) == 40 and data.isalnum():
            # data itself is etag like, guess it is another etag
            return data
    if isinstance(data, (dict, list)):
        data = json_dumps(data)
    elif not isinstance(data, str):
        data = str(data)
    return hashlib.sha1(data.encode(UTF_8)).hexdigest()


def duplicate(lst):
    _set = set(lst)
    _list = list(lst)
    for item in _set:
        _list.remove(item)
    return set(_list)


def represent(val) -> str:
    if isinstance(val, type):
        if val is type(None):
            return 'type(None)'
        return val.__name__
    if inspect.isfunction(val) or inspect.ismethod(val) or inspect.isclass(val) or inspect.isbuiltin(val):
        return val.__name__
    return repr(val)


def common_representable(data) -> bool:
    if multi(data):
        for val in data:
            if not common_representable(val):
                return False
        return True
    elif isinstance(data, dict):
        for key, val in data.items():
            if not common_representable(key) or not common_representable(val):
                return False
        return True
    elif type(data) in COMMON_TYPES:
        return True
    return False


def localhost(host: str) -> bool:
    local_list = ['http://127.0.0.1', 'http://localhost', '127.0.0.1', 'localhost',
                  'https://127.0.0.1', 'https://localhost']
    for local in local_list:
        if host.startswith(local):
            return True
    return False


def regular(s: str) -> str:
    rs = ''
    for char in s:
        if char in Reg.META:
            rs += f'\\{char}'
        else:
            rs += char
    return rs


def local_time_offset(t=None):
    """Return offset of local zone from GMT, either at present or at time t."""
    import time
    if t is None:
        t = time.time()
    if time.localtime(t).tm_isdst and time.daylight:
        return -time.altzone
    else:
        return -time.timezone


def value_str(s, max_compare: int = 4) -> int:
    val = 0
    for i, c in enumerate(str(s)):
        if i > max_compare:
            break
        n = ord(c)
        val += n / (128 ** i)
    return val


def model_tag(model, lower: bool = False) -> str:
    if not model:
        return ''
    meta = getattr(model, '_meta', None)
    if not meta:
        return ''
    app_label = meta.app_label
    tag = '.'.join((app_label, model.__name__))
    return tag.lower() if lower else tag


def make_percent(val, tot, fix=1, _100=True):
    val = float(val)
    tot = float(tot)
    _min = tot
    if _100:
        val *= 100
        _min *= 100
    if tot <= 0:
        return round(float(0), fix)
    return round(min(val, _min) / tot, fix)


def get_value(data: dict, keys: List[str], default=..., allow_conflict: bool = None):
    if not keys or not data:
        return default
    if allow_conflict is False:
        exists = False
        res = default
        for key in keys:
            if key in data:
                res = data[key]
                if exists:
                    raise ValueError(f'Duplicate data key: {keys[0]}')
                exists = True
        return res
    for key in keys:
        if key in data:
            return data[key]
    return default


def analyze_func(f, from_class=None):
    first_reserve = False
    if isinstance(f, classmethod):
        first_reserve = True
        f = f.__func__
    elif isinstance(f, staticmethod):
        f = f.__func__
    if inspect.ismethod(f) or inspect.isfunction(f):
        if from_class is ...:
            # force to count start at 1 for the reason that we know it's a instance function
            # but class is not clear from context
            first_reserve = True
        elif from_class:
            attr = from_class.__dict__.get(f.__name__)
            if isinstance(f, classmethod):
                first_reserve = True
                attr = attr.__func__
            elif isinstance(f, staticmethod):
                attr = attr.__func__
            else:
                # instance method
                first_reserve = True
            if attr is not f:
                first_reserve = False
    else:
        raise TypeError(f'Invalid function: {f}')
    return f, first_reserve


def class_func(f):
    return isinstance(f, (staticmethod, classmethod)) or inspect.ismethod(f) or inspect.isfunction(f)


def multi(f):
    return isinstance(f, (list, set, tuple, type({}.values()), type({}.keys())))


def pop(data, key, default=None):
    if isinstance(data, dict):
        return data.pop(key) if key in data else default
    elif isinstance(data, list):
        return data.pop(key) if key < len(data) else default
    return default


def make_dict_by(values: List[dict], key: str, formatter: Callable = lambda x: x) -> Dict[Any, List[dict]]:
    """
    make a dict that keys is the key value of every items in values
    make_dict_by([{'k': 1, 'v': 2}, {'k': 1, 'v': 3}, {'k': 2, 'v': 2}], key='k')
    {
        '1': [{'k': 1, 'v': 2}, {'k': 1, 'v': 3}],
        '2': [{'k': 2, 'v': 2}]
    }
    """
    if not key:
        return {}
    result: Dict[Any, List[dict]] = {}
    for val in values:
        if key not in val:
            continue
        kv = val[key]
        if kv is None:
            continue
        v = formatter(val)
        if multi(kv):
            for _k in kv:
                _k = str(_k)
                if _k in result:
                    if v not in result[_k]:
                        result[_k].append(v)
                else:
                    result[_k] = [v]
        else:
            kv = str(kv)
            if kv in result:
                if v not in result[kv]:
                    result[kv].append(v)
            else:
                result[kv] = [v]
    return result


def setval(dic, key, v, k=None, array=False):
    if array:
        if key in dic:
            dic[key].append(v)
        else:
            dic[key] = [v]
    else:
        assert k
        if key in dic:
            dic[key][k] = v
        else:
            dic[key] = {k: v}


def get_number(num_str: str, strict: bool = False) -> Union[int, float]:
    import decimal
    if isinstance(num_str, (int, float, decimal.Decimal)):
        return num_str
    if isinstance(num_str, bytes):
        num_str = num_str.decode()
    if not isinstance(num_str, str):
        if strict:
            raise TypeError(f'Invalid number type')
        return 0
    if not is_number(num_str):
        if strict:
            raise ValueError(f'Invalid number value')
        return 0
    if num_str.startswith('-'):
        return - get_number(num_str[1:], strict=strict)
    if num_str.isdigit():
        return int(num_str)
    return float(num_str)


def print_dict(data):
    if isinstance(data, list):
        print('[')
        for d in data:
            print_dict(d)
            print(',')
        print(']\n')
        return
    items = getattr(data, 'items', None)
    if callable(items):
        print('{')
        for key, val in items():
            print(f'\t{repr(key)}: {repr(val)},')
        print('}')
        return
    print(data)


def immutable(val):
    if isinstance(val, dict):
        data = {}
        for k, v in val.items():
            data[k] = immutable(v)
        return ImmutableDict(data)
    elif isinstance(val, list):
        data = []
        for v in val:
            data.append(immutable(v))
        return ImmutableList(data)
    return val


def clean_pks(pk_fields: Set[str], values: List[dict]):
    if pk_fields != {PK}:
        for val in values:
            if PK not in val:
                continue
            pk = val[PK] if PK in pk_fields else val.pop(PK)
            for f in pk_fields.difference({PK}):
                val[f] = pk
    return values


def file_like(obj) -> bool:
    try:
        return callable(getattr(obj, 'read')) and callable(getattr(obj, 'seek')) \
               and callable(getattr(obj, 'write')) and callable(getattr(obj, 'close'))
    except AttributeError:
        return False


def file_num(path) -> int:
    num = 0
    for root, dirs, files in os.walk(path):
        num += len(files)
    return num


def dir_getsize(path):
    size = 0
    for root, dirs, files in os.walk(path):
        size += sum([os.path.getsize(os.path.join(root, name)) for name in files])
    return size


def type_note(t: type) -> str:
    return TYPES_NOTE.get(t, TYPES_NOTE[str])


def get_python_type(note: str) -> type:
    for tp, nt in TYPES_NOTE.items():
        if nt == note:
            return tp
    return str


def is_sub_dict(base: dict, sub: dict):
    for key, val in sub.items():
        if key not in base:
            return False
        if val != base[key]:
            return False
    return True


def param_type(f):
    t = typing.get_type_hints(f)
    pop(t, 'return')
    return t


def assign_return_type(f, t):
    if not callable(f):
        return
    f.__annotations__['return'] = t


def return_type(f, raw: bool = False):
    if isinstance(f, (staticmethod, classmethod)):
        f = f.__func__
    if not f:
        return None
    _t = getattr(f, Attr.ANNOTATES).get('return')
    if raw:
        return _t
    try:
        t = typing.get_type_hints(f).get('return')
    except NameError:
        return _t
    if t is type(None):
        return None
    return t


def get_content_tag(body):
    if not body:
        return ''
    tag = body
    if isinstance(body, (dict, list)):
        tag = json_dumps(body).encode(UTF_8)
    elif not isinstance(body, bytes):
        tag = str(body).encode(UTF_8)
    return hashlib.sha256(tag).hexdigest()


def get_closest_to(base, target, field, raise_err: bool = True):
    field = get_field_name(field)
    gt_q = {f'{field}__gt': target}
    lt_q = {f'{field}__lt': target}
    closest_greater_qs = base.filter(**gt_q).order_by(field)
    closest_less_qs = base.filter(**lt_q).order_by(f'-{field}')

    try:
        try:
            closest_greater = closest_greater_qs[0]
        except IndexError:
            return closest_less_qs[0]

        try:
            closest_less = closest_less_qs[0]
        except IndexError:
            return closest_greater_qs[0]
    except IndexError:
        if raise_err:
            raise base.model.DoesNotExist("There is no closest object"
                                          " because there are no objects.")
        return None

    if getattr(closest_greater, field) - target > target - getattr(closest_less, field):
        return closest_less
    else:
        return closest_greater


def stream_content(content_type: str) -> bool:
    content_type = content_type.split(';')[0].strip()
    maj, sec = content_type.split('/')
    if maj in ('video', 'audio', 'image'):
        return True
    if sec == 'octet-stream':
        return True
    return False


def form_content(content_type: str) -> bool:
    content_type = content_type.split(';')[0].strip()
    maj, sec = content_type.split('/')
    if maj == 'multipart':
        return True
    if sec == 'x-www-form-urlencoded':
        return True
    return False


def load_form_data(request):
    m = request.method
    load_call = getattr(request, '_load_post_and_files')
    if m in ('PUT', 'PATCH'):
        if hasattr(request, '_post'):
            delattr(request, '_post')
            delattr(request, '_files')
        try:
            request.method = 'POST'
            load_call()
            request.method = m
        except AttributeError:
            request.META['REQUEST_METHOD'] = 'POST'
            load_call()
            request.META['REQUEST_METHOD'] = m


def gen_file_name(content_type: str) -> str:
    if not content_type:
        content_type = '/'
    maj, sec = content_type.split('/')
    date_str = time_now().strftime('%Y%m%d%H%M%S')
    key = gen_key(6, alnum=True)
    if maj in ('video', 'audio', 'image'):
        name = f'{maj}_{date_str}_{key}.{sec}'
    else:
        name = f'file_{date_str}_{key}'
    return name


def make_hash(value: str, seed: str = '', mod: int = 2 ** 32):
    return int(hashlib.md5((str(value) + str(seed or '')).encode()).hexdigest(), 16) % mod


def file_path(path: str):
    d = path.replace('\\', '/')
    if d.endswith('/'):
        d = d[:-1]
    return d


def get_code(f) -> str:
    code = getattr(f, Attr.CODE, None)
    if not code:
        return ''
    fl = code.co_firstlineno
    file = code.co_filename
    content = open(file, 'r', errors='ignore').read()
    ft = 0
    el = fl
    for i, line in enumerate(content.splitlines()[fl:]):
        tabs = line.count(' ' * 4)
        if not i:
            ft = tabs
            continue
        if tabs <= ft:
            el = fl + i
            break
    return '\n'.join(content.splitlines()[fl:el])


def get_root_base(cls):
    if not inspect.isclass(cls):
        if hasattr(cls, Attr.CLS):
            return getattr(cls.__class__, Attr.NAME, None)
        return None
    if cls.__bases__:
        if len(cls.__bases__) == 1 and cls.__bases__[0] is object:
            return cls.__name__
        return get_root_base(cls.__bases__[0])
    return cls.__name__


def loads(data, exclude_types: Tuple[type, ...] = (), bulk_data: bool = False):
    if data is None:
        return None
    if bulk_data and multi(data):
        return [loads(val, exclude_types=exclude_types) for val in data]
    if data is None:
        return None
    if isinstance(data, dict):
        values = {}
        for key, val in data.items():
            if isinstance(key, bytes):
                key = key.decode()
            values[key] = loads(val, exclude_types=exclude_types, bulk_data=bulk_data)
        return values
    try:
        return pickle.loads(data)
    except (*COMMON_ERRORS, pickle.PickleError):
        pass
    if isinstance(data, bytes):
        data = data.decode()
    if isinstance(data, exclude_types):
        return data
    if is_number(data):
        return get_number(data)
    for t in exclude_types:
        try:
            return type_transform(data, t)
        except TypeError:
            continue
    return data


def dumps(data, exclude_types: Tuple[type, ...] = (), bulk_data: bool = False):
    if data is None:
        return None
    if bulk_data and isinstance(data, dict):
        return {key: dumps(val, exclude_types=exclude_types) for key, val in data.items()}
    if isinstance(data, exclude_types):
        # False / True isinstance of int, so isinstance is not accurate here
        # for incrby / decrby / incrbyfloat work fine at lua script number typed data will not be dump
        return str(data).encode()
    return pickle.dumps(normalize(data))


def normalize(data, _json: bool = False):
    if isinstance(data, ATOM_TYPES):
        return data
    try:
        if _json:
            raise ValueError
        pickle.dumps(data)
        return data
    except (*COMMON_ERRORS, pickle.PickleError):
        return json.loads(json_dumps(data))


def json_dumps(data) -> str:
    from .encoder import CommonJSONEncoder
    if data is None:
        return ''
    return json.dumps(data, cls=CommonJSONEncoder, ensure_ascii=False)


def load_ini(content: str, parse_key: bool = False) -> dict:
    ini = {}
    dic = {}
    for ln in content.splitlines():
        line = ln.replace(' ', '').replace('\t', '')
        if not line or not line.split():
            continue
        annotate = line.split()[0].startswith('#') or line.split()[0].startswith(';')
        if annotate:
            continue
        if re.fullmatch('\[(.*?)\]', line):
            key = line.strip('[]')
            ini[key] = dic = {}
        else:
            key, val = line.split('=')
            if parse_key:
                key = key.replace('_', '-').lower()
            if val.isdigit():
                val = int(val)
            elif like_false(val):
                val = False
            dic[key] = val
    return ini or dic   # load no header conf file as well


def get_real_file(path: str):
    try:
        real_path = os.readlink(path)
        if not os.path.exists(real_path):
            raise FileNotFoundError
    except (OSError, FileNotFoundError):
        real_path = path
    if not os.path.exists(real_path):
        raise FileNotFoundError(f'file: {repr(real_path)} not exists')
    return real_path


def write_config(data: dict, path: str, append: bool = False, ini_syntax: bool = True) -> str:
    content = ''
    if ini_syntax:
        for key, val in data.items():
            content += f'[{key}]\n'
            assert type(val) == dict, TypeError(f"write ini failed, syntax error: {val} should be dict")
            for k, v in val.items():
                content += f'{k} = {v}\n'
            content += '\n'
    else:
        for k, v in data.items():
            content += f'{k} = {repr(v)}\n'
        content += '\n'

    write_to(path, content=content, mode='a' if append else 'w')
    return content


def ip_belong_networks(ip: IPType, networks: List[str]):
    if not networks or not ip:
        return True
    if isinstance(ip, str):
        ip = ip_address(ip)
    for addr in networks:
        try:
            if ip in ip_network(addr):
                return True
        except ValueError:
            continue
    return False


def based_number(num: int, base: int = 10) -> str:
    num, base = int(num), int(base)
    if base <= 1 or base > len(ELEMENTS):
        raise ValueError(f'number base should > 1 and < {len(ELEMENTS)}')
    if base == 10:
        return str(num)
    values = []
    elements = ELEMENTS[0:base]
    n = num
    while n:
        i = n % base
        n = n // base
        values.append(elements[i])
    values.reverse()
    return ''.join(values)


def get_based_number(num: Union[str, int], from_base: int, to_base: int = 10) -> str:
    if from_base <= 36:
        return based_number(int(num, base=from_base), base=to_base)
    if from_base > len(ELEMENTS):
        raise ValueError(f'number base should > 1 and < {len(ELEMENTS)}')
    num = str(num)
    value = 0
    for i, n in enumerate(num):
        value += ELEMENTS.index(n) * from_base ** (len(num) - i - 1)
    return based_number(value, base=to_base)


def url_join(base: str, *routes: str, with_scheme: bool = True,
             prepend_slash: bool = False, append_slash: bool = None):
    route_list = []
    if not routes:
        return base
    if not isinstance(base, str):
        base = str(base) if base else ''
    final_route = base
    for route in routes:
        if not route:
            continue
        url = str(route).strip('/')
        if not url:
            continue
        final_route = str(route)
        url_res = urlparse(url)
        if url_res.scheme:
            return url
        route_list.append(url)
    end_slash = final_route.endswith('/')     # last route
    res = urlparse(base)
    if with_scheme and not res.scheme:
        raise ValueError('base url must specify a valid scheme')
    result = '/'.join([base.strip('/'), *route_list])
    if not res.scheme:
        if prepend_slash:
            if not result.startswith('/'):
                result = '/' + result
        else:
            result = result.lstrip('/')
    if append_slash is not None:
        if append_slash:
            if not result.endswith('/'):
                result = result + '/'
        else:
            result = result.rstrip('/')
    elif end_slash:
        result = result + '/'
    return result


def path_join(base: str, path: str, *, dir: bool = False, create: bool = False, ignore: bool = False):
    if not path:
        return None
    if os.path.isabs(path):
        p = path
    else:
        p = path_merge(base, path)
    if not os.path.exists(p):
        if create:
            if dir:
                os.makedirs(p)
            else:
                write_to(p, content='')
        elif not ignore:
            raise OSError(f"path {p} not exists")
    return p


def search_file(filename, path=os.getcwd()):
    file = os.path.join(path, filename)
    while os.path.dirname(path) != path:
        if os.path.exists(file):
            return file
        path = os.path.dirname(path)
        file = os.path.join(path, filename)
    return None


def get_arg(args: List[str], key: str, *, sole: bool = False, remove: bool = True):
    # if key.startswith('--'):
    #     for arg in args:
    #         if arg.startswith(key + '='):
    #             return arg.lstrip(key + '=')
    #     return None
    if sole:
        if key in args:
            if remove:
                args.remove(key)
            return True
        return False
    try:
        arg = args[args.index(key) + 1]
        if remove:
            args.remove(key)
            args.remove(arg)
        return arg
    except (IndexError, ValueError):
        return None


def clear(filepath):
    files = os.listdir(filepath)
    for fd in files:
        cur_path = os.path.join(filepath, fd)
        if os.path.isdir(cur_path):
            if fd == "__pycache__":
                shutil.rmtree(cur_path)
            else:
                clear(cur_path)


def load_all_from(path):
    if os.path.isdir(path):
        pass


def run(cmd, *backup_commands):
    try:
        r = os.system(cmd)
        if r:
            for c in backup_commands:
                r = os.system(c)
                if not r:
                    return
            print(f'UtilMeta occur error, aborting..')
            exit(r)
    except KeyboardInterrupt:
        print('aborting..')
        exit(0)
    except Exception as e:
        print(f'UtilMeta occur error: {e}, aborting..')
        exit(1)


def current_master():
    import psutil
    return bool(psutil.Process(os.getpid()).children())


def get_processes(name, contains: str = None):
    import psutil
    assert name, name
    ls = []
    for p in psutil.process_iter():
        name_, exe, cmdline = "", "", []
        try:
            name_ = p.name()
            cmdline = p.cmdline()
            exe = p.exe()
        except (psutil.AccessDenied, psutil.ZombieProcess):
            pass
        except psutil.NoSuchProcess:
            continue
        if name == name_ or os.path.basename(exe) == name:
            if contains and not any([contains in cmd for cmd in cmdline]):
                continue
            ls.append(p)
    return ls


def kill(name, contains: str = None):
    import psutil
    killed = 0
    for p in get_processes(name=name, contains=contains):
        try:
            p.kill()
            killed += 1
        except (OSError, psutil.Error):
            continue
    return killed


def port_using(port: int):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        return not bool(s.connect_ex((LOCAL_IP, port)))
    except (OSError, *COMMON_ERRORS):
        return True


def find_port():
    ports = []

    def find(start: int = 8000, end: int = 10000):
        for p in range(start, end):
            if port_using(p) or p in ports:
                continue
            ports.append(p)
            return p
    return find


def get_max_socket_conn():
    if not sys_deployable:
        return None
    r = os.popen('cat /proc/sys/net/core/somaxconn').read().strip('\n')
    if not r:
        return None
    return int(r)


def get_max_open_files():
    if not sys_deployable:
        return None
    r = os.popen('ulimit -n').read().strip('\n')
    if not r:
        return None
    return int(r)


def running(pid):
    import psutil
    try:
        return psutil.Process(pid).is_running()
    except psutil.Error:
        return False


def read_from_socket(value: Union[str, int]) -> bytes:
    sock, file = parse_socket(value, valid_path=True)
    if file:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(sock)
    else:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        host, port = sock.split(':')
        s.connect((host, int(port)))
    data = b''
    while 1:
        d = s.recv(BUF)
        data += d
        if len(d) < BUF:
            break
    s.close()
    return data


def parse_socket(sock: str, valid_path: bool = False):
    file = False
    if callable(sock):
        sock = sock()
    assert sock, f'Invalid socket: {sock}'
    if isinstance(sock, int) or isinstance(sock, str) and sock.isdigit():
        try:
            sock = int(sock)
            assert 1000 < sock < 65536
        except (TypeError, ValueError, AssertionError) as e:
            raise ValueError(f'socket must be a valid .sock file path or a int port '
                             f'in (1000, 65536), got {sock} with error {e}')
        else:
            sock = f'127.0.0.1:{sock}'
    elif valid_path:
        if os.path.exists(sock):
            file = True
    else:
        file = True
    return sock, file


def process_url(url: Union[str, List[str]]):
    if multi(url):
        return [process_url(u) for u in url if u]
    url = url.strip('/')
    return f'/{url}/' if url else '/'


def sys_user_exists(name: str, group: bool = False):
    if name is None:
        return False
    # name can be a user name (like root) or user id (like 0)
    if not sys_deployable:
        return False
    if group:
        return bool(os.popen(f'grep "{name}" /etc/group').read())
    else:
        return bool(os.popen(f'grep "{name}" /etc/passwd').read())


def sys_user_add(name: str, home: str = None, group: str = None, login: bool = True, add_group: bool = False):
    if not sys_deployable:
        return
    if not name:
        return
    if add_group:
        os.system(f'groupadd {name}')
        return
    items = []
    if not login:
        items.append('-s /bin/false')
    if home:
        items.append(f'-d {home}')
    if group:
        items.append(f'-g {group}')
    append_str = ' '.join(items)
    os.system(f'useradd {append_str} {name}')


def sub_regs(reg: str) -> typing.Tuple[tuple, dict]:
    left_p = 0
    right_p = 0
    sub = None
    ls = 0
    ps = []
    for i, s in enumerate(reg):
        if s == '(':
            if i and reg[i-1] == '\\':
                continue
            if sub is not None:
                continue
            if not left_p:
                ls = i
            left_p += 1
        elif s == ')':
            if i and reg[i-1] == '\\':
                continue
            if sub is not None:
                continue
            right_p += 1
        elif s == '[':
            sub = i
        elif s == ']':
            sub = None
        if left_p == right_p and left_p > 0:
            ps.append(reg[ls+1:i])
            left_p = 0
            right_p = 0
    args = []
    kwargs = {}
    kw_reg = '\?P<([A-Za-z0-9_-]+)>(.+)'
    for p in ps:
        match = re.match(kw_reg, p)
        if match:
            key, reg = match.groups()
            kwargs[key] = reg
        else:
            args.append(p)
    return tuple(args), kwargs


def map_list(data: dict, *fields) -> list:
    return [data.get(str(f)) for f in fields]


def map_dict(data: Union[list, tuple], *fields) -> Dict[str, Any]:
    return {str(f): d for d, f in zip(data, fields)}


def keys_or_args(args=None, *keys) -> list:
    """
    this function can work will only if target item is not multi-valued
    """
    if multi(args):
        args = list(args)
    elif args:
        args = [args]
    else:
        args = []
    return args + list(keys)


def print_time(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        from django.db import connection
        import time
        start = time.time()
        qs = len(connection.queries)
        r = f(*args, **kwargs)
        end = time.time()
        t = round(end - start, 3)
        qc = len(connection.queries) - qs
        print(f'function {f.__name__} cost {t} s with {qc} queries')
        return r
    return wrapper


def print_queries(alias='default'):
    def deco(f, a=alias):
        @wraps(f)
        def wrapper(*args, **kwargs):
            from django.db import connections
            import time
            start = time.time()
            connection = connections[a]
            qs = len(connection.queries)
            r = f(*args, **kwargs)
            end = time.time()
            t = round(end - start, 3)
            qc = len(connection.queries) - qs
            print(f'function {f.__name__} cost {t} s with {qc} queries')
            return r
        return wrapper

    if callable(alias):
        return deco(alias, 'default')

    return deco


def replace_null(data: dict, default=0):
    return {key: val or default for key, val in data.items()}


def get_exp_field(exp):
    try:
        return exp.deconstruct()[1][0]
    except COMMON_ERRORS:
        return None


def struct_dict(value, key):
    if multi(value):
        return [struct_dict(val, key=key) for val in value]
    elif value is None:
        return None
    else:
        return {key: value}


def struct_retrieve(data, temp, key, raise_err=False):
    if temp is None:
        return
    if multi(temp):
        if not multi(data):
            return
        if len(data) != len(temp):
            if raise_err:
                raise ValueError(f'Data: {readable(data)} inconsistent to Template: {readable(temp)}')

        for d, t in zip(data, temp):
            struct_retrieve(d, t, key, raise_err=raise_err)
    else:
        temp[key] = data


def merge_arg(b, v):
    from utilmeta.util.base import Util
    if v is None or v is ...:
        # params that can be merged
        return b
    elif multi(b):
        if not multi(v):
            v = [v]
        return type(b)(distinct_add(list(v), b))
    elif isinstance(b, Util) and isinstance(v, Util):
        return getattr(b, '_merge')(v)
    elif isinstance(b, dict):
        value = dict(b)
        if isinstance(v, dict):
            value.update(v)
        return value
    return v


def pretty_name(name: str):
    new = ''
    for c in name.capitalize():
        if c == '_':
            new += ' '
            continue
        if new and new[-1] == ' ':
            c = c.upper()
        new += c
    return new


def class_dict(cls: Type[T], data: dict, invalid_callback=None) -> Dict[str, List[T]]:
    from utilmeta.core.schema import Schema, SchemaMeta
    result = {}
    if isinstance(data, Schema) or isinstance(data, SchemaMeta):
        data = data.__data__
    if not data:
        return result
    assert isinstance(data, dict), f"class dict data: {data} must be an instance of dict / Schema"
    for key, val in data.items():
        try:
            key = get_field_name(key)
        except (TypeError, ValueError):
            pass

        def valid(obj):
            if isinstance(obj, cls):
                return obj
            elif invalid_callback:
                return invalid_callback(obj)
            raise TypeError(f'class dict value must be {cls} object or {cls} iterable , got {obj}')

        values = []
        if multi(val):
            for v in val:
                values.append(valid(v))
        else:
            values.append(valid(val))

        if isinstance(key, str):
            result[key] = values
        elif isinstance(key, tuple):
            for k in key:
                if k in result:
                    raise KeyError(f'class dict detect duplicate key: {k}')
                result[k] = copy.deepcopy(values)
        else:
            raise TypeError(f"class dict key must be str or str tuple, got {key}")
    return result


def merge_attrs(base: Union[dict, list, tuple], attrs: Union[dict, list, tuple]) -> dict:
    if isinstance(base, dict) and isinstance(attrs, dict):
        result = {key: merge_arg(base.get(key), attrs.get(key)) for key in set(base.keys()).union(attrs.keys())}
    elif multi(base) and multi(attrs):
        result = [merge_arg(b, v) for b, v in zip(base, attrs)]
    else:
        raise TypeError(f'Invalid base: {base} and attrs: {attrs}')
    return copy.deepcopy(result)


def distinct_add(target: list, data: list):
    if not data:
        return target
    if not isinstance(target, list):
        raise TypeError(f'Invalid distinct_add target type: {type(target)}, must be lsit')
    # target = list(target)
    for item in data:
        if item not in target:
            target.append(item)
    return target


def include_many_relates(model, field: str):
    if not model or not field or not isinstance(field, str):
        return False
    lookups = field.split(SEG)
    mod = model
    for lkp in lookups:
        try:
            f = get_field(mod, lkp)
        except FieldDoesNotExist:
            return False
        if many_to(f):
            return True
        mod = f.related_model
        if not mod:
            return False
    return False


def merge_fields(key: str, values: Union[List[dict], dict], fields: List[str] = None, excludes: List[str] = ()) -> dict:
    result = {}

    if not values:
        for field in fields:
            if excludes and field in excludes:
                continue
            k = key if field in (PK, ID) else f'{key}{SEG}{field}'
            result[k] = None

    elif isinstance(values, dict):
        for field in fields or values.keys():
            if excludes and field in excludes:
                continue
            k = key if field in (PK, ID) else f'{key}{SEG}{field}'
            result[k] = values.get(field)

    elif multi(values):
        for val in values:
            for field in fields or val.keys():
                if excludes and field in excludes:
                    continue
                k = key if field in (PK, ID) else f'{key}{SEG}{field}'
                if k in result:
                    result[k].append(val.get(field))
                else:
                    result[k] = [val.get(field)]

    return result


def merge_query(queryset: QuerySet, fields: List[str]) -> List[dict]:
    # performance only better in constant
    # 100M  20s 19s
    # 700M  200s 197s
    fields = list(fields)
    if PK not in fields:
        fields.insert(0, PK)
    return [map_dict(values, *fields) for values in
            merge_multiple_tuple(queryset.values_list(*fields), fields=fields)]


def merge_multiple_tuple(data: List[tuple], fields: List[str], key=PK, depth: int = 1) -> List[tuple]:
    if len(data) < 2:
        return data
    orders = []
    index = fields.index(key)
    values: Dict[str, List[tuple]] = {}
    for d in data:
        if d[index] is None:
            continue
        vk: str = d[index]
        if vk not in orders:
            orders.append(vk)
        if vk in values:
            values[vk].append(d)
        else:
            values[vk] = [d]
    if len(values) == len(data):
        return data

    result = [tuple()] * len(values)
    merged_fields = set()
    for i, f in enumerate(fields):
        f: str
        if SEG not in f:
            continue
        lks = f.split(SEG)
        if depth > 1 and not f.startswith(key + SEG):
            continue
        if len(lks) <= depth:
            continue
        for lk in [SEG.join(lks[:i]) for i in range(depth, len(lks))]:
            if lk in fields:
                merged_fields.update({lk})
                break

    for kv, val in values.items():
        item: List[Any] = [None] * len(fields)
        item[index] = kv

        for v in val:
            for i, t in enumerate(v):
                k = fields[i]
                if k in merged_fields:
                    continue
                if depth > 1 and not k.startswith(key + SEG):
                    continue
                if item[i] is None:
                    item[i] = t
                    continue
                p = item[i]
                if t is None:
                    continue
                elif isinstance(p, tuple):
                    if t not in p:
                        p = p + (t,)
                elif p != t:
                    p = (p, t)
                item[i] = p

        for f in merged_fields:
            value = merge_multiple_tuple(val, fields=fields, key=f, depth=depth + 1)
            for i, k in enumerate(fields):
                if k.startswith(f + SEG):
                    item[i] = value[0][i] if len(value) == 1 else [v[i] for v in value]

        for i, v in enumerate(item):
            if isinstance(v, tuple):
                item[i] = list(v)

        result[orders.index(kv)] = tuple(item)
    return result


def merge_multiple(data: List[dict], key=PK, depth: int = 1) -> List[dict]:
    if not key or len(data) < 2:
        return data

    orders = []
    values: Dict[str, list] = {}
    for d in data:
        if d.get(key) is None:
            continue
        vk: str = d[key]
        if vk not in orders:
            orders.append(vk)
        if vk in values:
            values[vk].append(d)
        else:
            values[vk] = [d]

    if not values or len(values) == len(data):
        return data

    result = [{}] * len(values)
    fields = tuple(data[0].keys())
    merged_fields = set()
    for f in fields:
        f: str
        if SEG not in f:
            continue
        lks = f.split(SEG)
        if depth > 1 and not f.startswith(key + SEG):
            continue
        if len(lks) <= depth:
            continue
        for lk in [SEG.join(lks[:i]) for i in range(depth, len(lks))]:
            if lk in fields:
                merged_fields.update({lk})
                break
    # print('merge:', depth, merge_fields)

    for kv, val in values.items():
        merged_item = {}
        for f in merged_fields:
            value = merge_multiple(val, key=f, depth=depth+1)
            if not value:
                merged_item[f] = None
                continue
            v0 = {k: v for k, v in value[0].items() if k.startswith(f + SEG)}
            if len(value) == 1:
                merged_item.update(v0)
            else:
                merged_item.update({k: [v[k] for v in value] for k in v0.keys()})
        item = {key: kv}
        for v in val:
            v: dict
            for k, t in v.items():
                k: str
                if k == key or k in merged_item:
                    continue
                if depth > 1 and not k.startswith(key + SEG):
                    continue
                if k not in item:
                    item[k] = t
                    continue
                i = item[k]
                if t is None:
                    continue
                elif i is None:
                    i = t
                elif isinstance(i, tuple):
                    if t not in i:
                        i = i + (t,)
                elif i != t:
                    i = (i, t)
                item[k] = i

        item.update(merged_item)

        for k in list(item.keys()):
            if isinstance(item[k], tuple):
                item[k] = list(item[k])

        result[orders.index(kv)] = item
    return result


def gen_meta(headers: Union[Dict[str, str], HttpHeaders], cookie: dict) -> dict:
    result = {key.lower().replace('-', '_'): val for key, val in headers.items()}
    result['cookie'] = cookie
    return result


def get_backward(model, field: str) -> str:
    lookups = field.split(SEG)
    backwards = []
    for lk in lookups:
        f = get_field(model, lk)
        backwards.append(f.remote_field.name)
        model = f.related_model
    backwards.reverse()
    return SEG.join(backwards)


def get_reverse_lookup(model, lookup: str):
    reverse_fields = []
    _model = model
    for name in lookup.split(SEG):
        field = get_field(_model, name)
        reverse_fields.append(field.remote_field.name)
        _model = field.related_model
    reverse_fields.reverse()
    return SEG.join(reverse_fields)


def get_field(model, field: str, cascade: bool = False, custom_addon: bool = False) -> Union[Field, ForeignObjectRel]:
    from django.db import models
    assert model and field, f'get_field got model: {model}, field: <{field}> contains empty value'
    if cascade:
        f, addon = get_field_addon(model, field=field, custom=custom_addon)
        return f
    meta = getattr(model, '_meta')
    if field == PK:
        return meta.pk
    if isinstance(model, models.base.ModelBase):
        return meta.get_field(field)
    raise TypeError(f'get_field expect a Model to process, got {model}')


def get_field_addon(model, field: str, custom: bool = False) -> Tuple[Field, Optional[str]]:
    assert model and field, f'get_field got model: {model}, field: <{field}> contains empty value'
    if SEG not in field:
        return get_field(model, field), None
    lookups = field.split(SEG)
    f = None
    for i, lk in enumerate(lookups):
        if f and not model and i == len(lookups) - 1:
            if custom:
                return f, lk
            addon = ADDON_FIELD_LOOKUPS.get(f.get_internal_type())
            if addon and lk in addon:
                return f, lk
            if lk in FilterNote.lookups():
                # common filter
                return f, lk
        f = get_field(model, lk)
        model = f.related_model
    return f, None


def get_relate_model(field: Field):
    if not field.related_model:
        return None
    mod = field.related_model
    if isinstance(mod, str):
        from django.apps import apps
        if '.' in mod:
            app, model = mod.split('.')
            return apps.get_model(app_label=app, model_name=model)
        else:
            return apps.get_model(app_label=getattr(field.model, '_meta').app_label, model_name=mod)
    return mod


def get_pk(model, root=False) -> Field:
    meta = getattr(model, '_meta')
    if root:
        parents = meta.get_parent_list()
        if parents:
            return get_pk(parents[-1])
    return meta.pk


def one_to(field):
    from utilmeta.fields import CrossServiceKey
    return isinstance(field, (OneToOneField, ForeignKey, CrossServiceKey, OneToOneRel))


def many_to(field):
    if isinstance(field, OneToOneRel):
        # OneToOneRel is subclass of ManyToOneRel
        return False
    return isinstance(field, (ManyToManyField, ManyToManyRel, ManyToOneRel))


def to_many(field):
    return isinstance(field, (ManyToManyField, ManyToManyRel, ForeignKey))


def to_one(field):
    """
    This kind of field is mutable in Module side, because the modify can only be done from the certain One
    (OneRel | Fk)
    """
    return isinstance(field, (OneToOneField, OneToOneRel, ManyToOneRel))


def is_pk(f, model=None):
    _is = getattr(f, 'primary_key', False)
    if not model:
        return _is
    if f.name in (PK, ID):
        return True
    return _is and issubclass(model, f.model)


def get_many_field_names(model):
    if not model:
        return []
    fields = []
    for field in get_fields(model, many=True):
        if many_to(field):
            fields.append(field.get_cache_name())
    return fields


def get_fields(model, many=False, no_inherit=False) -> List[Union[Field, ForeignObjectRel]]:
    meta = getattr(model, '_meta')
    if not meta:
        return []
    else:
        fields = []
        pk = get_pk(model, root=True)
        if pk:
            # abstract model meta.pk is None
            fields.append(pk)
        for f in meta.get_fields() if many else meta.fields:
            f: Field
            if is_pk(f):
                continue
            if f.remote_field:
                if is_pk(f.remote_field):
                    continue
            if no_inherit:
                if f.model != model:
                    continue
            try:
                get_field(model, f.name)
            except FieldDoesNotExist:
                continue
            fields.append(f)
        return fields


def list_or_args(keys, args: tuple):
    # returns a single new list combining keys and args
    try:
        iter(keys)
        # a string or bytes instance can be iterated, but indicates
        # keys wasn't passed as a list
        if isinstance(keys, (str, bytes)):
            keys = [keys]
        else:
            keys = list(keys)
    except TypeError:
        keys = [keys]
    if args:
        keys.extend(args)
    return keys


def _list_dict(val):
    return isinstance(val, list) and len(val) == 1 and isinstance(val[0], dict)


def temp_patch(base: dict, *updates: dict):
    def patch(b: dict, p: dict):
        pop(p, Attr.MOD)
        for r in pop(p, Attr.REM, []):
            pop(b, r)
        for k in list(b.keys()):
            v = b[k]
            if k in p:
                if isinstance(v, dict) and isinstance(p[k], dict):
                    patch(v, p[k])
                elif _list_dict(v) and _list_dict(p[k]):
                    patch(v[0], p[k][0])
                else:
                    b[k] = p[k]
                p.pop(k)  # do not update this k at b
        b.update(p)

    for update in updates:
        patch(base, update)
    return base


def temp_diff(base: dict, temp: dict):
    """
         each time a new service is generated, this method will be used
         to compare the difference between the old root template and new one,
         to tell the add/remove/modify of the api system, to support API version control system
    """
    p = {}
    for k, v in temp.items():
        if k not in base:
            p[k] = v
        elif isinstance(v, dict) and isinstance(base[k], dict):
            df = temp_diff(base[k], v)
            if df:
                p[k] = df
        elif _list_dict(v) and _list_dict(base[k]):
            df = temp_diff(base[k][0], v[0])
            if df:
                p[k] = [df]
        else:
            if base[k] != v:
                p[k] = v
                setval(p, Attr.MOD, v=k, array=True)
    for k, v in base.items():
        if k not in temp:
            setval(p, Attr.REM, v=k, array=True)
    return p


def restrict_keys(keys: Union[list, tuple, set], data: dict, default=None) -> dict:
    for key in set(data).difference(keys):
        data.pop(key)
    for key in set(keys).difference(data):
        data[key] = default
    return data


def merge_list(*lst, keys=None) -> List[dict]:
    result = []
    for items in zip(*[ls for ls in lst if ls]):
        val = {}
        for item in items:
            val.update(item)
        result.append(restrict_keys(keys=keys, data=val) if keys else val)
    return result


def get_field_name(data):
    if data is None:
        return ''
    if multi(data):
        return type(data)([get_field_name(d) for d in data])
    elif isinstance(data, str):
        return data.replace('.', SEG)
    elif hasattr(data, 'field'):
        return getattr(data.field, 'name')
    elif isinstance(data, Field):
        return data.name
    raise ValueError(f"Can't find field in {data}, use str field or Model attr")


def del_field_id(field: str) -> str:
    if not field:
        raise ValueError(f'Empty field: {field}')
    return field if field[-3:] != '_id' else field[:-3]


def add_field_id(field: str) -> str:
    if not field:
        raise ValueError(f'Empty field: {field}')
    if field == PK or field == ID:
        return field
    return field if field[-3:] == '_id' else field + '_id'


def unique_field(field) -> bool:
    return getattr(field, 'unique', False)


def path_merge(base: str, path: str):
    """
        the base param is a absolute dir (usually the os.getcwd())
        path can be regular path like dir1/file2
        or the double-dotted path ../../file1
        in every case the base and path will merge to a absolute new path
    """
    if path.startswith('./'):
        path = path.strip('./')

    if path.startswith('/') or path.startswith('~'):
        return path

    if '..' in path:
        divider = os.sep
        dirs = path.split(divider)
        backs = dirs.count('..')
        while backs:
            base = os.path.dirname(base)
            backs -= 1
        path = divider.join([d for d in dirs if d != '..'])
    return os.path.join(base, path).replace('/', os.sep).replace('\\', os.sep).rstrip(os.sep)


def get_single_value(data):
    if multi(data):
        if data:
            return data[0]
        return None
    return data


def convert_data_frame(data: List[dict], align: bool = False, depth: int = 1, keys: List[str] = ()) -> Dict[str, list]:
    if not multi(data) or not data:
        return {key: [] for key in keys}
    result = {}
    for d in data:
        if not isinstance(d, dict):
            continue
        for k, v in d.items():
            if depth:
                if multi(v) and v and isinstance(v[0], dict):
                    v = convert_data_frame(v, align=align, depth=depth - 1)
            if k not in result:
                result[k] = [v]
            else:
                result[k].append(v)
    if align:
        for key in list(result.keys()):
            if len(result[key]) != len(data):
                result.pop(key)
    return result


def copy_value(data):
    """
    return a new value identical to default , but different in memory,
    to avoid multiple initialize to modify the same default data
    """
    if multi(data):
        return type(data)([copy_value(d) for d in data])
    elif isinstance(data, dict):
        return {k: copy_value(v) for k, v in data.items()}
    return data


def parse_raw_url(url: str) -> Tuple[str, dict]:
    res = urlparse(url)
    from django.http.request import QueryDict
    return res.path, parse_query_dict(QueryDict(res.query))


def extract_date(dt: datetime) -> date:
    return date(year=dt.year, month=dt.month, day=dt.day)


def parse_query_dict(qd: Dict[str, List[str]]) -> dict:
    data = {}
    for key, val in dict(qd).items():
        if key.endswith('[]'):
            data[key.rstrip('[]')] = val
            continue
        if len(val) > 1:
            data[key] = val
            continue
        v = val[0]
        if v.startswith('='):
            if key.endswith('>') or key.endswith('<'):
                data[key + '='] = v[1:]
                continue
        data[key] = v or ''
    return data


def gen_key(digit=64, alnum=False, lower=False, excludes: List[str] = ('$', '\\')) -> str:
    import secrets
    sample = string.digits
    if alnum:
        sample += string.ascii_lowercase if lower else string.ascii_letters
    else:
        sample = string.printable[:94]
    for ex in excludes:
        sample = sample.replace(ex, '')
    while len(sample) < digit:
        sample += sample
    return ''.join(secrets.choice(sample) for i in range(digit))
    # return ''.join(random.sample(sample, digit))


def parse_user_agents(ua_string: str) -> Optional[dict]:
    if not ua_string:
        return None
    try:
        import user_agents
    except ModuleNotFoundError:
        return None
    ua = user_agents.parse(ua_string)
    device = AgentDevice.bot
    if ua.is_bot:
        device = AgentDevice.bot
    elif ua.is_pc:
        device = AgentDevice.pc
    elif ua.is_tablet:
        device = AgentDevice.tablet
    elif ua.is_mobile:
        device = AgentDevice.mobile
    elif ua.is_email_client:
        device = AgentDevice.email
    return dict(
        browser=f'{ua.browser.family} {ua.browser.version_string}'.strip(' '),
        os=f'{ua.os.family} {ua.os.version_string}'.strip(' '),
        mobile=ua.is_mobile,
        bot=ua.is_bot,
        device=device
    )


def get_doc(obj) -> str:
    if not obj:
        return ''
    if isinstance(obj, str):
        return obj
    return (getattr(obj, Attr.DOC, '') or '').replace('\t', '').strip('\n').strip()


def import_util(dotted_path):
    """
    Import a dotted module path and return the attribute/class designated by the
    last name in the path. Raise ImportError if the import failed.
    """
    if os.path.exists(dotted_path):
        from importlib.util import spec_from_file_location
        name = dotted_path.split(os.sep)[-1].rstrip(PY)
        spec = spec_from_file_location(name, dotted_path)
        return spec.loader.load_module()
    try:
        # directly import packages and modules
        return importlib.import_module(dotted_path)
    except (ImportError, ModuleNotFoundError) as e:
        if dotted_path not in str(e):
            raise e
    if ':' not in dotted_path and '.' not in dotted_path:
        # module only
        return importlib.import_module(dotted_path)
    try:
        if ':' in dotted_path:
            module_path, class_name = dotted_path.split(':')
        else:
            module_path, class_name = dotted_path.rsplit('.', 1)
    except ValueError as err:
        raise ImportError("%s doesn't look like a module path" % dotted_path) from err

    module = importlib.import_module(module_path)

    try:
        return getattr(module, class_name)
    except AttributeError as err:
        raise ImportError('Module "%s" does not define a "%s" attribute/class' % (
            module_path, class_name)
        ) from err


def get_sql_type(sql_str: str):
    import sqlparse
    sql = sqlparse.parse(sql_str)
    if not sql:
        return None
    return sql[0].get_type()


def get_sql_tables(sql_str: str):
    import sqlparse
    from sqlparse.sql import Identifier
    sql = sqlparse.parse(sql_str)
    tables = []
    for statement in sql:
        for token in statement.tokens:
            if isinstance(token, Identifier):
                if token.get_name() and not token.get_ordering():
                    tables.append(token.get_name())
    return tables


def dict_diff(base: dict, data: dict):
    diff = {}
    for key, val in base.items():
        if key not in data:
            continue
        if data[key] != val:
            diff[key] = data[key]
    return diff


def dict_overflow(base: dict, data: dict):
    return {key: val for key, val in data.items() if key not in base}


def dict_number_add(base: dict, data: dict):
    if not base:
        return data
    if not data:
        return base
    result = {}
    for key, val in base.items():
        if key in data:
            result[key] = val + data[key]
        else:
            result[key] = val
    for key, val in data.items():
        if key not in base:
            result[key] = val
    return result


def check_requirement(pkg: str, hint: str = None, check: bool = True):
    from utilmeta.conf import config
    try:
        if check:
            import_util(pkg)
        else:
            raise ImportError
    except (ModuleNotFoundError, ImportError):
        if not config.service or config.service.install_when_require:
            print(f'INFO: current service require <{pkg}> package, installing...')
            try:
                import sys
                os.system(f'{sys.executable} -m pip install {pkg}')
            except Exception as e:
                print(f'install package failed with error: {e}, fallback to internal solution')
                import pip
                pip_main = import_util('pip._internal:main')
                pip_main(['install', pkg])
        else:
            if hint:
                print(hint)
            raise ImportError(f'package <{pkg}> is required for current settings, please install it '
                              f'or set install-when-require=True at meta.ini to allow auto installation')


def retrieve(data: list, val, key=PK) -> dict:
    for d in data:
        d: dict
        for k, v in d.items():
            if k == key and v == val:
                return d
    return {}


def pop_null(data):
    if multi(data):
        return [pop_null(d) for d in data]
    elif isinstance(data, dict):
        for k in list(data):
            if data[k] is None:
                data.pop(k)
        return data
    return data


def pop_key(data, key=PK):
    if type(data) == list:
        for d in data:
            if type(d) in (dict, list):
                pop_key(d, key)
    elif type(data) == dict:
        pop(data, key)
        for v in data.values():
            if type(v) in (dict, list):
                pop_key(v, key)


def order_list(data: list, orders: list, by: str, join_rest: bool = False) -> list:
    result = []
    if len(data) <= 1 or not orders:
        return data
    for i in orders:
        for d in data:
            d: dict
            if str(d.get(by)) == str(i):
                result.append(d)
                data.remove(d)
                break
    if join_rest:
        result += data  # if there is remaining data left, join the result
    return result


def order_dict(data: dict, orders: tuple) -> OrderedDict:
    # consider the origin data is already ordered (odict_items)
    return OrderedDict(sorted(list(data.items()), key=lambda item: orders.index(item[0]) if item[0] in orders else 0))


def distinct(data: list, key: str = None, val_type: type = None) -> list:
    if not data:
        return []
    if not multi(data):
        return [data]
    data = list(data)
    result = []
    values = []
    for d in data:
        if val_type:
            d = val_type(d)
        if key:
            val = d.get(key)
            if val not in values:
                values.append(val)
                result.append(d)
        elif d not in result:
            result.append(d)
    return result


def get_calls(attrs):
    result = {}
    for key, val in attrs.items():
        if inspect.isfunction(val) or inspect.ismethod(val):
            result[key] = val
    return result


def http_header(header: str) -> str:
    h = header.upper().replace('-', '_')
    if h in {'CONTENT_TYPE', 'CONTENT_LENGTH'}:
        return h
    return 'HTTP_' + h


def make_header(h: T) -> T:
    """
    lower-cased _ connected variable to header
    """
    if isinstance(h, str):
        return '-'.join([s.capitalize() for s in h.lower().split('_')])
    elif isinstance(h, dict):
        return {make_header(key): val for key, val in h.items()}
    return h


def allow_cors(response, *, origin, methods: Union[tuple, list], headers: Union[tuple, list]):
    from utilmeta.conf import config
    response[Header.ALLOW_ORIGIN] = origin or '*'
    response[Header.ALLOW_CREDENTIALS] = 'true'
    response[Header.ALLOW_METHODS] = ','.join(set([m.upper() for m in methods]))
    response[Header.ALLOW_HEADERS] = ','.join(set([h.lower() for h in headers]))
    expose = config.http_config.expose_headers
    if expose:
        response[Header.EXPOSE_HEADERS] = ','.join(expose)
    return response


def clean_line(line: str):
    return line.replace('\t', '').replace('\n', '').replace(' ', '')


def valid_attr(name: str):
    from keyword import iskeyword
    return name.isidentifier() and not iskeyword(name)


def start_end(value: str, start, end=None):
    if end is None:
        end = start
    return value.startswith(start) and value.endswith(end)


def key_normalize(key: str) -> str:
    if valid_attr(key):
        return key
    if '-' in key:
        # probably header
        return key.lower().replace('-', '_')

    from utilmeta.util.filter import Filter
    if key in NOTE_MAP:
        return f'_{NOTE_MAP[key]}'
    try:
        return Filter.normalize(key)
    except COMMON_ERRORS:
        new_key = ''
        for i, c in enumerate(key):
            if c.isalnum():
                new_key += c
            elif c == '.':
                new_key += '__'
            elif c == '-':
                new_key += '_'
            elif c == '_':
                new_key += c
            elif c in ('>', '<'):
                if i == len(key) - 2 and key[i+1] == '=':
                    new_key += f'__{NOTE_MAP[c]}e'
                    break
                new_key += f'__{NOTE_MAP[c]}'
            else:
                new_key += '__' + NOTE_MAP.get(c, '')
        return new_key


def camel_case(name: str, reverse: bool = False) -> str:
    cap = True
    s = ''
    for i, c in enumerate(name):
        if reverse:
            if c.isupper():
                if i:
                    # not for first upper case
                    s += '_'
                c = c.lower()
        else:
            if c == '_':
                cap = True
                continue
            if cap:
                c = c.upper()
                cap = False
        s += c
    return s


def valid_url(url: str, raise_err: bool = True) -> str:
    url = url.strip('/').replace(' ', '')
    res = urlparse(url)
    if SCHEME not in url:
        if raise_err:
            raise ValueError(f'Invalid url syntax: {url}')
        return ''
    if res.scheme not in (Scheme.HTTP, Scheme.HTTPS):
        if raise_err:
            raise ValueError(f'Invalid scheme: {res.scheme}')
        return ''
    if not res.netloc:
        if raise_err:
            raise ValueError(f'empty net loc')
        return ''
    return url


def request_length(request) -> int:
    from utilmeta.util.request import Request
    from utilmeta.util.call import Call
    req_length = 0
    if isinstance(request, Request):
        req_length = request.content_length
        for key, val in request.headers.items():
            if isinstance(val, str) and isinstance(key, str):
                req_length += len(key) + len(val)
    elif isinstance(request, Call):
        req_length = request.content_length + len(request.encoded_url)
        for key, val in request.headers.items():
            if isinstance(val, str) and isinstance(key, str):
                req_length += len(key) + len(val)
    return req_length


def response_length(response: HttpResponseBase, content_only: bool = True) -> int:
    if not response:
        return 0
    if isinstance(response, HTTPResponse):
        headers = response.headers
        resp_length = int(headers.get(Header.LENGTH) or len(response.read()))
    else:
        headers = response
        resp_length = int(headers.get(Header.LENGTH) or len(getattr(response, 'content', '')))
    if content_only:
        return resp_length
    for key, val in headers.items():
        resp_length += len(key) + len(val)
    return resp_length


def encode_multipart_form(form: dict) -> Tuple[bytes, str]:
    boundary = binascii.hexlify(os.urandom(16)).decode('ascii')
    body = (
        "".join("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n"
                "\r\n%s\r\n" % (boundary, field, value)
                for field, value in form.items()) + "--%s--\r\n" % boundary
    ).encode()
    content_type = "multipart/form-data; boundary=%s" % boundary
    return body, content_type


def get_origin(url: str, with_scheme: bool = True, remove_www_prefix: bool = False, convert_port: bool = False,
               default_scheme: str = Scheme.HTTP, trans_local: bool = True):
    if not url:
        return ''
    default_scheme = str(default_scheme).lower()
    if default_scheme not in SCHEMES:
        default_scheme = Scheme.HTTP
    if not url.startswith(HTTP) and not url.startswith(HTTPS):
        url = default_scheme + SCHEME + url
    result: ParseResult = urlparse(url)
    scheme = result.scheme
    host: str = result.netloc
    port = result.port
    if convert_port:
        if port == '80':
            port = None
            if not scheme:
                scheme = Scheme.HTTP
            elif scheme != Scheme.HTTP:
                raise ValueError(f'Invalid scheme port combination: {scheme} {port}')
        if port == '443':
            port = None
            if not scheme:
                scheme = Scheme.HTTPS
            elif scheme != Scheme.HTTPS:
                raise ValueError(f'Invalid scheme port combination: {scheme} {port}')
    if remove_www_prefix:
        host = host.lstrip('www.')
    if trans_local and host.startswith(LOCAL):
        host = '127.0.0.1'
        if port:
            host = f'{host}:{port}'
    if not with_scheme:
        return host
    if not scheme:
        scheme = default_scheme
    return f'{scheme}{SCHEME}{host}'


def get_limit_fds():
    import psutil
    if psutil.POSIX:
        return int(os.popen('ulimit -n').read().rstrip('\n'))
    return 0


def get_system_fds():
    import psutil
    fds = 0
    if psutil.POSIX:
        for proc in psutil.process_iter():
            try:
                fds += proc.num_fds()
            except psutil.Error:
                continue
    return fds


def get_system_open_files():
    import psutil
    files = 0
    for proc in psutil.process_iter():
        try:
            files += len(proc.open_files())
        except psutil.Error:
            continue
    return files


def get_server_ip(private_only: bool = False) -> Optional[str]:
    ip = socket.gethostbyname(socket.gethostname())
    if ip.startswith('127.'):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 53))
        ip = str(s.getsockname()[0])
        s.close()
    try:
        addr = ip_address(ip)
        if private_only and not addr.is_private:
            raise ValueError
    except ValueError:
        return LOCAL_IP
    return ip


def get_real_ip(ip: str):
    if localhost(ip):
        return get_server_ip()
    return get_ip(ip)


def get_ip(host: str, ip_only: bool = False) -> Optional[str]:
    ip_reg = re.compile(f'^{Reg.IP}')
    match = ip_reg.match(host)
    if match:
        return match.group()
    res: ParseResult = urlparse(host)
    match = ip_reg.match(res.netloc)
    if match:
        return match.group()
    if ip_only:
        return None
    try:
        return socket.gethostbyname(get_hostname(host))
    except (socket.error, OSError):
        return LOCAL_IP


def get_request_ip(meta: dict) -> IPType:
    ips = [*meta.get(Header.FORWARDED_FOR, '').replace(' ', '').split(','),
           meta.get(Header.REMOTE_ADDR)]
    if '' in ips:
        ips.remove('')
    if LOCAL_IP in ips:
        ips.remove(LOCAL_IP)
    for ip in ips:
        try:
            return ip_address(ip)
        except ValueError:
            continue
    return ip_address(LOCAL_IP)


def get_netloc(url: str) -> str:
    if not url:
        return ''
    res = urlparse(url)
    if res.netloc:
        return res.netloc
    res = urlparse(HTTP + url)
    return res.netloc


def get_hostname(url: str) -> str:
    if not url:
        return ''
    res = urlparse(url)
    if res.hostname:
        return res.hostname
    res = urlparse(HTTP + url)
    return res.hostname


def get_domain(url: str) -> Optional[str]:
    hostname = get_hostname(url)
    try:
        # is an ip address
        ip_address(hostname)
        return None
    except ValueError:
        return '.'.join(hostname.split('.')[-2:])


def parse_list(data, merge=False, distinct_merge=None, merge_type: type = None) -> list:
    if multi(data):
        if merge:
            result = []
            multi_occur = False
            for d in data:
                if multi(d):
                    multi_occur = True
                    result += parse_list(d, merge_type=merge_type, merge=True, distinct_merge=distinct_merge)
                else:
                    if merge_type:
                        d = type_transform(d, merge_type)
                    result.append(d)
            if distinct_merge is None and multi_occur:
                distinct_merge = True
            if distinct_merge:
                try:
                    return list(set(result))
                except TypeError:
                    return result
            return result
        return list(data)
    elif not data:
        return []
    elif type(data) == str:
        data: str
        maybe_list = start_end(data, '[', ']')
        maybe_json = start_end(data, '{', '}')
        if maybe_list or maybe_json:
            try:
                return parse_list(json.loads(data, strict=False), merge=merge)
            except json.JSONDecodeError:
                pass
        elif ',' in data:
            return data.replace(' ', '').split(',')
    elif not isinstance(data, COMMON_TYPES) and iterable(data):
        return parse_list(list(data), merge=merge, distinct_merge=distinct_merge, merge_type=merge_type)
    return [data]


def full_match_reg(reg: str) -> str:
    if not reg.startswith('^'):
        reg = '^' + reg
    if not reg.endswith('$'):
        reg = reg + '$'
    return reg


def close_connections(*_, **__):
    from django.db import connections
    connections.close_all()


def closest_hour(dt: datetime) -> datetime:
    lo = datetime(
        year=dt.year,
        month=dt.month,
        day=dt.day,
        hour=dt.hour,
        tzinfo=dt.tzinfo
    )
    hi = datetime(
        year=dt.year,
        month=dt.month,
        day=dt.day,
        hour=dt.hour,
        tzinfo=dt.tzinfo
    ) + timedelta(hours=1)
    if dt - lo > hi - dt:
        return hi
    return lo


def get_mark(obj: object):
    return f'{obj.__module__}:{obj.__name__}'


# def get_cache_size(using: str) -> int:
#     from utilmeta.conf import config
#     cache = config.caches[using]
#     if cache.type == 'db':
#         return get_db_size(using)
#     elif cache.type == 'file':
#         loc = cache.location
#         return os.path.getsize(loc)
#     elif cache.type == 'redis':
#         info = get_redis_info(using)
#         return info.get('used_memory', 0)
#     elif cache.type == 'memcached':
#         if sys_deployable:
#             # echo only apply to unix systems
#             try:
#                 host, port = cache.location.split(':')
#                 cmd = "echo \'stats\' | nc - w 1 %s %s | awk \'$2 == \"bytes\" { print $3 }\'" % (host, port)
#                 res = os.popen(cmd).read()
#                 return int(res)
#             except (OSError, TypeError):
#                 return 0
#     return 0


def get_redis_info(using: str) -> dict:
    from django_redis import get_redis_connection
    from redis.exceptions import ConnectionError
    try:
        con = get_redis_connection(using, write=False)
        return con.info()
    except ConnectionError:
        return {}


def dump_kwargs(*args, **kwargs) -> str:
    """
    dump the args & kwargs of a callable to a comparable string
    use for API cache
    """

    def dump_data(data) -> str:
        if multi(data):
            if isinstance(data, set):
                data = list(data)
                try:
                    data.sort()
                except TypeError:
                    pass
            lst = []
            for d in data:
                _d = dump_data(d)
                if _d is not None:
                    lst.append(_d)
            return ','.join(lst)
        elif isinstance(data, dict):
            keys = list(data.keys())
            keys.sort()
            lst = []
            for k in keys:
                _d = dump_data(data[k])
                if _d is not None:
                    lst.append(f'{k}={_d}')
            return '&'.join(lst)
        elif type(data) in COMMON_TYPES:
            return repr(data)

    args_str = dump_data(args)
    kwargs_str = dump_data(kwargs)
    if not args_str and not kwargs_str:
        return ''
    elif args_str and kwargs_str:
        return f'{args_str}|{kwargs_str}'
    return args_str or kwargs_str


def retrieve_path(url):
    parse: ParseResult = urlparse(url)
    if parse.scheme:
        return url[len(f'{parse.scheme}{SCHEME}{parse.netloc}'):]
    if url.startswith('/'):
        return url
    return f'/{url}'


def get_used_memory(pid):
    import psutil
    mem = 0
    try:
        process = psutil.Process(pid)
        for p in [process, *process.children()]:
            mem += p.memory_full_info().uss
    except psutil.Error:
        return mem
    return mem


def encode_query(query: dict, exclude_null: bool = True, comma_join_multi: bool = False) -> str:
    if not query:
        return ''
    from urllib.parse import urlencode
    encoded = []
    for key, val in query.items():
        if val is None and exclude_null:
            continue
        if multi(val):
            if comma_join_multi:
                val = ','.join(val)
            else:
                encoded.extend([f'{key}[]={v}' for v in val])
                continue
        encoded.append(urlencode({key: val}))
    return '&'.join(encoded)


def dump_request(url: str, method: str, tag: str = None, data: bytes = None):
    data: bytes = type_transform(data, bytes)
    request_string = f'{method.upper()}:{url}'
    if tag:
        request_string += f'@{tag}'
    elif data:
        request_string += f'@{hashlib.sha256(data).hexdigest()}'
    return hashlib.md5(request_string.encode('utf-8')).hexdigest()


def readable(data, max_length: int = 20, rep: bool = True, more: bool = True):
    if data is None:
        return repr(None)
    if isinstance(data, bytes):
        data = data.decode('utf-8', 'ignore')
    if multi(data):
        if not rep:
            if len(str(data)) <= max_length:
                return str(data)
            return str(data)[:max_length] + '...'
        form = {list: '[%s]', tuple: '(%s)', set: '{%s}'}
        items = []
        total = 0
        for d in data:
            total += len(repr(d))
            if total > max_length:
                items.append(f'...' + (f'({len(data)} items)' if more else ''))
                break
            items.append(repr(d))
        for t, fmt in form.items():
            if isinstance(data, t):
                return fmt % ', '.join(items)
        return '[%s]' % ', '.join(items)
    elif isinstance(data, dict):
        if not rep:
            if len(str(data)) <= max_length:
                return str(data)
            return str(data)[:max_length] + '...'
        items = []
        total = 0
        for k, v in data.items():
            total += len(str(k)) + len(str(v)) + 2
            if total > max_length:
                items.append(f'...' + (f'({len(data)} items)' if more else ''))
                break
            items.append(repr(k) + ': ' + repr(v))
        return '{%s}' % ', '.join(items)
    elif is_number(data):
        return data
    if not isinstance(data, str):
        rep = False
        data = str(data)
    excess = len(data) - max_length
    if excess >= 0:
        data = data[:max_length] + f'...' + (f'({excess} more chars)' if more else '')
    result = repr(data) if rep else data
    return result


def is_number(s):
    try:
        float(s)
        return True
    except (ValueError, TypeError):
        return False


def readable_size(size, depth=0):
    unit = ['B', 'KB', 'MB', 'GB', 'TB']
    if size < 1 or not size:
        return f"0 {unit[depth]}"
    if 1 <= size < 1000:
        return f'{str(size)} {unit[depth]}'
    return readable_size(int(size/1024), depth+1)


def function_pass(f):
    if not inspect.isfunction(f):
        return False
    return getattr(f, Attr.CODE).co_code == b'd\x00S\x00'


def function_not_implemented(f):
    if not inspect.isfunction(f):
        return False
    return getattr(f, Attr.CODE).co_code == b't\x00\x82\x01d\x01S\x00'


def is_origin(val, temp):
    if multi(temp):
        for t in temp:
            if is_origin(val, t):
                return True
        return False
    if not isinstance(temp, type):
        return False
    origin = getattr(temp, Attr.ORIGIN, None) or temp
    if isinstance(val, (origin, temp)):
        return True
    _val_origin = getattr(getattr(val, Attr.CLS, None), Attr.ORIGIN, None)
    if _val_origin:
        if _val_origin == origin:
            return True
    return False


def add_filter_base(q, base: str):
    from .exp import Q
    if not q or not base:
        return Q()
    if not isinstance(q, Q):
        return Q()

    if q.connector == 'AND':
        r = None
    else:
        r = Q()

    for child in q.children:
        if isinstance(child, tuple):
            _q = Q(**{f'{base}__{child[0]}': child[1]})
        elif isinstance(child, Q):
            _q = add_filter_base(child, base=base)
        else:
            continue
        if r is None:
            r = _q
        elif q.connector == 'AND':
            r &= _q
        else:
            r |= _q
    if not r:
        r = Q()
    if q.negated:
        r = ~r
    return r


def field_in_query(q, field: str):
    from .exp import Q
    if not q or not field:
        return False
    if not isinstance(q, Q):
        return False
    for child in q.children:
        if isinstance(child, tuple):
            if child[0].startswith(field):
                return True
        elif isinstance(child, Q):
            if field_in_query(child, field):
                return True
    return False


def type_transform(data: Any, t: type, strict: bool = False):
    assert callable(t), f"Invalid type {t}"
    try:
        if data is ...:
            return None
        if not isinstance(t, type):
            return t(data)
        if isinstance(data, t):
            return data
        if data is None:
            return t()

        if t not in COMMON_TYPES:
            # other class type, directly convert
            return t(data)
        if t == bool:
            if not data or like_false(data):
                return False
            return True
        if issubclass(t, str):
            if isinstance(data, bytes):
                return t(data.decode('utf-8', 'ignore'))
            elif multi(data):
                if len(data) == 1 and isinstance(list(data)[0], str):
                    # resolve set / tuple / list
                    return list(data)[0]
                if not data:
                    return ''
            return t(data)
        if issubclass(t, bytes):
            return t(str(data).encode())
        if issubclass(t, (list, tuple, set)):
            if isinstance(data, str):
                try:
                    lst = json.loads(data.replace("'", '"'))
                    if isinstance(lst, list):
                        return t(lst)
                    elif isinstance(lst, dict):
                        if strict:
                            raise TypeError(f'Invalid data type: dict')
                        return t(lst.keys())
                except json.JSONDecodeError:
                    pass
            if multi(data):
                return t(data)
            return t(parse_list(data))
        if multi(data) and data:
            if strict:
                raise TypeError(f'Invalid data type: {type(data)}')
            data = data[0]
        if issubclass(t, dict):
            from utilmeta.core.schema import SchemaMeta
            if not data:
                # no matter what type
                return t()
            elif isinstance(data, str) or isinstance(data, bytes):
                return t(json.loads(data, strict=False))
            elif isinstance(data, SchemaMeta):
                return t(data.__template__)
            elif isinstance(data, Element):
                return t(data.attrib)
        elif issubclass(t, (int, float, decimal.Decimal)):
            if not data:
                return t()
            if isinstance(data, timedelta):
                return t(data.total_seconds())
            if issubclass(t, (float, decimal.Decimal)):
                return t(data)
            #   value like '-10.33' cannot directly convert to int, convert to float first
            return t(float(data))
        elif t == datetime:
            if isinstance(data, date):
                return datetime(year=data.year, month=data.month, day=data.day)
            if is_number(data):
                try:
                    return datetime.fromtimestamp(float(data))
                except (OSError, ValueError):
                    # maybe ms timestamp (OSError in win, ValueError in unix), turn to seconds
                    return datetime.fromtimestamp(float(data) / 1000)
            if isinstance(data, bytes):
                data = data.decode('utf-8', 'ignore')
            trans_calls = [
                (datetime.fromisoformat, str),
                (datetime.fromordinal, int),
                (datetime.utcfromtimestamp, float),
                (datetime.fromtimestamp, float),
            ]
            for f, tp in trans_calls:
                try:
                    return f(tp(data))
                except (TypeError, ValueError):
                    pass
            for f in DATETIME_FORMATS:
                try:
                    val = datetime.strptime(data, f)
                    if data.endswith('GMT') or data.endswith('Z') and 'T' in data:
                        val = val.replace(tzinfo=timezone.utc)
                    return val
                except (TypeError, ValueError, re.error):
                    pass
        elif t == timedelta:
            try:
                return timedelta(seconds=float(data))
            except (ValueError, TypeError):
                pass
            tm = time.fromisoformat(str(data))
            return timedelta(hours=tm.hour, minutes=tm.minute,
                             seconds=tm.second, microseconds=tm.microsecond)
        elif t == date:
            if isinstance(data, datetime):
                return date(year=data.year, month=data.month, day=data.day)
            trans_calls = [
                (date.fromisoformat, str),
                (date.fromordinal, int),
                (date.fromtimestamp, float),
            ]
            for f, t in trans_calls:
                try:
                    return f(t(data))
                except (TypeError, ValueError):
                    continue
        elif t == time:
            if isinstance(data, datetime):
                return time(hour=data.hour, minute=data.minute, second=data.second, microsecond=data.microsecond)
            return time.fromisoformat(str(data))
        return t(data)
    except Exception as e:
        raise TypeError(f"Data: <{readable(data)}> cannot match or "
                        f"transform to type: {t}, \n with error: {str(e)}")
