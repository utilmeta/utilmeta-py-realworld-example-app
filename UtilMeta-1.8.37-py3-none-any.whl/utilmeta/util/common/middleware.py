from django.utils.deprecation import MiddlewareMixin
from utilmeta.util.common import ReqType, Header, localhost, pop
from django.http.response import HttpResponseBase


class CookieMiddleware(MiddlewareMixin):
    def process_response(self, request: ReqType, response: HttpResponseBase):
        origin = request.headers.get(Header.ORIGIN)

        if origin and localhost(origin):
            for key in response.cookies.keys():
                cookie = response.cookies[key]
                pop(cookie, 'domain')
                if not localhost(request.get_host()):
                    cookie['samesite'] = 'None'
        return response
