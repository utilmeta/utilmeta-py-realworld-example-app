import os
from utilmeta.util.common import SEG, import_util, PY, INIT_FILE, COMMON_TYPES
from .base import Util


class EnvMeta(type, Util):
    def __init__(cls, name, bases: tuple, attrs: dict, **kwargs):
        super().__init__(name, bases, attrs)
        Util.__init__(cls, locals())

        if not bases:
            return
        cls.__declare__ = False    # declarative class directly extend Env
        cls.__key__ = kwargs.get('key', kwargs.get('name', cls.__module__))

        cls.__key_defaults__ = {}
        cls.__key_types__ = {}
        cls.__requires__ = set()

        cls.__resolver__ = {}
        cls.__variables__ = {}

        variables = {}
        for key, val in attrs.items():
            key: str
            if key.startswith(SEG) or key.endswith(SEG):
                continue
            variables[key] = val
            # keys.append(key)
        cls.__variables__ = variables

        base: EnvMeta = cls.__base__
        if base is Env:
            cls.__key_defaults__ = dict(cls.__variables__)
            cls.__key__ = None
            cls.__declare__ = True

            for key, t in cls.__annotations__.items():
                if t in COMMON_TYPES:
                    cls.__key_types__[key] = t
                cls.__requires__.add(key)

        elif cls.__key__:
            cls.__key_defaults__ = base.__key_defaults__
            for key, default in cls.__key_defaults__.items():
                if key not in cls.__variables__:
                    cls.__variables__[key] = default

            excess = set(base.__requires__).difference(cls.__variables__)
            if excess:
                raise NotImplementedError(f'Environment: <{cls.__key__}> not implement these keys: {excess}')
            base.__resolver__[cls.__key__] = cls
            for key, val in base.__key_defaults__.items():
                cls.valid(key=key, temp=base.__key_types__.get(key), impl=cls.__variables__[key])

        else:
            raise NotImplementedError('Env class based on Env must implement specific a environment key, '
                      f'use class EnvImpl({cls.__base__.__name__}, key=<ENV_KEY>) to implement')

    @classmethod
    def valid(mcs, key: str, temp, impl):
        if not temp:
            return
        if not isinstance(impl, temp):
            raise TypeError(f'Env valid key: {key} failed: '
                            f'implement {repr(impl)} is not instance of base type: {type(temp)}')


class Env(metaclass=EnvMeta):
    def __init_subclass__(cls, **kwargs):
        base = cls.__base__
        assert len(cls.__bases__) < 2, f'Env can only be single extend'
        if base is Env:
            assert 'key' not in kwargs,  \
                f'Env implements must use key in declaration'

    def __init__(self, path: str = os.getcwd()):
        if not os.path.exists(path):
            raise ValueError(f'Env should initialize with __file__ param as path, got unexists path: {path}')
        self.path = path
        self.base = os.path.dirname(path)
        if not self.__declare__:
            return
        from utilmeta.bin.meta import MetaManagement
        service = MetaManagement(cwd=path).service
        if not service:
            raise ValueError(f'env should initialize inside service path with meta.ini in the outer scope')
        self.load_implementations()
        env = self.__resolver__.get(service.environment, self)
        for key, val in env.__variables__.items():
            setattr(self, key, val)

    def load_implementations(self):
        root, dirs, files = list(os.walk(self.base))[0]
        for file in files:
            if file.endswith(PY):
                if file == INIT_FILE:
                    continue
                import_util(os.path.join(self.base, file))
