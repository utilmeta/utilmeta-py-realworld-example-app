import traceback
from typing import Type, Dict, Callable, Optional, List, Any
from .common import Attr, SEG, readable, exc
from .base import Util
import sys
import inspect


class Error(Util):
    def __init__(self, e: Exception = None):
        super().__init__(locals())
        if isinstance(e, Exception):
            self.exc = e
            self.type = e.__class__
            self.exc_traceback = e.__traceback__
        elif isinstance(e, Error):
            self.exc = e.exc
            self.type = e.type
            self.exc_traceback = e.exc_traceback
        else:
            exc_type, exc_instance, exc_traceback = sys.exc_info()
            self.exc = exc_instance
            self.type = exc_type
            self.exc_traceback = exc_traceback

        trace = ''.join(traceback.format_tb(self.exc_traceback))
        if self.origin:
            origin_text = f'original error: {self.origin}\n'
            self.traceback = trace + origin_text + self.origin.traceback
            self.locals = self.origin.locals
        else:
            self.traceback = trace
            try:
                self.locals: Dict[str, Any] = self.clean_kwargs(inspect.trace()[-1][0].f_locals)
            except IndexError:
                self.locals = {}

        variables = []
        if self.locals:
            variables.append('Exception Local Variables:')
        for key, val in self.locals.items():
            if key.startswith(SEG) and key.endswith(SEG):
                continue
            try:
                variables.append(f'{key} = {readable(val, max_length=100)}')
            except Exception as e:
                print(f'Variable <{key}> serialize error: {e}')
        self.variable_info = '\n'.join(variables)
        self.combined = isinstance(self.exc, exc.CombinedError)
        self._errors = [Error(err) for err in self.exc.errors] if self.combined else []
        if self.combined:
            self.full_info = 'Combined multiple errors:\n' \
                             + ('\n' + '-' * 60 + '\n').join([err.full_info for err in self._errors])
        else:
            self.full_info = '\n'.join([self.message, *variables])

    def __str__(self):
        return f'<{self.type.__name__}: {str(self.exc)}>'

    def __iter__(self):
        return iter(self._errors)

    @property
    def message(self) -> str:
        return '{0}{1}: {2}'.format(
            self.traceback,
            self.type.__name__,
            self.exc
        )

    @property
    def origin(self) -> Optional['Error']:
        parents = self.parents
        return parents[0] if parents else None

    @property
    def parents(self) -> List['Error']:
        return getattr(self.exc, Attr.PARENTS, [])

    @property
    def target(self) -> 'Error':
        errors = []
        target = None
        for e in [*self.parents, self]:
            if str(e) in errors:
                continue
            errors.append(str(e))
            target = e
        return target or self

    @property
    def status(self) -> int:
        from utilmeta.conf import config
        if self.combined:
            status = 400
            for err in self._errors:
                s = config.http_config.error_status.get(err.type)
                if s > status:
                    status = s
            return status
        return config.http_config.error_status.get(self.type, 500)

    def log(self, logger=None, console: bool = False) -> int:
        from .log import Logger
        target = self.target
        if isinstance(logger, Logger):
            logger.resolve(brief=str(target), msg=target.full_info, status=self.status)
        if console:
            print(target.full_info)
        return self.status

    @property
    def cause_func(self):
        stk = traceback.extract_tb(self.exc_traceback, 1)
        return stk[0][2]

    def throw(self, type=None, prepend: str = '', **kwargs):
        if not (inspect.isclass(type) and issubclass(type, Exception)):
            type = None
        type = type or self.type
        if prepend or not isinstance(self.exc, type):
            e = type(f'{prepend}{self.exc}', **kwargs)
        else:
            e = self.exc
        parents: list = self.parents
        parents.append(self)
        setattr(e, Attr.PARENTS, parents)
        # raise e
        # it need the throw caller to raise the error like: raise Error().throw()
        # cause in that way can track the original variables
        return e

    def get_hook(self, hooks: Dict[Type[Exception], Callable]) -> Optional[Callable]:
        if not hooks:
            return None

        def _get(_e):
            for et, func in hooks.items():
                if et is Exception:
                    continue
                if isinstance(_e, et):
                    return func

        hook = _get(self.exc)
        if hook:
            return hook

        default = hooks.get(Exception)
        if self.combined:
            values = set()
            for err in self:
                _hook = _get(err)
                if _hook:
                    values.add(_hook)
            if len(values) == 1:
                return values.pop()

        return default
