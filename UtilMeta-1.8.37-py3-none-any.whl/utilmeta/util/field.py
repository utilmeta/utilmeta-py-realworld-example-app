from .rule import Rule, Bound
from .media import File
from .common import add_field_id, pop, FIELDS_TYPE, Key, exp, exc, \
    get_fields, Reg, get_field_name, SEG, PK, get_exp_field, model_tag, \
    one_to, many_to, get_pk, is_pk, multi, get_field, import_util, get_field_addon
from .base import Util
from .operator import Operator
from django.db.models.expressions import BaseExpression, CombinedExpression
from django.core.exceptions import FieldDoesNotExist
from django.db.models import ManyToManyField, QuerySet
from django.db.models import Field as FieldBase
from django.db.models.base import ModelBase, Model
from django.db.models.fields import NOT_PROVIDED
import inspect
from utilmeta.types import *


if TYPE_CHECKING:
    from utilmeta.core import module as _module
    from .auth import Auth

SM = 32767
MD = 2147483647
LG = 9223372036854775807
_type = type
_model_rules = {}


class Field(Util):
    class F:
        @property
        def field_name(self):
            return self.__class__.__name__ + 'Field'

        @property
        def field_class(self):
            return import_util(f'utilmeta.fields:{self.field_name}')

    class Date(date, F): pass
    class Array(list, F): pass
    class JSON(dict, F): pass
    class DateTime(datetime, F): pass
    class UUID(UUID, F): pass
    class Text(str, F): pass
    String = Text
    Char = Text
    class Time(time, F): pass
    class RichText(str, F): pass
    class URL(str, F): pass
    class Email(str, F): pass
    class FilePath(str, F): pass
    class IPAddress(str, F): pass
    class Password(str, F): pass
    class Binary(bytes, F): pass
    class Integer(int, F): pass
    class Boolean(int, F): pass     # TypeError: type 'bool' is not an acceptable base type
    class Decimal(Decimal, F): pass
    class Float(float, F): pass

    def __init__(self, name=None, *, retain: bool = True, require: bool = True,
                 readonly: bool = None,
                 writeonly: bool = None,
                 allow_creation: bool = None,
                 relate_creation: bool = False,
                 # auto_user_id: bool = False,
                 type: _type = None,
                 write_auth: Union['Auth', Callable] = None,
                 read_auth: Union['Auth', Callable] = None,
                 forbid_silently: bool = True,
                 operator: Union[Operator, List[Operator]] = None,
                 rule: Rule = None,
                 document: str = None,
                 alias: str = None,
                 default=...,
                 request_expression: Callable = None,
                 # options for many relate field
                 relate_query: Union[exp.Q, Callable] = None,
                 relate_order_by: Union[str, List[str], Callable] = None,
                 module: Union[str, Type['_module.Module']] = None,
                 module_auth: bool = False,
                 mixin_module_filters: bool = None,
                 module_sole_relates: bool = False,
                 mount: bool = False,
                 service: str = None    # Cross service relate field (not-registered in the model)
                 ):

        self.exp = None
        if isinstance(name, CombinedExpression):
            self.exp = name
            name = ''
        elif isinstance(name, BaseExpression):
            self.exp = name
            name = get_exp_field(name)
            if readonly is None:
                readonly = True
        else:
            # some non-fk field may end with _id
            name = get_field_name(name)

        if request_expression:
            if readonly is None:
                readonly = True

        if writeonly:
            retain = True

        if not retain:
            if readonly is None:
                readonly = True

        if SEG in name:
            # if readonly is explicitly set to False in this case
            # it can still remain False, as the upper-layer may wants to custom in hooks
            if readonly is None:
                readonly = True

        if read_auth or write_auth:
            require = False
            # field that have read auth might be exclude
        elif readonly or writeonly:
            require = False
        elif isinstance(rule, Rule):
            require = rule.require

        super().__init__(locals())

        self.name = name
        self.alias = alias
        self.retain = retain
        # if self.name == 'pk':
        #     raise ValueError('"pk" field is reserved for query, use another name')
        if rule:
            assert isinstance(rule, Rule) or isinstance(rule, File)
            # if isinstance(rule, Rule):
            #     assert not rule.alias, f"Field inner Rule must not have alias, got {rule.alias}"
        self.rule: Rule = rule or Rule()
        if not require:
            self.rule = Rule.optional(self.rule)
        if default is not ...:
            self.rule = Rule.make_default(self.rule, default=default)

        self.require = bool(require)
        self.default = default
        self.mount = mount
        self.mixin_module_filters = mixin_module_filters

        if readonly and writeonly:
            raise ValueError('Field readonly and writeonly cannot be set both')

        if write_auth:
            from .auth import Auth
            if not isinstance(write_auth, Auth):
                assert callable(write_auth), f"Field write_auth must be instance of Auth or callable, got {write_auth}"
                write_auth = Auth(require=write_auth)
            assert not readonly, f"Field with write_auth must be a writable field"
        if read_auth:
            from .auth import Auth
            if not isinstance(read_auth, Auth):
                read_auth = Auth(require=read_auth)
                assert callable(read_auth), f"Field read_auth must be instance of Auth or callable, got {read_auth}"

        if operator:
            if multi(operator):
                for op in operator:
                    assert isinstance(op, Operator), \
                        f'Field operator must be Operator objects or Operator list, got {op}'
            else:
                assert isinstance(operator, Operator), f'Field operator must be instance of Operator, got {operator}'
            assert not readonly, f'Field operator only support for writable field'
        if document:
            assert isinstance(document, str), f'Field document must be str, got {document}'

        # self.field = None
        self.document = document
        self.read_auth = read_auth
        self.write_auth = write_auth
        self.forbid_silently = forbid_silently
        self.readonly = readonly
        self.writeonly = writeonly
        self.allow_creation = allow_creation
        self.relate_creation = relate_creation
        # self.auto_user_id = bool(auto_user_id)
        self.operator = operator
        self.attname = None
        if relate_query:
            assert isinstance(relate_query, exp.Q) or callable(relate_query),\
                f'Field relate_query must be a Q object or callable, got {relate_query}'
        self.relate_query = relate_query
        self.relate_order_by = relate_order_by

        self.model = None
        self.module = None
        self.module_str = None
        self.service_name = service

        if module:
            if isinstance(module, str):
                self.module_str = module
            else:
                from utilmeta.core.module import Module
                assert issubclass(module, Module), \
                    f'Field module must be a Module subclass or string like <app_label>.<module_name>, got {module}'
                self.module = module
        self.module_auth = module_auth
        self.module_sole_relates = module_sole_relates
        self.field: Optional[FieldBase] = None
        self.remote_name = None
        # ADAPT TO MODEL FIELDS ----------------
        self.field_type = None
        self.field_kwargs = {}
        self._module_setters = []
        self.request_expression = request_expression
        # self.base_filter = base_filter
        # self.order_by = order_by
        # self.client_order = client_order    # allow client use <field>@order to select an order for relate field
        # self.page = page    # allow client use <field>@page <field>@rows to select a page

    def __deepcopy__(self, memo):
        field = self.__copy__()
        field.attname = self.attname
        return field

    def append_module_setter(self, setter):
        self._module_setters.append(setter)

    @property
    def with_module(self):
        return bool(self.module or self.module_str)

    @property
    def keys(self):
        # return name instead of attname
        if not self.operator:
            return self.name
        keys = []
        for opt in self.operator.options:
            if opt == '=':
                keys.append(self.name)
            else:
                keys.append(self.name + opt)
        return keys

    def copy_for_query(self):
        field = self.__copy__()
        if field.writeonly:
            field.writeonly = False
            field.retain = False
        return field

    @classmethod
    def reproduce(cls, attname: str, origin=None, rule: Rule = None):
        kwargs = {}
        name = attname
        if isinstance(origin, Field):
            name = origin.exp or origin.name or attname
            kwargs = dict(origin.__spec_kwargs__)
            if origin.rule:
                rule = Rule.merge(base=rule, rule=origin.rule)
        elif isinstance(origin, BaseExpression):
            name = origin
        kwargs['name'] = name
        kwargs['rule'] = rule
        field = cls(**kwargs)
        field.attname = attname
        return field

    @classmethod
    def get_first_base(cls, model) -> Type[Model]:
        from django.db.models.options import Options
        meta: Options = getattr(model, Key.META)
        parents = meta.get_parent_list()
        return parents[0] if parents else None

    @property
    def abstract_allowed(self):
        """
        Field can unrelated to any model fields
        """
        if self.module_str or self.module:
            return False
        # writeonly field might take dev-defined fields from client side
        # to alter other fields or models, for the fact that writeonly field does not
        # require read for db, so it does not needed to be a model field
        return not self.retain or self.writeonly

    def read_value(self, request, queryset: QuerySet, one: bool = False):
        if self.writeonly:
            raise exc.MethodNotAllowed(allows=['put'])
        if not self.model or not self.field:
            raise NotImplementedError
        if self.read_auth:
            self.read_auth(request, resource=queryset)
        if not issubclass(queryset.model, self.model):
            raise exc.BadRequest(f'Invalid operation')
        if one:
            inst = queryset.first()
            if not inst:
                raise exc.NotFound
            return self.rule(getattr(inst, self.field.name))
        return [self.rule(v) for v in queryset.values_list(self.field.name, flat=True)]

    def write_value(self, request, queryset: QuerySet, data=None):
        if self.readonly:
            raise exc.MethodNotAllowed(allows=['get'])
        if not self.model or not self.field:
            raise NotImplementedError
        if self.write_auth:
            self.write_auth(request, resource=queryset)
        if not issubclass(queryset.model, self.model):
            raise exc.BadRequest(f'Invalid operation')
        data = self.rule(data)
        queryset.update(**{self.field.name: data})

    @classmethod
    def get_field_rule(cls, field, addon: str = None):
        from .filter import ADDON_LOOKUP_RULES
        if not addon:
            return cls.get_rule(field).simplify()
        return ADDON_LOOKUP_RULES.get(addon, Rule())

    def check(self, model, schema=None):
        assert self.name, f'Field must assign a name'
        self.model = model

        if self.exp:
            try:
                field = self.exp.output_field
            except AttributeError:
                from django.db.models import QuerySet
                ann = QuerySet(model=self.model).annotate(v=self.exp).query.annotations['v']
                field = ann.output_field
        else:
            try:
                field, addon = get_field_addon(self.model, self.name)
            except FieldDoesNotExist as e:
                field = None
                if not self.abstract_allowed:
                    raise e

        if isinstance(field, FieldBase):
            if field.primary_key or not field.editable:
                self.readonly = True
            if self.is_auto(field):
                if self.readonly is None:
                    self.readonly = True
                if self.allow_creation is None:
                    self.allow_creation = False
        else:
            if self.readonly is None:
                self.readonly = True

        self.field = field

        # if SEG not in self.name and field:
        #     # if SEF in name, there may be wrap on the field rule, such as tags__name
        #     self.rule = self.rule & self.get_field_rule(field, addon=addon)
        # do not merge with raw field

        if many_to(field):
            self.remote_name = field.remote_field.get_cache_name()

        def check_module():
            assert many_to(field), f'Field module is for many-related field, got {field}'
            assert self.module.model == field.related_model, \
                f"Field module's model: {self.module.model}" \
                f" must be field.related_model: {field.related_model}"
            # rel_key = field.remote_field.name

            def check_schema(_s):
                assert inspect.isclass(_s) and (issubclass(self.module.schema, _s)
                                                or issubclass(_s, self.module.schema)), \
                    f'Field correspond schema: {_s} must be Field' \
                    f' module schema: {self.module.schema} or it base class / subclass'

                # if rel_key:
                #     keys = {rel_key, add_field_id(rel_key)} if one_to(field.remote_field) else {rel_key}
                #     assert set(keys).intersection(_s.__template__),\
                #         f'Field with module: {self.module} schema: {_s} must declare field relate key: {keys}'

            if isinstance(schema, tuple):
                for s in schema:
                    check_schema(s)
            else:
                check_schema(schema)
            # check_schema(self.module.schema)

        if self.module_str:
            from utilmeta.conf import config
            from utilmeta.core.module import Module

            def setter(mod):
                if self.module:
                    return
                self.module = mod
                for _set in self._module_setters:
                    _set(mod)
                check_module()

            config.app.register_referrer(
                self.__declare_path__,
                lazy_str=self.module_str,
                cls=Module, setter=setter
            )
        elif self.module:
            check_module()
        if self.relate_query:
            assert field and field.related_model, f'Field relate_query only apply to relate fields, got {field}'
        if self.read_auth:
            self.read_auth.model = model
            self.read_auth.check('get')
        if self.write_auth:
            self.write_auth.model = model
            self.write_auth.check('put')

    @classmethod
    def get_type(cls, f):
        from ..fields import ArrayField, BaseField
        if isinstance(f, str):
            return str
        if isinstance(f, ModelBase):
            f = get_pk(f)
        if one_to(f) and f.related_model:
            return cls.get_type(f.related_model)
        elif many_to(f):
            return [cls.get_type(f.target_field)]
        elif isinstance(f, ArrayField):
            return [cls.get_type(f.base_field)]
        if not isinstance(f, BaseField):
            raise TypeError(f'Invalid field: {f}')

        _t = f.get_internal_type()
        for fields, t in FIELDS_TYPE.items():
            if multi(fields) and _t in fields:
                return t
            if _t == fields:
                return t

        try:
            from utilmeta.fields import RangeField
            if isinstance(f, RangeField):
                t = cls.get_type(f.base_field)
                return Rule(template=(t, t))
        except ImportError:
            return str
        return str

    def gen_operators(self, model):
        operators = {}
        if self.operator:
            if multi(self.operator):
                for opt in self.operator:
                    operators.update(opt.copy(field=self.name, model=model, rule=self.rule))
            else:
                operators.update(self.operator.copy(field=self.name, model=model, rule=self.rule))
        return operators

    @classmethod
    def is_auto(cls, field: FieldBase):
        from utilmeta.fields import SmallAutoField, AutoField, BigAutoField, DistributedID
        if field.related_model:
            return False
        param = field.deconstruct()[3]
        auto_now_add = param.get('auto_now_add')
        auto_now = param.get('auto_now')
        auto_created = param.get('auto_created')
        auto_field = isinstance(field, (AutoField, SmallAutoField, BigAutoField, DistributedID))
        return auto_now_add or auto_now or auto_created or auto_field

    # @classmethod
    # def get_default(cls, field: FieldBase):
    #     if field.related_model:
    #         return False
    #     param = field.deconstruct()[3]
    #     auto_now = param.get('auto_now')
    #     if auto_now:
    #         # django will not update auto_now field
    #         # manually add default
    #         return datetime.now
    #     return None

    @classmethod
    def is_optional(cls, field: FieldBase) -> bool:
        from utilmeta.fields import OneToOneRel
        if many_to(field) or isinstance(field, OneToOneRel):
            return True
        return field.default != NOT_PROVIDED or field.null or cls.is_auto(field)

    @classmethod
    def get_rule(cls, field: FieldBase) -> Rule:
        import datetime
        import uuid
        from utilmeta.fields import \
            ChoiceField, PasswordField, DecimalField, TimeField, PositiveBigIntegerField, \
            DateField, ArrayField, UUIDField, EmailField, JSONField, DateTimeField, \
            PositiveSmallIntegerField, PositiveIntegerField, SmallIntegerField, \
            IntegerField, BigIntegerField, BigAutoField, AutoField, OneToOneRel
        from utilmeta.dist.id import DistributedID

        _t = cls.get_type(field)
        if many_to(field) or isinstance(field, OneToOneRel):
            return Rule(type=_t, field=field.name)

        kwargs = dict(field=field.name)

        if type(_t) == type:
            kwargs[Bound.type] = _t
        else:
            kwargs[Bound.template] = _t

        # default = cls.get_default(field)
        # if default:
        #     kwargs[Bound.default] = default

        param = field.deconstruct()[3]
        if isinstance(field, ChoiceField):
            kwargs[Bound.choices] = field.value_set
        elif param.get(Bound.max_length):
            kwargs[Bound.max_length] = param[Bound.max_length]
        if param.get(Bound.min_length):
            kwargs[Bound.min_length] = param[Bound.min_length]
        if 'max_value' in param:
            kwargs[Bound.le] = param['max_value']
        if 'min_value' in param:
            kwargs[Bound.ge] = param['min_value']

        if isinstance(field, PasswordField) and field.regex:
            kwargs[Bound.regex] = field.regex
        elif isinstance(field, EmailField):
            kwargs[Bound.regex] = Reg.EMAIL
        elif isinstance(field, UUIDField):
            kwargs[Bound.type] = uuid.UUID
        elif isinstance(field, DecimalField):
            kwargs[Bound.max_length] = field.max_digits
            kwargs[Bound.round] = field.decimal_places
        # for the reason that IntegerField is the base class of All integer fields
        # so the isinstance determine will be the last to include
        elif isinstance(field, IntegerField):

            if isinstance(field, PositiveSmallIntegerField):
                kwargs[Bound.ge] = 0
                kwargs[Bound.le] = SM
            elif isinstance(field, AutoField):
                kwargs[Bound.ge] = 1
                kwargs[Bound.le] = MD
            elif isinstance(field, BigAutoField):
                kwargs[Bound.ge] = 1
                kwargs[Bound.le] = LG
            elif isinstance(field, BigIntegerField):
                kwargs[Bound.ge] = -LG
                kwargs[Bound.le] = LG
            elif isinstance(field, PositiveBigIntegerField):
                kwargs[Bound.ge] = 0
                kwargs[Bound.le] = LG
            elif isinstance(field, PositiveIntegerField):
                kwargs[Bound.ge] = 0
                kwargs[Bound.le] = MD
            elif isinstance(field, SmallIntegerField):
                kwargs[Bound.ge] = -SM
                kwargs[Bound.le] = SM
            else:
                kwargs[Bound.ge] = -MD
                kwargs[Bound.le] = MD

        elif isinstance(field, TimeField):
            kwargs[Bound.type] = datetime.time
        elif isinstance(field, DateTimeField):
            kwargs[Bound.type] = datetime.datetime
        elif isinstance(field, DateField):
            kwargs[Bound.type] = datetime.date
        elif isinstance(field, ArrayField):
            base = field.base_field
            if isinstance(base, ChoiceField):
                kwargs[Bound.choices] = base.value_set
                kwargs[Bound.multiple] = True
            else:
                kwargs[Bound.template] = [cls.get_rule(base).simplify()]
            if field.size:
                kwargs[Bound.max_length] = field.size
        elif isinstance(field, JSONField):
            pop(kwargs, Bound.type)
            kwargs[Bound.type] = (dict, list)
        if field.null:
            kwargs[Bound.null] = True
        if cls.is_optional(field):
            # do not need to set default here, it's redundant when create instance
            # (since the missing value will use field default), and may cause wrong value when updating
            # (the missing value means not update, stay the same, but set default will turn it to a wrong value)
            # kwargs[Bound.default] = field.default
            kwargs[Bound.require] = False
        if isinstance(field, DistributedID):
            from utilmeta.dist.id import IDGenerator
            kwargs[Bound.validator] = IDGenerator(model=field.model).resolve
        return Rule(**kwargs)

    @classmethod
    def cached_rules(cls, model: Type[Model]):
        # this method is obsolete and remain here as a reminder
        # DO NOT use rules cache for model
        # because when a cached attribute is set to base model class
        # all of it's child model will be affected
        # use dict cache instead
        global _model_rules
        rules = _model_rules.get(model)
        if not rules:
            rules = cls.rules(model, redundant=True)
            _model_rules[model] = rules
        return rules

    @classmethod
    def rules(cls, model: Type[Model], many: bool = True, editable: bool = None, redundant: bool = False):
        data = {}
        for f in get_fields(model, many=many):
            if cls.is_auto(f):
                continue
            if editable and not f.editable:
                continue
            if isinstance(f, ManyToManyField):
                through: Type[Model] = getattr(model, f.name).rel.through
                requires = 0
                for _f in get_fields(through, many=True):
                    if not Field.is_optional(_f):
                        requires += 1
                if requires > 2:
                    # there exist a through table with more fields that is not defaulted, don't directly set
                    continue
            rule = cls.get_rule(f)
            name = f.name
            if one_to(f):
                name = add_field_id(name)
                if redundant:
                    data[f.name] = rule.simplify()
                else:
                    rule = Rule.add_alias_from(rule, f.name)
            data[name] = rule.simplify()
        return data

    @classmethod
    def gen_for(cls, model: Type[Model], optional: bool = False):
        template = cls.rules(model, many=False)
        if optional:
            return {key: Rule.optional(val) for key, val in template.items()}
        return template

    @classmethod
    def gen_field_values(cls, model: Type[Model]):
        from django.db.models import ForeignKey
        fields = {}
        for f in get_fields(model, many=False):
            name = f.name
            if one_to(f):
                name = add_field_id(f.name)
            rule = cls.get_rule(f)

            to_model = to_field = relate_name = None
            if isinstance(f, ForeignKey):
                to_model = cls.get_relate_model_tag(model, f.related_model)
                try:
                    to_field = f.to_fields[0]
                except IndexError:
                    pass
                relate_name = f.remote_field.get_cache_name()

            data = dict(rule.dict)
            # pop(data, '@')        # stay for frontend
            data.update(
                primary_key=f.primary_key,
                foreign_key=one_to(f),
                readonly=not f.editable,
                unique=f.unique,
                index=f.db_index,
                null=f.null,
                require=f.default is NOT_PROVIDED,
                category=f.__class__.__name__,
                verbose_name=f.verbose_name,
                to_model=to_model,
                to_field=to_field,
                relate_name=relate_name
            )

            fields[name] = data
        return fields

    @classmethod
    def get_relate_model_tag(cls, model, related_model):
        meta = getattr(model, '_meta')
        app = meta.app_label
        if isinstance(related_model, str):
            if related_model == 'self':
                return model_tag(model, lower=True)
            return related_model.lower() if '.' in related_model \
                else f'{app}.{related_model.lower()}'
        return model_tag(related_model, lower=True)

    @classmethod
    def gen_relations(cls, model: Type[Model]):
        relations = {}
        from django.db.models import ManyToManyRel, ManyToManyField
        for field in get_fields(model, many=True):
            if not many_to(field):
                continue

            rel: ManyToManyRel = field.remote_field if isinstance(field, ManyToManyField) else field
            many = field if isinstance(field, ManyToManyField) else field.remote_field

            name = field.get_cache_name()
            relate_name = field.remote_field.get_cache_name()
            through_model = through_table = through_fields = None

            if isinstance(rel, ManyToManyRel):
                if rel.through:
                    through_model = cls.get_relate_model_tag(model, rel.through)
                    if issubclass(rel.through, Model):
                        through_table = getattr(rel.through, '_meta').db_table

                if rel.through_fields:
                    through_fields = list(rel.through_fields)

            if isinstance(many, ManyToManyField) and not through_table:
                through_table = many.db_table

            relations[name] = dict(
                to_model=cls.get_relate_model_tag(model, field.related_model),
                relate_name=relate_name,
                symmetrical=rel.symmetrical,
                through_fields=through_fields,
                through_table=through_table,
                through_model=through_model
            )
        return relations

    @classmethod
    def valid_order_bys(cls, model, orders: List[str]):
        fields = cls.all_fields(model)
        pk_name = get_pk(model).name
        values = []
        for o in orders:
            ne = '-' if o.startswith('-') else ''
            ro = o.lstrip('-')
            if ro in ('pk', 'id'):
                ro = pk_name
            try:
                get_field(model, ro, cascade=True)
            except FieldDoesNotExist:
                continue
            if ro not in fields:
                continue
            o = ne + ro
            if o not in values:
                values.append(o)
        return values

    @classmethod
    def all_fields(cls, model, redundant: bool = False, many: bool = False):
        fields = []
        for f in get_fields(model, many=many):
            if one_to(f):
                fields.append(add_field_id(f.name))
                if not redundant:
                    continue
            fields.append(f.name)
        return tuple(fields)

    @classmethod
    def key_field(cls, model, name: str):
        from utilmeta.fields import ForeignKey, OneToOneRel
        if name == PK:
            return True
        field = get_field(model, name)
        if is_pk(field, model=model):
            return True
        if isinstance(field, (ForeignKey, OneToOneRel)):
            return True
        return False

    @classmethod
    def parse_kwargs(cls, model, kwargs: dict, restrict_key: bool = False, include_many: bool = False):
        result = {}
        for key, val in kwargs.items():
            try:
                field = get_field(model, key, cascade=True)
                if not include_many and many_to(field):
                    continue
                if cls.key_field(model, key):
                    if isinstance(val, Model):
                        val = val.pk
                if one_to(field):
                    key = add_field_id(key)
            except FieldDoesNotExist:
                if restrict_key:
                    continue
            result[key] = val
        return result
