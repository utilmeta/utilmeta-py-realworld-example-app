from .rule import Rule
from .common import get_field_addon, FilterNote, get_field_name, many_to, \
    add_field_id, multi, unique_field, one_to, SEG, exp, analyze_func, \
    valid_attr, duplicate, Logic, copy_value, COMMON_ERRORS, get_exp_field, \
    option_allowed_lookups
from .base import Util
from typing import Dict, List, Callable, Any, Union
from django.db.models.expressions import BaseExpression
from datetime import date, time

OPTIONS = ('=', '~', '$', '>', '<', '%', '*', '!')
OPTION_MAP = FilterNote.reverse_map()
operations = FilterNote.options()
ADDON_LOOKUP_RULES = {
    'date': Rule(type=date),
    'time': Rule(type=time),
    'year': Rule(type=int, ge=0, le=9999),
    'iso_year': Rule(type=int, ge=0, le=9999),
    'month': Rule(type=int, ge=1, le=12),
    'day': Rule(type=int, ge=1, le=31),
    'week': Rule(type=int, ge=1, le=53),
    'week_day': Rule(type=int, ge=1, le=7),
    'quarter': Rule(type=int, ge=1, le=4),
    'hour': Rule(type=int, ge=0, le=23),
    'minute': Rule(type=int, ge=0, le=59),
    'second': Rule(type=int, ge=0, le=59),

    'len': Rule(type=int),
    'has_key': Rule(type=str),
    'has_any_keys': Rule(template=[str]),
    'has_keys': Rule(template=[str]),
    'keys': Rule(template=[str]),
    'values': Rule(type=list),

    'isempty': Rule(type=bool),
    'upper_inc': Rule(type=bool),
    'lower_inc': Rule(type=bool),
    'upper_inf': Rule(type=bool),
    'lower_inf': Rule(type=bool),
}

__all__ = ['Filter', 'ADDON_LOOKUP_RULES']


class Filter(Util):
    IN = FilterNote.IN
    exact = FilterNote.exact
    iexact = FilterNote.iexact
    startswith = FilterNote.startswith
    istartswith = FilterNote.istartswith
    endswith = FilterNote.endswith
    iendswith = FilterNote.iendswith
    contains = FilterNote.contains
    icontains = FilterNote.icontains
    gt = FilterNote.gt
    lt = FilterNote.lt
    gte = FilterNote.gte
    lte = FilterNote.lte
    regex = FilterNote.regex
    iregex = FilterNote.iregex
    isnull = FilterNote.isnull

    @staticmethod
    def val_opt(options):
        if options == '*':
            options = tuple(operations)
        else:
            dif = set(options).difference(operations)
            assert not dif,\
                ValueError(f'Filter options must be subset of {operations}, exceptions: {dif}')
            options = tuple(options)
        return options

    def __init__(self, *options, field=None,
                 require: bool = False, mixins: dict = None, alias: str = None,
                 rule: Union[type, Rule] = Rule(), sole: bool = False,
                 custom: bool = False,      # do not relate model fields. using in user-defined logics
                 custom_lookup: bool = False,
                 default=...,
                 value_exp: Callable[[Any], Any] = None,  # expression to convert a input string to a query value
                 query_exp: Callable[[Any], exp.Q] = None,  # expression to convert a input string to a Q object,
                 auto_user_id: bool = False,
                 set_as=..., assign: bool = False,
                 list_order: bool = False,
                 empty_allowed: bool = None
                 ):

        options = options or ('=',)
        super().__init__(locals())
        assert not duplicate(options), \
            f'Filter options must be distinct options, got duplicates: {duplicate(options)}'

        self.list_order = bool(list_order)
        if list_order:
            assert '^' in options, "Filter list_order only support ^ in option with unique field"
        self.options = self.val_opt(options)
        self.model = None
        self.empty_allowed = empty_allowed
        self.one = False

        self.exp = None
        if isinstance(field, BaseExpression):
            self.exp = field
            field = get_exp_field(field)
        self.field = get_field_name(field)
        self.alias = alias

        if isinstance(rule, type):
            rule = Rule(type=rule)
        assert isinstance(rule, Rule), f'Filter rule must be a Rule object, got {rule}'
        if default is not ...:
            rule = Rule.make_default(rule, default=default)

        if self.empty_allowed is False:
            rule &= Rule(min_length=1, message='Filter empty value is not allowed')
        self.rule = rule
        self.default = default
        self.require = bool(require)
        if not self.require:
            self.rule = Rule.optional(self.rule)

        if value_exp:
            value_exp, fr = analyze_func(value_exp)
            if fr:
                raise TypeError(f'Filter value_exp should be a function, staticmethod or lambda, got {value_exp}')
        if query_exp:
            query_exp, fr = analyze_func(query_exp)
            if fr:
                raise TypeError(f'Filter query_exp should be a function, staticmethod or lambda, got {query_exp}')
            inst = self.rule.instance
            try:
                test_q = query_exp(inst)
            except Exception as e:
                raise ValueError(f'Filter query_exp test inst: {inst} failed with error: {e}, \n'
                                 f'you should specify a rule for this Filter to generate a common test instance')
            if not isinstance(test_q, exp.Q) or not test_q:
                raise TypeError(f'Invalid query_exp, must return a Q object with query, got {test_q}')
        if value_exp or query_exp or mixins or sole:
            assert len(options) == 1, \
                f'Filter with query_exp or value_exp or mixins or sole=True must have only one option, got: {options}'

        if value_exp and query_exp:
            raise ValueError('Filter value_exp and query_exp cannot set both')
        self.value_exp = value_exp
        self.query_exp = query_exp
        self.auto_user_id = auto_user_id
        if auto_user_id:
            assert len(options) == 1, f'Filter(auto_user_id=True) must have only one option, got: {options}'
            assert set_as is ..., f'Filter(auto_user_id=True) could not define set_as, or you can use ' \
                                  f'Filter(set_as=lambda self: self.user_id)'

        if set_as is not ...:
            assert len(options) == 1, f'Filter with set_as can only support one query option, got: {options}'
            assert not mixins and not assign, f'Filter with set_as does not support mixins or assign enabled'

        if callable(set_as):
            from utilmeta.conf import config
            set_as = config.preference.function_parser_cls(set_as).wrapper
        if mixins:
            assert not assign and set_as is ..., f'Filter with mixins does not support assign or set_as'
        if assign:
            assert not mixins and set_as is ..., f'Filter with mixins does not support mixins or set_as'
        self.sole = sole
        self.set_as = set_as
        self.assign = assign
        self.mixins = mixins
        self.custom = custom

        # if lookup:
        #     assert isinstance(lookup, str), f'Filter lookup must be a str, got {lookup}'
        #     assert field, f'Filter with lookup specified should set field'
        #     assert not options, f'Filter with lookup specified should not set options, got {options}'
        self.custom_lookup = custom_lookup

    @property
    def field_name(self):
        if self.exp:
            return self.alias
        return self.field

    @property
    def first_key(self):
        if not self.alias:
            raise ValueError('Filter alias have not set')
        if not self.options or self.options[0] == '=' or self.sole:
            return self.alias
        return self.alias + self.options[0]

    @property
    def equal_only(self) -> bool:
        return len(self.options) == 1 and self.options[0] == '='

    @property
    def public(self):
        return self.set_as is ...

    def apply_mixin(self, reverse_field: str) -> 'Filter':
        if not self.field:
            raise ValueError(f'Filter not assigned alias')
        kwargs = dict(self.__spec_kwargs__)
        kwargs['field'] = SEG.join([reverse_field, self.field])
        return self.__class__(
            *self.options, **kwargs
        )

    def get_value(self, *args):
        if self.public:
            return ...
        try:
            if callable(self.set_as):
                return self.set_as(*args)
            return copy_value(self.set_as)
        except COMMON_ERRORS:
            return ...

    @classmethod
    def gen(cls, filters_dict: Dict[str, List['Filter']], model, allow_logic=False):
        template = {}
        for alias, filters in filters_dict.items():
            options = set()
            for f in filters:
                f: Filter
                inter = options.intersection(f.options)
                if inter:
                    raise ValueError(f'Filter for <{alias}> detect duplicate options: {inter}, please merge them')
                options.update(f.options)
                f.valid(model, alias)
                if not f.public:
                    continue
                if f.auto_user_id:
                    continue
                template.update(f.template())

        if allow_logic:
            template[Logic.OR] = template[Logic.AND] = \
                Rule(type=(list, dict), require=False,
                     converter=cls.convert_nested(template.keys()))
        return template

    @classmethod
    def convert_nested(cls, keys):
        def converter(data):
            if isinstance(data, dict):
                result = {}
                for key, val in data.items():
                    if key in (Logic.OR, Logic.AND):
                        result[key] = converter(val)
                    elif key in keys:
                        result[key] = val
                return result
            elif isinstance(data, list):
                return [converter(d) for d in data]
            else:
                raise TypeError(f'Invalid nested query struct data: {data}, must be a dict/list')
        return converter

    def template(self):
        from .field import Field
        from utilmeta.fields import ArrayField, ChoiceField
        if self.query_exp or self.custom:
            return {self.alias: self.rule}
        addon = None
        if self.exp:
            try:
                _field = self.exp.output_field
            except AttributeError:
                from django.db.models import QuerySet
                ann = QuerySet(model=self.model).annotate(v=self.exp).query.annotations['v']
                _field = ann.output_field
        else:
            _field, addon = get_field_addon(self.model, self.field, custom=self.custom_lookup)

        _rule = self.get_filter_rule(_field, addon=addon)

        template = {}
        for opt in self.options:
            rule = _rule    # prevent multiple access inconsistent
            if opt == '=':
                opt = ''

            if opt == FilterNote.isnull:
                rule = bool

            elif opt in (FilterNote.startswith, FilterNote.endswith):

                try:
                    from utilmeta.fields import RangeField
                    if isinstance(_field, RangeField):
                        rule = Field.get_rule(ArrayField(_field.base_field)).simplify()
                except (ImportError, ModuleNotFoundError):
                    pass

            elif opt and opt[-1] == '^':
                if not multi(rule):
                    if isinstance(_field, ChoiceField):
                        rule = Field.get_rule(ArrayField(_field)).simplify()  # just for ArrayField(ChoiceField)
                    else:
                        rule = [rule]

            rule = self.rule & rule
            if not self.require:
                rule = Rule.optional(rule)
            if self.sole:
                opt = ''

            template[self.alias + opt] = Rule.make_field(rule, self.get_field(opt))
        return template

    def get_field(self, opt):
        fields = [self.field] if self.field else []
        _not = opt.startswith(FilterNote.NOT)
        _in = opt.endswith(FilterNote.IN)
        _o = opt.lstrip(FilterNote.NOT).rstrip(FilterNote.IN)
        if _not:
            fields.append('not')
        if _o:
            note = FilterNote.get_option(_o)
            if note:
                fields.append(note)
        if _in:
            fields.append('in')
        return ':'.join(fields)

    @classmethod
    def get_filter_rule(cls, field, addon: str = None):
        from .field import Field
        if many_to(field):
            # for many to field, use remote_field type
            field_rule = Field.get_rule(field.target_field)
        else:
            field_rule = Field.get_rule(field)

        if not addon:
            return field_rule
        if addon == 'isnull':
            return Rule(type=bool)

        rule = ADDON_LOOKUP_RULES.get(addon)
        if rule:
            return rule
        try:
            from utilmeta.fields import HStoreField, ArrayField, RangeField
            if isinstance(field, ArrayField):
                if addon in ('contains', 'contained_by', 'overlap'):
                    return field_rule
            if isinstance(field, HStoreField):
                if addon in ('contains', 'contained_by'):
                    return field_rule
            if isinstance(field, RangeField):
                if addon in ('contains', 'contained_by', 'overlap', 'fully_gt', 'not_gt', 'adjacent_to'):
                    return field_rule
        except ImportError:
            return Rule()

    def valid(self, model, alias: str):
        from utilmeta.fields import CrossServiceKey
        self.model = model
        disallows = ('@', '.', '&', '|', ':') + OPTIONS
        invalids = set(alias).intersection(disallows)
        assert not invalids, ValueError(f'Filter alias: {repr(alias)} contains invalid chars {invalids}')
        if not self.public:
            if len(self.options) > 1:
                hint = "'%s': [%s]" % (alias, ', '.join(["Filter('%s', set_as=...)" % opt for opt in self.options]))
                raise ValueError(f'Filter options: {self.options} sharing one set_as, use:\n{hint}')

        self.alias = alias
        assert not set(alias).intersection(OPTIONS), \
            f'Filter alias: {alias} should not contains non-alnum notes'
        if self.query_exp:
            return
        if self.custom:
            return
        if not self.field:
            self.field = alias

        f, addon = get_field_addon(self.model, self.field, custom=self.custom_lookup)

        if addon:
            if addon not in option_allowed_lookups and not self.equal_only:
                raise ValueError(f'Filter addon: [{addon}] only allow further equal lookup,'
                                 f' other options: {self.options} are invalid')

        if one_to(f):
            self.field = add_field_id(self.field)
        if self.auto_user_id:
            from utilmeta.conf import config
            if isinstance(f, CrossServiceKey):
                if not config.auth.auth_service:
                    raise ValueError(f'Auth Filter auto_user_id: {f} must specify auth_service')
                assert f.service_name == config.auth.auth_service, \
                    f'Filter auto_user_id: CrossServiceKey(service={f.service_name}) ' \
                    f'must consistent to auth_service: {config.auth.auth_service}'
            else:
                if f.primary_key and issubclass(self.model, config.auth.UserModel):
                    pass
                else:
                    assert f.related_model and issubclass(f.related_model, config.auth.UserModel), \
                        f'Filter auto_user_id=True must relate to ' \
                        f'field of user_model: {config.auth.UserModel}, got {f.related_model}'

        if alias == 'id':
            assert f.primary_key, \
                f"Filter 'id' alias only support primary_key field, got {self.field}"
        if self.list_order:
            assert '^' in self.options and unique_field(f), \
                f"Filter list_order only support ^ in option with unique field, got {self.field}"
        self.one = '=' in self.options and f.model == self.model and unique_field(f)

    @classmethod
    def extract(cls, string: str):
        i = 1
        opt = ''
        exclude = False
        _in = False
        if string[-1] == FilterNote.IN:
            string = string[:-1]
            _in = True
        while True:
            s = string[-i]
            if s in OPTIONS:
                opt = s + opt
                i += 1
            else:
                break
        s = string[1-i]
        if opt and opt not in operations:
            raise ValueError(f'Invalid filter option: {opt}')
        if s == FilterNote.NOT:
            exclude = True
            opt = opt[1:]
        field = string[:1-i] if i > 1 else string
        if not valid_attr(field):
            raise ValueError(f'Invalid filter field: {field}')
        return field, opt, exclude, _in

    @classmethod
    def normalize(cls, name: str):
        field, opt, exclude, _in = cls.extract(name)
        result = field
        if exclude:
            result += SEG + 'not'
        if opt:
            result += SEG + OPTION_MAP[opt]
        if _in:
            result += SEG + 'in'
        return result

    def qualifier(self, name: str):
        from utilmeta.util.query import Lookup
        if self.public:
            raise TypeError(f'Filter with no set_as params does not support qualify method')
        key = name + self.options[0]
        name, opt, exclude, _in = self.extract(name + self.options[0])
        func = getattr(Lookup, opt, Lookup.exact)
        if _in:
            if opt:
                def func(v, lst): any(getattr(Lookup, opt)(v, item) for item in lst)
            else:
                func = Lookup.IN
        if exclude:
            func = Lookup.not_decorator(func)

        def q(data: dict):
            try:
                if name in data:
                    return func(data[name], self.set_as)
                elif self.field in data:
                    return func(data[self.field], self.set_as)
                elif exclude:
                    if name + opt in data:
                        return data[name + opt] != self.set_as
                elif _in:
                    if name + opt + exclude in data:
                        return data[name + opt + exclude] in self.set_as
                return data.get(key) == self.set_as
            except COMMON_ERRORS:
                return False
        return q
