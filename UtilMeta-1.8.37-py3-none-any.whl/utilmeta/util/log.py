import time
import os
from utilmeta.util.common import Static, LOG_LEVELS, ignore_errors, pop
from .base import Util
from typing import Union, Optional, TYPE_CHECKING, Dict, List, Tuple
from functools import wraps
import threading
from datetime import datetime, timedelta
import warnings


if TYPE_CHECKING:
    from utilmeta.core.unit import Unit


class TraceType(Static):
    span = 'span'
    stamp = 'stamp'


def level_log(f):
    lv = f.__name__.upper()
    if lv not in LOG_LEVELS:
        raise ValueError(f'Invalid log level: {lv}')
    index = LOG_LEVELS.index(lv)

    @wraps(f)
    def emit(self: 'Logger', brief: str, msg: str = None, **kwargs):
        return self.emit(brief, level=index, data=kwargs, msg=msg)
    return emit


@ignore_errors(log=False)
def log_queries(alias: str, count: int):
    from utilmeta.conf import config
    if not count or not config.ops:
        return
    cache = config.cluster.cache if config.cluster else config.ops.cache
    key = f'{config.cache_prefix}#{alias}-queries'
    return cache.incr(key, count)


@ignore_errors(default=(0, 0))
def pop_queries(alias: str) -> Tuple[float, float]:
    from utilmeta.conf import config
    key = f'{config.cache_prefix}#{alias}-queries'
    time_key = f'{config.cache_prefix}#{alias}-time'
    cache = config.cluster.cache if config.cluster else config.ops.cache
    prev_time = cache.get(time_key)
    cnt = cache.get(key) or 0
    cur_time = time.time()
    cache.set(time_key, cur_time)
    cache.set(key, 0)
    if not prev_time or not cnt:
        return cnt, 0
    qps = cnt / (cur_time - prev_time)
    return cnt, qps


_thread_logger: Dict[int, 'Logger'] = {}
# a process level dict to store thread-ident: logger items
# used to do context tracing, like lo


class Logger(Util):
    _MUTABLE = True
    OMIT = 'OMIT'       # omit this request and directly response (even for error status)
    VOLATILE = 'VOLATILE'     # (default) store this log, delete when no longer calculated by any monitors
    PERSIST = 'PERSIST'     # persist store the log, wait for manual clean up by admin
    # except for OMIT, all request with error (status >= 400 or level >= WARN) will be persist

    def __init__(self, *,
                 # invoke: bool = False,
                 to_service: str = None, to_instance: str = None,
                 from_process: int = None, from_thread: int = None,
                 root: bool = False, invoke: bool = False,
                 from_logger: 'Logger' = None, span_for: Union[str, 'Unit'] = None
                 ):
        super().__init__(locals())
        if from_process:
            assert from_thread, f'cross-process Logger must specify from_process and from_thread'
        self.to_service = to_service
        self.to_instance = to_instance
        self.from_process = from_process
        self.from_thread = from_thread

        from django.db import connections
        from utilmeta.conf import Log as LogConfig
        from utilmeta.conf import config

        self.init_time = from_logger.init_time if from_logger else time.time()
        self.invoke = invoke
        self.init = self.relative_time()
        self.duration = None
        self.from_logger = from_logger

        self.conn_proxy = {alias: connections[alias] for alias, db in config.databases.items()}
        # a pooled db queries cannot be properly distinct so far

        self.config = config.log or LogConfig()

        if self.config and self.config.log_db_query:
            for conn in self.conn_proxy.values():
                conn.force_debug_cursor = True

        self.root = not from_logger and root
        self.option = self.VOLATILE      # default
        self.cache = config.cluster.cache if config.cluster else config.ops.cache if config.ops else None

        self._level = 1
        self._prepared_span = None      # when calling Logger.span, set this attribute
        self._span_logger: Optional[Logger] = None               # when enter the prepared span, set this attribute

        self._span_for = span_for
        self._briefs = []
        self._messages = []     # message is only set in root logger (without from_logger)
        self._events = []

        self._init_queries_snapshot = self.get_queries_snapshot()
        self._queries_num = 0
        self._queries_duration = 0
        self._queries = {}
        self.id = None
        self._exited = False
        self._context_logger: Optional[Logger] = None
        self._derived_loggers: List[Logger] = []
        self._foreground = False
        self._queries_collected = False

        self._warnings_catcher = None
        self._warnings = []

        if self.root:
            global _thread_logger
            if self.invoke:
                self._context_logger = _thread_logger.get(self.thread_id)
                if self._context_logger:
                    self._context_logger.append(self)
            else:
                # _thread_logger is a dynamic per-process request handler thread -> logger map
                # that only set when this Logger is a root request handler logger
                # not other's span_logger (with from_logger) or in a request context (invoke=True)
                # set the process-level lo
                _prev_logger: Logger = _thread_logger.get(self.thread_id)
                if not _prev_logger or _prev_logger.id:
                    # when thread logger is empty or is obsolete
                    _thread_logger[self.thread_id] = self

    @property
    def context_logger(self) -> Optional['Logger']:
        return self._context_logger

    @property
    def derived_loggers(self) -> List['Logger']:
        return self._derived_loggers

    def append(self, logger: 'Logger'):
        if not self.root or self.invoke:
            return
        if not isinstance(logger, Logger):
            return
        self._derived_loggers.append(logger)

    @property
    def vacuum(self):
        return not self._events

    @property
    def messages(self):
        return self._messages

    @property
    def events(self):
        return self._events

    @property
    def queries(self):
        return self._queries

    @property
    def queries_num(self):
        return self._queries_num

    @property
    def queries_duration_ms(self):
        return self._queries_duration * 1000

    @property
    def level(self) -> int:
        return self._level

    @property
    def level_str(self) -> str:
        return LOG_LEVELS[self._level]

    @property
    def omitted(self):
        return self.option == self.OMIT

    def resolve(self, brief: str, msg: str = None, status: int = None):
        msg = msg or brief
        f = self.debug
        if isinstance(status, int):
            if status < 400:
                f = self.info
            elif status < 500:
                f = self.warn
            else:
                f = self.error
        return f(brief, msg=msg)

    @property
    def process_id(self):
        return self.from_process or os.getpid()

    @property
    def thread_id(self):
        return self.from_thread or threading.current_thread().ident

    def __call__(self, name: Union[str, 'Unit']):
        if self._span_logger:
            return self._span_logger(name)
        assert name, f'Empty scope name'
        self._prepared_span = name
        return self

    def __enter__(self) -> 'Logger':
        if self._span_logger:
            return self._span_logger.__enter__()
        if not self._prepared_span:
            return self
        logger = Logger(
            span_for=self._prepared_span,
            from_logger=self
        )
        logger._warnings_catcher = warnings.catch_warnings(record=True)
        logger._warnings = logger._warnings_catcher.__enter__()
        self._span_logger = logger
        return logger

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not self._span_logger:
            return
        self._span_logger: Logger
        self._span_logger.exit()
        self._events.append(self._span_logger.span)
        self._span_logger = self._prepared_span = None

    def relative_time(self):
        return int((time.time() - self.init_time) * 1000)

    def exit(self, do_exit: bool = False):
        if self._exited:
            return
        self._exited = True
        if self._span_logger:
            self._span_logger.exit(do_exit=do_exit)
        if self._warnings:
            for warn in self._warnings:
                self.warn(warn.message)
            self._warnings_catcher.__exit__()

        if self.duration is None:
            # forbid to recalculate
            self.duration = self.relative_time()
        if self.root:
            self.collect_queries()
        if do_exit:
            global _thread_logger
            pop(_thread_logger, self.thread_id)

    def _push_message(self, brief: str, msg: str = None):
        brief = str(brief)
        msg = str(msg or brief)
        if not msg:
            return None
        if self.from_logger:
            return self.from_logger._push_message(brief, msg)
        if brief not in self._briefs:
            self._briefs.append(brief)
        i = len(self._messages)
        if msg in self._messages:
            return self._messages.index(msg)
        self._messages.append(msg)
        return i

    def emit(self, brief: str, level: int, data: dict, msg: str = None):
        from .error import Error
        if isinstance(brief, Exception):
            brief = Error(brief)
        if isinstance(brief, Error):
            msg = brief.message
            brief = str(brief)

        if self._span_logger:
            return self._span_logger.emit(brief, level, data, msg=msg)
        if self._level < level:
            self._level = level
        name = LOG_LEVELS[level]
        self._events.append(dict(
            name=name,
            init=self.relative_time(),
            type=f'log.{name.lower()}',
            msg=self._push_message(brief, msg=msg),
            data=data
        ))

    @ignore_errors
    def save_api(self, request, response):
        from utilmeta.conf import config
        self.exit(do_exit=True)     # exit and set duration
        if not config.ops or self.omitted:
            return
        from utilmeta.util.request import Request
        from utilmeta.util.call import Call
        if isinstance(request, Request):
            if request.METHOD in self.config.exclude_http_methods:
                return
        elif isinstance(request, Call):
            if request.method in self.config.exclude_http_methods:
                return
        else:
            return
        return self.config.manager_cls.append_api_queue(request, response)

    @ignore_errors
    def foreground_save_api(self, request):
        from utilmeta.conf import config
        if not config.ops or not config.task or self.omitted or self.id:
            return
        from utilmeta.util.common import omit
        self._foreground = True
        return omit(self.config.manager_cls(self).save_api_log)(request)

    @property
    def foreground_saved(self):
        return self._foreground

    @ignore_errors(default=None)
    def wait_for_id(self):
        from utilmeta.conf import config
        if not config.ops or not config.task or self.omitted:
            return None
        if self.id or not config.cluster:
            return self.id
        timeout = self.config.foreground_save_timeout
        if not timeout:
            return None
        sleep = 0
        while sleep < timeout:
            t = timeout / 10
            time.sleep(t)
            if self.id:
                return self.id
            sleep += t
        return None

    def stamp(self, name: str):
        if self._span_logger:
            return self._span_logger.stamp(name)
        self._events.append(dict(
            name=name,
            type=TraceType.stamp,
            init=self.relative_time()
        ))

    @property
    def span(self):
        from utilmeta.core.unit import Unit
        if isinstance(self._span_for, Unit):
            return dict(
                name=self._span_for.name,
                type=self._span_for.log_type,
                parent=self._span_for.log_parent,
                init=self.init,
                time=self.duration,
                events=self._events,
                queries=self._queries_num
            )
        return dict(
            name=str(self._span_for),
            init=self.init,
            time=self.duration,
            type=TraceType.span,
            events=self._events,
            queries=self._queries_num
        )

    def get_db_queries(self):
        return {key: con.queries for key, con in self.conn_proxy.items() if con.queries}

    def get_queries_snapshot(self):
        return {key: len(con.queries) for key, con in self.conn_proxy.items()}

    def generate_query_logs(self):
        return self.config.manager_cls(self).generate_query_logs()

    def collect_queries(self):
        if self._queries_collected:
            return
        db_queries = {}
        total = 0
        total_duration = 0
        snapshot = self.get_queries_snapshot()
        from utilmeta.conf import config
        for alias, count in self._init_queries_snapshot.items():
            current = snapshot.get(alias) or 0
            if not current or current < count:
                continue
            queries = self.conn_proxy[alias].queries
            db = config.databases.get(alias)
            num = 0
            if current - count:
                sqls = []
                for query in queries[count:current]:
                    duration = float(query.get('time') or 0)
                    total_duration += duration
                    if not self.config.query_limit or duration > self.config.query_limit:
                        sqls.append(query)
                    if db.pooled and query.get('key') != db.get_pooled_key():
                        continue
                    num += 1
                total += num
                if sqls:
                    db_queries[alias] = sqls

                log_queries(alias=alias, count=num)

        self._queries = db_queries
        self._queries_num = total
        self._queries_duration = total_duration
        self._queries_collected = True

    @level_log
    def debug(self, brief: Union[str, Exception], msg: str = None, **kwargs):
        pass

    @level_log
    def info(self, brief: Union[str, Exception], msg: str = None, **kwargs):
        pass

    @level_log
    def warn(self, brief: Union[str, Exception], msg: str = None, **kwargs):
        pass

    @level_log
    def error(self, brief: Union[str, Exception], msg: str = None, **kwargs):
        pass

    @level_log
    def urgent(self, brief: Union[str, Exception], msg: str = None, **kwargs):
        pass
    
    @property
    def message(self) -> str:
        return '\n'.join(self._messages)

    @property
    def brief_message(self) -> str:
        return '; '.join(self._briefs)

    @property
    def expired(self):
        return datetime.now() - datetime.fromtimestamp(self.init_time) > \
               timedelta(seconds=self.config.process_context_timeout)

    @classmethod
    def expire_timeout_context(cls):
        with threading.Lock():
            global _thread_logger
            for key in list(_thread_logger):
                val: Logger = _thread_logger[key]
                if val.expired:
                    pop(_thread_logger, key)
