import random
import uuid
import math
import time
import datetime
import inspect
import os
from io import BytesIO
from django.http.response import FileResponse
from django.core.files import File as FileBase
from typing import Callable, Union, List
from .common import file_like, GeneralType, GENERAL_TYPES, \
    multi, readable_size, file_path, readable, pop, url_join, \
    ALIAS_FILE_SUFFIX, path_merge, exc, Header, static_require
from utilmeta.conf.deploy import SSH
from .base import Util
from .rule import BaseParam
from utilmeta.conf import config

if not config.resolved:
    raise ImportError('Utils should not be load before service resolve')

__all__ = ['Media', 'File']


class File(FileBase, BaseParam):
    type = '*'

    def __init__(self, *, type: str = None, suffix: Union[str, List[str]] = '*', max_size: int = None,
                 document: str = None, message: str = None,
                 alias_from: Union[str, List[str]] = None, alias_for: str = None, alias: str = None,
                 strict: bool = True, null: bool = False,
                 require: bool = True, default=..., **kwargs):

        __class__ = File
        if kwargs:
            FileBase.__init__(self, file=kwargs.get('file'), name=kwargs.get('name'))
        else:
            FileBase.__init__(self, None)
        BaseParam.__init__(**locals())

        if type is not None:
            assert type in GENERAL_TYPES, f"Invalid File type: <{type}>, should in {GENERAL_TYPES}"
            self.type = type
        self.suffix = self.gen_suffixes(suffix)
        if max_size:
            assert isinstance(max_size, int)
        self.max_size = max_size
        self.content_type = f'{type}/{suffix}'

    @property
    def common_type(self):
        if self.type == GeneralType.IMAGE:
            return 'Media.Image'
        if self.type == GeneralType.AUDIO:
            return 'Media.Audio'
        if self.type == GeneralType.VIDEO:
            return 'Media.Video'
        return 'File'

    @classmethod
    def gen_suffixes(cls, suffix):
        if suffix == '*':
            return suffix

        def expand(s: str):
            for names in ALIAS_FILE_SUFFIX:
                if s in names:
                    return names
            return [s]
        if isinstance(suffix, str):
            assert not suffix.startswith('.')
            return tuple(expand(suffix))
        elif multi(suffix):
            res = []
            for suf in suffix:
                res += expand(suf)
            return tuple(set(res))
        return '*'

    def __str__(self):
        s = f'<{self.__class__.__name__}:'

        s += self.type + '/' if self.type != '*' else '*/'
        if self.suffix != '*':
            suffix = ','.join(self.suffix)
            if suffix:
                s += suffix
        else:
            s += self.suffix

        if self.max_size:
            s += f' size<={readable_size(self.max_size)}'
        if self.name:
            s += ' ' + self.name

        s += '>'
        return s

    def __repr__(self):
        return str(self)

    @property
    def common_repr(self):
        return super(BaseParam, self).__repr__()

    @property
    def dict(self):
        return {
            '@': 'File',
            'type': self.type,
            'suffix': None if self.suffix == '*' else list(self.suffix),
            'max_size': readable_size(self.max_size) if self.max_size else None
        }

    def save(self, path):
        f = open(path, 'wb')
        for chunk in self.chunks():
            f.write(chunk)
        f.close()
        self.seek(0)

    @classmethod
    def trans(cls, obj):
        if isinstance(obj, bytes):
            return BytesIO(obj)
        if isinstance(obj, str):

            paths = [obj, os.path.join(config.deploy.media_root, obj)]
            for path in paths:
                if os.path.isfile(path):
                    return open(path)
            return BytesIO(obj.encode())
        raise TypeError(f"Data: {readable(obj)} cannot transform to a file-like object")

    def apply(self, file, options=None):
        if self.null and file is None:
            return None
        content_type = None
        name = ''
        if multi(file):
            file = file[0]
        if isinstance(file, FileBase):
            if self.max_size:
                if file.size > self.max_size:
                    raise ValueError(f"File size: {readable_size(file.size)} "
                                     f"exceed expected size limit {readable_size(self.max_size)}")
            if self.type == '*':
                return file
            content_type = getattr(file, 'content_type', None)
            name = file.name
            file = file.file
        if not file_like(file):
            file = self.trans(file)

        suffix = name.split('.')[-1] if '.' in name else '*'
        assert file_like(file), f'File instance must be a file-like object, got {file}'
        if content_type:
            assert '/' in content_type
            _type, _subtype = content_type.split('/')
            suffix = _subtype
            if self.type != '*':
                if self.type != _type:
                    raise exc.UnsupportedMediaType(f"File type need to be <{self.type}>, got <{_type}>")
            if self.suffix != '*':
                if _subtype not in self.suffix:
                    raise exc.UnsupportedMediaType(f"File suffix need to in {self.suffix}, got {repr(_subtype)}")
        elif self.type != '*':
            raise exc.UnsupportedMediaType(f"File type need to be <{self.type}>, got None")
        return self.__class__(file=file, name=name, suffix=suffix)


class Media(Util):
    B = 1
    KB = B*1024
    MB = KB*1024
    GB = MB*1024
    TB = GB*1024

    @classmethod
    def date_rand(cls, form='%Y-%m-%d-%H-%M-%S') -> str:
        now = datetime.datetime.now().strftime(form)
        rand = str(random.randint(1000, 9999))
        return f'{now}-{rand}'

    @classmethod
    def time_stamp(cls) -> str:
        return str(math.floor(time.time() * 100))

    @classmethod
    def uuid_str(cls) -> str:
        return str(uuid.uuid4())

    File = File

    class Image(File):
        type = GeneralType.IMAGE
        content_type = 'image/*'

        def compress(self, rate=None, width=None, height=None):
            pass

        def encode(self):
            pass

    class Audio(File):
        type = GeneralType.AUDIO
        content_type = 'audio/*'

        def compress(self):
            pass

    class Video(File):
        type = GeneralType.VIDEO
        content_type = 'video/*'

        def compress(self):
            pass

    def __init__(self, root: str = None, path: str = '',
                 ssh_host: SSH = None,
                 local_store: bool = True,
                 origin: str = None,
                 name_func: Callable = None, size_limit: int = GB):
        super().__init__(locals())
        if name_func:
            assert callable(name_func)
        self.name_func = name_func or self.date_rand
        root = path_merge(base=config.service.base, path=root) if root else config.service.media_root
        if not config.resolved:
            raise NotImplementedError('config not set')
        assert not path.startswith('/'), "Media path should be a relative path to Media.root, " \
                                         "define the absolute path at root param"
        if ssh_host:
            assert isinstance(ssh_host, SSH), f'Media ssh_host must be a SSH object, got {ssh_host}'
        elif not local_store:
            raise ValueError(f'Media local_store must set to True when no ssh_host specified')

        self.ssh_host = ssh_host
        self.local_store = local_store
        self.root = root
        if self.root:
            self.rel_path = path
            self.path = os.path.join(self.root, path)

            sd = config.service_dir.replace('\\', '/')
            pd = self.path.replace('\\', '/')
            if sd.startswith(pd) or pd.startswith(sd):
                raise ValueError(f'For security concerns. UtilMeta forbid to make '
                                 f'Media path: {repr(self.path)} \n the parent/sub path of service dir: '
                                 f'{repr(config.service_dir)}, \n'
                                 f'please reconstruct your packages or change the Media params')
            assert os.path.exists(self.root), f'Media root: {self.root} not exist'
            if not os.path.exists(self.path):
                os.makedirs(self.path)
        self.size_limit = size_limit
        self.origin = origin

    @classmethod
    def file_param(cls, p):
        from .rule import Rule, Bound
        if p is FileBase:
            return True
        if inspect.isclass(p) and issubclass(p, FileBase):
            return True
        if isinstance(p, FileBase):
            return True
        if isinstance(p, Rule):
            _type = p.get(Bound.type)
            _temp = p.get(Bound.template)
            return cls.file_param(_type) or cls.file_param(_temp)
        if isinstance(p, list) and p:
            return cls.file_param(p[0])
        return False

    @classmethod
    def find_file(cls, d):
        from utilmeta.core.schema import SchemaMeta
        if multi(d):
            for p in d:
                f = cls.find_file(p)
                if f:
                    return f
            return None
        if isinstance(d, SchemaMeta):
            d = d.__template__
        if isinstance(d, dict):
            for v in d.values():
                f = cls.find_file(v)
                if f:
                    return f
            return None
        return d if cls.file_param(d) else None

    @classmethod
    def content_type(cls, p):
        content_map = {
            cls.Image: GeneralType.IMAGE,
            cls.Audio: GeneralType.AUDIO,
            cls.Video: GeneralType.VIDEO,
            File: GeneralType.OCTET_STREAM
        }
        for _cls, ct in content_map.items():
            if inspect.isclass(p) and issubclass(p, _cls) or isinstance(p, _cls):
                return ct
        return GeneralType.OCTET_STREAM

    @classmethod
    def file_rule(cls, type=None, rule=None):
        from .rule import Rule, Bound
        t = type
        kwargs = {}
        if isinstance(rule, Rule):
            kwargs = rule.rules
            if cls.file_param(rule.type):
                rule = rule.type
            else:
                temp = rule.get(Bound.template)
                if cls.file_param(temp):
                    rule = temp
        if not type:
            if not isinstance(rule, File):
                return File()
        mul = multi(type)
        if type is FileBase:
            t = File
        if mul:
            type: list
            t = type[0]
            if multi(rule):
                rule = rule[0]
        if not inspect.isclass(t):
            t = t.__class__
        if isinstance(rule, t):
            return rule
        if not isinstance(rule, File):
            rule = File()
        if not cls.file_param(t):
            t = File
        file_rule = t(**rule.__spec_kwargs__)
        f = [file_rule] if mul else file_rule
        if kwargs:
            if mul:
                kwargs[Bound.template] = f
                pop(kwargs, Bound.type)
            else:
                kwargs[Bound.type] = f
                pop(kwargs, Bound.template)
            return Rule(**kwargs)
        return f

    def get_name(self, filename: str, given_name: str = '', suffix_default: str = ''):
        suffix = '.'.join(filename.split('.')[1:]) or suffix_default
        if given_name:
            if given_name.endswith(suffix):
                return given_name
            return f'{given_name}.{suffix}'
        if self.name_func is None:
            return filename
        name = self.name_func()
        return f'{name}.{suffix}'

    @static_require(lambda: config.service.media_root, runtime=False)
    def delete(self, path: str = ''):
        file = os.path.join(self.path, path)
        if self.ssh_host:
            with self.ssh_host as host:
                host.exec_command(f'rm {file}')
        if self.local_store:
            if os.path.exists(file):
                os.remove(file)

    @static_require(lambda: config.service.media_root, runtime=False)
    def store(self, file: FileBase, path: str = '', name: str = '', suffix: str = '', prepend_slash: bool = False):
        assert file_like(file), f"Media.store require a file-like object as file. got {file}"
        file_name = self.get_name(filename=file.name, given_name=name, suffix_default=suffix)
        path = path.strip('/')
        store_dir = os.path.join(self.path, path)
        store_path = os.path.join(store_dir, file_name)

        if not os.path.exists(store_dir):
            os.makedirs(store_dir)
        with open(store_path, 'wb') as f:
            for chunk in file.chunks():
                f.write(chunk)
            f.close()
        file.seek(0)

        if self.ssh_host:
            with self.ssh_host as host:
                host.put_file(store_path, store_path)
            if not self.local_store:
                os.remove(store_path)

        url_path = os.path.join(self.rel_path, path, file_name).replace('\\', '/')
        if prepend_slash and not url_path.startswith('/'):
            url_path = '/' + url_path
        if self.origin:
            url_path = url_join(self.origin, url_path)
        return url_path

    @static_require(lambda: config.service.media_root, runtime=False)
    def get(self, path: str = '', *, check_exists: bool = True) -> str:
        if not self.local_store:
            pass

        file_loc = file_path(os.path.join(self.path, path))
        if check_exists and not os.path.exists(file_loc):
            raise FileNotFoundError(f'File: {file_loc} not found')
        return file_loc

    @static_require(lambda: config.service.media_root, runtime=False)
    def stream(self, file=None, path: str = '', name: str = ''):
        last_modified = None
        if not file:
            file_loc = self.get(path)
            last_modified = datetime.datetime.fromtimestamp(os.path.getmtime(file_loc))
            file = open(file_loc, 'rb')
        assert file_like(file), f"Media.stream require a file-like object as file. got {file}"
        file.seek(0)
        resp = FileResponse(file, filename=name)
        if last_modified:
            resp[Header.LAST_MODIFIED] = str(last_modified)
        return resp
