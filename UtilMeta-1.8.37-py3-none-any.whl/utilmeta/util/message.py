import re
from utilmeta.util.common import SEG, Attr, LANGUAGES, LOCALES, LANGUAGE_LOCALE_MAP, \
    Reg, COMMON_ERRORS
from typing import Type
from .base import Util


class MessageMeta(type, Util):
    def __init__(cls, name, bases: tuple, attrs: dict, **kwargs):
        super().__init__(name, bases, attrs)
        Util.__init__(cls, locals())

        if not bases:
            return
        language = kwargs.get('language')
        locale = kwargs.get('locale')
        default = kwargs.get('default')
        cls.__declare__ = False    # declarative class directly extend Message
        cls.__language__ = None    # Language implement extend declarative class
        cls.__locale__ = None  # Locale implement extend language implement class

        #   __declare__ properties
        cls.__keys__ = []
        cls.__default__ = default
        cls.__languages__ = {}

        #   __lang__ properties
        cls.__locales__ = {}

        keys = []
        messages = {}
        for key, val in attrs.items():
            key: str
            if key.startswith(SEG) or key.endswith(SEG):
                continue
            assert isinstance(val, str), f'Message property value must be a valid str, got {val}'
            messages[key] = val
            keys.append(key)
        cls.__messages__ = messages

        base: MessageMeta = cls.__base__
        if base is Message:
            annotates: dict = attrs.get(Attr.ANNOTATES, {})
            keys += list(annotates)
            cls.__keys__ = keys
            cls.__declare__ = True
        elif language:
            assert language in LANGUAGES, 'Message language Implement must specify a language in standard code ' \
                                          f'(use utilmeta.util.common.Language), got <{language}>'
            assert not locale, f'Message locale implement: <{locale}> should extend language implement class'
            excess = set(base.__keys__).difference(keys)
            if excess:
                raise NotImplementedError(f'Message for language: <{language}> not implement these keys: {excess}')
            if language in base.__languages__:
                raise AttributeError(f'Message for language: <{language}> detect duplicate implement,'
                                     f' please reserve one or turn the duplicates to locale implement'
                                     f' (use class MessageImpl({cls.__name__}, locale=<LOCALE_CODE>))')
            base.__languages__[language] = cls
            cls.__language__ = language
            for key, val in base.__messages__.items():
                cls.valid(key=key, temp=val, impl=cls.__messages__[key])

        elif locale:
            assert locale in LOCALES, 'Message locale Implement must specify a language in standard code '\
                                     f'(use utilmeta.util.common.Locale), got <{locale}>'
            assert base.__language__, f'Message locale Implement must extend a language implement class, got {base}'
            locales = LANGUAGE_LOCALE_MAP[base.__language__]
            assert locale in locales, f'Message locale Implement: <{locale}> for language: <{base.__language__}> ' \
                                      f'excess the language locales list: {locales}'
            if locale in base.__locales__:
                raise AttributeError(f'Message for locale: <{locale}> detect duplicate implement, '
                                     f'please merge into one')
            base.__locales__[locale] = cls
            cls.__language__ = base.__language__
            cls.__locale__ = locale
            root: MessageMeta = base.__base__
            for key, val in root.__messages__.items():
                if key not in cls.__messages__:
                    cls.__messages__[key] = base.__messages__[key]
                    continue
                cls.valid(key=key, temp=val, impl=cls.__messages__[key])

        else:
            raise NotImplementedError('Message class based on Message must implement specific language or locale, '
                      f'use class MessageImpl({cls.__base__.__name__}, language=<LANG_CODE>) to implement')

    @classmethod
    def valid(mcs, key: str, temp: str, impl: str):
        if '%s' in temp:
            if temp.count('%s') != impl.count('%s'):
                raise ValueError(f'Message format for key: {repr(key)} in declarative class require '
                                 f'{temp.count("%s")} "%s" pattern, got {impl.count("%s")}')
        if '{' in temp and '}' in temp:
            temp_format = re.findall(Reg.PATH_REGEX, temp)
            impl_format = re.findall(Reg.PATH_REGEX, impl)
            if set(temp_format) != set(impl_format):
                raise ValueError(f'Message format for key: {repr(key)} in declarative class is {temp_format}'
                                 f', but implemented in {impl_format}')

    @property
    def default_lang_cls(cls):
        return cls.__languages__.get(cls.__default__)

    def _deconstruct(cls):
        data = {lang: lang_cls.__messages__ for lang, lang_cls in cls.__languages__.items()}
        data['@'] = Message.__name__
        return data

    def check(cls):
        assert cls.__declare__, \
            f'Message to mount on API must be a declarative message ' \
            f'class directly extend the Message class , got bases {cls.__bases__}'
        if not cls.__languages__:
            raise NotImplementedError('Message to mount on API must implement in specific language, '
                                      f'use class MessageImpl({cls.__name__}, language=<LANG_CODE>) to imply')
        if cls.__default__:
            assert cls.__default__ in cls.__languages__, \
                f'Message Main default: {cls.__default__} language should be implied'
        else:
            cls.__default__ = cls.__languages__[0]


class Message(metaclass=MessageMeta):
    def __init_subclass__(cls, **kwargs):
        base = cls.__base__
        assert len(cls.__bases__) < 2, f'Message can only be single extend'
        if base is Message:
            assert 'language' not in kwargs and 'locale' not in kwargs,  \
                f'Message Base not imply language or locale, ' \
                f'use "default" param for default language'
        else:
            assert 'default' not in kwargs, f'Message implements cannot use default, it is for the base class'

    @classmethod
    def __gen__(cls, request):
        from .request import Request
        request: Request
        lang: str = request.language
        lang_cls = cls.default_lang_cls
        if not lang or lang == '*':
            pass
        elif ',' not in lang and ';' not in lang:
            lang_cls = cls.__find__(*lang.split('-')) or lang_cls
        else:
            try:
                items = lang.replace(' ', '').split(';')
                lang_map = {}
                prev: tuple = ()
                for item in items:
                    if 'q=' in item:
                        q = item.split(',')[0].split('=')[1]
                        lang_map[prev] = q
                        notes = item.split(',')[1:]
                    else:
                        notes = item.split(',')
                    prev = tuple(notes)
                    if prev:
                        lang_map[prev] = None
                lang_list = [(k, v) for k, v in lang_map.items() if v]
                lang_list.sort(key=lambda v: v[1], reverse=True)
                languages = ()
                for lg in lang_list:
                    languages += lg[0]
                for lg in languages:
                    lg: str
                    if '-' in lg:
                        lan, locale = lg.split('-')
                    else:
                        lan, locale = lg, None
                    l_cls = cls.__find__(lang=lan, locale=locale)
                    if l_cls:
                        lang_cls = l_cls
                        break
            except COMMON_ERRORS as e:
                import warnings
                warnings.warn(f'message parse error: {e}')
        return cls(lang_cls)

    def __init__(self, lang_cls: Type['Message']):
        if not self.__declare__:
            return
        if not issubclass(lang_cls, Message):
            language = self.__class__.default_lang_cls
        else:
            language = lang_cls.__language__
        for key, val in lang_cls.__messages__.items():
            setattr(self, key, val)
        self.content_language = language

    @classmethod
    def __find__(cls, lang, locale=None):
        if lang == '*':
            lang = cls.__default__
        lang_cls = cls.__languages__.get(lang)
        if not lang_cls:
            return None
        if locale:
            locale_cls = lang_cls.__locales__.get(locale)
            if locale_cls:
                return locale_cls
        return lang_cls
