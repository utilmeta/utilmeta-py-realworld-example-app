from .base import Util

from .auth import Auth
from .page import Page
from .bulk import Bulk
from .request import Request

from utilmeta.core.unit import Unit
from utilmeta.util.common import multi, COMMON_METHODS, CommonMethod
from typing import Dict


def check_in(m):
    @property
    def prop(self: 'Method'):
        if m in self.methods:
            return m
        raise AttributeError(f'Method({self.__declare_path__}) did not declared method: {repr(m)}'
                             f', please select from {self.methods} when hooking methods')

    return prop


class Method(Util):
    GET: str = check_in(CommonMethod.GET)
    PUT: str = check_in(CommonMethod.PUT)
    POST: str = check_in(CommonMethod.POST)
    PATCH: str = check_in(CommonMethod.PATCH)
    DELETE: str = check_in(CommonMethod.DELETE)

    def __init__(self, *, get=None, put=None, post=None, patch=None, delete=None):
        super().__init__(locals())
        self.hooks = {}

        self.model = None
        self.paging = {}
        self.batch = {}
        self.auth = {}
        self.option = {}
        self.proxy = post or delete

        method_dict = {}
        for m in COMMON_METHODS:
            _m = locals().get(m)
            if _m is not None:
                method_dict[m] = _m

        self.method_dict = method_dict
        self.query_domain: Dict[str, tuple] = {}
        self.body_domain: Dict[str, tuple] = {}

    def get_transaction_using(self, method: str):
        unit: Unit = self.option.get(method)
        if not unit:
            return []
        return unit.transaction_using

    @property
    def methods(self):
        return tuple(self.method_dict.keys())

    def check(self):
        for m, val in self.method_dict.items():
            if multi(val):
                for v in val:
                    self.valid(m, v)
            else:
                self.valid(m, val)

        for method in self.methods:
            if method not in self.auth:
                self.auth[method] = Auth()

    def valid(self, m, val):
        if isinstance(val, Unit):
            self.option[m] = val
        elif isinstance(val, Auth):
            val.model = self.model
            val.check(m)
            if m in self.auth:
                self.auth[m] = val & self.auth[m]
            else:
                self.auth[m] = val
        elif isinstance(val, Page):
            assert m != CommonMethod.POST, f"Page util does not support native POST method"
            if val.all:
                if m != CommonMethod.GET:
                    raise ValueError(f"Method: {m} don't support Page(all=True) for too dangerous")
            val.model = self.model
            self.paging[m] = val
        elif isinstance(val, Bulk):
            assert m in (CommonMethod.POST, CommonMethod.PUT, CommonMethod.PATCH), \
                "Bulk Util only apply to METHODS: put/patch/post, which allows list of data to be created or updated"
            val.model = self.model
            val.post = m == CommonMethod.POST
            self.batch[m] = val
        elif isinstance(val, Request):
            self.option[m] = Unit(request=val)
        elif isinstance(val, Request.Query):
            self.query_domain[m] = val.params
        elif isinstance(val, Request.Body):
            self.body_domain[m] = val.params
        else:
            raise ValueError(f"Module method value must be an instance or "
                             f"tuple of Auth/Page/Bulk/Unit or Request.Query/Request.Body, got {val}")
