from .base import Util
from .common import OperatorOption, OPERATORS, valid_attr, get_field, duplicate
from .common import exp
from .rule import Rule
from typing import Dict
from django.db.models import IntegerField, FloatField, DecimalField


VALUE_FIELDS = (IntegerField, FloatField, DecimalField)
EXP_MAP = {
    OperatorOption.equ: lambda field, value: value,
    OperatorOption.add: lambda field, value: exp.F(field) + value,
    OperatorOption.min: lambda field, value: exp.F(field) - value,
    OperatorOption.div: lambda field, value: exp.F(field) / value,
    OperatorOption.mul: lambda field, value: exp.F(field) * value,
    OperatorOption.mod: lambda field, value: exp.F(field) % value,
    OperatorOption.pow: lambda field, value: exp.F(field) ** value,
}


class Operator(Util):
    def __init__(self, *options, rule: Rule = None):
        options = options or ('=',)
        super().__init__(locals())

        assert not duplicate(options), \
            f'Filter options must be distinct options, got duplicates: {duplicate(options)}'
        assert set(options).issubset(OPERATORS),\
            f'Invalid operators: {set(options).difference(OPERATORS)}, must in {OPERATORS}'

        self.options = options
        self.model = None
        self.field = None
        self.relate = None
        if rule:
            assert isinstance(rule, Rule), f'Operator rule must be a Rule object, got {rule}'
        self.rule = rule
        # self.operator_rules: Dict[str, Rule] = {}

    @classmethod
    def gen(cls, operators: Dict[str, 'Operator']) -> Dict[str, Rule]:
        return {key: Rule.optional(val.rule) for key, val in operators.items()}

    def copy(self, field, model, rule):
        opt = self.__copy__()
        if opt.rule:
            if rule:
                opt.rule = Rule.merge(rule, opt.rule)
        else:
            opt.rule = rule
        opt.model = model
        opt.field = field
        opt.check()

        def comb(f, o):
            return f if o == '=' else f + o

        return {comb(field, op): opt for op in opt.options}

    def check(self):
        from .field import Field
        assert self.model and self.field
        field = get_field(self.model, self.field)
        if field.many_to_many:
            self.relate = True
            self.rule = Rule(template=[Field.get_type(field.related_model)], require=False)
        else:
            assert isinstance(field, VALUE_FIELDS), f'Operator field must be ManyToMany relate fields or ' \
                f'number value fields in {VALUE_FIELDS}, got {field}'
            rule_type = int if isinstance(field, IntegerField) else float
            if self.rule and self.rule.has_type:
                assert self.rule.type == rule_type or self.rule.type is int, \
                    f'Invalid Operator rule type: {self.rule.type} must be {rule_type}'
            else:
                self.rule = Rule(type=rule_type, require=False)

    @classmethod
    def extract(cls, string: str):
        operator = string[-1]
        if operator not in OPERATORS:
            return string, ''
        field = string[:-1]
        if not valid_attr(field):
            raise ValueError(f'Invalid operation field: {repr(field)}')
        return field, operator

    @classmethod
    def process(cls, data: dict, options: Dict[str, 'Operator']):
        if not options:
            return
        add_relates = {}
        rem_relates = {}
        fields = []
        for key in tuple(data.keys()):
            operator = options.get(key)
            if not operator:
                continue
            field, opt = cls.extract(key)
            if not opt:
                continue
            if field in fields:
                raise ValueError(f'Operator error: one field applied multiple operators')
            fields.append(field)
            value = data.pop(key)
            if operator.relate:
                if opt == OperatorOption.add:
                    add_relates[field] = value
                elif opt == OperatorOption.min:
                    rem_relates[field] = value
                else:
                    raise ValueError(f'Invalid relate operator: {repr(opt)}')
            else:
                data[field] = EXP_MAP[opt](field, value)
        return add_relates, rem_relates
