from .base import Util
from .rule import Rule
from .field import Field
from .filter import Filter
from .page import Page
from .order import Order
from .request import Request
from django.db.models import Model, Q
from django.db.models import Field as FieldBase
from utilmeta.util.common import CommonMethod as M
from django.db.models.expressions import BaseExpression
from django.core.exceptions import FieldDoesNotExist
from .common import get_field_name, add_field_id, one_to, del_field_id,\
    Param, SEG, get_field, get_fields, COMMON_TYPES, get_exp_field, import_util, \
    value_str, get_pk, multi, ignore_errors, class_dict, COMMON_ERRORS
from typing import Optional, Dict, Union, List, Tuple, Any, Callable, Type, TYPE_CHECKING
from django.utils.functional import cached_property
if TYPE_CHECKING:
    from utilmeta.core.schema import Schema


class Option(Util):
    PARAM_ROWS = Param.rows
    PARAM_PAGE = Param.page
    PARAM_OFFSET = Param.offset
    PARAM_LIMIT = Param.limit
    PARAM_KEY = Param.key
    PARAM_ORDER = Param.order
    PARAM_FIELD = Param.field
    PARAM_EXCLUDE = Param.exclude
    PARAM_TEMPLATE = Param.template
    PARAM_DATAFRAME = Param.dataframe

    class Assign(Util):
        def __init__(self, filter_dict: Dict[str, List[Filter]]):
            super().__init__(locals())
            self.by_pk = bool({'pk', 'id'}.intersection(filter_dict))
            self.by_filters = {}
            self.from_filters = {}
            self.mixin_filters = {}

            self.dispatcher: Dict[type, Callable] = {}
            fields = []
            for key, filters in filter_dict.items():
                for fil in filters:
                    if fil.mixins:
                        self.mixin_filters[key] = fil
                    if fil.assign:
                        fields.append(key)
                        if key in self.by_filters:
                            raise ValueError(f'Filter(assign=True) can set once in one key: {key}')
                        self.by_filters[key] = fil
                    if not fil.public:
                        if key in self.from_filters:
                            raise ValueError(f'Filter with set_as can set once in one key: {key}')
                        self.from_filters[key] = fil

            self.by_fields = fields
            self.foreign_lookups: Dict[str, List[str]] = {}
            self.model: Optional[Model] = None
            self.field: Optional[FieldBase] = None

        def __bool__(self):
            return bool(self.by_filters)

        def inject(self, sub_module):
            from utilmeta.core.module import Module
            if not issubclass(sub_module, Module):
                raise TypeError(f'Invalid inject object: {sub_module}, must be Module subclass')
            sub_assign = sub_module.option.assign
            if not self or not sub_assign.from_filters:
                return
            for key, fil in sub_assign.from_filters.items():
                if key in self.by_filters:
                    if sub_module in self.dispatcher:
                        f = self.dispatcher[sub_assign]
                        q = fil.qualifier(key)
                        self.dispatcher[sub_module] = lambda data: f(data) and q(data)
                    else:
                        self.dispatcher[sub_module] = fil.qualifier(key)

        def get_by(self, data: dict):
            for module, validator in self.dispatcher.items():
                if validator(data):
                    return module
            return None

        def from_inst(self, inst: Model):
            if not inst:
                return None
            data = {}
            for key, fil in self.by_filters.items():
                lookups = self.foreign_lookups.get(key)
                if lookups:
                    res = inst
                    for lkp in lookups:
                        res = getattr(res, lkp)
                else:
                    res = getattr(inst, fil.field or key)
                data[key] = res
            return self.get_by(data)

        def check(self):
            assert self.model

            def check_rel(f):
                self.foreign_lookups[key] = name.split(SEG)[1:]
                assert one_to(f), f"Assign field: {f} cannot be multiple relates"
                assert SEG in name, f"Assign ForeignKey: {field} must with a single lookup"
                look = get_field(self.model, name, cascade=True)
                assert not look.related_model

            for key, fil in self.by_filters.items():
                name = fil.field or key
                field = get_field(self.model, name.split(SEG)[0])
                field.editable = False
                if get_pk(self.model, root=True) == field:
                    self.by_pk = True
                if field.related_model:
                    check_rel(field)

            for key, fil in self.mixin_filters.items():
                name = fil.field or key
                field = get_field(self.model, name.split(SEG)[0])
                field.editable = False
                if field.related_model:
                    check_rel(field)

    class Client(Util):
        def __init__(self, _all=None, *,
                     dataframe: Union[bool, str] = False,
                     template: Union[bool, str] = False,
                     exclude: Union[bool, str] = False,
                     offset: Union[bool, str] = False,
                     limit: Union[bool, str] = False,
                     field: Union[bool, str] = False,
                     order: Union[bool, str] = False,
                     page: Union[bool, str] = False,
                     rows: Union[bool, str] = False,
                     key: Union[bool, str] = False,
                     ):
            super().__init__(locals())
            self.options = {}
            self.rules = {}

            for key, param in locals().items():
                if key.startswith('_') or key == 'self':
                    continue
                if _all or param:
                    from utilmeta.conf import config
                    self.options[key] = param if isinstance(param, str) else config.preference.get_param_name(key)

            self.model = None
            self.optional = template or exclude or field
            self.fields = []
            self.order_range = []

        def __bool__(self):
            return bool(self.options)

        def apply_page(self, page: Page):
            if not isinstance(page, Page):
                return
            from utilmeta.conf import config
            if page.offset_mode:
                for param in ['offset', 'limit']:
                    self.options.setdefault(param, config.preference.get_param_name(param))
            else:
                for param in ['page', 'rows']:
                    self.options.setdefault(param, config.preference.get_param_name(param))
            self.rules.update(page.gen())

        def check(self):
            assert self.model
            self.fields = [f.name for f in get_fields(self.model)]
            self.order_range = self.fields + ['-' + f for f in self.fields]

        @classmethod
        def parse_temp(cls, temp):
            if multi(temp):
                return {key: Rule() for key in temp if isinstance(key, str)}
            elif isinstance(temp, dict):
                return {key: cls.parse_temp(val) for key, val in temp.items()}
            elif type(temp) in COMMON_TYPES:
                return Rule(type=type(temp), default=temp)
            return None

        @property
        def dataframe(self):
            return self.options.get('dataframe')

        @property
        def template(self):
            return self.options.get('template')

        @property
        def exclude(self):
            return self.options.get('exclude')

        @property
        def order(self):
            return self.options.get('order')

        @property
        def field(self):
            return self.options.get('field')

        @property
        def offset(self):
            return self.options.get('offset')

        @property
        def page(self):
            return self.options.get('page')

        @property
        def rows(self):
            return self.options.get('rows')

        @property
        def key(self):
            return self.options.get('key')

        @property
        def limit(self):
            return self.options.get('limit')

        @property
        def keys(self):
            return list(self.options.values())

        def gen(self, *keys):
            temp = {}
            default_rules = dict(
                dataframe=Rule(type=int, require=False,
                               field=Param.dataframe, ge=0),
                template=Rule(require=False, type_union=(dict, list),
                              converter=self.parse_temp, field=Param.template),
                exclude=Rule(template=[str], require=False, choices=keys,
                             multiple=True, strict=False, field=Param.exclude) if keys else None,
                offset=Rule(type=int, ge=0, require=False, field=Param.offset),
                limit=Rule(type=int, ge=0, require=False, field=Param.limit),
                field=Rule(type=str, require=False, choices=keys, strict=False, field=Param.field) if keys else None,
                order=Rule(template=[str], require=False, field=Param.order,
                           choices=self.order_range, multiple=True, strict=False) if self.order_range else None,
                page=Rule(type=int, gt=0, require=False, field=Param.page),
                rows=Rule(type=int, ge=0, require=False, field=Param.rows),
                key=Rule(type=str, choices=keys, require=False, field=Param.key) if keys else None,
            )
            for key, name in self.options.items():
                rule = default_rules.get(key)
                if key in self.rules:
                    if rule:
                        try:
                            rule &= self.rules[key]
                        except (AssertionError, *COMMON_ERRORS):
                            rule = self.rules[key]
                    else:
                        rule = self.rules[key]
                if not rule:
                    continue
                temp[name] = rule
            return temp

    def __init__(self, *,
                 filters: Dict[Any, Union[Filter, List[Filter]]] = None,
                 orders: Dict[Any, Order] = None,
                 # order_option: 'Option.Order' = None,
                 client_option: 'Option.Client' = None,
                 base_filter: Union[Q, Callable] = Q(),
                 order_by=(),
                 order_not_null: bool = True,
                 distinct_by=None,
                 auto_user_field=None,
                 path_param_field=None,
                 path_param_rule: Union[type, Rule] = None,
                 path_param_create: bool = False,
                 client_cache: bool = False,
                 valid_match: bool = False,
                 post_query: Union[str, bool] = False,
                 relative_key: str = None,
                 data_frame: Union[bool, int] = False,
                 # data frame: convert [{"a": 1, "b": 2}, {"a": 3, "b": 4}] to {"a": [1, 3], "b": [2, 4]}
                 logic_query: bool = False,
                 valid_integrity: bool = False,
                 ignore_mixin_conflicts: bool = False,
                 discard_incomplete_mixin: bool = False,
                 split_many_relation_query: bool = False,
                 ignore_invalid_params: bool = False,
                 filter_with_rules: bool = False,
                 ensure_sole: bool = False,

                 schema_generator_cls: str = None,
                 module_queryset_cls: str = None,
                 module_parser_cls: str = None,

                 using_db: Union[str, Callable] = None,
                 unlimited_filters: bool = False,
                 unlimited_orders: bool = False,
                 unlimited_options: bool = False,
                 unlimited_fields: bool = False,
                 ):

        order_by, self.order_by_result = self.parse_order_by(order_by)
        filters = class_dict(cls=Filter, data=filters, invalid_callback=lambda v: Filter(set_as=v))
        # orders = class_dict(cls=Order, data=orders, allow_multi=True)
        if orders:
            assert client_option and client_option.order, \
                f'Option with orders must enable client_option and set order=True'

        auto_user_field = get_field_name(auto_user_field) or None
        # use None instead of '' to make sure that when merging attrs will get the valid result

        super().__init__(locals())

        self.order_option: Optional[Order] = None
        self.order_not_null = order_not_null
        order_dict = {}
        distinct = []
        if orders:
            for key, order in orders.items():
                if not isinstance(order, Order):
                    raise TypeError(f'Option orders value must be an Order instance, got {order}')
                if order.model_order:
                    if self.order_option:
                        raise ValueError(f'Option can have at most 1 model_order, got {self.order_option, order}')
                    self.order_option = order
                key = get_field_name(key)
                order.alias = key
                if order.distinct:
                    distinct.append(order.alias)
                order_dict[key] = order
        distinct_by = distinct_by or distinct

        client_option = client_option or self.Client()
        assert isinstance(client_option, self.Client), \
            f'Option client_option param should pass a Option.Client instance, got {client_option}'
        if not base_filter:
            base_filter = Q()
        assert isinstance(base_filter, Q) or callable(base_filter), \
            f'Option base_filter param should be a Q object or a callable return a Q object, got {base_filter}'

        if post_query and path_param_field:
            raise ValueError(f'Option cannot enable path_param_field: '
                             f'{path_param_field} and post_query at the same time')
        self.model = None
        self.order_dict = order_dict
        self.filter_dict = filters

        self.filters: Dict[str, Rule] = {}
        self.options: Dict[str, Rule] = {}

        self.ignore_invalid_params = ignore_invalid_params
        if auto_user_field:
            auto_user_field = del_field_id(auto_user_field)
        self.auto_user_field = auto_user_field
        self.data_frame = int(data_frame)
        self.relative_key = get_field_name(relative_key)

        self.path_param_field = get_field_name(path_param_field)
        self.path_param_pk = False
        self.path_param_rule = Rule.gen_from(path_param_rule) if path_param_rule else Rule(require=False)
        self.path_param_required = self.path_param_rule.require
        self.path_param_create = path_param_create

        self.valid_integrity = valid_integrity
        self.ignore_mixin_conflicts = ignore_mixin_conflicts
        self.discard_incomplete_mixin = discard_incomplete_mixin
        self.split_many_relation_query = split_many_relation_query

        from utilmeta.conf import config

        self.schema_generator_cls_string = schema_generator_cls or config.preference.schema_generator_cls_string
        self.module_queryset_cls_string = module_queryset_cls or config.preference.module_queryset_cls_string
        self.module_parser_cls_string = module_parser_cls or config.preference.module_parser_cls_string

        self.ensure_sole = ensure_sole
        self.module_query_cls = None
        self.using_db = using_db

        if client_cache:
            try:
                if not config.auto_cache.client_cache or not config.auto_cache.model_cache:
                    client_cache = False
                    # only set False, not raise error
                    # some test cases might alter the auto_cache settings without change code
                    # just use default
            except AttributeError:
                raise ValueError(f'Option client_cache=True requires to set '
                                 f'auto_cache in your config and activate client_cache & model_cache')

        self.base_filter = base_filter
        self.client_cache = bool(client_cache)
        self.etag_cache = False
        self.client_option = client_option.__copy__()
        self.assign = self.Assign(self.filter_dict)

        if distinct_by:
            distinct_by = get_field_name(distinct_by)
            if not multi(distinct_by):
                distinct_by = [distinct_by]
            else:
                distinct_by = list[distinct_by]
            if not order_by:
                order_by = distinct_by

        if not callable(order_by):
            assert isinstance(order_by, (list, tuple)),\
                f'Option order_by must be a list or callable, got {order_by}'
            order_by = list(order_by)

        self.order_by = order_by
        self.distinct_by = distinct_by or []
        self.order_fields = []
        self.annotates: Dict[str, BaseExpression] = {}
        self.filter_with_rules = bool(filter_with_rules)
        self.valid_match = bool(valid_match)
        # whether use If-Match -> Etag / If-Unmodified-Since -> Last-Modified to valid match before PUT/PATCH
        self.post_query = bool(post_query)
        self.post_query_route = post_query if isinstance(post_query, str) else Param.query
        self.logic_query = bool(logic_query)
        self.unique_fields = []

        self._checked = False

    @property
    def path_params(self):
        if not self.path_param_field:
            return {}
        return {self.path_param_field: self.path_param_rule}

    @cached_property
    def schema_generator_cls(self):
        from utilmeta.util.query.schema import SchemaGenerator
        if not self.schema_generator_cls_string:
            return SchemaGenerator
        cls = import_util(self.schema_generator_cls_string)
        if not issubclass(cls, SchemaGenerator):
            raise TypeError(f'Option.schema_generator_cls must be a subclass'
                            f' of {SchemaGenerator}, got {cls}')
        return cls

    @cached_property
    def module_queryset_cls(self):
        from utilmeta.util.query.manager import MetaQuerySet
        if not self.module_queryset_cls_string:
            return MetaQuerySet
        cls = import_util(self.module_queryset_cls_string)
        if not issubclass(cls, MetaQuerySet):
            raise TypeError(f'Option.module_queryset_cls must be a subclass'
                            f' of {MetaQuerySet}, got {cls}')
        return cls

    def get_base_filter(self, request=None) -> Q:
        if not self.base_filter:
            return Q()
        if isinstance(self.base_filter, Q):
            return self.base_filter
        import inspect
        try:
            if len(inspect.signature(self.base_filter).parameters) >= 1:
                q = self.base_filter(request)
            else:
                q = self.base_filter()
            if isinstance(q, Q):
                return q
        except COMMON_ERRORS:
            pass
        return Q()

    def get_base_order(self, request=None) -> List[str]:
        if not self.order_by:
            return []
        if isinstance(self.order_by, list):
            return self.order_fields
        import inspect
        try:
            if len(inspect.signature(self.order_by).parameters) >= 1:
                o = self.order_by(request)
            else:
                o = self.order_by()
            if isinstance(o, list):
                return o
        except COMMON_ERRORS:
            pass
        return []

    def get_using_db(self, request=None) -> Optional[str]:
        if not self.using_db:
            return None
        if isinstance(self.using_db, str):
            return self.using_db
        import inspect
        try:
            if len(inspect.signature(self.using_db).parameters) >= 1:
                db = self.using_db(request)
            else:
                db = self.using_db()
            if isinstance(db, str):
                return db
        except COMMON_ERRORS:
            pass
        return None

    def check_query(self, query: dict):
        for key, val in query.items():
            if key not in self.filters:
                raise ValueError(f'Query key: {key} out of filters scope')

    @property
    def optional(self):
        if not self.client_option:
            return False
        return self.client_option.optional

    def check_methods(self, *methods):
        """
        Means current option will take effect only if those methods are enabled
        :return:
        """
        if self.client_option or self.order_by or self.distinct_by or self.data_frame or self.post_query:
            if M.GET not in methods:
                raise ValueError(f'{self} take effect needs to enable get method')
        if self.auto_user_field:
            if not {M.PATCH, M.PUT, M.POST}.intersection(methods):
                raise ValueError(f'{self} take effect needs to enable post/put/patch method')
        if self.valid_match:
            if not {M.PATCH, M.PUT}.intersection(methods):
                raise ValueError(f'{self} take effect needs to enable put/patch method')

    def assign_user_id(self, data: dict, user_id):
        if not self.auto_user_field:
            return None
        user_val = data.get(self.auto_user_field, data.get(add_field_id(self.auto_user_field)))
        if not user_val:
            data[add_field_id(self.auto_user_field)] = user_id
        return

    def add_annotate(self, key, exp: BaseExpression):
        if not isinstance(exp, BaseExpression):
            raise TypeError(f'Invalid expression: {exp}')
        annotate = self.annotates.get(key)
        if annotate:
            assert getattr(annotate, 'deconstruct')() == getattr(exp, 'deconstruct')(), \
                ValueError(f'Inconsistent expression field: [{key}]: {exp}, {annotate}')
        else:
            self.annotates[key] = exp

    def apply_query(self, query: Union[Type['Schema'], dict]):
        if not query:
            return
        filters = {}
        options = {}
        rules = {}

        from utilmeta.core.schema import SchemaMeta
        if isinstance(query, SchemaMeta):
            data = query.__data__
            self.module_query_cls = query
        elif isinstance(query, dict):
            data = query
        else:
            raise TypeError

        for key, val in data.items():
            if isinstance(val, Filter):
                filters[val.alias or key] = [val]
            if isinstance(val, Field):
                if val.name in Param.gen():
                    k = val.name.lstrip('@')
                    options[k] = val.alias or key
                    rules[k] = val.rule

        self.filter_dict.update(filters)
        self.client_option.options.update(options)
        self.client_option.rules.update(rules)

    def check(self, *keys):
        if self._checked:
            return

        from utilmeta.fields import CrossServiceKey
        assert self.model
        if self.assign:
            self.assign.model = self.model
            self.assign.check()

        if self.using_db:
            if isinstance(self.using_db, str):
                from utilmeta.conf import config
                if self.using_db not in config.databases:
                    raise TypeError(f'Option.using_db should within database '
                                    f'aliases: {list(config.databases)}, got {self.using_db}')

        order_fields = []

        if isinstance(self.order_by, list):
            for o in self.order_by:
                od = self.order_dict.get(o)
                if od and od.exp:
                    continue
                try:
                    get_field(self.model, o.strip('-'), cascade=True)
                    order_fields.append(o)
                except FieldDoesNotExist:
                    if o.strip('-') not in keys:
                        raise ValueError(f'Invalid order_by field: {repr(o)}, must be model field or schema field')

            if self.distinct_by:
                from .query import MetaQuerySet
                from .common import exc
                try:
                    MetaQuerySet(model=self.model).distinct(get_pk(self.model).name)
                    # if database backend does not support for distinct, will raise a NotSupportedError
                except (exc.ProgrammingError, exc.OperationalError):
                    # but if database is not migrate yet, ignore the OperationalError
                    pass
                for d in self.distinct_by:
                    get_field(self.model, d, cascade=True)

                msg = 'When you specify field names, you must provide an order_by() in the QuerySet, ' \
                      'and the fields in order_by() must start with the fields in distinct(), in the same order'
                assert len(self.distinct_by) <= len(order_fields), msg
                for o, d in zip(order_fields, self.distinct_by):
                    assert o.lstrip('-') == d, msg

        unique_fields = []
        for field in get_fields(self.model):
            if field.unique:
                unique_fields.append(field.name)

        if self.relative_key:
            if self.relative_key not in keys:
                raise ValueError(f'Option relative_key not in response keys: {keys}')

        if self.auto_user_field:
            field = get_field(self.model, self.auto_user_field)
            from utilmeta.conf import config
            if isinstance(field, CrossServiceKey):
                if not config.auth.auth_service:
                    raise ValueError(f'Option auto_user_field: {field} must specify auth_service')
                assert field.service_name == config.auth.auth_service, \
                    f'Option auto_user_field CrossServiceKey(service={field.service_name}) ' \
                    f'must consistent to auth_service: {config.auth.auth_service}'
            else:
                assert issubclass(field.related_model, config.auth.UserModel), \
                    f'Option auto_user_field must relate to ' \
                    f'field of user_model: {config.auth.UserModel}, got {field.related_model}'

        if self.path_param_field:
            field = get_field(self.model, self.path_param_field)
            assert field.unique, f'Option.path_param_field must be an unique field, got {field}'
            self.path_param_rule = Field.get_rule(field) & self.path_param_rule
            self.path_param_pk = field.primary_key

        self.order_fields = order_fields
        self.unique_fields = unique_fields

        if self.client_option:
            self.client_option.model = self.model
            self.client_option.check()

            if self.order_dict:
                order_range = []
                for key, order in self.order_dict.items():
                    order.model = self.model
                    order_range += order.gen()
                    if order.exp:
                        self.add_annotate(key, exp=order.exp)
                self.client_option.order_range = order_range

            self.options = self.client_option.gen(*keys)

        for key, filters in self.filter_dict.items():
            for filter in filters:
                if filter.exp:
                    self.add_annotate(key, exp=filter.exp)
        self.filters = Filter.gen(self.filter_dict, model=self.model, allow_logic=self.logic_query)
        self._checked = True

    @property
    def query_dict(self):
        if self.filter_dict and not self.filters:
            self.filters = Filter.gen(self.filter_dict, model=self.model, allow_logic=self.logic_query)
        if self.client_option and not self.options:
            self.options = self.client_option.gen()
        query = dict()
        query.update(self.filters)
        query.update(self.options)
        return query

    def get_filter(self, key: str) -> Optional[Filter]:
        field, *_ = Filter.extract(key)
        option = key.lstrip(field)
        filters = self.filter_dict.get(field)
        if not filters:
            return None
        for fil in filters:
            if not option and '=' in fil.options:
                return fil
            if fil.sole:
                return fil
            if option in fil.options:
                return fil
        return None

    @classmethod
    def parse_order_by(cls, order_by) -> Tuple[Union[List[str], Callable], bool]:
        def parse(by) -> Tuple[str, bool]:
            if isinstance(by, property):
                return by.fget.__name__, True
            elif isinstance(by, Field):
                if by.exp:
                    return by.attname, True
                return by.name, False
            elif isinstance(by, BaseExpression):
                return get_exp_field(by), True
            return get_field_name(by), False

        if not order_by:
            return [], False
        if callable(order_by):
            return order_by, False

        by_result = False
        if multi(order_by):
            orders = []
            for o in order_by:
                field, bp = parse(o)
                orders.append(field)
                if bp:
                    by_result = True
            return list(orders), by_result
        od, by_result = parse(order_by)
        return [od], by_result

    def process_request(self, request: Request):
        if self.post_query and request.post_query:
            request.params = dict(request.data)
        return request

    @property
    def order_function(self):
        order_by = self.order_by

        @ignore_errors(default=0, log=True)
        def f(item: dict):
            if not order_by or callable(order_by):
                return 0
            if not isinstance(item, dict):
                return 0
            value = []
            for order in order_by:
                order: str
                n = 0
                val = item.get(order)
                if isinstance(val, str):
                    n = value_str(val)
                elif isinstance(val, (int, float)):
                    n = val
                if order.startswith('-'):
                    n = -n
                value.append(n)
            if len(value) == 1:
                value = value[0]
            return value
        return f
