from .base import Util
from utilmeta.util.common import del_field_id, get_field, get_field_name, get_exp_field
from django.db.models.expressions import BaseExpression


class Order(Util):
    def __init__(self, field=None, *, asc: bool = True, desc: bool = True,
                 distinct: bool = False, default: bool = False,
                 notnull: bool = True,
                 model_order: bool = False,
                 model_order_key: str = None,
                 model_order_start: int = 0,
                 model_order_strict: bool = True,
                 ):
        super().__init__(locals())
        if not asc and not desc:
            raise ValueError(f'Order must specify asc or desc')

        self.asc = asc
        self.desc = desc
        self.distinct = distinct
        self.default = default

        self.exp = None
        if isinstance(field, BaseExpression):
            self.exp = field
            field = get_exp_field(field)
            if model_order:
                raise TypeError(f'Expression Order cannot set model_order=True')

        self.field = get_field_name(field)
        if self.field and self.field.startswith('-'):
            self.desc = True
            self.asc = False
            self.field = self.field.lstrip('-')

        self.alias = None
        self.notnull = notnull
        self.model = None

        self.model_order = model_order
        self.model_order_key = model_order_key
        self.model_order_start = model_order_start
        self.model_order_strict = model_order_strict

    @property
    def field_name(self):
        if self.exp:
            return self.alias
        return self.field or self.alias

    def gen(self):
        if not self.alias:
            raise ValueError(f'Order alias not set')
        get_field(self.model, self.field or self.alias, cascade=True)
        if self.model_order:
            from utilmeta.fields import IntegerField
            assert self.model
            if self.model_order_key:
                unique_together = getattr(self.model, '_meta').unique_together
                for uq in unique_together:
                    assert set(uq) not in ({del_field_id(self.model_order_key),
                                            self.field}, {self.model_order_key, self.field}), \
                        f'Option order_option for {self.model} will guarantee the key and order field \n' \
                        f'to be unique_together at Module level, set additional constraint will cause update ' \
                        f"errors, \nplease remove the unique_together = {uq} in your model's Meta config"

            field = get_field(self.model, self.field)
            assert isinstance(field, IntegerField), \
                f'Option order_field must be instance of IntegerField (or it subclasses), got {field}'

        fields = []
        if self.asc:
            fields.append(self.alias)
        if self.desc:
            fields.append('-' + self.alias)
        return fields
