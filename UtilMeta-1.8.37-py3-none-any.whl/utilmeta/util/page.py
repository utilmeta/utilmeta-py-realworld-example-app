import math
from .base import Util
from typing import TypeVar, Union
from .common import Param, exc

T = TypeVar('T')

__all__ = ['Page']


class Page(Util):
    # page mode: @page & @rows
    # offset mode: @offset & @limit
    PARAM_ROWS = Param.rows
    PARAM_PAGE = Param.page
    PARAM_OFFSET = Param.offset

    def __init__(self, default_rows: int = None,
                 max_rows: int = None,
                 default_page: int = None,
                 offset: bool = False,
                 all: bool = False):
        super().__init__(locals())
        if default_rows:
            assert isinstance(default_rows, int) and default_rows > 0, \
                ValueError(f"Page default_rows must be int > 0, got {default_rows}")
        if default_page:
            assert isinstance(default_page, int) and default_page > 0, \
                ValueError(f"Page default_page must be int > 0, got {default_page}")
        if max_rows:
            assert isinstance(max_rows, int) and max_rows > 0, \
                ValueError(f"Page max_rows must be int > 0, got {max_rows}")

        self.page = default_page
        self.rows = default_rows
        self.offset_mode = offset
        self.max = max_rows
        self.all = bool(all)

    def gen(self):
        from .rule import Rule
        page_default = None if self.all else (self.page or ...)
        rows_default = self.rows if self.rows else ...
        return dict(
            page=Rule(type=int, gt=0, default=page_default, require=not self.all),
            rows=Rule(type=int, ge=0, le=self.max, default=rows_default, require=not self.rows and not self.all)
        )

    def count(self, rows, total) -> int:
        rows = rows or self.rows
        return math.ceil(total / rows)

    def __call__(self, orders: T, rows, page) -> T:
        page = page or self.page
        if page is not None:
            rows = rows or self.rows
            page = int(page)
            start = (page - 1) * rows
            end = page * rows
            orders = orders[start:end]
        elif not self.all:
            raise exc.BadRequest(f'Page params @page is required for Page(all=False) API')
        return orders

    def offset(self, orders: T, offset, limit) -> T:
        start = 0
        end = None
        if offset is not None:
            start = offset
        if limit is not None:
            end = start + limit
        if not start and not end:
            if not self.all:
                raise exc.BadRequest(f'Page params offset/limit is required for Page(all=False) API')
            return orders
        return orders[start:end]
