import inspect
from utilmeta.util.common import Attr, COMMON_TYPES, cached_property, pop, \
    class_func, multi, type_transform, readable, is_origin, import_util, \
    parse_list, COMMON_ERRORS, return_type, distinct, get_value, CaseStyle
from utilmeta.util.rule import BaseParam, Bound, Rule
from enum import Enum
from django.db.models.expressions import BaseExpression
from typing import Any, Dict, List, TypeVar, Callable
from utilmeta.util.error import Error
from ..base import Util
from xml.etree.ElementTree import Element
from .exceptions import *
import typing
import warnings

try:
    from typing import ForwardRef
except ImportError:
    # compat with early version of python
    ForwardRef = getattr(typing, '_ForwardRef')
T = TypeVar('T')

__all__ = ['Alias', 'Options', 'Parser', 'FieldTransfer']


class FieldTransfer:
    @classmethod
    def guess_style(cls, style: str):
        if not isinstance(style, str) or not style:
            return None
        style = style.lower()
        if CaseStyle.camelCase in style:
            return CaseStyle.camelCase
        if CaseStyle.snake_case in style:
            if 'cap' in style:
                return CaseStyle.CAP_SNAKE_CASE
            return CaseStyle.snake_case
        if CaseStyle.kebab_case in style:
            if 'cap' in style:
                return CaseStyle.CAP_KEBAB_CASE
            return CaseStyle.kebab_case
        if CaseStyle.PascalCase in style:
            return CaseStyle.PascalCase
        # guess val
        ans = ''.join(filter(str.isalnum, style))
        if '_' in style:
            if ans.isupper():
                return CaseStyle.CAP_SNAKE_CASE
            return CaseStyle.snake_case
        if '-' in style:
            if ans.isupper():
                return CaseStyle.CAP_KEBAB_CASE
            return CaseStyle.kebab_case
        if ans.isupper():
            return CaseStyle.CAP_SNAKE_CASE
        if ans.islower():
            return CaseStyle.snake_case
        if ans[0].islower():
            return CaseStyle.camelCase
        return CaseStyle.PascalCase

    def __init__(self, style: str, allow_conflict: bool = False):
        self.style = self.guess_style(style)
        self.allow_conflict = allow_conflict
        self.func = getattr(self.__class__, self.style, None)
        if self.style and not self.func:
            raise ValueError(f'Invalid case style: {style}')

    def __call__(self, data):
        from utilmeta.core.schema import SchemaMeta
        if not self.style or not data:
            return data
        if multi(data):
            return [self(d) for d in data]
        elif isinstance(data, dict):
            result = {}
            if data.get('@'):
                return data
            for key, val in data.items():
                k = self(key)
                if not self.allow_conflict and k in result:
                    raise ValueError(f'Duplicate data key: {k}')
                result[k] = val
            return result
        elif isinstance(data, SchemaMeta):
            temp = self(data.__template__)
            return data.__reproduce__(
                template=temp, assign_template=True
            )
        elif isinstance(data, str):
            try:
                return self.func(data)
            except COMMON_ERRORS:
                return data
        return data

    @classmethod
    def pascal(cls, val: str):
        if not val:
            return ''
        split = None
        if '_' in val:
            # guess type: snake / cap_snake
            split = '_'
        elif '-' in val:
            split = '-'
        if split:
            val = "".join(
                word.capitalize() for word in val.split(split)
            )
        val = ''.join(filter(str.isalnum, val))
        if split:
            return val
        if val.islower():
            return val.capitalize()
        if val.isupper():
            return val.capitalize()
        if val[0].islower():
            # guess is PascalCase
            return val[0].upper() + val[1:]
        return val

    @classmethod
    def snake(cls, val: str):
        if not val:
            return ''
        if '_' in val:
            # guess type: snake / cap_snake
            return val.lower()
        elif '-' in val:
            return val.replace('-', '_').lower()

        val = ''.join(filter(str.isalnum, val))
        if val.islower():
            return val
        if val.isupper():
            return val.lower()

        s = ''
        for i, c in enumerate(val):
            if c.isupper():
                if i:
                    # not for first upper case
                    s += '_'
                c = c.lower()
            s += c

        return s

    @classmethod
    def camel(cls, val: str):
        val = cls.pascal(val)
        return val[0].lower() + val[1:]

    @classmethod
    def cap_snake(cls, val: str):
        return cls.snake(val).upper()

    @classmethod
    def kebab(cls, val: str):
        return cls.snake(val).replace('_', '-')

    @classmethod
    def cap_kebab(cls, val: str):
        return cls.cap_snake(val).replace('_', '-')

    @classmethod
    def generate_aliases(cls, val: str, styles: Union[str, List[str], bool] = '*'):
        if not styles:
            return []
        if styles == '*' or styles is True:
            styles = CaseStyle.gen()
        elif isinstance(styles, str):
            styles = [styles]
        aliases = []
        for style in styles:
            aliases.append(cls(style=style)(val))
        return aliases


class Alias(Util):
    class Field(Util):
        def __init__(self, alias_for: str, alias_from: Union[str, List[str]], relate_alias: 'Alias' = None):
            super().__init__(locals())
            if not alias_for or not alias_from:
                raise ValueError('Alias must contains non-empty alias_for and alias_from')
            self.alias_for = alias_for
            if isinstance(alias_from, str):
                alias_from = [alias_from]
            elif multi(alias_from) and alias_from:
                alias_from = distinct([str(a) for a in alias_from])
            else:
                raise TypeError(f'Alias.Field alias must be a non-empty str or List of str, got {repr(alias_from)}')
            self.alias_from = alias_from
            # print('ALIAS FORM:',)
            if relate_alias:
                assert isinstance(relate_alias, Alias), \
                    f'Alias.Field relate_alias must be Alias object, got {relate_alias}'
            self.relate_alias = relate_alias

        def __bool__(self):
            """
            This field does affect means bool(field) = True
            """
            if self.relate_alias:
                return True
            return [self.alias_for] != self.alias_from

        @property
        def keys(self):
            return [self.alias_for, *self.alias_from]

    def __init__(self, fields: List['Alias.Field'],
                 scope: tuple = None, prevents: tuple = (),
                 allow_conflict: bool = False,
                 reserve_original: bool = False):

        super().__init__(locals())
        # self.raw = dict(alias)
        # _alias = self.parse(alias)
        _keys = []
        _values = []
        _fields = []
        for_from_map = {}
        for field in fields:
            assert isinstance(field, self.Field), f'Alias fields must be List of Alias.Field object'
            if not field:
                # this field doesn't have effects
                continue
            _fields.append(field)
            _keys.append(field.alias_for)
            _values += field.alias_from
            for_from_map[field.alias_for] = field.alias_from

        dif = set(_keys).difference(scope) if scope else None
        inter = set(_values).intersection(prevents)
        # dup = duplicate(_values)

        assert not (dif or inter), \
            f"Field alias must satisfy: \n" \
            f"1. different from the existing fields: {prevents}, exceptions: {inter or None}\n" \
            f"2. in the alias scope: {scope}, exceptions: {dif or None}\n" \
            # f"3. not duplicate, exceptions: {dup or None}"
        self.fields = _fields
        self.for_from_map = for_from_map
        self.reserve_original = reserve_original
        self.allow_conflict = allow_conflict

    def __bool__(self):
        return bool(self.fields)

    def __contains__(self, item):
        for field in self.fields:
            if item in field.keys:
                return True
        return False

    def __call__(self, data: T) -> T:
        if not self or not data:
            return data
        if multi(data):
            return type(data)([self(d) for d in data])
        elif isinstance(data, dict):
            _data = {}
            for key, val in data.items():
                _k = None
                for field in self.fields:
                    if key == field.alias_for:
                        # first priority
                        if field.relate_alias:
                            val = field.relate_alias(val)
                        _k = field.alias_for
                        break
                    elif key in field.alias_from:
                        if field.relate_alias:
                            val = field.relate_alias(val)
                        _k = field.alias_for
                        break
                if _k:
                    if not self.allow_conflict and _k in _data:
                        raise ValueError(f'Duplicate data key: {_k}')
                    _data[_k] = val
                    if not self.reserve_original:
                        continue
                _data.setdefault(key, val)
            return type(data)(**_data)
        elif isinstance(data, str):
            for field in self.fields:
                if data in field.alias_from:
                    return field.alias_for
        return data

    def __and__(self, other: 'Alias') -> 'Alias':
        if not isinstance(other, Alias):
            raise TypeError(f'Alias and operator must connect with other Alias object, got {other}')
        if not self:
            return other
        if not other:
            return self
        fields = self.fields
        for field in other.fields:
            add = True
            for f in fields:
                if f == field:
                    add = False
                    break
            if add:
                fields.append(field)
        return Alias(fields)

    @classmethod
    def from_template(cls, template: dict) -> 'Alias':
        fields = []
        from utilmeta.core.schema import SchemaMeta
        if isinstance(template, SchemaMeta):
            template = template.__template__
        if not isinstance(template, dict):
            return cls([])
        for key, val in template.items():
            if isinstance(val, Rule):
                relate_alias = None
                if val.template:
                    relate_alias = cls.from_template(SchemaMeta.__retrieve__(val.template))
                if not relate_alias and not val.aliases:
                    continue
                fields.append(cls.Field(
                    alias_from=val.alias_from or [key],
                    alias_for=val.alias_for or key,
                    relate_alias=relate_alias)
                )
                continue
            relate_alias = cls.from_template(SchemaMeta.__retrieve__(val))
            if relate_alias:
                fields.append(cls.Field(alias_from=key, alias_for=key, relate_alias=relate_alias))
        return cls(fields=fields)


class Options(Util):
    excess_preserve: bool
    allow_excess: bool
    allow_type_transform: bool
    bulk_dict: bool
    list_item_merge: bool
    max_depth: int
    list_exclude_against: bool
    list_preserve_against: bool
    ignore_required: bool
    bypass_schema_data: bool
    best_effort_transform: bool

    case_insensitive: bool
    alias_from_case_styles: Union[str, List[str], bool]
    allow_conflict_case_styles: bool
    target_case_style: str
    alias_reserve_original: bool

    schema_allow_delete_required: bool
    schema_allow_popitem: bool
    schema_allow_clear: bool

    parser_cls: str

    def __init__(self, *, excess_preserve: bool = False,
                 allow_excess: bool = True,
                 ignore_required: bool = False,
                 allow_type_transform: bool = True,
                 alias_generator: Callable = None,
                 bypass_schema_data: bool = False,
                 best_effort_transform: bool = False,

                 alias_from_case_styles: Union[str, List[str], bool] = None,
                 allow_conflict_case_styles: bool = None,
                 target_case_style: str = None,
                 alias_reserve_original: bool = False,
                 parser_cls: str = None,

                 schema_allow_delete_required: bool = False,
                 schema_allow_popitem: bool = False,
                 schema_allow_clear: bool = False,

                 case_insensitive: bool = True, bulk_dict: bool = False, list_item_merge: bool = False,
                 max_depth: int = None, list_exclude_against: bool = False, list_preserve_against: bool = False):
        super().__init__(locals())
        self.excess_preserve = excess_preserve
        self.allow_excess = allow_excess
        if not allow_excess and excess_preserve:
            raise AttributeError("Schema excess_preserve=True requires excess_allow=True")
        self.transform = allow_type_transform
        if max_depth:
            assert isinstance(max_depth, int)
        self.max_depth = max_depth
        self.bulk_dict = bulk_dict
        self.case_insensitive = case_insensitive
        self.alias_generator = alias_generator
        self.list_item_merge = list_item_merge
        self.ignore_required = ignore_required
        self.best_effort_transform = best_effort_transform
        assert not (list_exclude_against and list_preserve_against), \
            "Schema list item strategy must choose from exclude or reserve"
        self.list_exclude_against = list_exclude_against
        self.list_preserve_against = list_preserve_against
        self.bypass_schema_data = bypass_schema_data

        self.alias_from_case_styles = alias_from_case_styles
        self.allow_conflict_case_styles = allow_conflict_case_styles
        self.target_case_style = target_case_style
        self.alias_reserve_original = alias_reserve_original

        self.schema_allow_delete_required = schema_allow_delete_required
        self.schema_allow_clear = schema_allow_clear
        self.schema_allow_popitem = schema_allow_popitem

        self.parser_cls_string = parser_cls

    @cached_property
    def parser_cls(self):
        from utilmeta.conf import config
        if not self.parser_cls_string:
            return config.preference.base_parser_cls
        cls = import_util(self.parser_cls_string)
        if not issubclass(cls, Parser):
            raise TypeError(f'Preference.base_parser_cls must inherit {Parser}, got {cls}')
        return cls

    @cached_property
    def class_parser_cls(self):
        from .cls import ClassParser
        from utilmeta.conf import config
        if not self.parser_cls_string:
            return config.preference.class_parser_cls
        cls = import_util(self.parser_cls_string)
        if not issubclass(cls, ClassParser):
            return ClassParser
        return cls

    @cached_property
    def function_parser_cls(self):
        from .func import FunctionParser
        from utilmeta.conf import config
        if not self.parser_cls_string:
            return config.preference.class_parser_cls
        cls = import_util(self.parser_cls_string)
        if not issubclass(cls, FunctionParser):
            return FunctionParser
        return cls

    @property
    def vacuum(self):
        return self._vacuum


class Parser(Util):
    # common parser, suitable for all python function and data classes
    # use <field_name>: <field_type> = <rule or default> to define template
    def __init__(self, field_holder, annotates: Dict[str, Any],
                 defaults: Dict[str, Any], options: Options = None, **kwargs):
        kwargs.update(locals())
        pop(kwargs, 'kwargs', pop(kwargs, 'self'))
        super().__init__(kwargs)

        # param_holder is a function or schema class, holding parameters and template
        if not inspect.isclass(field_holder) and not class_func(field_holder):
            raise TypeError(f'Invalid Parser field_holder: {field_holder}, must be class or function')
        if options:
            assert isinstance(options, Options), f'Invalid Parser options: {options}, must be Options object'

        self.holder = field_holder
        self.annotates = annotates
        self.defaults = defaults
        self.template: Dict[str, Any] = {}
        self.alias = Alias([])
        self.attr_alias = Alias([])
        self.options = options or Options()
        self.exclude_properties = set()
        self.make_template()
        self.__declare_path__ = f'{self.holder.__module__}.{self.holder.__name__}'

    @classmethod
    def valid_template(cls, template, for_read: bool = False):
        from utilmeta.util.field import Field
        from utilmeta.util.media import Media
        from utilmeta.core.schema import SchemaMeta

        if template is None:
            return Rule(default=None, null=True)
        if isinstance(template, (BaseParam, Field, BaseExpression, property)):
            return template
        elif Media.file_param(template):
            return template
        elif isinstance(template, list) or isinstance(template, set):
            t = type(template)
            template = list(template)
            if template:
                template = t([cls.valid_template(template[0])])
            else:
                template = t
            return template
        elif isinstance(template, tuple):
            pos_err = "tuple template must order by required -> defaulted -> omitted"
            def_beg = None
            omit_beg = None
            for i, v in enumerate(template):
                if isinstance(v, Rule):
                    if Bound.default in v:
                        def_beg = i
                        if omit_beg is not None:
                            assert omit_beg > def_beg, pos_err
                        continue
                    elif not v.require:
                        omit_beg = i
                        if def_beg is not None:
                            assert omit_beg > def_beg, pos_err
                        continue
                if omit_beg is not None:
                    assert omit_beg > i, pos_err
                if def_beg is not None:
                    assert def_beg > i, pos_err
                cls.valid_template(v)
            return template
        elif isinstance(template, dict):
            for key in list(template.keys()):
                val = template[key]
                assert isinstance(key, str), TypeError(f'Schema template key must be str, got {key}')
                template[key] = cls.valid_template(val)
            return template
        elif isinstance(template, SchemaMeta):
            cls.valid_template(template.__template__)
            if for_read:
                return template.__reproduce__(for_read=True)
            return template
        elif type(template) == type:
            # assert template in COMMON_TYPES, ValueError(f"Template type must in {COMMON_TYPES},\n got {template}")
            return template
        tp = cls.parse_type(template)
        if tp:
            return tp
        raise TypeError(f"Invalid template: {repr(template)}")

    @classmethod
    def parse_type(cls, t, for_read: bool = False):
        from utilmeta.core.schema import SchemaMeta
        # convert typing hint to standard parsable data structure
        if type(t) == type:
            return t
        if isinstance(t, SchemaMeta):
            return cls.valid_template(t, for_read=for_read)
        if isinstance(t, Util):
            return t
        if inspect.isclass(t) and issubclass(t, BaseParam):
            return t
        if isinstance(t, (dict, list, tuple)):
            return cls.valid_template(t, for_read=for_read)
        if t is Ellipsis:
            return None
        if isinstance(t, ForwardRef):
            t = t.__forward_arg__
        if isinstance(t, str):
            for tp in COMMON_TYPES:
                if t == tp.__name__ or t.endswith('.' + tp.__name__):
                    return tp
            print(f'unrecognized str type name: {t}')

        args = getattr(t, Attr.ARGS, None)
        origin = getattr(t, Attr.ORIGIN, None)
        if not args or not origin:
            raise TypeError(f"Invalid type: {t}")
        if hasattr(origin, Attr.ORIGIN):
            # in older (3.6) version, origin is typing object like List, Dict, has attr __extra__ to common type
            # but in new version, origin is common type like list, dict, set
            origin = getattr(origin, Attr.ORIGIN) or getattr(origin, Attr.EXTRA, None) or origin

        if origin in (list, set):
            return origin([cls.parse_type(args[0])])
        if origin == tuple:
            # to distinguish from Union tuple, directly use template
            return Rule(template=tuple(cls.parse_type(a) for a in args))
        if origin == dict:
            return Rule(dict_type=(cls.parse_type(args[0]), cls.parse_type(args[1])))
            # return {cls.parse_type(args[0]): cls.parse_type(args[1])}

        if isinstance(origin, Enum) or inspect.isclass(origin) and issubclass(origin, Enum):
            return Rule(choices=origin)
        if origin == Union:
            null = False
            union = []
            for arg in args:
                if arg is type(None):
                    null = True
                else:
                    _arg = cls.parse_type(arg)
                    if _arg:
                        union.append(_arg)
            union = union[0] if len(union) == 1 else tuple(union)
            return Rule(type=union, null=null)
        return None

    def make_template(self):
        from utilmeta.util.media import Media, File
        from utilmeta.util.field import Field
        from utilmeta.core.schema import SchemaMeta
        template = {}

        for key, val in self.annotates.items():
            if key.startswith('_'):
                continue
            kwargs = {}
            try:
                t = self.parse_type(val)
            except TypeError:
                t = None
            if t:
                # if isinstance(t, BaseParam):
                #     template[key] = t
                #     continue
                # entry for Rule type injection
                kwargs[Bound.type] = t

            if key in self.defaults:
                attr = self.defaults[key]
                if isinstance(attr, Field):
                    attr = attr.rule
                if attr is Ellipsis:
                    kwargs[Bound.require] = False
                elif isinstance(attr, Rule):
                    if Media.file_param(t):
                        template[key] = Media.file_rule(type=t, rule=attr)
                        continue
                    kwargs.update(attr.rules)
                elif isinstance(attr, File):
                    template[key] = Media.file_rule(type=t, rule=attr)
                    continue
                elif isinstance(attr, BaseExpression):
                    kwargs[Bound.require] = False
                else:
                    # temp = Rule.inject(t, attr)  # try to inject for multiple temp
                    # print('INJECT:', t, attr, temp)
                    if t:
                        kwargs[Bound.type] = t
                    if isinstance(attr, COMMON_TYPES) or attr in COMMON_TYPES or inspect.isfunction(attr):
                        # callable for dynamic default or simple type callable is accepted
                        kwargs[Bound.default] = attr

            template[key] = Rule(**kwargs)

        for key, val in self.defaults.items():
            if key.startswith('_'):
                continue
            # data[key] = val
            if key in template:
                continue
            if class_func(val):
                continue
            if isinstance(val, SchemaMeta):
                if val.__isolate__:
                    if key == val.__name__:
                        continue
                template[key] = self.valid_template(val)
            if isinstance(val, Rule):
                template[key] = val
                continue
            if Media.file_param(val):
                template[key] = Media.file_rule(val)
                continue
            if val in COMMON_TYPES:
                template[key] = Rule(type=val)
                continue
            if isinstance(val, Field):
                # not restrict readonly or not here
                # query template depend on it
                # field readonly is reflect when __setattr__ or __setitem__
                template[key] = val.rule
            if isinstance(val, BaseExpression):
                template[key] = Rule(require=False)
            if isinstance(val, property):
                if val.fget:
                    _rt = return_type(val.fget, raw=True)
                    if _rt and isinstance(_rt, str):
                        # calculated not retain property mark with str return type
                        self.exclude_properties.add(key)

                if val.fset:
                    from .func import FunctionParser
                    template[key] = FunctionParser(val.fset).template
                    # _self, param = inspect.signature(val.fset).parameters.values()
                    # _t = {'@': param.annotation} if param.annotation is not param.empty else {}
                    # _d = {'@': param.default} if param.default is not param.empty else {}
                    # template[key] = self.__make__(_t, _d).get('@', Rule())
                continue
            if type(val) in COMMON_TYPES:
                template[key] = Rule(default=val)
        # for now, alias is not considered in template
        # just generate based on attr name
        # then alter with Rule's alias config

        if self.options.alias_from_case_styles or self.options.target_case_style:
            for key in list(template):
                val = template[key]
                if self.options.alias_from_case_styles:
                    aliases = [key]
                    if isinstance(val, BaseParam):
                        aliases.extend(val.aliases)
                    alias_from = []
                    for k in aliases:
                        alias_from.extend(FieldTransfer.generate_aliases(
                            val=k, styles=self.options.alias_from_case_styles))
                    if key in alias_from:
                        alias_from.remove(key)
                    val = Rule.add_alias_from(val, *alias_from)
                if self.options.target_case_style:
                    name = key
                    if isinstance(val, BaseParam):
                        name = val.field_name or key
                    name = FieldTransfer(self.options.target_case_style)(name)
                    if name != key:
                        val = Rule.make_alias_for(val, alias=name)

                template[key] = val

        alias_fields = []
        attr_alias_fields = []
        keys = list(template.keys())
        for attname in keys:
            unit = template.get(attname)
            name = attname
            _from = [attname]
            if isinstance(unit, Rule):
                name = unit.alias_for or attname
                _from = unit.alias_from or []
                if unit.aliases:
                    inter = set(unit.aliases).intersection(keys).difference({attname, name})
                    assert not inter, \
                        f"Rule aliases: {inter} shouldn't in the Schema key scope"
                    alias_fields.append(Alias.Field(alias_from=[attname, *_from], alias_for=name))
                unit = unit.assign_attname(attname).simplify()
            if {name, *_from} != {attname}:
                attr_alias_fields.append(Alias.Field(alias_from=[name, *_from], alias_for=attname))
            if name != attname:
                # convert key names to attribute name
                template.pop(attname)
            template[name] = unit
        self.alias = Alias(
            alias_fields,
            allow_conflict=self.options.allow_conflict_case_styles,
            reserve_original=self.options.alias_reserve_original
        )
        # convert all valid field names to target name
        self.attr_alias = Alias(
            attr_alias_fields,
            allow_conflict=self.options.allow_conflict_case_styles,
            reserve_original=self.options.alias_reserve_original
        )
        self.template = template

    @classmethod
    def parse(cls, data, template, options: Options = Options(), depth=0):
        from utilmeta.core.schema import SchemaMeta, Schema, ArbitrarySchema
        assert isinstance(options, Options), \
            f"Schema parse options must be instance of Schema.Options, got {options}"
        info = dict(data=data, template=template, options=options)
        if template is None:
            return None
        if template is ...:
            return data
        if options.max_depth and depth > options.max_depth:
            raise RecursionExceeded(f"Recursion depth {depth} is greater than max_depth {options.max_depth}",
                                    depth=depth, **info)

        if isinstance(template, BaseParam):  # Rule / File
            return template(data, options=options)
        if not template and type(template) in (str, list):
            template = type(template)

        if type(template) == type:
            if not isinstance(data, template):
                if options.transform:
                    data = type_transform(data, template)
                else:
                    raise InvalidType(f"Data type: {type(data)} not match template type: {template}",
                                      data_type=type(data), **info)

        elif isinstance(template, list) or isinstance(template, set):
            t = type(template)
            template = list(template)
            values = []
            for i, d in enumerate(parse_list(data, merge=options.list_item_merge)):
                try:
                    values.append(cls.parse(d, template[0], options=options, depth=depth + 1))
                except COMMON_ERRORS as e:
                    if options.list_exclude_against:
                        warnings.warn(f'Parse Item: [{i}] excluded with error: {e}')
                        # print(Error(e).message)
                        continue
                    if options.list_preserve_against:
                        warnings.warn(f'Parse Item: [{i}] with template: '
                                      f'{readable(template[0], max_length=100)} ignored error: {e}')
                        values.append(ArbitrarySchema(d))
                        continue
                    raise Error().throw(ParseError, prepend=f'Parse Item: [{i}] with template: '
                                                            f'{readable(template[0], max_length=100)} '
                                                            f'with error: ', origin_exc=e)
            data = t(values)

        elif isinstance(template, tuple):
            data = parse_list(data)
            result = []
            for i, t in enumerate(template):
                if i >= len(data):
                    if isinstance(t, Rule):
                        if Bound.default in t:
                            result.append(t.default)
                        elif not t.require:
                            break
                        else:
                            raise AbsenceError(f"value required position {i} not in data", absence_item=i, **info)
                else:
                    result.append(cls.parse(data[i], template[i], options=options, depth=depth + 1))
            data = tuple(result)

        else:
            if isinstance(data, list):
                if not depth and options.bulk_dict:
                    return cls.parse(data, [template], options=options)
            if isinstance(data, Schema):
                if options.bypass_schema_data:
                    return data

            if not isinstance(data, (dict, Element)):
                data = type_transform(data, dict)
            if isinstance(template, SchemaMeta):
                if is_origin(data, template):
                    return data
                data = template(**data)
            elif isinstance(template, dict):
                if not options.allow_excess:
                    d = set(data.keys()).difference(template.keys())
                    if d:
                        raise ExcessError(
                            f"Data keys {d} is out of scope",
                            excess_items=d, **info
                        )

                result = dict(data) if options.excess_preserve else {}
                _data_class = data.__class__

                for key, temp in template.items():
                    names = [key]
                    if isinstance(temp, Rule):
                        if temp.alias_from:
                            names.extend(temp.alias_from)

                    if isinstance(data, Element):
                        value = get_value(data.attrib, names, allow_conflict=options.allow_conflict_case_styles)
                        if value is ...:
                            nodes = data.findall(key)
                            if nodes:
                                value = nodes
                    else:
                        value = get_value(data, names, allow_conflict=options.allow_conflict_case_styles)

                    if value is ...:
                        if isinstance(temp, Rule):
                            if temp.default is not ...:
                                result[key] = temp.get_default()
                                continue
                            elif not temp.require:
                                continue
                        if options.ignore_required:
                            # ignore required
                            continue
                        raise AbsenceError(f"Required key: {repr(key)} does not provided in data",
                                           absence_item=key, **info)
                    try:
                        result[key] = cls.parse(value, temp, options=options, depth=depth + 1)
                    except COMMON_ERRORS as e:
                        if options.best_effort_transform:
                            warnings.warn(f'Parse key: [{repr(key)}] with error: {e}, doing best effort transform')
                            result[key] = value
                            continue
                        raise Error().throw(
                            type=ParseError, origin_exc=e,
                            prepend=f'Parse key: [{repr(key)}] with error: ',
                        )

                data = _data_class(**result)
        return data

    def __call__(self, data, options: Options = None):
        return self.parse(self.alias(data), template=self.template, options=options or self.options)
