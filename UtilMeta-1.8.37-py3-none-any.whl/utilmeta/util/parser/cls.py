import inspect
from utilmeta.util.common import Attr, represent, Key
from utilmeta.util.rule import BaseParam, Rule
from django.db.models.expressions import BaseExpression
from django.db.models import Model
from typing import Any, Dict
from .base import Parser, Options
from .func import FunctionParser

__all__ = ['ClassParser']


class ClassParser(Parser):
    def __init__(self, field_holder, options: Options = None, **kwargs):
        from utilmeta.util.field import Field
        from utilmeta.core.schema import Schema
        from utilmeta.util.media import File
        data_types = (Field, Rule, File, BaseExpression, property)
        if not inspect.isclass(field_holder):
            raise TypeError(f'ClassParser field_holder must be class, got {field_holder}')
        self.type = None
        self.store = True
        self.meta = None
        self.init = None

        self.bases = []
        self.options_kwargs = {}
        fields = []
        __init = field_holder.__dict__.get(Attr.INIT)
        if __init:
            self.init = FunctionParser(__init, from_class=field_holder)
        annotates: Dict[str, Any] = {k: v for k, v in field_holder.__dict__.get(
            Attr.ANNOTATES, {}).items() if not k.startswith('_')}
        defaults: Dict[str, Any] = {k: v for k, v in field_holder.__dict__.items() if not k.startswith('_')}

        if issubclass(field_holder, Schema):
            self.type = Schema.__name__
            self.bases = [getattr(b, Key.ID) for b in getattr(field_holder, Attr.BASES) if getattr(b, Key.ID, None)]
            self.options_kwargs = field_holder.__options__.__spec_kwargs__
            self.options = field_holder.__options__

            for key, val in field_holder.__data__.items():
                name = key
                alias_from = []
                alias_for = None
                type = ''
                util = None
                if not isinstance(val, data_types):
                    val = field_holder.__template__.get(key)
                if not val:
                    continue
                if isinstance(val, Field):
                    alias_from = [val.name]
                    if val.rule:
                        type = represent(val.rule.type)
                    util = val._deconstruct()
                elif isinstance(val, BaseParam):
                    alias_from = val.alias_from
                    alias_for = val.alias_for
                    if val.attname:
                        name = val.attname
                    util = val.dict
                elif isinstance(val, BaseExpression):
                    type = str(val)
                elif isinstance(val, property):
                    type = property.__name__
                if isinstance(val, Rule):
                    type = represent(val.type)

                fields.append(dict(
                    name=name,
                    alias_from=alias_from,
                    alias_for=alias_for,
                    type=type,
                    util=util
                ))
        else:
            self.store = False
            # raise TypeError(f'Invalid field_holder type, must be Model or Schema class, got {field_holder}')

        # after store is certain
        kwargs.update(annotates=annotates, defaults=defaults, options=options)
        super().__init__(field_holder, **kwargs)

        if issubclass(field_holder, Model):
            self.template = Field.gen_for(field_holder)

        template = {}
        for base in field_holder.__bases__:
            parser: ClassParser = getattr(base, Attr.PARSER, None)
            if parser:
                template.update(parser.template)
                self.alias = self.alias & parser.alias
                self.attr_alias = self.attr_alias & parser.attr_alias
        template.update(self.template)
        # merge base template before parse init (because init may contains base schema's fields)
        if self.init:
            for key, val in self.init.template.items():
                template[key] = val if key not in template else Rule.merge(template[key], val)
            self.alias = self.alias & self.init.alias
            self.attr_alias = self.attr_alias & self.init.attr_alias
            self.init.template = template
            # sync to init function to absorb all template key args (but at the form of attname)
            # from functools import wraps
            #
            # @wraps(self.init.holder)
            # def _init(_self, *_args, **_kwargs):
            #     try:
            #         return self.init.kwargs_wrapper(_self, *_args, **_kwargs)
            #     except TypeError:
            #         pass
            # field_holder.__init__ = self.init.kwargs_wrapper   # wrap_init(self.init.holder, self.template)
        self.template = template
        self.fields = fields

    # @property
    # def _model_store(self) -> bool:
    #     return self.store
    #
    # @property
    # def _model_class(self):
    #     from utilmeta.ops.models.utils import DataClass
    #     return DataClass
    #
    # @property
    # def _model_data(self) -> dict:
    #     from utilmeta.conf import config
    #     return dict(
    #         id=self._id,
    #         type=self.type,
    #         instance_id=config.deploy.instance_id,
    #         document=getattr(self.holder, Attr.DOC, '') or '',
    #         declared_path=self.__declare_path__,
    #         application_id=self._app_id,
    #         name=self.holder.__name__,
    #         bases=self.bases,
    #         options=Util.clean_kwargs(self.options_kwargs),
    #         template=Rule.note(self.template)
    #     )
    #
    # def _model_save(self):
    #     from utilmeta.ops.models.utils import ParamField
    #     fields = [ParamField(**field, holder_id=self._id) for field in self.fields]
    #     super()._model_save()
    #     ParamField.objects.bulk_create(fields)
