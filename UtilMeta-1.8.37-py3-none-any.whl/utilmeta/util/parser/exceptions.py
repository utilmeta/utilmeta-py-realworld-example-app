# ERROR for handling parse
from typing import Union


class ParseError(TypeError, ValueError):
    def __init__(self, msg: str = None, *, origin_exc: Exception = None, template=None, data=None, options=None):
        self.msg = msg
        self.origin_exc = origin_exc
        self.template = template
        self.data = data
        self.options = options


class ExcessError(ParseError):
    # a key has excess the dict template and allow_excess=False in options
    def __init__(self, msg: str = None, excess_items: Union[list, set] = None, **kwargs):
        super().__init__(msg, **kwargs)
        self.excess_items = excess_items


class AbsenceError(ParseError):
    def __init__(self, msg: str = None, absence_item: Union[int, str] = None, **kwargs):
        super().__init__(msg, **kwargs)
        self.absence_item = absence_item


class InvalidType(ParseError, TypeError):
    def __init__(self, msg: str = None, data_type: type = None, **kwargs):
        super().__init__(msg, **kwargs)
        self.data_type = data_type


class RecursionExceeded(ParseError, RecursionError):
    def __init__(self, msg: str = None, depth: int = None, **kwargs):
        super().__init__(msg, **kwargs)
        self.depth = depth
