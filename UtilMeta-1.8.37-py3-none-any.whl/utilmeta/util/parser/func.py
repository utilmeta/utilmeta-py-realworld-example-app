import inspect
from utilmeta.util.common import class_func, analyze_func, return_type, represent, pop, dict_overflow, COMMON_ERRORS
from utilmeta.util.rule import BaseParam,  Rule
from typing import Tuple
from functools import wraps
from .base import Parser, Options

__all__ = ['FunctionParser']


class FunctionParser(Parser):
    def __init__(self, field_holder, *, from_class=None, options: Options = None,
                 parse_params: bool = True, parse_result: bool = True, provide_default: bool = True, **kwargs):
        if not class_func(field_holder):
            raise TypeError(f'Invalid FunctionParser holder: {field_holder}, must be method or function')

        field_holder, self.first_reserve = analyze_func(field_holder, from_class=from_class)
        self.parameters = inspect.signature(field_holder).parameters.items()
        if self.first_reserve:
            _, *self.parameters = self.parameters
        annotates = {k: v.annotation for k, v in self.parameters if v.annotation is not v.empty}
        defaults = {k: v.default for k, v in self.parameters if v.default is not v.empty}
        # if a param is not defaulted or annotated, it rule is Rule(require=True)

        self.key_var = None  # only for function, **kwargs
        self.pos_var_index = None
        self.pos_var = None  # only for function, *args
        self.pos_key_map = {}   # reverse version of arg index
        self.arg_index = {}
        self.max_args = 0
        self.min_args = 0
        self.do_parse_params = bool(parse_params)
        self.do_parse_result = bool(parse_result)
        self.arg_names = [k for k, v in self.parameters]
        self.kw_names = [k for k, v in self.parameters if v.kind in (v.KEYWORD_ONLY, v.POSITIONAL_OR_KEYWORD)]
        self.pos_annotate = None
        self.kw_annotate = None
        self.provide_default = provide_default

        fields = []
        default_positions = []
        default_keys = []

        for i, (k, v) in enumerate(self.parameters):
            v: inspect.Parameter
            if v.kind == v.VAR_POSITIONAL:
                self.pos_var_index = i
                self.pos_var = k
                self.pos_annotate = pop(annotates, k)
                continue
            elif v.kind == v.VAR_KEYWORD:
                self.key_var = k
                self.kw_annotate = pop(annotates, k)
                continue
            elif v.kind != v.KEYWORD_ONLY:
                self.max_args += 1
                self.pos_key_map[i] = k
                self.arg_index[k] = i
            if v.kind == v.POSITIONAL_ONLY:
                self.min_args += 1

            ty = represent(annotates.get(k, ''))
            alias_for = None
            alias_from = []
            util = None
            if v.default != v.empty:
                value = v.default
                default = value
                if isinstance(value, BaseParam):
                    default = value.default if not value.require else v.empty
                    alias_from = value.alias_from
                    alias_for = value.alias_for
                    util = value.dict
                if default != v.empty:
                    if v.kind != v.KEYWORD_ONLY:
                        default_positions.append(i)
                    default_keys.append(k)   # real default regardless of Rule
            elif k not in annotates:
                defaults[k] = Rule(require=True)

            fields.append(dict(
                name=k,
                type=ty,
                alias_for=alias_for,
                alias_from=alias_from,
                util=util,
            ))

        kwargs.update(annotates=annotates, defaults=defaults, options=options)
        super().__init__(field_holder, **kwargs)

        if self.provide_default:
            for key, val in self.template.items():
                if isinstance(val, BaseParam):
                    if not val.require and val.no_default:
                        raise TypeError(f'Optional param: {repr(key)} in function: <{self.holder.__name__}> '
                                        f'should define a default')

        if self.pos_annotate:
            self.pos_annotate = self.parse_type(self.pos_annotate)
        if self.kw_annotate:
            self.kw_annotate = Rule(dict_type=(str, self.kw_annotate))
        if self.key_var:
            self.options.excess_preserve = self.options.allow_excess = True
        self.fields = fields
        self.default_keys = default_keys
        self.default_positions = default_positions
        try:
            self.return_type = self.parse_type(return_type(self.holder))
        except TypeError:
            self.return_type = None

    @property
    def kwargs_wrapper(self):
        @wraps(self.holder)
        def f(_, *args, **kwargs):
            if not kwargs and len(args) == 1:
                data = args[0]
                if isinstance(data, dict):
                    try:
                        return self(_, **data)
                    except COMMON_ERRORS:
                        pass
            return self(_, *args, **kwargs)
        return f

    @property
    def wrapper(self):
        @wraps(self.holder)
        def f(*args, **kwargs):
            return self(*args, **kwargs)
        return f

    def parse_params(self, _args: tuple, _kwargs: dict) -> Tuple[tuple, dict]:
        # def f(self, *args, arg1, arg2, **kwargs):
        # self.f(1, 2, 3)
        # def f(self, data):
        # self.f({})
        # not keyword-only argument may show up at pos args
        args = []
        template = dict(self.template)
        for i, arg in enumerate(_args):
            if self.pos_var and i >= self.pos_var_index:
                # eg. f(a, b, *args): pos_var_index = 2
                if self.pos_annotate and self.do_parse_params:
                    arg = self.parse(arg, self.pos_annotate, options=self.options)
            else:
                key = self.pos_key_map.get(i)
                if not key:
                    break
                arg = self.parse(arg, pop(template, key), options=self.options) if self.do_parse_params else arg
            args.append(arg)

        if template:
            data: dict = self.alias(_kwargs)
            if self.kw_annotate:
                diff = self.kw_annotate(dict_overflow(template, data))
                data.update(diff)
            if self.do_parse_params:
                kwargs = self.parse(data, template, options=self.options)
                for key, val in data.items():
                    if key not in kwargs and key in self.kw_names:
                        # some kwargs that does not defined in template (may be a _ prefixed param)
                        kwargs[key] = val
            else:
                kwargs = data
        else:
            kwargs = _kwargs
        if not self.key_var:
            # need to restrict keys
            kwargs = {key: val for key, val in kwargs.items() if self.attr_alias(key) in self.kw_names}
        return tuple(args), kwargs

    def arg_required(self, arg, kw=False):
        if kw:
            if arg in self.arg_names:
                if arg in self.default_keys:
                    return False
                else:
                    return True
            elif self.key_var:
                return False
        else:
            if self.pos_var_index is not None:
                if arg >= self.pos_var_index:  # e.g. func: def f(a, b, *args, k): arg index >=2 will not be require
                    return False
            if arg in self.default_positions:
                return False
        return True

    def valid_omit(self, _p, omit_beg):
        kw = True
        if type(_p) == int:
            kw = False
        if not self.arg_required(_p, kw=kw):  # this positional arg has a default in param
            if omit_beg is None:
                omit_beg = _p
        elif omit_beg is not None:
            raise ValueError(f"Required argument ({_p}) "
                             f"is after a omitted arg ({omit_beg}), which is invalid")
        return omit_beg

    def __call__(self, *args, **kwargs):
        _ = None
        if self.first_reserve and args:
            _, *args = args
        args, kwargs = self.parse_params(args, kwargs)
        if self.first_reserve:
            args = (_, *args)
        result = self.holder(*args, **self.attr_alias(kwargs))
        if self.do_parse_result and self.return_type:
            result = self.parse(result, self.return_type, options=self.options)
        return result

    # @property
    # def _model_store(self) -> bool:
    #     return True
    #
    # @property
    # def _model_class(self):
    #     from utilmeta.ops.models.utils import Function
    #     return Function
    #
    # def _model_save(self):
    #     from utilmeta.ops.models.utils import ParamField
    #     super()._model_save()
    #     objs = [ParamField(**field, holder_id=self._id) for field in self.fields]
    #     ParamField.objects.bulk_create(objs)

    # @property
    # def _model_data(self) -> dict:
    #     from utilmeta.conf import config
    #     return dict(
    #         id=self._id,
    #         type='Function',
    #         instance_id=config.deploy.instance_id,
    #         name=self.holder.__name__,
    #         document=get_doc(self.holder),
    #         application_id=self._app_id,
    #         declared_path=self.__declare_path__,
    #         code=get_code(self.holder),
    #         return_type=represent(self.return_type) if self.return_type else None,
    #         template=Rule.note(self.template)
    #     )
