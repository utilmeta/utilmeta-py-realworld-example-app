from .req import RequestParser
from .base import Options
from typing import TYPE_CHECKING, Type, List
from utilmeta.fields import Model
import inspect
from utilmeta.util.rule import Rule
from utilmeta.util.error import Error
from utilmeta.util.page import Page
from utilmeta.util.operator import Operator


from utilmeta.util.common import pop, get_pk, restrict_keys, COMMON_METHODS, UnitAttr, multi, HAS_BODY_METHODS
from utilmeta.util.common import CommonMethod as M
import warnings

if TYPE_CHECKING:
    from utilmeta.core.module import Module
    from utilmeta.util.option import Option

__all__ = ['ModuleParser']


class ModuleParser(RequestParser):
    @classmethod
    def to_raw(cls, temp, _dict: bool = False):
        from utilmeta.core.schema import SchemaMeta
        if isinstance(temp, SchemaMeta):
            return temp.__template__
        elif isinstance(temp, dict):
            return temp
        elif multi(temp):
            if _dict and temp:
                return cls.to_raw(temp[0])
            return [cls.to_raw(t) for t in temp]
        return temp

    def __init__(self, field_holder, *,
                 cls: Type['Module'],
                 method: str,
                 route: str = None,
                 before: List[str] = None,
                 after: List[str] = None,
                 error: List[str] = None,
                 from_class=None, options: Options = None,
                 path_config: RequestParser.PathConfig = None, from_request: bool = False,
                 parse_params: bool = True, parse_result: bool = True, **kwargs
                 ):

        kwargs.update(locals())
        pop(kwargs, 'kwargs', pop(kwargs, 'self'))
        super().__init__(**kwargs)

        from utilmeta.util.option import Option
        from utilmeta.util.field import Field
        from utilmeta.util.request import Request
        from utilmeta.core.schema import SchemaMeta

        core = method and (not route or route in COMMON_METHODS)
        self.query_schema = None
        self.data_schema = None
        self.instance_key = None
        self.result_key = None
        self.error_key = None
        self.page = None
        self.bulk = None
        self.before_targets = before
        self.after_targets = after
        self.error_targets = error

        bulk = False
        holder_option = getattr(self.holder, UnitAttr.option, None)
        request: Request = getattr(self.holder, UnitAttr.request, None)
        self.auth = getattr(self.holder, UnitAttr.auth, request.auth if request else None)
        if core:
            self.auth = cls.method.auth.get(method)
            self.page: Page = cls.paging.get(method)
            self.bulk = cls.batch.get(method)
            bulk = bool(self.bulk)
        else:
            if error and set(error).intersection(cls.batch):
                bulk = True
            if before and set(before).intersection(cls.batch):
                bulk = True
            if after and set(after).intersection(cls.batch):
                bulk = True

        get = method == M.GET
        put = method == M.PUT
        post = method == M.POST
        patch = method == M.PATCH
        delete = method == M.DELETE

        has_body = method in HAS_BODY_METHODS
        if self.before_targets and set(self.before_targets).intersection(HAS_BODY_METHODS):
            has_body = True
        if self.after_targets and set(self.after_targets).intersection(HAS_BODY_METHODS):
            has_body = True
        if self.error_targets and set(self.error_targets).intersection(HAS_BODY_METHODS):
            has_body = True

        if holder_option:
            option = holder_option
        elif core:
            option = cls.option.__copy__()
            if not get:
                option.client_option = Option.Client()
            if post:
                option.filter_dict = {}
                if not option.path_param_create:
                    option.path_param_field = None
                    option.path_param_rule = None
        else:
            # sub-route's options path param still inherit base option
            option = Option(
                path_param_field=cls.option.path_param_field,
                path_param_rule=cls.option.path_param_rule,

                split_many_relation_query=cls.option.split_many_relation_query,
                ignore_invalid_params=cls.option.ignore_invalid_params,
                filter_with_rules=cls.option.filter_with_rules,
                ignore_mixin_conflicts=cls.option.ignore_mixin_conflicts,
                valid_integrity=cls.option.valid_integrity,

                schema_generator_cls=cls.option.schema_generator_cls_string,
                module_parser_cls=cls.option.module_parser_cls_string,
                module_queryset_cls=cls.option.module_queryset_cls_string,
                using_db=cls.option.using_db
            )

        def _pop(_k):
            if not self.query_key:
                pop(self.query, _k)

        for i, (k, v) in enumerate(self.parameters):
            v: inspect.Parameter
            if v.kind in (v.POSITIONAL_ONLY, v.VAR_POSITIONAL, v.VAR_KEYWORD):
                # raise TypeError(f'Module hook detect positional args: {repr(k)}')
                continue

            an = self.annotates.get(k)

            if inspect.isclass(an) and issubclass(an, Model):
                assert an is cls.model, \
                    f'{cls} route: <{route}> model annotate at key: {repr(k)} must be {cls.model}, got {an}'
                if k not in self.defaults:
                    option.ensure_sole = True
                self.instance_key = k
                _pop(k)
                continue

            if error and an is Error:
                if not self.error_key:
                    if not self.error_targets:
                        raise TypeError(f'Module function error key: {repr(k)} is only for error_hooks')
                    self.error_key = k
                    _pop(k)
                    continue

            if cls.query and an is cls.query:
                if not self.query_key:
                    self.query_key = k
                    self.query = self.parse_type(an)
                    _pop(k)
                    continue

            if cls.schema and an is cls.schema:
                if has_body and not self.body_key:
                    self.body_key = k
                    _pop(k)
                    continue
                if after:
                    self.result_key = k
                    _pop(k)
                    continue

            if cls.schema and an is List[cls.schema]:
                if has_body and not self.body_key:
                    self.body_key = k
                    _pop(k)
                    continue
                if after:
                    self.result_key = k
                    _pop(k)
                    continue

            # the types that cannot hint as
            if not i:
                if after:
                    self.result_key = k
                    _pop(k)
                    continue
                if error:
                    if an:
                        assert inspect.isclass(an) and issubclass(an, Error),\
                            f'Invalid error hook error param type: {error}'
                    self.error_key = k
                    _pop(k)
                    continue

        if self.body_key:
            _an = self.annotates.get(self.body_key)
            if _an:
                _tp = self.parse_type(_an)
                if bulk and not multi(_tp):
                    warnings.warn(f'Module function: {self.__declare_path__} is declared as bulk,\n'
                                  f'request data will accept List[{cls.schema}], got {_an} as type hint')
                if not bulk and multi(_tp):
                    warnings.warn(f'Module function: {self.__declare_path__} is not bulk method,\n'
                                  f'request data will accept {cls.schema}, got List[{cls.schema}] as type hint')

        _query_schema = SchemaMeta.__retrieve__(self.query, schema=True)
        if _query_schema:
            option.apply_query(_query_schema)
        else:
            option.apply_query(self.defaults)

        option.model = cls.model
        if self.page:
            option.client_option.apply_page(self.page)

        self.option = option
        self.query: dict = self.to_raw(self.query)
        self.body: dict = self.to_raw(self.body, _dict=True)

        if not method:
            # hooks
            return

        option.check(*cls.keys)
        # this function will called in the class initialization for once and provided a
        # constant dict to later parse

        if core:
            query = {}
            data = {}
            resp = {}

            pk_rule = Field.get_rule(get_pk(cls.model))
            if not option.ensure_sole:
                pk_rule = Rule.optional(pk_rule)

            if not option.path_param_field and not post:
                query[cls.pk_name] = pk_rule

            query.update(option.query_dict)

            if get:
                query.update(cls.schema_generator.gen(query=True, setter_target=lambda: self.query))
                resp.update(cls.schema_generator.gen(setter_target=lambda: self.return_type))
            elif not delete:
                data.update(cls.schema_generator.gen(
                    setter_target=lambda: self.body,
                    get=False, optional=patch, require=put, create=post,
                    optional_fields=[option.auto_user_field])
                )

            if get:
                multiple = bool(option.filters or cls.paging.get(method))

                if option.data_frame:
                    # data frame: {"key1": [...], "key2": [...]}
                    resp = {key: [val] for key, val in resp.items()}

                if cls.mixins:
                    for mixin in cls.mixins:
                        resp.update(mixin.read_template)

                if not option.data_frame and multiple:
                    resp = [resp]

            elif patch:
                cls.operators = cls.schema_generator.gen(cls.model, operators=True)
                data.update(Operator.gen(cls.operators))
            elif post:
                resp = Rule.required(pk_rule)

            if get or delete:
                if data:
                    raise TypeError(f'No body in get/delete')
                data = None

            if patch or put:
                # allow id in POST to self-define id
                # but don't allow id in PUT/PATCH cause pk is not meant to be modified
                if not cls.batch.get(method):
                    pop(data, 'id', pop(data, cls.pk_name))
                else:
                    # Bulk data need to reserve id
                    data[cls.pk_name] = pk_rule

            if cls.inherited and cls.base.option.assign:
                base_unit = cls.base.get_unit(method)
                parser = base_unit.parser
                base_resp = base_unit.response
                if get:
                    cls.base.keys.update(cls.keys)
                    parser.query.update(cls.base.option.options)
                    # an assigned base module result may lead to submodule result schema
                    # do merge or union in Response logic
                    base_resp.union_schema(resp)
                elif not delete:
                    for key, val in data.items():
                        if key not in parser.body:
                            parser.body[key] = Rule.optional(val)

            if cls.batch.get(method):
                self.body_options.bulk_dict = True

            query_domain = cls.method.query_domain.get(method)
            body_domain = cls.method.body_domain.get(method)

            if query_domain:
                dif = set(query_domain).difference(query)
                assert not dif, f'Module method params domain: {dif} for {repr(method)} is out of params scope'
                query = restrict_keys(keys=set(query_domain).union({cls.pk_name}),
                                      data=query, default=pk_rule)
            # pk_name query / body does not affected by domain (eg. for bulk)
            if body_domain:
                dif = set(body_domain).difference(data)
                assert not dif, f'Module method body domain: {dif} for {repr(method)} is out of data scope'
                data = restrict_keys(keys=set(body_domain).union({cls.pk_name}),
                                     data=data, default=pk_rule)

            if not self.query:
                self.query = query
            if not self.body:
                self.body = data
            if not self.return_type:
                self.return_type = resp

        elif method:
            self.query.update(option.query_dict)

        if self.option.path_param_field:
            self.kwargs[self.option.path_param_field] = self.option.path_param_rule
            if self.option.path_param_required:
                # remove query
                self.query = {}

        self.query_options.allow_excess = bool(option.ignore_invalid_params)

        if self.body is not None:
            # request schema is the first wrapper to convert raw data to schema data
            # directly set data, because when data is set by the setter of field this template is also updated
            if core:
                for mixin in cls.mixins:
                    unit = mixin.get_unit(method)
                    if not unit:
                        continue
                    mix_body = unit.parser.body
                    if mix_body:
                        self.body.update({key: Rule.optional(val) for key, val in mix_body.items()})
                    # for mixins, update optional mix rules to main body

            self.data_schema = cls.schema.__reproduce__(
                options=Options(
                    ignore_required=True,
                    allow_excess=True,
                    excess_preserve=True
                    # for module function, other field (not related to model)
                    # will be delete after module.process_data
                ),
                # with_properties=get,
                name=f'_{cls.__name__}{method.capitalize()}Schema',
                template=self.body, assign_template=True  # assign template (for lazy module setter)
            )

        _query_schema = _query_schema or cls.query
        if _query_schema:
            self.query_schema = _query_schema.__reproduce__(
                options=self.query_options,
                name=f'_{cls.__name__}{method.capitalize()}Query',
                template=self.query, assign_template=True
            )

    # def parse_request(self, request):
    #     args, kwargs = super().parse_request(request=request)
    #
