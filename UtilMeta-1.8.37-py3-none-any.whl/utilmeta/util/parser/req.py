import inspect
from utilmeta.util.common import duplicate, Reg, url_join,\
    full_match_reg, regular, valid_attr, \
    sub_regs, CONTENT_TYPE, exc, handle_parse
from utilmeta.util.rule import Rule
from typing import Dict, List, Tuple
from utilmeta.util.call import Call
import re
from .base import Options
from .func import FunctionParser

__all__ = ['RequestParser']


class RequestParser(FunctionParser):
    # suitable to handle http requests
    class PathConfig:
        def __init__(self, path: str, regex: bool = False,
                     path_unit: str = None):
            self.path = path.strip('/')
            if '(?P<' in path:
                regex = True
            if path.startswith('^') or path.endswith('$'):
                regex = True

            self.regex = regex
            self.path_unit = path_unit or Reg.ALNUM_SCORE_SEP

        def __call__(self, parser: 'RequestParser') -> Tuple[list, List[str], Dict[str, str]]:
            pos = 0  # new args position, also the num of args
            regs = []
            path_kwargs = []
            keys = []
            pos_keys = []
            used_keys = parser.used_keys
            pos_var = parser.pos_var
            key_var = parser.key_var
            parameters = parser.parameters
            valid_omit = parser.valid_omit

            def valid_keys(_k):
                assert _k not in pos_keys, f"Unit path kwargs key <{_k}> in the positional keys {pos_keys}"
                assert _k not in used_keys, f"Unit path kwargs key <{_k}> in used keys: {used_keys}"
                if key_var:
                    if _k not in keys:
                        keys.append(_k)
                else:
                    assert _k in keys, f"Unit keyword param <{_k}> should define in " \
                                       f"function params or use a **kwargs in function to obtain"

            def gen_keys(args_num: int = 0):
                if not pos_var and args_num > len(parameters):
                    raise TypeError(
                        f"Unit path args ({args_num}) overflow the args in function ({len(parameters)})")
                _pos_var = None
                _keys = []
                for index, (key, val) in enumerate(parameters):
                    val: inspect.Parameter
                    if val.kind == val.VAR_POSITIONAL:
                        _pos_var = index
                    if _pos_var is None:
                        if index >= args_num:
                            if val.kind in (val.KEYWORD_ONLY, val.POSITIONAL_OR_KEYWORD):
                                _keys.append(key)
                    else:
                        if val.kind in (val.KEYWORD_ONLY, val.POSITIONAL_OR_KEYWORD):
                            _keys.append(key)
                return [par[0] for par in parameters[:args_num]], _keys

            if not self.regex:
                try:
                    params = re.findall(Reg.PATH_REGEX, self.path)
                    d = duplicate(params)
                    assert not d, f"Unit path should't contains duplicate param {d}"
                    assert params, "Unit path should define at least one param use {<key or pos>}, " \
                                   "elsewhere you should define a sub API"
                    args = max([int(n) for n in params if n.isdigit()] or [-1]) + 1
                    pos_keys, keys = gen_keys(args)

                    omit = None
                    beg = 0
                    divider = []
                    for p in params:
                        p: str
                        if p.isdigit():
                            assert pos == int(p), f"Unit positional path arg ({p}) " \
                                                  f"should be continuous"
                            omit = valid_omit(pos, omit)
                            pos += 1
                        else:
                            if not valid_attr(p):
                                raise ValueError(f'Invalid keyword param {p} as a variable')
                            omit = valid_omit(p, omit)
                            valid_keys(p)
                            path_kwargs.append(p)
                        sub = '{%s}' % p
                        end = self.path.find(sub)
                        div = self.path[beg:end]
                        if beg and not div:
                            raise ValueError(f"Unit path param {sub} should divide each other with string")
                        divider.append((div, p))
                        beg = end + len(sub)

                    pattern = r''
                    for div, param in divider:
                        div = regular(div)
                        if param == str(omit) or param != str(omit) and regs:
                            regs.append(re.compile(full_match_reg(pattern)))
                        pattern += f'{div}({self.path_unit})' if param.isdigit() \
                            else f'{div}(?P<{param}>{self.path_unit})'
                    regs.append(re.compile(full_match_reg(pattern)))
                    regs.reverse()  # reverse the reg list so the longest reg match the path first,
                    # if success then break, else try out all the regs
                except (AssertionError, ValueError):
                    self.regex = True

            if self.regex:
                regex = re.compile(full_match_reg(self.path))
                if regex.groups:
                    # assert regex.groups, f"Unit regex {self.path} must has at least one group, " \
                    #                      f"elsewhere you should define a sub API"
                    pos = regex.groups - len(regex.groupindex.keys())

                    pos_keys, keys = gen_keys(pos)
                    for p in range(0, pos):
                        assert parser.arg_required(p), \
                            f"Unit reg positional arg {p} must be required (cannot set default)"
                    for k in regex.groupindex.keys():
                        assert parser.arg_required(k, kw=True), \
                            f"Unit reg keyword arg {k} must be required (cannot set default)"
                        valid_keys(k)
                    regs.append(regex)
                    path_kwargs = list(regex.groupindex.keys())
                else:
                    self.regex = False

            if pos < parser.min_args:
                raise TypeError(f"Unit path positional args num ({pos}) < "
                                f"POSITIONAL_ONLY args num ({parser.min_args})")
            if pos_var and parser.pos_var_index >= pos:
                raise ValueError(f"Unit param *args position ({pos_var}) >= "
                                 f"possible positional arg num ({pos}), the args will always be empty")

            args_reg, kwargs_reg = sub_regs(self.path) if self.regex else\
                [self.path_unit] * pos, {k: self.path_unit for k in path_kwargs}

            return regs, args_reg, kwargs_reg

    def __init__(self, field_holder, *, from_class=None, options: Options = None,
                 path_config: PathConfig = None, from_request: bool = False,
                 provide_default: bool = True,
                 parse_params: bool = True, parse_result: bool = True, **kwargs):
        kwargs.update(
            from_class=from_class, options=options,
            parse_params=parse_params,
            parse_result=parse_result,
            provide_default=provide_default
        )
        super().__init__(field_holder, **kwargs)

        from utilmeta.util.request import Request
        from utilmeta.util.media import File
        self.args = []  # template for path positional arguments
        self.kwargs = {}  # template for path kwargs
        # self.params = {}    # template for querystring params
        self.query = {}  # template for querystring params
        self.headers = {}  # template for headers
        self.body = None  # template for requestBody
        self.path = None
        self.regex_list = []

        self.kw_template = {}
        self.body_key = None
        self.headers_key = None
        self.query_key = None
        self.path_key = None
        # self.path_url = path_url
        self.path_config = None
        self.query_options: Options = self.options.__copy__()
        self.body_options: Options = self.options.__copy__()
        self.headers_options: Options = self.options.__copy__()

        self.from_request = from_request
        self.path_keys = []

        used_keys = []
        file_keys = []

        for k, v in self.defaults.items():
            a = self.annotates.get(k)
            if k not in self.template:
                continue
            t = self.template.get(k)
            has_schema = Rule.gen_from(t).has_schema
            if v in (Request.Path, Request.path):  # for capable of compat
                if self.path_key:
                    raise ValueError(f"RequestParser detect duplicate Path key <{self.path_key}>, <{k}>")
                Request.Path.valid(a)
                self.path_key = k
                used_keys.append(k)
                if not from_request:
                    self.template[k] = Rule.make_default(t, '')
            elif v in (Request.Body, Request.BODY, Request.body, Request.data):
                Request.Body.valid(a)
                if self.body_key:
                    raise ValueError(f"RequestParser detect duplicate Body key <{self.body_key}>, <{k}>")
                self.body_key = k
                used_keys.append(k)
                if not from_request and not has_schema:
                    self.template[k] = Rule.make_default(t, None)
            elif v in (Request.Query, Request.QUERY, Request.query):
                Request.Query.valid(a)
                if self.query_key:
                    raise ValueError(f"RequestParser detect duplicate Query key <{self.query_key}>, <{k}>")
                self.query_key = k
                used_keys.append(k)
                if not from_request and not has_schema:
                    self.template[k] = Rule.make_default(self.template[k], dict)
            elif v in (Request.Headers, Request.META, Request.headers):
                Request.Headers.valid(a)
                if self.headers_key:
                    raise ValueError(f"RequestParser detect duplicate Headers key <{self.headers_key}>, <{k}>")
                self.headers_key = k
                used_keys.append(k)
                if not from_request and not has_schema:
                    self.template[k] = Rule.make_default(self.template[k], dict)
            elif isinstance(v, File) or inspect.isclass(a) and issubclass(a, File):
                if self.body_key:
                    raise ValueError(f"RequestParser detect file key <{k}> while body key <{self.body_key}>")
                used_keys.append(k)
                file_keys.append(k)
                self.template[k] = Rule.make_default(self.template[k], File())

        self.used_keys = used_keys
        remains = list(set(self.arg_names).difference(used_keys))

        if path_config:
            assert isinstance(path_config, self.PathConfig), \
                f'RequestParser path_config must be PathConfig object, got {path_config}'

            self.regex_list, args_reg, kwargs_reg = path_config(self)

            for i, reg in enumerate(args_reg):
                if self.pos_var is not None and i >= self.pos_var_index:
                    self.args.append(Rule(require=False, regex=reg))
                else:
                    k = self.parameters[i][0]
                    assert k not in self.alias, f"Unit path args: {k} alias is useless, please remove it"
                    if k in remains:
                        remains.remove(k)
                    self.args.append(Rule.merge(Rule(regex=reg), self.template.get(k, Rule())))

            for key, reg in kwargs_reg.items():
                assert key not in self.alias, f"Unit path kwargs: {repr(key)} alias is useless, " \
                                              f"remove it or change the path kwargs name"
                if key in remains:
                    remains.remove(key)
                self.kwargs[key] = Rule(require=False, regex=reg) if key not in self.template \
                    else Rule.merge(Rule(regex=reg), self.template[key])

            self.args = tuple(self.args)
            self.path_config = path_config
        elif self.path_key:
            self.path = self.template.get(self.path_key, str)

        if self.query_key:
            self.query = self.template.get(self.query_key, {})
        else:
            self.query = {k: self.template.get(k, Rule()) for k in self.alias(remains) if k in self.template}
            remains = []

        if self.body_key:
            self.body = self.template.get(self.body_key, Rule())
        elif self.query_key and remains:
            self.body = {k: self.template.get(k, Rule()) for k in self.alias(remains) if k in self.template}

        if file_keys:
            if not self.body:
                self.body = {}
            for fk in file_keys:
                self.body[fk] = self.template.get(fk, File())

        if self.headers_key:
            self.headers = self.template.get(self.headers_key, {})

        if path_config:
            assert not remains, f"Unit function detect redundant params {remains}, define them in path kwargs"

        self.check()

    @handle_parse
    def parse_request(self, request):
        from utilmeta.util.request import Request
        if not isinstance(request, Request):
            raise TypeError(f'Invalid request: {request}, must be Request object')
        # only classify request (path | query | body | headers), don't parse specific data
        path = request.route
        query = request.query
        body = request.body
        headers = request.headers
        args = []
        kwargs = {}
        if self.regex_list:
            path_args = ()
            path_kwargs = {}
            match = None
            for regex in self.regex_list:
                match = regex.match(path)
                if match:
                    args_pos = tuple(set(range(1, regex.groups + 1)).difference(regex.groupindex.values()))
                    path_args = tuple([match.groups()[i - 1] for i in args_pos])
                    path_kwargs = match.groupdict()
                    break
            if not match:
                raise exc.NotFound(path=path)
            args = path_args
            kwargs.update(path_kwargs)
        elif path:
            if self.path_key:
                kwargs[self.path_key] = path
            else:
                raise exc.NotFound(path=path)

        if self.query_key:
            kwargs[self.query_key] = query
        elif isinstance(query, dict):
            kwargs.update(query)
        else:
            raise TypeError(f"non-dict params {query}")
        if self.body_key:
            kwargs[self.body_key] = body
        elif isinstance(body, dict):
            kwargs.update(body)
        if self.headers_key:
            kwargs[self.headers_key] = headers
        return tuple(args), kwargs

    # parse to generate request (reverse action of parse_request)
    def request_call(self, args, kwargs,
                     base_url: str = None,
                     append_slash: bool = None,
                     base_query: dict = None,
                     base_headers: dict = None,
                     timeout: int = None,
                     block: bool = True,
                     logger=None) -> Call:
        # get Call object from kwargs
        args, kwargs = self.parse_params(args, kwargs)
        path = ''
        query = base_query or {}
        headers = base_headers or {}
        body = None

        def get(k, d=None, _pop=False):
            try:
                if k in kwargs:
                    return kwargs.pop(k) if _pop else kwargs[k]
                if args:
                    return args[self.arg_index[k]]
            except (KeyError, IndexError):
                # @call function may have default
                pass
            return d

        if self.path_key:
            path = get(self.path_key, '')

        target_url = url_join(base_url, path, append_slash=append_slash) if base_url else path

        for i, arg in enumerate(self.args):
            unit = '{%s}' % i
            target_url = target_url.replace(unit, str(args[i]))
        for key in self.kwargs:
            unit = '{%s}' % key
            target_url = target_url.replace(unit, str(get(key, _pop=True)))

        if self.query_key:
            query.update(get(self.query_key, {}))
        elif self.query:
            query.update(kwargs)
            if args:
                for ar in self.query:
                    if ar not in query:
                        query[ar] = get(ar)
        if self.body_key:
            body = get(self.body_key)
        elif self.body:
            body = kwargs
        if self.headers_key:
            headers.update(get(self.headers_key, {}))

        return Call(
            url=target_url,
            query=query,
            data=body,
            headers=headers,
            timeout=timeout,
            logger=logger,
            block=block
        )

    @property
    def content_type(self):
        from utilmeta.util.request import Request
        return self.headers.get(CONTENT_TYPE, Request.Body.content_type(self.body))

    @property
    def vacuum(self):
        return not (self.args or self.path or self.kwargs or self.query or self.headers or self.body)

    @property
    def path_params(self) -> dict:
        params = dict(self.kwargs)
        for i, arg in enumerate(self.args):
            params[i] = arg
        return params

    def check(self):
        from utilmeta.util.request import Request
        if self.query is dict:
            self.query = {}
        if self.headers is dict:
            self.headers = {}
        if self.body:
            Request.Body.valid(self.body)
        if self.query:
            Request.Query.valid(self.query)
        if self.headers:
            Request.Headers.valid(self.headers)

    @handle_parse
    def parse_params(self, _args: tuple, _kwargs: dict) -> Tuple[tuple, dict]:
        return super().parse_params(_args, _kwargs)

    @handle_parse
    def parse_query(self, query: dict, options: Options = None) -> dict:
        return self.parse(query, self.query, options=options or self.query_options)

    @handle_parse
    def parse_body(self, body, options: Options = None):
        return self.parse(body, self.body, options=options or self.body_options)

    @handle_parse
    def parse_headers(self, headers, options: Options = None):
        return self.parse(headers, self.headers, options=options or self.headers_options)
