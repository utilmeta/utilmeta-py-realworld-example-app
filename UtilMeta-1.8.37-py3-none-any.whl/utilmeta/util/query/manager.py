from django.db.models import QuerySet, Manager, Count, Aggregate, Model, Case, When, Q, Subquery, OuterRef, \
    ForeignKey, ManyToOneRel, ManyToManyField, ManyToManyRel
from django.db.models.fields.files import FieldFile
from django.db.models.expressions import BaseExpression
from django.db import connections, transaction
from django.db.backends.base.base import BaseDatabaseWrapper
from ..common import get_field, one_to, many_to, get_exp_field, Static, \
    multi, get_fields, merge_multiple, map_list, parse_list, field_in_query, \
    pop, is_pk, SEG, Key, add_field_id, clean_pks, merge_fields, make_dict_by, \
    MAX_ENTRIES, LOOKUPS, readable, ignore_errors, include_many_relates, del_field_id, get_reverse_lookup,  \
    WRITE_BACK, CACHE_ASIDE, WRITE_THROUGH, get_pk, get_field_name, PK, ID, exc, order_list
from ..cache import BaseModelCache
from .resolver import Lookup, resolve_expression
from typing import Dict, Optional, Tuple, List, Callable, Union, Any, TYPE_CHECKING
from datetime import datetime
import warnings
from django.core.exceptions import FieldDoesNotExist

if TYPE_CHECKING:
    from ..request import Request

__all__ = ['MetaManager', 'MetaQuerySet', 'MetaQueryValues']


class RelMode(Static):
    SET = 'set'
    ADD = 'add'
    REMOVE = 'remove'
    CLEAR = 'clear'


class MetaQuerySet(QuerySet):
    """
    QuerySet wrapper for UtilMeta to support Auto-Cache System and Distribution System
    """
    # def __iter__(self):
    #     cache = self.get_cache()
    #     if not cache:
    #         return super().__iter__()
    #
    #     if self._result_cache is None:
    #         instances = []
    #         values: List[dict] = list(self.values())
    #         for value in values:
    #             i = self.model(pk=value.get(self.pk_name))
    #             for key, val in value.items():
    #                 setattr(i, key, val)
    #             instances.append(i)
    #         if not instances:
    #             return super().__iter__()
    #         self._result_cache = instances
    #     return iter(self._result_cache)

    def __bool__(self):
        cache = self.get_cache()
        if not cache:
            return super().__bool__()
        return self.exists()

    @property
    def pk_type(self) -> type:
        from ..field import Field
        return Field.get_type(self.model) or str

    def select_for_update(self, nowait=False, skip_locked=False, of=(), no_key=False):
        """
        For distribute services, this select for update should lock
        """
        try:
            return super().select_for_update(nowait=nowait, skip_locked=skip_locked, of=of, no_key=no_key)
        except TypeError:
            # for django compat
            return super().select_for_update(nowait=nowait, skip_locked=skip_locked, of=of)

    @property
    def connection(self) -> BaseDatabaseWrapper:
        return connections[self.db]

    @property
    def in_transaction(self) -> bool:
        return self.connection.in_atomic_block

    def alter_query_from(self, from_q: Q = Q(), args: tuple = (), kwargs: dict = None, exclude: bool = False):
        for arg in args:
            if isinstance(arg, Q):
                q = ~arg if exclude else arg
                from_q &= q
        kwargs = kwargs or {}
        if list(kwargs.keys()) == [Key.PK_IN] and not exclude:
            pks = self.parse_pk_list(kwargs[Key.PK_IN])
            if Key.PK_LIST in self._hints:
                if set(self.pk_list) == set(pks):
                    return self
            elif not from_q:
                # if there has no internal_q (no filters yet)
                # the pk__in query will directly set the pk_list
                self.pk_list = pks
        if kwargs:
            q = ~Q(**kwargs) if exclude else Q(**kwargs)
            from_q &= q
        self.internal_q = from_q

        return self

    @property
    def internal_q(self) -> Q:
        return self._hints.get(Key.Q, Q())

    @internal_q.setter
    def internal_q(self, q: Q):
        del self.pk_list
        self._hints[Key.Q] = q

    @ignore_errors
    def last_modified(self, domain: dict, seq: bool = False) -> datetime:
        cache = self.get_cache()
        now = datetime.now()
        if not cache:
            return now
        time = cache.last_modified(self.pk_values, domain=domain, seq=seq)
        if not isinstance(time, datetime):
            return now
        return time

    @property
    def disable_cache(self):
        return bool(self._hints.get(Key.DISABLE_CACHE))

    @property
    def pk_name(self):
        return get_pk(self.model, root=True).name

    @ignore_errors
    def resolve_query(self, with_orders: bool = True):
        """
        For the reason that the cache hold all the relations
        the relation-only query can goes without query DB
        """
        cache = self.get_cache()
        if not cache:
            return None
        _q = self.internal_q
        if not self.query.order_by:
            order = None
        elif '?' in self.query.order_by:
            order = '?'
        elif set(self.query.order_by).issubset({self.pk_name, PK, '-' + self.pk_name, '-' + PK}):
            order = not self.query.order_by[0].startswith('-')
        else:
            # unresolvable with complicate order, direct query DB without further parse
            if with_orders:
                return None
            order = None

        result = None
        query_db = False
        if not _q:
            if self.query.where:
                return None
            else:
                result = cache.pk_list
                if result is None:
                    return None

        def retrieve_keys(field: str, value):
            lookup = 'exact'
            for f in LOOKUPS:
                if field.endswith(SEG + f):
                    lookup = f
                    field = field[:-len(SEG + f)]
            func = getattr(Lookup, lookup, Lookup.IN)
            if not multi(value) and func is Lookup.IN:
                func = Lookup.exact
            if isinstance(value, Model):
                value = value.pk
            elif isinstance(value, MetaQuerySet):
                value = value.pk_list
            elif isinstance(value, QuerySet):
                return None
            elif multi(value):
                # prevent resolve_pk_list counter invalid repr(Model object) input
                value = [v.pk if isinstance(v, Model) else v for v in value]
            return cache.resolve_pk_list(lookup=field, value=value, func=func)

        def recursive_resolve(q: Q) -> Tuple[bool, list]:
            _and = q.connector == q.AND
            pk_set = None if _and else set()
            db_query = False
            for child in q.children:
                keys = []
                if isinstance(child, Q):
                    db_query, keys = recursive_resolve(child)
                elif isinstance(child, list):
                    key_list = None
                    for f, v in child:
                        val = retrieve_keys(f, v)
                        if val is None:
                            return True, []
                        key_list = val if key_list is None else key_list.intersection(val)
                    keys = key_list
                elif isinstance(child, tuple):
                    keys = retrieve_keys(*child)
                    db_query = keys is None
                if db_query:
                    return True, []
                if _and and not keys:
                    return False, []
                if _and:
                    pk_set = set(keys) if pk_set is None else pk_set.intersection(keys)
                else:
                    pk_set = pk_set.union(keys)
            if q.negated:
                return db_query, list(set(cache.pk_list or []).difference(pk_set))
            return db_query, list(pk_set)

        if result is None:
            query_db, result = recursive_resolve(_q)
        if query_db:
            return None
        t = self.pk_type
        if t is not str:
            result = [t(v) for v in result]
        # convert type before order
        if order == '?':
            import random
            random.shuffle(result)
        elif order is not None:
            # order by pk
            result.sort(reverse=not order)
        return result[self.query.low_mark: self.query.high_mark]

    def query_db_pks(self):
        return list(self.reconstruct_queryset(query_only=True).values_list(PK, flat=True))

    def fetch(self, pk) -> Union[Model, Any]:
        if pk is None:
            return None
        instance = self.model(pk=pk)
        query = self.filter(pk=pk)
        query.pk_list = [pk]
        values = list(query.values())
        if not values:
            return None
        data = values[0]
        for key, val in data.items():
            setattr(instance, key, val)
        state = getattr(instance, '_state', None)
        if state:
            state.db = query.db
        return instance

    def get_cache(self) -> Optional[BaseModelCache]:
        from utilmeta.conf import config
        if not config.auto_cache or not config.auto_cache.model_cache or self.disable_cache:
            return None
        cache = config.auto_cache.get(self.model)
        if not cache or not cache.fields_loaded:
            # before setup
            return None
        return cache

    def fetch_pk_list(self, *pk_list):
        return self.order_by(Case(*[When(pk=pk, then=pos) for pos, pk in enumerate(pk_list)])).filter(pk__in=pk_list)

    def order_by(self, *field_names) -> 'MetaQuerySet':
        if field_names:
            del self.pk_list
        return super().order_by(*field_names)

    def filter(self, *args, **kwargs) -> 'MetaQuerySet':
        args, kwargs = self._get_query_params(args, kwargs)
        q = super().filter(*args, **kwargs)
        return q.alter_query_from(self.internal_q, args=args, kwargs=kwargs, exclude=False)

    def exclude(self, *args, **kwargs) -> 'MetaQuerySet':
        args, kwargs = self._get_query_params(args, kwargs)
        q = super().exclude(*args, **kwargs)
        return q.alter_query_from(self.internal_q, args=args, kwargs=kwargs, exclude=True)

    def _get_query_params(self, args: tuple, kwargs: dict) -> Tuple[tuple, dict]:
        if self.model:
            pks = get_pk(self.model).name, PK, ID
            params = {}
            # prevent error: Field <pk> expected a number/string but got <Model instance>
            for key, val in kwargs.items():
                key = str(key)
                if key in pks:
                    if isinstance(val, Model):
                        val = val.pk
                elif key.rstrip('__in') in pks:
                    val = self.parse_pk_list(val)
                params[key] = val
            kwargs = params
        return args, kwargs

    def exists(self) -> bool:
        cache = self.get_cache()
        if not cache:
            return super().exists()
        pks = self.resolve_query(with_orders=False)
        if pks is None:
            return super().exists()
        return bool(pks)

    def count(self) -> int:
        cache = self.get_cache()
        if not cache:
            return super().count()
        if not self.query.where:
            return cache.total
        pks = self.resolve_query(with_orders=False)
        if pks is None:
            return super().count()
        return len(pks)

    @property
    def bulk_data(self):
        return self._hints.get(Key.DATA)

    @bulk_data.setter
    def bulk_data(self, data):
        self._hints[Key.DATA] = data

    @property
    def query_in_annotate(self):
        # if query show up in annotations, the query need to be split
        # for example filter(followers=A).values(followers_num=Count('followers')) this followers_num will end up be 1
        return self._hints.get(Key.QUERY_IN_ANNOTATE)

    @query_in_annotate.setter
    def query_in_annotate(self, b):
        self._hints[Key.QUERY_IN_ANNOTATE] = b

    @property
    def split_many_relations(self):
        # if query show up in annotations, the query need to be split
        # for example filter(followers=A).values(followers_num=Count('followers')) this followers_num will end up be 1
        return self._hints.get(Key.SPLIT_MANY_RELATIONS)

    @split_many_relations.setter
    def split_many_relations(self, b):
        self._hints[Key.SPLIT_MANY_RELATIONS] = b

    @property
    def pk_list(self) -> list:
        if Key.PK_LIST not in self._hints:
            pk_list = self.resolve_query()
            if pk_list is None:
                # case 1: no cache for current model
                # case 2: the query cannot resolved by cache
                # case 3: errors raised and caught by @ignore_errors, downgrade to DB query
                pk_list = self.query_db_pks()
            self.pk_list = pk_list
        return self._hints.get(Key.PK_LIST)

    @property
    def pk_values(self):
        """
        pk_list without values
        """
        if Key.PK_LIST not in self._hints:
            pk_list = self.resolve_query(with_orders=False)
            if pk_list is None:
                return self.query_db_pks()
            return pk_list
        return self._hints.get(Key.PK_LIST)

    def parse_pk_list(self, pk_list: list):
        pks = []
        t = self.pk_type
        for pk in pk_list:
            if isinstance(pk, Model):
                pk = pk.pk
            else:
                pk = t(pk)
            if pk not in pks:
                pks.append(pk)
        return pks

    @pk_list.setter
    def pk_list(self, pk_list: list):
        pks = self.parse_pk_list(pk_list)
        if len(pks) >= 1:
            self._hints[Key.ORDER_REQUIRED] = True
        self._hints[Key.PK_LIST] = pks

    @pk_list.deleter
    def pk_list(self):
        pop(self._hints, Key.PK_LIST)
        pop(self._hints, Key.ORDER_REQUIRED)

    @property
    def order_required(self):
        return self._hints.get(Key.ORDER_REQUIRED, False)

    def aggregate(self, *args, **kwargs) -> dict:
        if len(kwargs) > MAX_ENTRIES:
            chunks = [{}]
            for i, (k, v) in enumerate(kwargs.items()):
                la = len(chunks)
                n = int(i / MAX_ENTRIES)
                if n < la:
                    chunks[n][k] = v
                elif n == la:
                    chunks.append({k: v})
            result = dict(super().aggregate(*args))
            for chunk in chunks:
                result.update(super().aggregate(**chunk))
        else:
            result = super().aggregate(*args, **kwargs)
        return result

    def _update(self, values):
        result = super()._update(values)
        cache = self.get_cache()
        if not result or not cache:
            # result == 0: no update
            return result
        c = self.internal_q.children
        if not c or c[0][0] != PK:
            # not standard call
            return result
        pk = c[0][1]
        data = {}
        for field, _, value in values:
            if isinstance(value, FieldFile):
                value = value.name
            data[field.name] = value
        cache.update_values({pk: data})
        return result

    def _insert(self, objs: List[Model], fields, returning_fields=None,
                raw=False, using=None, ignore_conflicts=False):
        """
        when the target model is inherited (C is based on B)
        B is called first with [pk] as <returning_fields> and all value fields as <fields>
        then call C with [] as <returning_fields> and C's value fields as <fields>
        the thing is, these calling are independent from inner perspective
        but cache storage requires to read the stored data and store it to cache
        so returning fields need to be alter
        """
        cache = self.get_cache()
        _returning = returning_fields or []
        if cache:
            ignore_conflicts = False
            if returning_fields:
                returning_fields += list(fields)
            else:
                returning_fields = [get_pk(self.model)] + list(fields)

        results = super()._insert(
            objs, fields, returning_fields=returning_fields,
            raw=raw, using=using, ignore_conflicts=ignore_conflicts
        )
        if not cache:
            return results

        if self.in_transaction:
            pass

        # also need to update many-to-one relates
        # for example, Content (contents<-creator->Account)
        # when add a new Content(creator=1), need to find Account(pk=1).contents.add()
        tuple_value = False

        if isinstance(results, tuple):
            tuple_value = True
            # there has different between django 3.0 ~ 3.1
            # in django 3.0 objs with length 1 will return a tuple, need to wrap
            results = [results]
        pk_index = 0
        for i, field in enumerate(returning_fields):
            if is_pk(field, model=self.model):
                pk_index = i
                break
        pk_list = []
        pk_data = {}
        pk_relates: Dict[str, dict] = {}
        raw_result = []
        for result in results:
            if not isinstance(result, tuple):
                continue
            pk = str(result[pk_index])
            pk_list.append(pk)
            pk_data[pk] = {PK: pk}
            pk_relates[pk] = {}
            raw_result.append(tuple(result[:len(_returning)]))

            for value, field in zip(result, returning_fields):
                if is_pk(field, model=self.model):
                    continue
                elif one_to(field):
                    pk_relates[pk][field.name] = value
                pk_data[pk][field.name] = value

        cache.append_pk_list(pk_list)
        cache.append_key_relates(pk_relates)
        cache.update_values(pk_data, append=True)
        cache.refresh_sequence()    # refresh sequence last modified
        return raw_result[0] if tuple_value else raw_result

    @property
    def relate_request_maker(self) -> Callable[[str], 'Request']:
        return self._hints.get(Key.RELATE_REQUEST_MAKER, lambda f: {})

    @relate_request_maker.setter
    def relate_request_maker(self, f: Callable[[str], 'Request']):
        self._hints[Key.RELATE_REQUEST_MAKER] = f

    # @property
    # def original_annotations(self):
    #     return self._hints.get(Key.ORIGINAL_ANNOTATIONS) or {}
    #
    @property
    def _query_chain(self):
        return self._hints.get(Key.QUERY_CHAIN, [])[:]

    @property
    def values_fields(self):
        chain = self._query_chain
        chain.reverse()
        for v in chain:
            if v[0] == 'fields':
                return v[1]
        return []

    @property
    def values_str_fields(self):
        from utilmeta.util.field import Field
        fields = []
        for f in self.values_fields:
            val = f
            if isinstance(f, Field):
                val = f.name
            elif not isinstance(f, str):
                val = get_field_name(f)
            fields.append(val)
        return fields

    @property
    def values_expressions(self):
        chain = self._query_chain
        fields = self.values_str_fields

        expr = {}
        for v in chain:
            if v[0] == 'expressions':
                expr.update(v[1])

        return {k: v for k, v in expr.items() if k in fields}

    @property
    def values_settings(self):
        chain = self._query_chain
        chain.reverse()
        for v in chain:
            if v[0] == 'fields':
                return v[2]
        return None

    def reconstruct_queryset(self, fields: List[str] = None, expressions: dict = None,
                             query_only: bool = False, pk_list: list = None):
        qs = QuerySet(model=self.model)
        fields = fields or ()
        expressions = expressions or {}
        value_fields = self.values_str_fields
        values_applied = False
        after_annotates = {}
        for item in self._query_chain:
            if item[0] == 'expressions' and item[1]:
                if not values_applied:
                    qs = qs.annotate(**item[1])
                else:
                    after_annotates.update({k: v for k, v in item[1].items() if k not in value_fields})
            if item[0] == 'fields':
                values_applied = True

        if not query_only:
            within_annotates = {k: v for k, v in expressions.items() if k in value_fields}
            after_annotates.update({k: v for k, v in expressions.items() if k not in value_fields})

            qs = qs.values(*fields, **within_annotates)
            if after_annotates:
                qs = qs.annotate(**after_annotates)

        if pk_list is not None:
            if not pk_list:
                return self.none()
            qs = qs.filter(pk__in=pk_list)
        else:
            qs = qs.filter(self.internal_q)

        if pk_list is None:
            # only order/slice if pk is None, elsewhere slice will cause no result for @page > 1
            if self.query.order_by:
                qs = qs.order_by(*self.query.order_by)
            if self.query.distinct:
                qs = qs.distinct(*self.query.distinct_fields)
            if self.query.low_mark or self.query.high_mark:
                qs = qs[self.query.low_mark:self.query.high_mark]

        return qs.using(self.db)

    def _append_chain(self, payload, type: str = 'fields', extras: dict = None):
        data = (type, payload, extras)
        if not self._query_chain:
            self._hints[Key.QUERY_CHAIN] = [data]
        self._hints[Key.QUERY_CHAIN].append(data)

    def annotate(self, *args, **kwargs):
        qs: MetaQuerySet = super().annotate(*args, **kwargs)
        kwargs = dict(kwargs)
        for arg in args:
            kwargs[arg.default_alias] = arg
        qs._append_chain(kwargs, type='expressions')
        # kwargs.update(self.original_annotations)
        # hints = getattr(qs, Key.HINTS, {})
        # hints[Key.ORIGINAL_ANNOTATIONS] = kwargs
        return qs

    def result(self) -> 'MetaQueryValues':
        from ..field import Field
        from utilmeta.fields import CrossServiceKey
        # if self.values_fields is None:
        #     raise TypeError(f'MetaQuerySet should call values() before result()')
        cache = self.get_cache()
        fields = parse_list(self.values_fields, merge=True)
        expressions = self.values_expressions

        pk_fields = set()
        module_fields = {}

        forward_crosses: List[CrossServiceKey] = []  # forward CrossServiceKey fields
        backward_crosses: List[Field] = []  # backward CrossServiceKey relates

        isolates: Dict[str, List[str]] = {}
        isolate_expressions: Dict[str, BaseExpression] = {}

        # many_excludes = []
        many_includes = []
        removes = []
        adds = []

        for i, f in enumerate(fields):
            if isinstance(f, Field):
                if f.module:
                    # foreign key without db constraint may cross db,
                    # but modules split the query apart so no join will happens
                    module_fields[f.name] = f
                    if include_many_relates(self.model, f.name):
                        # only remove many relates
                        removes.append(f.name)

                if f.service_name:
                    backward_crosses.append(f)

                if include_many_relates(self.model, f.name):
                    if field_in_query(self.internal_q, f.name):
                        self.query_in_annotate = True

                    if self.split_many_relations:
                        removes.append(f.name)
                        isolates.setdefault(f.name, [])
                    else:
                        many_includes.append(f.name)

                fields[i] = f.name
                continue
            elif not isinstance(f, str):
                f = fields[i] = get_field_name(f)

            if f in expressions:
                removes.append(f)
                continue

            try:
                field = get_field(self.model, f, cascade=True)
            except FieldDoesNotExist:
                removes.append(f)
                continue

            if is_pk(field, model=self.model):
                # is THIS.MODEL's pk (not any other pk from related models)
                pk_fields.update({f})

            if isinstance(field, CrossServiceKey):
                # handle CrossServiceKey
                forward_crosses.append(field)

            # -------- cross databases relation query adaption
            if cache:
                # if data is cached, will not need isolation
                continue

            rel_name, *rests = f.split(SEG)
            rel_lookup = SEG.join(rests)
            rel_field = get_field(self.model, rel_name)
            split = False
            if isinstance(rel_field, ManyToOneRel) and not rel_field.remote_field.db_constraint:
                # regardless of layer
                if not rel_lookup:
                    rel_lookup = PK
                split = True
            # elif isinstance(rel_field, ForeignKey) and not rel_field.db_constraint and rel_lookup:
            #     if rel_name not in fields:
            #         # add foreign key with lookup to locate result values
            #         adds.append(rel_name)
            #     split = True
            elif isinstance(rel_field, ManyToManyRel):
                if rel_field.through:
                    pass
            elif isinstance(rel_field, ManyToManyField) and not rel_field.remote_field.db_constraint:
                pass
            elif isinstance(rel_field, ManyToManyRel) and not rel_field.db_constraint:
                pass

            if include_many_relates(self.model, f):
                if field_in_query(self.internal_q, f):
                    self.query_in_annotate = True
                if self.split_many_relations:
                    split = True

            if split:
                removes.append(f)
                if rel_lookup:
                    if rel_name in isolates:
                        isolates[rel_name].append(rel_lookup)
                    else:
                        isolates[rel_name] = [rel_lookup]
                else:
                    isolates.setdefault(rel_name, [])

            elif many_to(rel_field):
                many_includes.append(f)
                continue

        fields = set(fields).union(adds).difference(removes)
        if pk_fields:
            fields = set(fields).difference(pk_fields).union({PK})
        fields = list(fields)

        duplicates = {}
        values = None

        if cache:
            pk_list = self.pk_list
            values = cache.get_values(
                pk_list=pk_list,
                fields=fields,
                expressions=expressions
            )
            # expression only contains exp that has not been resolved by cache
            expressions = cache.unresolved_expressions(values, expressions)

        def gen_annotates(exps: dict):
            query = {}
            for k, exp in exps.items():
                if isinstance(exp, BaseExpression):
                    exp_field = get_exp_field(exp)
                    # Subquery does not have deconstruct
                    if exp_field:
                        if field_in_query(self.internal_q, exp_field):
                            # apply query_in_annotate before split isolate expressions
                            # because isolate expr also meed qs (depend on query_in_annotate)
                            self.query_in_annotate = True

                        if isinstance(exp, Aggregate):
                            if isinstance(exp, Count):
                                pass
                            else:
                                isolate_expressions[k] = exp
                                continue

                        # add distinct before split
                        if include_many_relates(self.model, exp_field) and self.split_many_relations:
                            isolate_expressions[k] = exp
                            continue

                        if exp_field in fields:
                            duplicates[k] = (exp_field, exp)
                            continue

                    query[k] = exp
            return query

        annotates = gen_annotates(expressions)
        qs = self.reconstruct_queryset(fields=fields, expressions=annotates)
        # _qs = self.reconstruct_queryset(query_only=True)

        order_pks = []
        if values is None:
            # once a queryset is sliced, query it's many-related data may return wrong values
            # for example, qs[2:] should return [{"id": 1, "many": [1, 2, 3]}, {...}], but the slice of main queryset
            # is affected on the join queries, so it only return [{"id": 1, "many": [1, 2]}, {...}]
            # as the max num of many-to relations is less than the slice is has taken
            # the annotations will also be affected, if Count("many") on that query, the correct will be 3
            # but the sliced will return 2 instead
            # so when a queryset is sliced and the fields contains many-field or annotates
            # make the queryset unsliced and only contains the pks in the sliced query (which is identical)
            if self.query.is_sliced and many_includes or self.query_in_annotate:
                # (many_excludes or annotates)
                # whether annotates is affected is yet to be proving
                # but annotates with this row queryset will raise entry error in complicate case
                # must concern about sliced orders
                order_pks = self.pk_list
                if order_pks:
                    qs = self.reconstruct_queryset(fields=fields, expressions=annotates, pk_list=order_pks)
                    # _qs = self.reconstruct_queryset(query_only=True, pk_list=order_pks)
                else:
                    values = []

        if values is None:
            values = merge_multiple(list(qs))

        if not values:
            return MetaQueryValues(
                values=[],
                model=self.model,
                query=self.query,
                hints=self._hints,
                using=self.db,
                named=True
            )

        if order_pks:
            values = order_list(values, order_pks, by=PK)

        if isolates or module_fields:
            if not pk_fields:
                raise ValueError(f'MetaQuerySet result() with isolate fields or module '
                                 f'fields must along with primary_key field')

            pk_list = [val[PK] for val in values]

            for key, rel_fields in isolates.items():
                field = get_field(self.model, key, cascade=True)
                rel_model = field.related_model
                rel_key = get_reverse_lookup(self.model, key)

                base_query = self.__class__(model=rel_model, hints={Key.DISABLE_CACHE: self.disable_cache})
                relate_values = list(base_query.filter(
                    **{rel_key + '__in': pk_list}).values(PK, rel_key, *rel_fields).result())

                self.insert_isolates(
                    values, result=relate_values, key=key,
                    rel_key=rel_key, merged_fields=rel_fields
                )

            for key, field_config in module_fields.items():
                module_cls = field_config.module
                field = get_field(self.model, key, cascade=True)
                rel_key = get_reverse_lookup(self.model, key)

                def query_module_result(query: dict = None, key_map: dict = None):
                    try:
                        request = self.relate_request_maker(key)
                        queryset = MetaQuerySet(
                            model=module_cls.model).filter(
                            module_cls.option.get_base_filter(request)
                        ).filter(**query) if query else None
                        _module = module_cls(
                            request=request,
                            auth=field_config.module_auth,
                            queryset=queryset,
                            pk_list=list(set(key_map.values())) if key_map is not None else None
                        ).assign()
                        _result = _module()

                        if key_map is not None:
                            _pk_map = {str(k): v for k, v in key_map.items()}
                        else:
                            _pk_map = make_dict_by(_module.q.values(PK, rel_key).result(),
                                                   key=rel_key, formatter=lambda x: x[PK])
                        # _pk_map: <rel-key>: [<pk>...]

                        if not multi(_result):
                            _result = [_result]

                        return _result, _pk_map
                    except exc.RequestError as e:
                        warnings.warn(f'Serialize related module occur request error: {e}')
                        return [], {}

                if one_to(field):
                    pk_map = {}
                    for val in values:
                        fk = val.get(del_field_id(key), val.get(add_field_id(key)))
                        if not fk:
                            continue
                        pk_map[val[PK]] = fk
                    if not pk_map:
                        relates_result = []
                    else:
                        relates_result, pk_map = query_module_result(key_map=pk_map)

                elif field_config.module_sole_relates:
                    relates_result = []
                    pk_map = {}
                    for pk in pk_list:
                        _res, _map = query_module_result({rel_key: pk})
                        relates_result.extend(_res)
                        pk_map.update(_map)

                else:
                    relates_result, pk_map = query_module_result({rel_key + '__in': pk_list})

                self.insert_relates(
                    values,
                    result=relates_result, pk_map=pk_map,
                    sole=one_to(field), key=key,
                    rel_pk_name=module_cls.query_pk_name
                )

        if isolate_expressions:
            if not pk_fields:
                raise ValueError(f'MetaQuerySet result() with isolate fields or module '
                                 f'fields must along with primary_key field')

            pk_list = [val[PK] for val in values]

            pk_iso_result = {}
            for key, expr in isolate_expressions.items():
                if SEG in key:
                    # relate isolate expression like user__followers_num: Count('followers')
                    *lks, ann = key.split(SEG)
                    lkp = SEG.join(lks)
                    rel_pks = []
                    for val in values:
                        relates = val.get(lkp)
                        if not relates:
                            continue
                        if multi(relates):
                            rel_pks.extend(relates)
                        else:
                            rel_pks.append(relates)
                    rel_model = get_field(self.model, lkp, cascade=True).related_model
                    if not rel_model:
                        continue

                    rel_res = {str(v[PK]): v[ann] for v in QuerySet(model=rel_model).filter(
                        pk__in=rel_pks).values(PK, **{ann: expr})} if rel_pks else {}

                    for val in values:
                        relates = val.get(lkp)
                        if not relates:
                            continue
                        if multi(relates):
                            exp_v = []
                            for rel_pk in relates:
                                exp_v.append(rel_res.get(str(rel_pk)))
                            val[key] = exp_v
                        else:
                            val[key] = rel_res.get(str(relates))

                    continue

                for val in list(QuerySet(model=self.model).filter(pk__in=pk_list).values(PK, **{key: expr})):
                    pk = str(val[PK])
                    if pk in pk_iso_result:
                        pk_iso_result[pk].update(val)
                    else:
                        pk_iso_result[pk] = {key: val[key]}

            for val in values:
                pk = val.get(PK)
                if not pk:
                    continue
                iso_res = pk_iso_result.get(str(pk))
                if not iso_res:
                    continue
                val.update(iso_res)

        for key, (lkp, dup) in duplicates.items():
            for value in values:
                value[key] = resolve_expression(expression=dup, value=value.get(lkp))
        values = clean_pks(pk_fields=pk_fields, values=values)

        values_settings = self.values_settings
        if values_settings:
            flat = values_settings.get('flat')
            merge = values_settings.get('merge')
            values = [map_list(d, *fields) for d in self.values(*fields)]
            if flat:
                values = [r[0] for r in values]
            if merge:
                values = parse_list(values, merge=True)

        return MetaQueryValues(
            values=values,
            model=self.model,
            query=self.query,
            hints=self._hints,
            using=self.db,
            named=True
        )

    def values(self, *fields, **expressions) -> 'MetaQuerySet':
        if not fields and not expressions:
            fields = []
            for f in get_fields(self.model):
                name = add_field_id(f.name) if one_to(f) else f.name
                fields.append(name)

        # self._hints[Key.VALUES_FIELDS] = fields
        # self._hints[Key.VALUES_EXPRESSIONS] = expressions
        # self._hints.setdefault(Key.ORIGINAL_QUERYSET, self._clone())

        from ..field import Field
        fields = parse_list(fields, merge=True)
        raw_fields = fields[:]

        for i, f in enumerate(fields):
            if isinstance(f, Field):
                fields[i] = f.name
                continue
            elif not isinstance(f, str):
                fields[i] = get_field_name(f)

        def gen_annotates(exps: dict, base: str = '', model=self.model, reverse: str = ''):
            query = {}
            for k, exp in exps.items():
                lookup = f'{base}{SEG}{k}' if base else k
                if isinstance(exp, dict):
                    if not exp:
                        continue
                    relate_field = get_field(model, k, cascade=True)
                    query.update(gen_annotates(
                        exp, base=lookup, model=relate_field.related_model,
                        reverse=get_reverse_lookup(model, k)))
                elif isinstance(exp, BaseExpression):
                    if isinstance(exp, Count):
                        # only take values fields in distinct
                        # some after annotate use group_by and not distinct count
                        exp.distinct = True
                    if base:
                        exp = Subquery(QuerySet(model=model)
                                       .filter(**{reverse: OuterRef(PK)})
                                       .values(reverse).annotate(v=exp).values('v'))
                    query[lookup] = exp
            return query

        # keep in track with the super values() while capable to deal with unexpected field types
        # give user the compat to define annotate() after values() for group by
        annotations = gen_annotates(expressions)
        self._append_chain(list(raw_fields) + list(annotations))
        return super().values(*fields, **annotations)

    @staticmethod
    def insert_isolates(values: List[dict], *, result: List[dict],
                        key: str, rel_key: str, merged_fields: List[str]):
        if not result:
            for val in values:
                val[key] = []
                for field in merged_fields:
                    # include merged fields too
                    merge_field = f'{key}{SEG}{field}'
                    val[merge_field] = []

            return values
        key_result = make_dict_by(result, key=rel_key)

        for val in values:
            pk = val.get(PK)
            if pk is None:
                continue
            relates = key_result.get(str(pk))
            merge_res = merge_fields(
                key=key,
                values=relates,
                fields=list({PK}.union(merged_fields)),
                excludes=list({rel_key}.difference(merged_fields))
            )
            val.update(merge_res)
        return values

    @staticmethod
    def insert_relates(values: List[dict], *, result: List[dict],
                       key: str, pk_map: dict,
                       rel_pk_name: str = 'id',
                       sole: bool = False):
        if not result:
            for val in values:
                val[key] = []
            return values
        key_result = {str(res.get(rel_pk_name)): res for res in result}
        for val in values:
            pk = val.get(PK)
            if pk is None:
                continue
            relates = pk_map.get(str(pk), [])

            if sole:
                if multi(relates) and relates:
                    relates = relates[0]
                data = key_result.get(str(relates)) if relates else None
            else:
                if not multi(relates):
                    relates = [relates]
                data = []
                for rel in relates:
                    data.append(key_result.get(str(rel)))

            val[key] = data
        return values

    def values_list(self, *fields, flat=False, named=False, merge=False) -> 'MetaQueryValues':
        if not fields:
            fields = []
            for f in get_fields(self.model):
                name = add_field_id(f.name) if one_to(f) else f.name
                fields.append(name)
        self._append_chain(fields, extras=dict(flat=flat, named=named, merge=merge))
        return super().values_list(*fields, flat=flat, named=named)

    def update_or_create(self, defaults=None, **kwargs):
        try:
            return super().update_or_create(defaults=defaults, **kwargs)
        except exc.IntegrityError as e:
            obj = self.filter(**kwargs).first()
            if obj:
                return obj, False
            raise e
        except exc.DatabaseError:
            obj = self.filter(**kwargs).first()
            created = False
            if obj:
                self.update(**defaults)
            else:
                created = True
                obj = self.create(**kwargs, **defaults)
            return obj, created

    def update_relates(self, key_relates: Dict[str, Union[Dict[Union[Model, str, int], list], list]],
                       mode: str = RelMode.SET, query_scope: bool = False):
        # relates: {relate_key: {pk: [relates]}}
        if not key_relates:
            return
        cache = self.get_cache()

        def apply(inst, field, values):
            if not isinstance(inst, Model):
                inst = self.model(pk=inst)
            manager = getattr(inst, field)
            if values:
                if not multi(values):
                    values = [values]
                func = getattr(manager, mode, None)
                if mode == RelMode.SET:
                    # set(objs, bulk=True, clear=False)
                    # add(*objs, bulk=True)
                    # remove(*objs)
                    values = (values,)
                if not callable(func):
                    raise ValueError(f'Invalid mode: {mode}')
                func(*values)

            elif mode == RelMode.SET:
                manager.clear()

        # if cache update_strategy is WRITE_BACK
        # will directly update cached relates then async update db
        if not cache or cache.update_strategy != WRITE_BACK:
            if query_scope:
                for obj in self.pk_list:
                    for key, relates in key_relates.items():
                        apply(obj, key, relates)
            else:
                for key, objs in key_relates.items():
                    for obj, relates in objs.items():
                        apply(obj, key, relates)
        if not cache:
            return
        for key, pk_values in key_relates.items():
            _cache = cache.base_cache.get(key, cache)   # relate might be inherit from base
            if key not in _cache.relate_fields:
                continue
            if query_scope:
                # unify to the same format
                pk_values = {pk: pk_values for pk in self.pk_list}
            _cache.set_relates(field=key, pk_relates=pk_values,
                               add=mode == RelMode.ADD, remove=mode == RelMode.REMOVE,
                               backward=True, clear_through=True)
            if cache.update_strategy == WRITE_BACK:
                _cache.update_queue(relate_pks={key: list(pk_values.keys())})

    def set_relates(self, relates: Dict[str, Dict[Union[Model, str, int], list]], query_scope: bool = False):
        return self.update_relates(relates, mode=RelMode.SET, query_scope=query_scope)

    def add_relates(self, relates: Dict[str, Dict[Union[Model, str, int], list]], query_scope: bool = False):
        return self.update_relates(relates, mode=RelMode.ADD, query_scope=query_scope)

    def remove_relates(self, relates: Dict[str, Dict[Union[Model, str, int], list]], query_scope: bool = False):
        return self.update_relates(relates, mode=RelMode.REMOVE, query_scope=query_scope)

    def clear_relates(self, relates: Dict[str, List[Union[Model, str, int]]], query_scope: bool = False):
        return self.update_relates({
            key: {v: [] for v in val} for key, val in relates.items()},
            mode=RelMode.SET, query_scope=query_scope)

    def update(self, **kwargs) -> int:
        # bulk_update will call update with Case/When at last
        # the update logic here include the bulk_update circumstance
        from ..field import Field
        cache = self.get_cache()
        kwargs = Field.parse_kwargs(self.model, kwargs, restrict_key=True, include_many=False)
        if not cache:
            return super().update(**kwargs)
        pk_list = self.pk_list
        if not pk_list:
            return 0
        data = self.bulk_data
        strategy = cache.update_strategy

        from django.db.models.expressions import Combinable

        for k in list(kwargs.keys()):
            v = kwargs[k]
            if isinstance(v, Model):
                kwargs[add_field_id(k)] = kwargs.pop(k).pk
            elif isinstance(v, Combinable) and not data:
                # for the F expressions or Cast/Case/When expression
                # directly calculate to cache may cause inconsistent, so change the strategy
                strategy = CACHE_ASIDE
        if self.in_transaction:
            # when update query inside a atomic block, delete the cache instance when db updated
            strategy = CACHE_ASIDE

        if not data:
            data = {pk: kwargs for pk in pk_list}

        if strategy == CACHE_ASIDE:
            pk_values = cache.load_from_db(pk_list)
            rows = super().update(**kwargs)
            cache.update_keys(data, current_values=pk_values.values())
            cache.del_values(pk_list)
            return rows
        elif strategy == WRITE_THROUGH:
            cache.update_values(data)
            return super().update(**kwargs)
        elif strategy == WRITE_BACK:
            cache.update_values(data)
            # some updated values might not in cache
            # update those to DB
            cache.update_queue(pk_list=pk_list)
            return len(pk_list)
        return super().update(**kwargs)

    # create -> save (save_base -> save_table) -> _insert
    # def create(self, **kwargs):
    #   pass

    def bulk_create(self, objs, batch_size=None, ignore_conflicts=False):
        # bulk_create -> save (save_base -> save_table) -> _insert
        # bulk_create -> _batched_insert -> insert
        if not objs:
            return []
        self._for_write = True
        try:
            objs = super().bulk_create(objs, batch_size, ignore_conflicts)
        except ValueError:
            for obj in objs:
                obj: Model
                obj.save(force_insert=True, using=self.db)
        return objs

    def delete(self):
        """
        QuerySet deletion, need to do:
        * delete cached data
        * if model is attached to remote service (by a CrossServiceKey)
          need to trigger remote deletion
        """
        cache = self.get_cache()
        pk_list = self.pk_list if cache else []
        res = super().delete()
        from utilmeta.conf import config
        if config.cluster:
            if self.db != config.ops.db_alias:
                # ops deletion will not trigger broadcast
                try:
                    config.cluster_manager.broadcast_deletion(self.model, pk_list=self.pk_list)
                except Exception as e:
                    warnings.warn(f'Broadcast deletion failed with error: {e}')
        if not cache:
            return res
        cache.del_values(pk_list, delete=True)
        cache.refresh_sequence()
        del self.pk_list
        return res

    def truncate(self, cascade=True, restart=True):
        cache = self.get_cache()
        if cache:
            cache.clear_data()
        table = getattr(self.model, Key.META).db_table
        extra = f"{'RESTART IDENTITY' if restart else ''}{' CASCADE' if cascade else ''}"
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(f"TRUNCATE TABLE {table} {extra}")
            transaction.commit(using=self.db)
        except Exception as e:
            warnings.warn(f'Truncate table: {table} failed wilt error: {e}')
            self.all().delete()

    def __getitem__(self, k):
        if self._result_cache is None or isinstance(k, int):
            return super().__getitem__(k)
        if not isinstance(k, slice):
            raise TypeError(
                'QuerySet indices must be integers or slices, not %s.'
                % type(k).__name__
            )
        assert ((not isinstance(k, slice) and (k >= 0)) or
                (isinstance(k, slice) and (k.start is None or k.start >= 0) and
                 (k.stop is None or k.stop >= 0))), \
            "Negative indexing is not supported."
        q: MetaQuerySet = self._chain()
        q.query.set_limits(k.start, k.stop)
        q._reset_pks(k)
        q._result_cache = self._result_cache[k]
        return q

    def _clone(self):
        """
        Return a copy of the current QuerySet. A lightweight alternative
        to deepcopy().
        """
        c = super()._clone()
        c._hints = dict(c._hints)
        return c

    def _reset_pks(self, k: slice):
        pks = self._hints.get(Key.PK_LIST)
        if pks is not None:
            self.pk_list = pks[k]


class MetaQueryValues(MetaQuerySet):
    def __init__(self, values: list, named: bool, model, query, using, hints):
        super().__init__(model=model, query=query, using=using, hints=hints)
        self.named = named
        # self.values = values
        # self._result_cache = MetaQueryValues()
        # self._result_cache
        self._result_cache = self.values = values

    def __iter__(self):
        return iter(self.values)

    def _clone(self):
        c = MetaQuerySet(model=self.model, query=self.query.chain(), using=self._db, hints=self._hints)
        c._sticky_filter = self._sticky_filter
        c._for_write = self._for_write
        c._prefetch_related_lookups = self._prefetch_related_lookups[:]
        c._known_related_objects = self._known_related_objects
        c._iterable_class = self._iterable_class
        c._fields = self._fields
        return c

    def __str__(self):
        return f'<{self.__class__.__name__} {readable(self.values, max_length=100)}>'

    def __getitem__(self, item):
        return self.values[item]

    def __repr__(self):
        return str(self)


class MetaManager(Manager.from_queryset(MetaQuerySet)):
    pass
