from django.db.backends.postgresql.base import DatabaseWrapper as BaseDatabaseWrapper
from django.db.backends.utils import CursorWrapper as BaseCursorWrapper
from utilmeta.conf import config
import time
from contextlib import contextmanager
from utilmeta.util.common import time_now
from django.utils.asyncio import async_unsafe


class CursorWrapper(BaseCursorWrapper):
    def close(self):
        if isinstance(self.db, DatabaseWrapper):
            self.db.reset_connection()
        return self.cursor.close()


class CursorDebugWrapper(CursorWrapper):
    def execute(self, sql, params=None):
        if self.closed:
            # get new cursor if closed
            self.cursor = self.db.cursor()
        with self.debug_sql(sql, params, use_last_executed_query=True):
            return super().execute(sql, params)

    def executemany(self, sql, param_list):
        if self.closed:
            # get new cursor if closed
            self.cursor = self.db.cursor()
        with self.debug_sql(sql, param_list, many=True):
            return super().executemany(sql, param_list)

    @contextmanager
    def debug_sql(self, sql=None, params=None, use_last_executed_query=False, many=False):
        start = time.monotonic()
        init = time_now()
        try:
            yield
        finally:
            stop = time.monotonic()
            duration = stop - start
            if use_last_executed_query:
                sql = self.db.ops.last_executed_query(self.cursor, sql, params)
            try:
                times = len(params) if many else ''
            except TypeError:
                # params could be an iterator.
                times = '?'
            self.db.queries_log.append({
                'sql': '%s times: %s' % (times, sql) if many else sql,
                'key': self.db.key if isinstance(self.db, DatabaseWrapper) else None,
                'init': init,
                'time': '%.3f' % duration,
            })

    def copy_expert(self, sql, file, *args):
        with self.debug_sql(sql):
            return self.cursor.copy_expert(sql, file, *args)

    def copy_to(self, file, table, *args, **kwargs):
        with self.debug_sql(sql='COPY %s TO STDOUT' % table):
            return self.cursor.copy_to(file, table, *args, **kwargs)


class DatabaseWrapper(BaseDatabaseWrapper):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.db = config.databases[self.alias]
        self.key = self.db.get_pooled_key()
        self.execute_wrappers = []

    @async_unsafe
    def ensure_connection(self):
        if self.connection is None or self.connection.closed:
            with self.wrap_database_errors:
                self.connect()

    def get_manager(self):
        return self.db.pool_manager

    @property
    def is_green(self):
        from utilmeta import conf
        if conf.BACKGROUND:
            return conf.config.task.is_green
        else:
            return conf.config.deploy.is_green

    @async_unsafe
    def get_new_connection(self, conn_params):
        manager = self.get_manager()
        if not manager or self.in_atomic_block:
            # if inside a transaction, return common connection
            return super().get_new_connection(conn_params)
        from psycopg2.pool import PoolError

        start = time.time()
        while True:
            try:
                return manager.getconn(self.key)
            except PoolError:
                pass
            time.sleep(self.db.pool_get_conn_retry_interval)
            if time.time() - start > self.db.pool_get_conn_timeout:
                raise PoolError(f'cannot get new connection: timeout')

    def reset_connection(self):
        if self.in_atomic_block or not self.connection:
            # do not put connection in transaction
            return
        manager = self.get_manager()
        if not manager:
            return
        manager.putconn(conn=self.connection, key=self.key, close=False)
        self.connection = None

    def _close(self, *args, **kwargs):
        if self.connection is not None:
            manager = self.get_manager()
            if not manager:
                return super()._close()
            with self.wrap_database_errors:
                try:
                    return manager.putconn(conn=self.connection, key=self.key, close=False)
                except KeyError:
                    pass

    def make_cursor(self, cursor):
        return CursorWrapper(cursor, self)

    def make_debug_cursor(self, cursor):
        return CursorDebugWrapper(cursor, self)
