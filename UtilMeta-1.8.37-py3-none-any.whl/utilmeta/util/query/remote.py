from django.db.models import QuerySet, Manager, Count, Model, Case, When, Q, Subquery, OuterRef, \
    ForeignKey, ManyToOneRel, ManyToManyField, ManyToManyRel
from .manager import MetaQuerySet
from utilmeta.conf import config


class RemoteQuerySet(MetaQuerySet):
    """
    Provide a remote service access queryset using the standard ops API
    empower the module system to support remote access
    """

    def __init__(self, service_name: str = None, app_label: str = None,
                 timeout: int = None,
                 model_name: str = None, query=None, hints=None):
        """
        model here is a string with this form
        <service_name>:<app_label>.<model_name>
        eg. for Content model in www service's forum app, it can represent as
        www:forum.content (all lowercase)
        """
        super().__init__(query=query, hints=hints)
        self.service_name = service_name
        self.app_label = app_label
        self.model_name = model_name
        self.timeout = timeout or config.cluster.default_timeout
        self.query_dict = {}

    @property
    def ops_api(self) -> str:
        return config.cluster.get_ops_api(self.service_name)

    def get_keys(self):
        from utilmeta.ops.sdk import ClusterSDK
        invoke = ClusterSDK(service=self.service_name)
        return invoke.query_keys(self.ops_api, self.query_dict).result
