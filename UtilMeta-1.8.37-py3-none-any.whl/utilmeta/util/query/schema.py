from django.db.models.expressions import BaseExpression
from django.core.exceptions import FieldDoesNotExist
from django.db.models import ManyToOneRel
from utilmeta.util.rule import Rule
from utilmeta.util.field import Field, is_pk, get_pk
from utilmeta.util.parser.exceptions import ParseError
from utilmeta.util.error import Error
from utilmeta.util.parser import Alias, Options
from utilmeta.util.common import COMMON_TYPES, Param, PK, ID, \
    pop, get_field, SEG, multi, COMMON_ERRORS, many_to, one_to, \
    return_type, struct_dict, distinct, exp, \
    struct_retrieve, add_field_id, del_field_id, class_func, \
    SC_THRESHOLD, MANY_WEIGHT
from utilmeta.util.common import CommonMethod as M
from utilmeta.util.query import MetaQuerySet
from typing import List, Tuple, Callable, Dict, Any, Type, TypeVar
from utilmeta.core.schema import Schema, SchemaMeta
from django.db.models import Model

__all__ = ['SchemaGenerator']

T = TypeVar('T')


class SchemaGenerator:
    def __init__(self, schema: Type[Schema], model: Type[Model]):
        self.schema = schema
        self.model = model

    def query(self, optional=True, with_rules: bool = False, split_relates: bool = False)\
            -> Callable[[MetaQuerySet], List['Schema']]:
        # assert not cls.__alias__, f"Schema for query use Field(<field_name>) " \
        #                           f"to specify field instead of alias"
        options = Options.merge_util(Options(
            list_item_merge=True,
            best_effort_transform=not with_rules,
            list_exclude_against=with_rules,
            ignore_required=optional,
            bypass_schema_data=True  # bypass parsed module serialize data
        ), self.schema.__options__)

        dependency = dict(self.schema.__dependency__)

        def gen_fields(temp: dict = None, data: dict = None, model=self.model,
                       base: str = '', alias_base: str = '') \
                -> Tuple[List[str], Alias, dict, dict, dict, int]:
            if temp is None:
                # affect actual __template__
                # if pk is missing in template, should add
                # this is a basic consensus between module serialize and related schemas
                # that every item of the result contains pk
                temp = self.schema.__template__
            if data is None:
                data = self.schema.__data__

            strip = False
            fields = []
            required_fields = []
            # first class fields, always required in spite of strip (without lookup fields)
            alias_fields = []
            modules = {}
            exps = {}
            dicts = {}
            relates = []
            sc = MANY_WEIGHT
            many_relates = 0
            pk_name = get_pk(model, root=True).name

            if ID in temp:
                # maybe pk_name is different from id
                pass
            elif pk_name not in temp:
                # do not add a required field to affect __template__
                # may cause initialize errors
                temp[pk_name] = Rule(type=Field.get_type(model), require=False)

            for k, unit in temp.items():
                item = data.get(k)
                if class_func(item):
                    continue

                if k == PK:
                    raise ValueError(f'"pk" field is reserved for Schema query,'
                                     f' use "{pk_name}" for {model}\'s primary_key instead')
                dicts[k] = None
                f = k
                if isinstance(item, Field):
                    if item.exp:
                        if isinstance(item.exp, exp.Count):
                            many_relates += 1

                        get_field(model, item.name, cascade=True)
                        exps[k] = item.exp
                        continue
                    if item.request_expression:
                        exps[k] = item.request_expression
                        continue

                    if item.name:
                        if item.name != k:
                            try:
                                _field = get_field(model, k)
                                raise ValueError(f'Field name={repr(item.name)} with attname: {repr(k)} '
                                                 f'is a model field, which is not allowed')
                            except FieldDoesNotExist:
                                pass
                            f = item.name

                    else:
                        try:
                            item.name = k  # may cause AttributeError when on runtime __lock__
                        except AttributeError:
                            continue
                    # field is writeonly don't means no serialize, property may need it
                    # just set retain=False
                    # if item.writeonly:
                    #     continue
                    item.check(model, schema=self.schema.__retrieve__(unit, schema=True))
                    if item.with_module:
                        modules[f] = item
                    elif item.relate_query or item.relate_order_by:
                        # RELATE QUERY
                        strip = True

                elif isinstance(item, BaseExpression):
                    if isinstance(item, exp.Count):
                        many_relates += 1

                    _name = Field(item).name
                    if _name:
                        get_field(model, _name, cascade=True)  # test if field exist
                    exps[k] = item
                    continue
                elif isinstance(item, property):
                    continue

                if k == ID:
                    f = pk_name
                    k = ID

                try:
                    field = get_field(model, f, cascade=True)
                except FieldDoesNotExist as e:
                    if isinstance(unit, Rule) and not unit.require:
                        #  Field for further override, don't query
                        continue
                    raise e

                if pk_name in (f, k):
                    # if f != k:
                    #     raise ValueError(f'You cannot apply alias for primary_key field: {pk}')
                    if base and f == k and k == ID:
                        # with base field, id will be auto add with original field,
                        # like 'tags', so adding 'tags__id' is redundant
                        continue

                key = f'{base}{SEG}{k}' if base else k
                val = f'{alias_base}{SEG}{f}' if alias_base else f
                if key != val:
                    # get key from aliased field
                    alias_fields.append(Alias.Field(alias_from=val, alias_for=key))

                if f in modules:
                    # continue if field has module, the following relates will be resolved by it's module
                    continue

                fields.append(val)
                required_fields.append(val)

                t = self.schema.__retrieve__(unit)
                if field.related_model:
                    if many_to(field):
                        if not t:
                            sc *= MANY_WEIGHT
                        many_relates += 1

                    if not t:
                        continue

                    d = self.schema.__retrieve__(unit, data=True) or {}
                    s = self.schema.__retrieve__(unit, schema=True)
                    if isinstance(s, tuple) or isinstance(d, tuple):
                        raise ValueError(f'Union schemas relates: <{f}> should provide Field(module=<Module Name>) '
                                         f'which module is inherit by different subclasses. got {s}')

                    _fs, _alias, _exp, _tmp, _mod, _sc = gen_fields(
                        temp=t, data=d, model=field.related_model,
                        base=key, alias_base=val)

                    fields += _fs
                    alias_fields += _alias.fields
                    if _tmp:
                        dicts[k] = _tmp
                    if _exp:
                        exps[k] = _exp
                        sc *= len(_exp) * MANY_WEIGHT
                    if s and s.__dependency__:
                        dependency[k] = dict(s.__dependency__)

                    if one_to(field):
                        assert not k.endswith('_id'), \
                            f"Schema Query for ForeignKey: {k} with relate schema cannot endswith '_id' "
                        sc += _sc
                    if many_to(field):
                        sc *= _sc
                    if _mod:
                        # if sub schema is modular stripped, the upper layer should do also
                        strip = True

                    relates.append((k, f, field, val, s, _sc, item))

            if sc >= SC_THRESHOLD:
                strip = True

            if strip:
                from utilmeta.util.option import Option
                # structure complexity passed the threshold, need to strip the many-to relations
                relates.reverse()
                # reverse the relates list to let the complexity operation follow the original orders
                for k, f, field, val, sch, c, _item in relates:
                    _base_query = _item.relate_query if isinstance(_item, Field) else None
                    _base_order = _item.relate_order_by if isinstance(_item, Field) else None
                    from utilmeta.core.module import Module

                    class module(Module):
                        model = field.related_model
                        schema = sch
                        option = Option(
                            base_filter=_base_query,
                            order_by=_base_order,
                            filter_with_rules=with_rules,
                            split_many_relation_query=split_relates
                        )

                    modules[f] = Field(f, module=module)
                    fields = [fd for fd in fields if not fd.startswith(val + SEG)]
                    if c:
                        if one_to(field):
                            sc -= c
                        else:
                            sc /= c
                    e = pop(exps, k)
                    if e:
                        sc /= len(e) * MANY_WEIGHT
                fields = list(set(fields).union(required_fields))

            if not base and many_relates >= 3 and not split_relates:
                import warnings
                warnings.warn(f'{self.schema.__name__} generate query template for model: {model} '
                              f'find {many_relates} joined many relations,\n it is recommended to use'
                              f' split_many_relation_query=True in your Module\'s Option which introduce this schema '
                              f'to avoid multiple table joining ')

                # relate fields strip will not strip required fields
            return distinct(fields), Alias(alias_fields, reserve_original=True), exps, dicts, modules, sc

        def reduce_temp(domain: dict = None, base: str = '',
                        exp_domain: dict = None, depend_domain: dict = None):
            if domain is None and not base:
                return value_fields + list(field_modules.values()), annotates
            if not exp_domain:
                exp_domain = annotates
            if not depend_domain:
                depend_domain = dependency

            fields = []
            expressions = {}
            for key, val in domain.items():
                field = f'{base}{SEG}{key}' if base else key
                _field = del_field_id(field)
                if isinstance(val, dict):
                    fields.append(field)
                    fs, exps = reduce_temp(val, base=field,
                                           depend_domain=depend_domain.get(key, {}),
                                           exp_domain=exp_domain.get(key, {}))
                    fields += fs
                    if exps:
                        expressions[key] = exps
                elif field in value_fields:
                    if field not in fields:
                        fields.append(field)
                elif _field in value_fields:
                    if _field not in fields:
                        fields.append(_field)
                elif key in exp_domain:
                    expressions[key] = exp_domain[key]
                elif key in depend_domain:
                    for b in depend_domain[key]:
                        bound = f'{base}{SEG}{b}' if base else b
                        if bound in value_fields and bound not in fields:
                            fields.append(bound)
                            continue
                        if b in exp_domain:
                            expressions[key] = exp_domain[b]

            for key, val in field_modules.items():
                if key in domain:
                    fields.append(val)

            return fields, expressions

        def assign_request(expressions: dict, request):
            result = {}
            for key in list(expressions):
                val = expressions[key]
                if callable(val):
                    v = val(request)
                    if not isinstance(v, BaseExpression):
                        v = exp.Value(v)
                    result[key] = v
                elif isinstance(val, dict):
                    result[key] = assign_request(val, request)
                else:
                    result[key] = val
            return result

        def parse_values(temp: dict, raw, base: str = ''):
            if isinstance(raw, list):
                return [parse_values(temp, data) for data in raw]
            elif isinstance(raw, type(self.schema)):
                # module schema, does not need to parse
                return raw
            elif isinstance(raw, dict):
                data = {}
                for k, t in temp.items():
                    k: str
                    key = SEG.join([base, k]) if base else k
                    if key not in raw:
                        continue
                    val = raw.get(key)
                    if not t or val is None:
                        data[key] = val
                        continue
                    if not any(field.startswith(key + SEG) for field in raw.keys()):
                        # probably resolved by module
                        data[key] = val
                        continue

                    part: dict = parse_values(t, raw, base=key)
                    # <val> represent the rest part structure, like [[1,2,3], 4, [1,3]] may be deeply nested
                    item = struct_dict(val, key=pk)
                    for _k in t.keys():
                        if _k == pk:
                            continue
                        value = part.get(SEG.join([key, _k]), ...)
                        if value is ...:
                            continue
                        # except this value has same nested list struct as item
                        struct_retrieve(data=value, temp=item, key=_k)
                    data[key] = item
                return data

        pk = get_pk(self.model, root=True).name
        value_fields, field_alias, annotates, template, field_modules, structure_complexity = gen_fields()
        # reproduce schema after gen_fields, there might be template alter during gen
        schema = self.schema.__reproduce__(
            optional=optional,
            with_rules=with_rules,
            options=options,
            from_query=True,
            no_default=True
        )

        def wrapper(q: MetaQuerySet, request=None, domain: dict = None) -> List[Schema]:
            from utilmeta.util.request import Request
            from utilmeta.conf import config
            fields, expressions = reduce_temp(domain)
            expressions = assign_request(expressions, request or Request.custom(M.GET))
            raw_values = field_alias(list(q.values(pk, *fields, **expressions).result()))
            result = parse_values(template, raw_values)
            try:
                return config.preference.base_parser_cls.parse(result, [schema], options=options)
            except COMMON_ERRORS as e:
                raise Error().throw(ParseError, origin_exc=e)

        return wrapper

    def aggregate(self) -> Callable:
        aggregates: Dict[str, BaseExpression] = {}

        def gen_data(value, base='', index=None):
            parsed_data = {}
            name = base if index is None else f'{base}:{index}'
            if isinstance(value, Field):
                value = value.exp
            if isinstance(value, BaseExpression):
                aggregates[name] = value
                return value
            if isinstance(value, (SchemaMeta, Schema)):
                value = dict(value.__data__)
            if isinstance(value, dict):
                for k, v in value.items():
                    if ':' in k:
                        raise ValueError(f'SchemaGenerator.aggregate template key should not contains ":", got {k}')
                    key = f'{base}:{k}' if base else k
                    if index is not None:
                        key = f'{key}:{index}'
                    parsed_data[k] = gen_data(v, base=key)
                return parsed_data
            elif multi(value):
                return [gen_data(v, base=base, index=i) for i, v in enumerate(value)]
            return value

        def parse_result(result, temp: dict, base='', index=None):
            target = {}
            if not isinstance(temp, dict):
                key = base if index is None else f'{base}:{index}'
                return result.get(key)
            for k, v in temp.items():
                key = f'{base}:{k}' if base else k
                if index is not None:
                    key = f'{key}:{index}'
                if isinstance(v, BaseExpression):
                    target[k] = result.get(key)
                    continue
                if isinstance(v, dict):
                    target[k] = parse_result(result, temp=v, base=key)
                    continue
                if multi(v):
                    target[k] = [parse_result(result, temp=s, base=key, index=i) for i, s in enumerate(v)]
                    continue
                if type(v) in COMMON_TYPES:
                    target[k] = v
            return target

        def reduce_temp(domain: Dict[str, Any]):
            if not domain:
                return aggregates
            data = {}
            for key, val in domain.items():
                for k, v in aggregates.items():
                    if k.startswith(key):
                        data[k] = v
            return data

        template = gen_data(self.schema)

        def wrapper(q: MetaQuerySet, **domain):
            result = parse_result(q.aggregate(**reduce_temp(domain)), temp=template)
            try:
                return self.schema(**result)
            except COMMON_ERRORS:
                raise Error().throw(ParseError)

        return wrapper

    def gen(self, get=True, require: bool = False, query: bool = False, operators: bool = False,
            optional: bool = False, exclude: str = None,
            create: bool = False, setter_target=None, optional_fields: List[str] = None):

        field_keys = {}
        data = {}
        model = self.model
        cls = self.schema
        rules = Field.cached_rules(model)
        relative_opt = not require and not optional
        exclude_names = []

        for key in cls.__keys__:
            opt = optional
            unit = cls.__template__.get(key)
            item = cls.__data__.get(key)
            readonly = None
            writeonly = None
            allow_create = None

            expr = item if isinstance(item, BaseExpression) else None
            if expr:
                readonly = True
            name = key
            docs = []
            if isinstance(item, SchemaMeta):
                if item.__isolate__ and key == item.__name__:
                    continue
            if class_func(item):
                continue
            if isinstance(item, Field):
                if item.name:
                    name = item.name

                readonly = item.readonly
                writeonly = item.writeonly
                allow_create = item.allow_creation

                expr = item.exp
                if item.document:
                    docs.append(item.document)

                if get and not item.retain:
                    # retain continue should be ahead of Module setter
                    continue

                if not item.require:
                    opt = True

                if operators:
                    if item.operator:
                        data.update(item.gen_operators(model))
                    continue

                if create and item.allow_creation is False:
                    exclude_names.append(name)
                    continue

                elif item.operator:
                    if require or optional:
                        # require / optional indicate that this operation is from PUT/PATCH write methods
                        # if Field has operator, just continue
                        continue

                elif item.with_module and get:
                    def setter(mod, target=None, target_key=key, mixin_filters=item.mixin_module_filters):
                        """
                        when lazy loaded and setting directly set to the local variable (like data)
                        may not affect the service api (since the local
                        data returned may be updated to another variable)
                        so upper layer will pass a setter_target param to retrieve
                        the target schema that actually point to (affect) the real template

                        MUST NOT directly use variables from outer locals (data / key) amd MUST pass them as arguments
                        elsewhere outer variable update will cause wrong result

                        target param: when lazy-loading, set to None and use setter_target to get target dict object
                        but when realtime-loading, the "data" must provide (otherwise values will be overwrite)
                        """
                        from utilmeta.core.module import ModuleMeta
                        mod: ModuleMeta
                        if target is None:
                            if not setter_target:
                                return
                            target = setter_target()
                        u = mod.get_unit(M.GET)
                        if not u:
                            raise TypeError(f'Field module: {mod} not support reading (get method), which '
                                            f'is required by upper layer at field: {repr(name)}')
                        if query:
                            if not isinstance(target, dict):
                                return
                            if mixin_filters:
                                for k, v in u.parser.query.items():
                                    k: str
                                    if k in [Param.template, Param.exclude, Param.field]:
                                        continue
                                    rel_key = f'{target_key}{k}' if k.startswith('@') else f'{target_key}.{k}'
                                    # "." is used for module filters
                                    target[rel_key] = Rule.optional(v)  # relate query is always optional
                        else:
                            if isinstance(target, list):
                                target[0][target_key] = u.response.schema
                            elif isinstance(target, dict):
                                target[target_key] = u.response.schema
                            else:
                                return

                    if item.module:
                        setter(item.module, target=data)
                    else:
                        item.append_module_setter(setter)
                    continue
            if name == 'id':
                # some primary key doesn't call "id"
                # but id is reserved only for pk, so allow the name alias
                name = get_pk(model, root=True).name

            try:
                field = get_field(model, name, cascade=True)
                from utilmeta.fields import PasswordField
                if isinstance(field, PasswordField) and not writeonly:
                    raise TypeError(f'Password field: {field} in {model}'
                                    f' schema must be writeonly, use Field(writeonly=True)')
            except FieldDoesNotExist:
                # only skip when field is not in model
                # the upper layer may want to keep this not require settings for self-define use
                field = None

            if query or operators:
                continue
            if get:
                if writeonly:
                    continue
                t = unit
                if isinstance(item, property):
                    if key in cls.__parser__.exclude_properties:
                        # excluded properties does not include in result data
                        continue
                    t = return_type(item.fget) or Rule()
                data[key] = t
                continue
            if SEG in name and readonly:
                exclude_names.append(name)
                # POST method also ignore (with readonly=True, may be turn-off in Field)
                continue
            if expr:
                if readonly:
                    exclude_names.append(name)
                    continue
                field = None

            if unit is None:
                # key not in write template
                continue
            if readonly:
                # POST method will ignore readonly
                if create:
                    if field:
                        if Field.is_optional(field) or opt:
                            # if field is not required and readonly, it is om
                            unit = Rule.optional(unit)
                        else:
                            # a not-defaulted field in creation is required
                            # in spite of what has been configured in the Rule or Field
                            unit = Rule.required(unit)
                            opt = False
                    elif not allow_create:
                        exclude_names.append(name)
                        continue
                else:
                    exclude_names.append(name)
                    continue

            # allow add redundant fields to self-define logic in Module

            if isinstance(item, property) and not item.fset:
                continue
            if del_field_id(name) == exclude:
                exclude_names.append(del_field_id(name))
                continue
            if 'id' in (key, name):
                continue

            if field and optional_fields:
                if field.name in optional_fields:
                    if create:
                        if allow_create is not True:
                            exclude_names.append(name)
                            continue
                    else:
                        if readonly is not False:
                            exclude_names.append(name)
                            continue

            rule = unit or Rule()
            if name in rules:
                if is_pk(field):
                    # pk_field / assign_field is not writable
                    continue

                if one_to(field):
                    rule = rules[name]
                elif isinstance(field, ManyToOneRel):
                    if create:
                        if isinstance(item, Field) and not item.relate_creation:
                            exclude_names.append(name)
                            continue
                    else:
                        if readonly is not False:
                            exclude_names.append(name)
                            continue

                    _exclude = field.remote_field.name
                    if isinstance(item, Field) and item.with_module:
                        def setter(mod, target=None, target_key=key):
                            from utilmeta.core.module import ModuleMeta
                            mod: ModuleMeta
                            if not target:
                                if not setter_target:
                                    return
                                target = setter_target()
                            if not isinstance(target, dict):
                                return
                            method = M.POST if create else M.PUT if require else M.PATCH
                            try:
                                rel_data = {}
                                body_data = mod.get_unit(method).parser.body
                                excluded = False
                                for k, v in body_data.items():
                                    if del_field_id(k) == _exclude:
                                        excluded = True
                                        v = Rule.optional(v)
                                        # do not completely remove remote_field
                                        # when re-serialize dict values there might be required error
                                    rel_data[k] = v
                                if not excluded:
                                    raise ValueError(f'Field module: {mod} relate field: <{_exclude}>'
                                                     f' must provided in schema data')
                                target[target_key] = Rule(template=[rel_data], require=False, options=Options(
                                    excess_preserve=True
                                ))
                            except KeyError:
                                pass
                                # raise TypeError(f'Field module: {mod} does not support for <{method}> method, \n'
                                #       f'if this module is only for serialize, use readonly=True, or \n'
                                #       f'declare a private [use Unit(public=False)] <{method}> method in {mod}')

                        if item.module:
                            setter(item.module, target=data)
                        else:
                            item.append_module_setter(setter)
                        continue

                    schema = self.schema.__retrieve__(unit, schema=True)
                    if schema:
                        def new_setter(target_key=key):
                            target = setter_target()
                            if isinstance(target, list):
                                target = target[0]
                            return lambda: target[target_key]

                        temp = self.__class__(
                            schema=schema,
                            model=field.related_model
                        ).gen(
                            require=require, exclude=_exclude,
                            get=False, optional=optional, create=create,
                            setter_target=new_setter if setter_target else None
                        )

                        pk = get_pk(field.related_model, root=True).name
                        if pk not in temp:
                            pk = 'id'
                        temp[pk] = Rule.optional(Field.get_type(field.related_model))
                        rule = Rule.insert(unit, temp)
                    else:
                        rule = Field.get_type(field)
                        if Rule.multi(unit):
                            rule = [rule]

                else:
                    # ManyToManyField / ManyToManyRel relate instances inner data (not relations)
                    # cannot be modified from put/patch, so the write model is strictly merge into [int] or [str]
                    # but when creating new instance, you may use a self-define schema to create new many-relations
                    if create:
                        rule = rule or rules[name]
                    else:
                        rule = Rule.merge(rules[name], rule)

                if many_to(field) or Field.is_optional(field):
                    if relative_opt:
                        opt = True
            elif field:
                # this field is not considered as a write template field
                if create:
                    if allow_create is not True:
                        exclude_names.append(name)
                        continue
                        # use allow_creation=True to keep invalid post field
                else:
                    if readonly is not False:
                        exclude_names.append(name)
                        # if field not in rules and readonly=None (default) also continue
                        continue
                    # use readonly=False to keep invalid put/patch field

            if opt:
                rule = Rule.optional(rule)
            if docs:
                rule = Rule.set_doc(rule, ', '.join(docs))

            if field:
                _key = field_keys.get(field)
                if _key:
                    if not get and _key in data:
                        # writing method for same field must have consistent rule
                        def pk_converter(_d):
                            if isinstance(_d, dict):
                                return _d.get(PK, _d.get(ID))
                            return _d

                        rule = Rule.gen_from(data[_key]) & rule
                        data[_key] = Rule.add_converter(Rule.add_alias_from(rule, key), pk_converter, first=True)
                        continue
                else:
                    field_keys[field] = key

            data[key] = rule

        if create:
            for name, rule in Field.rules(model, many=False).items():
                f = get_field(model, name)
                names = [name]
                if one_to(f):
                    names.extend([add_field_id(name), del_field_id(name)])

                if set(names).intersection(exclude_names):
                    # field is declared at schema to be allow_creation=False no matter it's state
                    continue

                key = field_keys.get(f)
                if key and key in data:
                    try:
                        rule = Rule.gen_from(rule) & data[key]
                    except COMMON_ERRORS as e:
                        raise ValueError(f'{model} generate field: {repr(key)} with error: {e}, \n'
                                         f'does your field rule: {data[key]} match the model field?')

                opt = optional_fields and f.name in optional_fields

                if one_to(f):
                    # handle the logic for foreign keys
                    if key:
                        key_rule = data.get(key)
                        Rule.valid_key(key_rule)
                    else:
                        key = name
                        key_rule = rule
                    aliases = [f.name, add_field_id(f.name)]
                    if key in aliases:
                        aliases.remove(key)
                    rule = Rule.add_alias_from(key_rule, *aliases)

                else:
                    key = key or name
                    if Field.is_auto(f):
                        pop(data, key)
                        continue
                if Field.is_optional(f) or opt:
                    # if a field not in data and not required, won't add post template
                    rule = Rule.optional(rule)
                if isinstance(rule, Rule):
                    rule = rule.simplify()
                data[key] = rule
        return data

    def separate_alias(self) -> Tuple[Alias, Alias]:
        read_alias_fields = []
        write_alias_fields = []
        for key, unit in self.schema.__template__.items():
            item = self.schema.__data__.get(key)
            expr = item if isinstance(item, BaseExpression) else None
            readonly = False
            field_name = key
            read_from = [key]
            write_from = []
            if isinstance(unit, Rule):
                write_from.extend(unit.alias_from or [])

            if isinstance(item, Field):
                if item.name:
                    field_name = item.name
                if item.exp:
                    expr = True
                if item.alias:
                    read_from.append(item.alias)

                readonly = item.readonly
            if isinstance(item, property) or expr:
                # property has no alias
                # expression is readonly and use annotates key-value as alias
                continue
            if class_func(item):
                continue
            if SEG in field_name:
                readonly = True
            try:
                field = get_field(self.model, field_name, cascade=True)
            except FieldDoesNotExist:
                continue

            if field_name not in read_from:
                read_from.append(field_name)

            if not readonly and one_to(field):
                for k in [add_field_id(field_name), del_field_id(field_name)]:
                    if k not in read_from:
                        read_from.append(k)

            t = self.schema.__retrieve__(unit, schema=True)
            relate_read_alias = relate_write_alias = None

            if t and field.related_model:
                if isinstance(t, tuple):
                    relate_read_alias_fields = []
                    relate_write_alias_fields = []
                    for sch in t:
                        ra, wa = self.__class__(schema=sch, model=field.related_model).separate_alias()
                        relate_read_alias_fields.extend(ra.fields)
                        relate_write_alias_fields.extend(wa.fields)
                    relate_read_alias, relate_write_alias = \
                        Alias(relate_read_alias_fields), Alias(relate_write_alias_fields)
                else:
                    relate_read_alias, relate_write_alias = self.__class__(
                        schema=t,
                        model=field.related_model
                    ).separate_alias()

            if field_name != key:
                if field_name not in self.schema.__template__:
                    read_alias_fields.append(Alias.Field(
                        alias_from=read_from, alias_for=key, relate_alias=relate_read_alias))
                    write_alias_fields.append(Alias.Field(
                        alias_from=[*read_from, *write_from], alias_for=field_name, relate_alias=relate_write_alias))
            else:
                if relate_read_alias:
                    read_alias_fields.append(Alias.Field(
                        alias_from=read_from, alias_for=key, relate_alias=relate_read_alias))
                if relate_write_alias:
                    write_alias_fields.append(Alias.Field(
                        alias_from=[*read_from, *write_from], alias_for=field_name, relate_alias=relate_write_alias))

        return Alias(read_alias_fields), Alias(write_alias_fields)
