from ..base import Util


class Queue(Util):
    """
    Message Queue which support multiple backends (redis list / kafka / rabbitMQ)
    """
    pass
