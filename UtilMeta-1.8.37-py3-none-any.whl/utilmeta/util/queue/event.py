from ..base import Util


class Event(Util):
    """
    Event class provide abilities for async

    event backends can choice from
    redis
    message queues (kafka, rabbitMQ, ...)
    websocket (publish / subscribe)
    """
    pass
