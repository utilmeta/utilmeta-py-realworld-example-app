from .base import LogicUtil, Util
from .media import File, Media
from .rule import Rule
from .common import ReqType, multi, exc, COMMON_ERRORS, \
    RequestType, Header, ADMIN_HEADERS, MetaMethod, CommonMethod, allow_cors, \
    immutable, Param, Scheme, HAS_BODY_METHODS, get_origin, SAFE_METHODS, ISOLATED_HEADERS, pop_null, \
    ALLOW_HEADERS, get_field_name, HTTP_METHODS, localhost, Key, IPType, NetworkType, utc_ms_ts, \
    ignore_errors, HTTPMethod, ImmutableDict, LOCAL_IP, MetaHeader, http_header, convert_time
from django.http.response import HttpResponse
from typing import Optional, Union, Callable, List, Any, Dict, Tuple
from datetime import datetime, date, timedelta
from django.middleware.csrf import CsrfViewMiddleware, get_token
from django.http.request import HttpHeaders
from django.utils.functional import cached_property
from django.db.models import Model
from django.contrib.sessions.backends.base import SessionBase
from django.core.handlers.wsgi import WSGIRequest
from django.core.handlers.asgi import ASGIRequest
from utilmeta.conf import Version as VersionConfig
from ..conf import config
from .log import Logger
import re
from ipaddress import IPv4Address, ip_network


__all__ = ['Request']


class Request(LogicUtil):
    PLAIN = 'text/plain'
    JSON = 'application/json'
    FORM_URLENCODED = 'application/x-www-form-urlencoded'
    FORM_DATA = 'multipart/form-data'
    XML = 'text/xml'
    OCTET_STREAM = 'application/octet-stream'

    HTTP = 'http'
    HTTPS = 'https'
    WEBSOCKET = 'ws'
    MQTT = 'mqtt'

    def __call__(self, *args, **kwargs) -> 'Request':
        return super().__call__(*args, **kwargs)

    class Agent(Util):
        def __init__(self, bot: bool = None, pc: bool = None,
                     mobile: bool = None, tablet: bool = None):
            super().__init__(locals())
            # None: no restriction whether or not agent is match
            # True: request agent must be ...
            # False: request agent must not be ...
            if not bot:
                assert not pc and not mobile and not tablet
            assert [pc, mobile, tablet].count(True) <= 1, f'Request Agent cannot specify multiple platform'
            assert {bot, pc, mobile, tablet} != {None}, f'Request Agent must specify some rules'
            self.bot = bot
            self.pc = pc
            self.mobile = mobile
            self.tablet = tablet

        def __call__(self, user_agent):
            from user_agents.parsers import UserAgent
            user_agent: UserAgent

            if self.bot is not None:
                if self.bot ^ user_agent.is_bot:
                    raise exc.PermissionDenied('Request Agent is denied')

            if self.pc is not None:
                if self.pc ^ user_agent.is_pc:
                    raise exc.PermissionDenied('Request Agent is denied')

            if self.mobile is not None:
                if self.mobile ^ user_agent.is_mobile:
                    raise exc.PermissionDenied('Request Agent is denied')

            if self.tablet is not None:
                if self.tablet ^ user_agent.is_tablet:
                    raise exc.PermissionDenied('Request Agent is denied')

    class Record(Util):
        def __init__(self, origin: 'Request', alias: str = None, timeout: int = None):
            super().__init__(locals())
            if not alias:
                if config.cluster:
                    alias = config.cluster.service_cache_alias
                elif config.ops:
                    alias = config.ops.cache_alias
                else:
                    alias = 'default'
            self.alias = alias
            self.timeout = timeout
            self.origin = origin

        def __contains__(self, item):
            return item in self.cache

        @property
        def cache(self):
            from django.core.cache import caches, BaseCache
            cache: BaseCache = caches[self.alias]
            return cache

        def make_key(self, key: str):
            """
            Use Record._id to make key different among Request objects
            """
            ident = self.origin.__declare_path__ or self._id
            return f'{config.cache_prefix}:{ident}.record:{key}'

        def set(self, key, *, time, times, errors):
            self.cache.set(self.make_key(key), (time, times, errors), timeout=self.timeout)

        def get(self, key) -> Tuple[datetime, int, int]:
            try:
                time, times, errors = self.cache.get(self.make_key(key))
            except TypeError:
                return datetime.now(), 1, 0
            return time, times, errors

        def __getitem__(self, item):
            return self.get(item)

    class Version(Util):
        FALLBACK = 'fallback'
        MAJOR_EQ = 'M='
        MINOR_EQ = 'm='
        MINOR_GE = 'm>='

        def __init__(self, accept_version: str = None, *, major: int = None, minor: int = None,
                     minor__ge: int = None, fallback: bool = False):
            super().__init__(locals())
            self.accept_version = accept_version
            self.major = major
            self.minor = minor
            self.minor__ge = minor__ge
            self.fallback = fallback

            if not accept_version or not isinstance(accept_version, str):
                return
            try:
                values = accept_version.split(';')
                for val in values:
                    if not val:
                        continue
                    if val.lower() == self.FALLBACK:
                        self.fallback = True
                        continue
                    if val.isdigit():
                        self.major = int(val)
                        continue
                    if '.' in val:
                        if self.major:
                            raise ValueError(f'Invalid Accept Version: {accept_version}')
                        versions = [int(v) for v in val.split('.')]
                        if len(versions) == 2:
                            self.major, self.minor__ge = versions
                        else:
                            raise ValueError(f'Invalid Accept Version: {accept_version}')
                        continue
                    if val.startswith(self.MAJOR_EQ):
                        self.major = int(val.lstrip(self.MAJOR_EQ))
                        continue
                    if val.startswith(self.MINOR_EQ):
                        self.minor = int(val.lstrip(self.MINOR_EQ))
                        continue
                    if val.startswith(self.MINOR_GE):
                        self.minor__ge = int(val.lstrip(self.MINOR_GE))
                        continue
                if self.minor is not None and self.minor__ge is not None:
                    raise ValueError
            except COMMON_ERRORS:
                self.fallback = True
                return

        def __bool__(self):
            return self.major is not None

        def __str__(self):
            if self.accept_version:
                return self.accept_version
            values = []
            if self.major is not None:
                values.append(self.MAJOR_EQ + str(self.major))
            if self.minor is not None:
                values.append(self.MINOR_EQ + str(self.minor))
            if self.minor__ge is not None:
                values.append(self.MINOR_GE + str(self.minor__ge))
            if self.fallback:
                values.append(self.FALLBACK)
            return ';'.join(values)

        @property
        def resolved(self):
            """
            Check if current config's version settings satisfy version requirement
            """
            return self.valid_config(config.version)

        def valid_config(self, cfg: VersionConfig):
            if self.major is None:
                return True
            if cfg.major != self.major:
                return False
            if self.minor is not None:
                if cfg.minor != self.minor:
                    return False
            elif self.minor__ge is not None:
                if cfg.minor < self.minor__ge:
                    return False
            return True

        def get_instances(self, service: str):
            from utilmeta.conf import Version
            from utilmeta.ops.models.log import VersionLog
            from utilmeta.ops.module.service import InstanceMain
            if not self.major:
                return None
            if service == config.name:
                inst_pks = VersionLog.valid_instances(
                    major=self.major,
                    minor=self.minor,
                    minor__ge=self.minor__ge
                )
                if not inst_pks:
                    if not self.fallback:
                        raise exc.NotAcceptable(f'Required version: [{self}] is not served '
                                                f'currently and fallback is prohibited')
                    return None
                try:
                    return InstanceMain(pk_list=inst_pks).serialize()
                except COMMON_ERRORS:
                    return None
            else:
                targets = []
                for inst in config.cluster_manager.get_instances(service, connected=True):
                    if self.valid_config(Version.decode(inst.version)):
                        targets.append(inst)
                if not targets and not self.fallback:
                    raise NotImplementedError(f'Required version: [{self}] is not served in this cluster')
                return targets

    def __invert__(self):
        raise NotImplementedError(f'Request does not support invert operation')

    # when merging, None means it is defaulted and can be merged, other value means it is already set
    def __init__(self, request: ReqType = None, *,
                 # asgi=False, scheme: str = HTTP   # will be implement in next version
                 allow_origin: Union[List[str], str] = None,
                 allow_headers: List[str] = None,
                 # allow localhost/127.0.0.1 as origin (front-end proxy)
                 allow_services: Union[List[str], str] = None,
                 block_services: Union[List[str], str] = None,

                 block_ips: List[Union[NetworkType, str]] = None,
                 allow_ips: List[Union[NetworkType, str]] = None,

                 admin_only: bool = None,
                 local_only: bool = None,   # for micro-service integration
                 supervisor_exempt: bool = None,
                 open_time: Union[datetime, date] = None,
                 close_time: Union[datetime, date] = None,
                 login: bool = None,
                 require: Union[Callable, List[Callable]] = None,
                 log_option: str = None,
                 logger_cls: str = None,

                 max_rps: Union[int, float] = None, max_times: int = None, max_errors: int = None,
                 url_max_length: int = None, body_max_length: int = None,
                 set_token: bool = None, valid_accept: bool = None,
                 previous_exempt: bool = None,
                 user_agent: 'Request.Agent' = None,
                 content_type: str = None,
                 # record_persist: bool = False,      # store record
                 record_cache_alias: str = None,
                 record_reset_after: Union[int, timedelta, List[int], List[timedelta]] = None, ban_user: bool = None,
                 secure: bool = None, csrf_exempt: bool = None,
                 ):

        self._request: Optional[ReqType] = request

        if request:
            self._MUTABLE = True
        del request
        super().__init__(locals())

        from .auth import Auth
        self.error_recorded = None
        # other schemes and async will be support in 2.0
        self.scheme_conf = Scheme.HTTPS if secure else config.scheme
        self.secure = secure
        # =======================================================
        if local_only:
            allow_ips = list({LOCAL_IP, config.private_ip, config.public_ip})
        if block_ips and allow_ips:
            raise ValueError(f'Request specify block_ips: {block_ips}'
                             f' and allow_ips: {allow_ips} at the same time is redundant')
        if block_services and allow_services:
            raise ValueError(f'Request specify block_services: {block_services}'
                             f' and allow_services: {allow_services} at the same time is redundant')

        if block_ips and not multi(block_ips):
            block_ips = [block_ips]
        if allow_ips and not multi(allow_ips):
            allow_ips = [allow_ips]
        if allow_services and not multi(allow_services):
            allow_services = [allow_services]
        if block_services and not multi(block_services):
            block_services = [block_services]

        self.block_ips: List[NetworkType] = [ip_network(ip) for ip in block_ips] if block_ips else []
        self.allow_ips: List[NetworkType] = [ip_network(ip) for ip in allow_ips] if allow_ips else []

        if content_type:
            types = (self.JSON, self.FORM_URLENCODED, self.FORM_DATA, self.XML)
            assert content_type in types, f'API only accept common content_types in {types}, got {content_type}'
        self.type = content_type

        if open_time:
            assert isinstance(open_time, date) or isinstance(open_time, datetime)
        if close_time:
            assert isinstance(open_time, date) or isinstance(close_time, datetime)
        self.open_time = open_time
        self.close_time = close_time
        self.csrf_exempt = csrf_exempt
        self.supervisor_exempt = supervisor_exempt
        self.previous_exempt = previous_exempt
        self.allow_services = allow_services
        self.block_services = block_services

        self.auth = Auth(login=login, require=require)
        if max_rps:
            assert isinstance(max_rps, (int, float)) and max_rps > 0, \
                f"Invalid max_rps: {max_rps}, must be a int / float > 0"
        if max_times:
            assert isinstance(max_times, int) and max_times > 0, \
                f"Invalid max_times: {max_times}, must be a int > 0"
        if max_errors:
            assert isinstance(max_errors, int) and max_errors > 0, \
                f"Invalid max_errors: {max_errors}, must be a int > 0"
        if ban_user:
            assert login, f'Request ban_user option requires to set login=True to ensure there is a user to ban'

        if url_max_length:
            assert isinstance(url_max_length, int) and url_max_length > 0, \
                f"Invalid url_max_length: {url_max_length}, must be a int"
        if body_max_length:
            assert isinstance(body_max_length, int) and url_max_length > 0, \
                f"Invalid body_max_length: {body_max_length}, must be a int"

        self.set_token = set_token
        self.max_rps = max_rps
        self.max_times = max_times
        self.max_errors = max_errors
        self.body_max_length = body_max_length
        self.url_max_length = url_max_length
        self.admin_only = admin_only
        self.valid_accept = valid_accept
        self.reset_after = record_reset_after if isinstance(record_reset_after, timedelta) else None\
            if record_reset_after is None else timedelta(seconds=record_reset_after)

        if allow_origin:
            if isinstance(allow_origin, str):
                if allow_origin != '*':
                    allow_origin = [allow_origin]
            elif not multi(allow_origin):
                raise TypeError(f'Request allow_origin must be None, "*" or a origin str / str list')

        allow_hosts = config.host_config.allows
        if not allow_origin:
            self.allow_origins = allow_hosts
        elif multi(allow_origin):
            self.allow_origins = list(allow_origin) + allow_hosts
        else:
            self.allow_origins = allow_origin
        if multi(self.allow_origins):
            self.allow_origins = set([get_origin(
                origin, default_scheme=config.scheme)
                for origin in self.allow_origins]
            )
        self.access_control_allow_headers = allow_headers

        if user_agent and not self._request:
            # self._request is not None means it's runtime, do not change config during runtime!!!
            assert isinstance(user_agent, self.Agent)
            try:
                config.log.parse_user_agent = True
            except AttributeError:
                pass
            # add user_agents requirement checks

        self.agent = user_agent
        self.record = self.Record(
            origin=self,
            alias=record_cache_alias,
            timeout=self.reset_after.total_seconds() if self.reset_after else None
        )

        if log_option:
            options = (Logger.OMIT, Logger.PERSIST, Logger.VOLATILE)
            assert log_option in options, f'Request log_option must in {options}, got {log_option}'
        self.log_option = log_option
        # do not use bool() , omit_log = None mean the omit config is defaulted
        self.ban_user = bool(ban_user)
        self.end_point = False
        self.cached = False

    @property
    def allow_all(self) -> bool:
        return self.allow_origins == '*'

    def get_params_schema(self, auth_config=None, external_auth=None):
        from utilmeta.core.sdk import RequestParams
        target: Request = self._origin
        if target._vacuum:
            return None
        auth = external_auth or self.auth
        return pop_null(RequestParams(
            content_type=target.__spec_kwargs__.get('content_type'),
            allow_origin=target.__spec_kwargs__.get('allow_origin'),
            scheme=target.__spec_kwargs__.get('scheme'),
            admin_only=target.admin_only,
            auth_config=auth_config,
            auth_require=auth.dict or None,
            max_rps=target.max_rps,
            max_times=target.max_times,
            max_errors=target.max_errors,
            open_time=target.open_time,
            close_time=target.close_time,
        )) or None

    def apply(self, request: Union[ReqType, 'Request'], default: bool = False) -> 'Request':
        """
        request filter, raise error if request doesn't fit the demand
        """
        if isinstance(request, Request):
            request = request._request

        r = self.make_request(request)
        if not self.end_point:
            # do not valid when this Request util is not end point
            return r
        # if all request be vacuum and origin is crossed, will check when make response
        # invalid origin will not set Allow-Origin headers
        if self.from_api:
            if r.origin_crossed and config.production:
                # origin cross settings is above all other request control settings
                # so that when request error occur, the cross-origin settings can take effect
                # so that client see a valid error message instead of a CORS error
                if self.allow_origins is None:
                    raise exc.PermissionDenied(f'Invalid request origin: {r.origin}')
                else:
                    if self.allow_origins != '*':
                        if r.origin not in self.allow_origins:
                            raise exc.PermissionDenied(f'Invalid request origin: {r.origin}')

            if self.set_token:
                get_token(request)
            elif not self.csrf_exempt:
                # only check csrf for from_api requests
                r.check_csrf()

        if self.type:
            if request.content_type and r.write:
                if request.content_type != self.type:
                    raise exc.UnsupportedMediaType(f'Invalid request Content-Type: '
                                                   f'{repr(request.content_type)}, must be {repr(self.type)}')

        now = r.time
        if self.open_time:
            if now < self.open_time:
                raise exc.TooEarly(f'This API is not open util {self.open_time}')
        if self.close_time:
            if now > self.close_time:
                raise exc.Gone(f'This API is now closed after {self.close_time}')

        if self.block_ips:
            if not any([r.ip_address in addr for addr in self.block_ips]):
                raise exc.PermissionDenied('Sorry, Your IP is not allowed to request')
        if self.allow_ips:
            if not any([r.ip_address in addr for addr in self.allow_ips]):
                raise exc.PermissionDenied('Sorry, Your IP is not allowed to request')
        if self.allow_services:
            if r.source_service not in self.allow_services:
                raise exc.BadRequest(f'Invalid source service')
        if self.block_services:
            if r.source_service in self.block_services:
                raise exc.BadRequest(f'Invalid source service')

        if self.max_rps or self.max_times or self.max_errors:
            key = r.user_id if self.ban_user else str(r.ip)

            if key not in self.record:
                self.record.set(key, time=now, times=1, errors=0)
            else:
                last_req, times, errors = self.record.get(key)
                rps = round(1 / (now - last_req).total_seconds(), 2)
                times += 1
                self.record.set(key, time=now, times=times, errors=errors)
                invalid = None
                if self.max_times and times > self.max_times:
                    invalid = f'You request this API too much that pass the times limit: {self.max_times}'
                if self.max_rps and rps > self.max_rps:
                    invalid = f'You request this API too frequent that pass the rps limit: {self.max_rps}'
                if self.max_errors and errors >= self.max_errors:
                    invalid = f'You request this API failed too much that pass errors limit: {self.max_errors}'
                if invalid:
                    if self.reset_after and now - last_req > self.reset_after:
                        self.record.set(key, time=now, times=1, errors=0)
                    else:
                        raise exc.TooManyRequests(invalid)

        if self.url_max_length:
            if len(r.url) > self.url_max_length:
                raise exc.RequestURITooLong(f'You request URL length: {len(r.url)}'
                                            f' exceed the limit: {self.url_max_length}')
        if self.body_max_length:
            if r.content_length > self.body_max_length:
                raise exc.RequestEntityTooLarge(f'Your request Content-Length:'
                                                f' {r.content_length} exceed the limit: {self.body_max_length}')

        if self.agent:
            self.agent(r.user_agent)

        if r.options:
            # for OPTIONS method, don't auth and directly return
            return r

        self.auth(r)

        if self.admin_only:
            if not r.managed:
                raise exc.PermissionDenied("This API is only for admin")
        return r

    @classmethod
    def custom(cls, method: str, path: str = '', headers: Union[dict, HttpHeaders] = None,
               query: dict = None, data=None, user_id=None, admin=None):
        from django.http.request import HttpRequest
        req = HttpRequest()
        req.method = method.upper()
        req.PATH = path
        req.path = path
        req.query = query or {}
        req.QUERY = immutable(query)
        req.data = data
        req.BODY = immutable(data)
        req.META = {
            http_header(key): val for key, val in headers.items()
            if key not in ISOLATED_HEADERS
        } if headers else {}
        req.user_id = user_id
        req.admin = admin
        return cls().make_request(req)

    def check_csrf(self):
        if CsrfViewMiddleware().process_view(self._request, None, None, None) is not None:
            raise exc.PermissionDenied('CSRF token missing or incorrect')

    def valid_response(self, response):
        from .response import Response
        response: Response
        if not self.valid_accept:
            return
        accept = self.accept
        if accept == '*' or '*/*' in accept:
            return
        content_type: str = response.content_type or response.type
        if not content_type:
            return
        if content_type in accept:
            return
        for ac in accept.split(';'):
            ac = ac.strip(' ')
            if '/*' in ac:
                gt = ac.strip('/*')
                if content_type.startswith(gt):
                    return
        raise exc.NotAcceptable()

    def _merge(self, util: 'Request') -> 'Request':
        if util.previous_exempt:
            return util.__copy__()
        return super()._merge(util)

    def record_error(self):
        if not self.from_api:
            return
        if not self.max_errors:
            return
        if self.error_recorded:
            return
        key = self.user_id if self.ban_user else str(self.ip)
        if not key:
            return
        self.error_recorded = True
        if key not in self.record:
            self.record.set(key, time=self.time, times=1, errors=1)
        else:
            last, times, errors = self.record[key]
            errors += 1
            self.record.set(key, time=last, times=times, errors=errors)

    def make_request(self, request: ReqType) -> 'Request':
        r = self.__class__(request, **self.__kwargs__)
        if r.log_option is not None:
            r.log.option = r.log_option
        r.record = self.record
        return r

    def load_routes(self) -> List[str]:
        if hasattr(self._request, 'routes'):
            return self.routes
        path = getattr(self._request, 'PATH', '')
        if self.post_query:
            path = path[:-len(Param.query)]
        self.routes = [item for item in path.split('/') if item]
        return self.routes

    @property
    def recv_ts(self):
        return getattr(self._request, 'recv_ts', utc_ms_ts())

    @property
    def errors(self):
        key = self.user_id if self.ban_user else self.ip
        return self.record.get(key)[2]

    @property
    def left_errors(self):
        if not self.max_errors:
            return None
        return max(0, self.errors - self.max_errors)

    @property
    def times(self):
        key = self.user_id if self.ban_user else self.ip
        return self.record.get(key)[1]

    @property
    def left_times(self):
        if not self.max_times:
            return None
        return max(0, self.times - self.max_times)

    @property
    def rps(self):
        key = self.user_id if self.ban_user else self.ip
        rc = self.record.get(key)
        return round(1 / (self.time - rc[0]).total_seconds(), 2)

    @property
    def from_api(self) -> bool:
        if not self._request:
            return False
        return isinstance(self._request, (WSGIRequest, ASGIRequest))

    @property
    def source_instance(self) -> str:
        return self.headers.get(MetaHeader.INSTANCE)

    @property
    def source_service(self) -> str:
        return self.headers.get(MetaHeader.SERVICE_NAME)

    @property
    def routes(self):
        if not hasattr(self._request, 'routes'):
            return self.load_routes()
        return getattr(self._request, 'routes')

    @routes.setter
    def routes(self, val):
        self._request.routes = val

    @property
    @ignore_errors(default='*')
    def accept(self) -> str:
        return self._request.headers[Header.ACCEPT]

    @property
    def route(self):
        r = '/'.join(self.routes)
        if getattr(self._request, 'post_query', None):
            r += Param.query
        return r

    @property
    def is_ops(self):
        return self.path.lstrip('/').startswith(config.ops_url.lstrip('/'))\
            if config.ops and config.ops.route else False

    @property
    def BODY(self):
        return immutable(getattr(self._request, 'BODY', None))

    @property
    def QUERY(self) -> ImmutableDict:
        return immutable(getattr(self._request, 'QUERY', None))

    # use "data" as alias for request.body
    @property
    def data(self):
        return getattr(self._request, 'data', None)

    @data.setter
    def data(self, val):
        if self._request:
            self._request.data = val

    @property
    def body(self):
        return getattr(self._request, 'data', None)

    @property
    def has_body(self) -> bool:
        return self.METHOD.lower() in HAS_BODY_METHODS

    @property
    def raw_body(self):
        return getattr(self._request, 'body', None)

    @body.setter
    def body(self, val):
        if self._request:
            self._request.data = val

    @property
    def query(self) -> Dict[str, Any]:
        return getattr(self._request, 'query', {})

    @query.setter
    def query(self, val: dict):
        if self._request:
            self._request.query = val

    @property
    def params(self) -> Dict[str, Any]:
        return getattr(self._request, 'query', {})

    @params.setter
    def params(self, val: dict):
        if self._request:
            self._request.query = val

    @property
    def safe(self):
        return self.METHOD in SAFE_METHODS

    @property
    def auth_scheme(self):
        header: str = self.headers.get(Header.AUTHORIZATION)
        if not header:
            return None
        return header.split()[0].lower()

    @property
    @ignore_errors(default=None)
    def auth_params(self) -> Union[str, dict, None]:
        header: str = self.headers.get(Header.AUTHORIZATION)
        if not header:
            return None
        value = ''.join(header.split()[1:])
        if self.auth_scheme == 'digest':
            params = {}
            for val in value.split(','):
                k, v = val.split('=')
                params[k] = v
            return params
        return value

    @property
    def jwt_token(self):
        return getattr(self._request, '_jwt_token', None)

    @jwt_token.setter
    def jwt_token(self, val: str):
        if isinstance(val, str) and val:
            setattr(self._request, '_jwt_token', val)

    @property
    def jwt_params(self):
        return getattr(self._request, '_jwt_params', None)

    @jwt_params.setter
    def jwt_params(self, val: dict):
        if isinstance(val, dict) and val:
            setattr(self._request, '_jwt_params', val)

    def options_response(self):
        response = HttpResponse()
        response[Header.ALLOW] = ', '.join(self.allow_methods)
        response[Header.LENGTH] = '0'
        return allow_cors(
            response,
            origin=self.origin,
            methods=self.allow_methods,
            headers=self.allow_headers
        )

    @property
    def allow_methods(self) -> List[str]:
        return getattr(self._request, 'allow_methods', [self.method])

    @allow_methods.setter
    def allow_methods(self, methods):
        if self._request:
            self._request.allow_methods = sorted(list(set(methods)))

    def load(self):
        from .auth import Auth
        if hasattr(self._request, 'user_id'):
            # already loaded
            return

        Auth.load(self)

    def enter_unit(self, endpoint_path: str = None):
        # fore save
        if config.cluster and config.cluster.enable_log_tracing and self.source_instance:
            self.log.foreground_save_api(self)
        if endpoint_path:
            setattr(self._request, '_endpoint_path', endpoint_path)

    @property
    @ignore_errors(default=False)
    def access_control_required(self) -> bool:
        """
        Need to set Access-Control-Allow-xxx headers for response
        :return:
        """
        # error default, so when error occur, CORS headers cam also be set
        if self.managed or self.options or self.allow_origins == '*':
            return True
        if self.origin_crossed:
            return True
        if self.allow_origins is None or self.origin not in self.allow_origins:
            return False
        return True

    @property
    def access_control_request_headers(self) -> List[str]:
        return self.headers.get(Header.OPTIONS_HEADERS, '').split(',')

    @property
    def origin_crossed(self) -> bool:
        """
        Only when Origin header is provided (possibly by Browser)
        """
        return self.origin and config.origin != self.origin

    @property
    def allow_headers(self) -> list:
        headers = list(ALLOW_HEADERS)
        if self.access_control_allow_headers:
            headers.extend(self.access_control_allow_headers)
        if self.managed:
            headers.extend(ADMIN_HEADERS)
        if self.options:
            headers.extend(self.access_control_request_headers)
        return getattr(self._request, 'allow_headers', headers)

    @allow_headers.setter
    def allow_headers(self, headers):
        if self._request:
            self._request.allow_headers = list(set(headers))

    @property
    @ignore_errors(default='GET', log=False)
    def METHOD(self) -> str:
        return self._request.method or 'GET'

    @property
    def post_query(self) -> bool:
        if not self.path.endswith(Param.query):
            return False
        if self.METHOD == HTTPMethod.OPTIONS:
            return self.access_control_request_method == HTTPMethod.POST
        return self.METHOD == HTTPMethod.POST

    @property
    def access_control_request_method(self) -> str:
        return self.headers.get(Header.OPTIONS_METHOD, self.METHOD)

    @cached_property
    @ignore_errors
    def method(self) -> str:
        m = self.METHOD.lower()
        if m == MetaMethod.HEAD:
            m = CommonMethod.GET
        elif m == MetaMethod.OPTIONS:
            m = self.access_control_request_method.lower()
        if self.post_query:
            m = CommonMethod.GET
        return m

    @METHOD.setter
    def METHOD(self, m: str):
        if not isinstance(m, str) or not self._request:
            return
        m = m.upper()
        if m not in HTTP_METHODS:
            return
        self._request.method = m

    @property
    def local(self):
        return localhost(self.ip) and localhost(self.host)

    @property
    @ignore_errors(default=lambda: HttpHeaders({}), log=False)
    def headers(self) -> HttpHeaders:
        return self._request.headers

    @property
    def head(self) -> str:
        return self.METHOD == HTTPMethod.HEAD

    @property
    def options(self) -> str:
        return self.METHOD == HTTPMethod.OPTIONS

    @property
    def write(self) -> bool:
        return self.METHOD in (HTTPMethod.POST, HTTPMethod.PUT, HTTPMethod.PATCH)

    @property
    def META(self) -> dict:
        return self._request.META

    @property
    def ip(self) -> str:
        return str(getattr(self._request, 'IP', LOCAL_IP))

    @property
    def ip_address(self) -> IPType:
        return getattr(self._request, 'IP', IPv4Address(LOCAL_IP))

    @property
    def origin(self) -> str:
        origin = self.headers.get(Header.ORIGIN)
        # do not transfer local
        return get_origin(origin, default_scheme=config.scheme, trans_local=False) if origin else ''

    @property
    def managed(self) -> bool:
        if not config.ops:
            return False
        if self.options and self.is_ops:
            return True
        return bool(self.srv_token or self.supervisor)

    @property
    def supervisor(self):
        from ..ops.models.admin import Supervisor
        sp: Supervisor = getattr(self._request, 'supervisor', None)
        return sp

    @supervisor.setter
    def supervisor(self, obj):
        from ..ops.models.admin import Supervisor
        if not isinstance(obj, Supervisor) or not self._request:
            return
        self._request.supervisor = obj

    @property
    def admin(self):
        return getattr(self._request, 'admin', None)

    @admin.setter
    def admin(self, obj):
        from ..ops.models.admin import Admin
        if not isinstance(obj, Admin) or not self._request:
            return
        self._request.admin = obj

    @property
    def srv_token(self) -> str:
        return self.headers.get(MetaHeader.SERVICE_TOKEN)

    @property
    def ops_token(self) -> str:
        return getattr(self._request, 'ops_token', self.headers.get(MetaHeader.OPERATION))

    @ops_token.setter
    def ops_token(self, token: str):
        if self._request:
            self._request.ops_token = token

    @property
    def token_data(self) -> dict:
        return getattr(self._request, 'token_data', {})

    @token_data.setter
    def token_data(self, data: dict):
        if not isinstance(data, dict) or not self._request:
            return
        self._request.token_data = data

    @property
    def token_type(self) -> str:
        return getattr(self._request, 'token_type', None)

    @token_type.setter
    def token_type(self, type: dict):
        if not isinstance(type, str) or not self._request:
            return
        self._request.token_type = type

    @property
    def action_token(self) -> str:
        return self.headers.get(MetaHeader.ACTION_TOKEN)

    @property
    @ignore_errors(default=0, log=False)
    def content_length(self) -> int:
        if self.method not in HAS_BODY_METHODS:
            return 0
        length = self.headers.get(Header.LENGTH)
        if length is not None:
            return int(length)
        return len(getattr(self._request, '_body', b''))

    @property
    def user(self) -> Union[Model, Any]:
        if not self.user_id:
            return None
        if hasattr(self._request, Key.USER_CACHE):
            return getattr(self._request, Key.USER_CACHE)

        from .auth import Auth
        from django.utils.functional import SimpleLazyObject

        def get_user(_request):
            if not hasattr(_request, Key.USER_CACHE):
                setattr(_request, Key.USER_CACHE, Auth.get_user(_request))
            return getattr(_request, Key.USER_CACHE)
        return SimpleLazyObject(lambda: get_user(self._request))

    @user.setter
    def user(self, val):
        if not isinstance(val, Model) or not self._request:
            return
        self._request.user_id = val.pk

    @property
    def user_id(self) -> Union[int, str]:
        return getattr(self._request, 'user_id', None)

    @user_id.setter
    def user_id(self, val):
        if not self._request:
            return
        self._request.user_id = val
        # clear cache
        if hasattr(self._request, Key.USER_CACHE):
            delattr(self._request, Key.USER_CACHE)

    @property
    def login(self) -> bool:
        return bool(self.user_id) or bool(self.admin)

    @property
    def session(self) -> SessionBase:
        return getattr(self._request, 'session', SessionBase())

    @property
    def time(self) -> datetime:
        return convert_time(datetime.fromtimestamp(self.log.init_time))

    @property
    def log(self) -> Logger:
        logger = getattr(self._request, 'log', None)
        if not isinstance(logger, Logger):
            logger = Logger(root=True)
            self.log = logger
        return logger

    @log.setter
    @ignore_errors(log=False)
    def log(self, logger):
        if self._request:
            self._request.log = logger

    @property
    @ignore_errors(default='', log=False)
    def path(self) -> str:
        return self._request.path.strip('/')

    @property
    def raw_path(self) -> str:
        return self._request.path if self._request else '/'

    @property
    def context(self) -> dict:
        _local = getattr(self._request, '_context')
        if not _local:
            _local = {}
            setattr(self._request, '_context', _local)
        return _local

    @property
    @ignore_errors(default='', log=False)
    def endpoint_path(self) -> str:
        if hasattr(self._request, '_endpoint_path'):
            return getattr(self._request, '_endpoint_path')
        if not config.root_url:
            return self.path
        return re.compile(config.root_pattern).match(self.path).groups()[0]

    @property
    def endpoint_ident(self):
        return f'{self.method}:{self.endpoint_path}'

    @property
    @ignore_errors(default='', log=False)
    def full_path(self) -> str:
        return self._request.get_full_path()

    @property
    def accept_version(self) -> Version:
        return self.Version(self.headers.get(MetaHeader.ACCEPT_VERSION))

    @property
    def reroute_target(self):
        if self.accept_version.resolved:
            return None
        if not config.cluster:
            # if no cluster configured, mismatch version will be resolved locally without reroute
            return None
        if not self.accept_version.get_instances(config.name):
            return None
        from utilmeta.core.sdk import SDK
        return SDK(service=config.name, version=self.accept_version)

    @property
    @ignore_errors(default='http', log=False)
    def scheme(self) -> str:
        return self._request.scheme or 'http'

    @property
    def is_http(self) -> bool:
        return self.scheme in (Scheme.HTTP, Scheme.HTTPS)

    @property
    @ignore_errors(default='', log=False)
    def url(self) -> str:
        return self._request.get_raw_uri()

    @property
    @ignore_errors(default='', log=False)
    def host(self):
        return self._request.get_host()

    @property
    @ignore_errors(default='', log=False)
    def port(self):
        return self._request.get_port()

    @property
    @ignore_errors(default=dict, log=False)
    def COOKIES(self) -> dict:
        return self._request.COOKIES

    @property
    @ignore_errors(log=False)
    def content_type(self) -> str:
        return self._request.content_type

    @property
    def language(self) -> str:
        return self.headers.get(Header.ACCEPT_LANGUAGE, 'zz')

    @property
    def ua_string(self) -> str:
        return self.headers.get(Header.USER_AGENT)

    @property
    @ignore_errors(log=False)
    def user_agent(self):
        ua = getattr(self._request, 'user_agent', None)
        if not ua:
            from user_agents.parsers import UserAgent
            ua = UserAgent(self.ua_string)
            self._request.user_agent = ua
        return ua

    class Path(str):
        @classmethod
        def valid(cls, val):
            if isinstance(val, type):
                if not issubclass(val, str):
                    raise TypeError(f'Path must be str type, got {val}')
            elif isinstance(val, Rule):
                if val.type:
                    if not issubclass(val.type, str):
                        raise TypeError(f'Path must be str type, got {val.type}')

    class Body:
        def __init__(self, *keys, **kwargs):
            self.params = get_field_name(keys)
            self.kwargs = kwargs

        @classmethod
        def valid(cls, data) -> bool:
            from ..core.schema import SchemaMeta
            form = False
            if Media.file_param(data):
                if multi(data):
                    assert len(data) == 1, "Request Body file list should contains one File template," \
                                           " the key in form don't have order"
                    assert isinstance(data[0], File)
                else:
                    assert isinstance(data, File)

            if isinstance(data, SchemaMeta):
                data = data.__template__
            if isinstance(data, dict):
                for key, val in data.items():
                    if Media.file_param(val):
                        if multi(val):
                            assert len(val) == 1, "Request Body file list should contains one File template," \
                                                   " the key in form don't have order"
                        form = True
                    else:
                        f = Media.find_file(data)
                        if f:
                            raise TypeError(f"Invalid File param: {f} in Request.Body[{repr(key)}], "
                                            f"file param in body must expose at first layer for multipart/form-data")
            return form

        @classmethod
        def content_type(cls, body) -> Optional[str]:
            from ..core.schema import SchemaMeta
            if not body:
                return None
            if Media.file_param(body):
                if multi(body):
                    return RequestType.FORM_DATA
                elif body in (Media.Image, Media.Audio, Media.Video):
                    return body.content_type
                elif isinstance(body, File):
                    return RequestType.OCTET_STREAM
                return RequestType.FORM_DATA
            if isinstance(body, SchemaMeta):
                body = body.__template__
            if isinstance(body, dict):
                for value in body.values():
                    if Media.file_param(value):
                        return RequestType.FORM_DATA
            return RequestType.JSON

    class Query(dict):
        def __init__(self, *keys, **kwargs):
            super().__init__(kwargs)
            self.params = get_field_name(keys)

        @classmethod
        def valid(cls, data: dict):
            import inspect
            if isinstance(data, Rule):
                if data.type and issubclass(data.type, dict):
                    return
                data = data.template
            if inspect.isclass(data):
                assert issubclass(data, dict), f"Request Query type should be dict subclass, got {data}"
            elif isinstance(data, dict):
                for k in data.keys():
                    assert isinstance(k, str)
                    if k.endswith('[]'):
                        raise ValueError(f'Request Query template key cannot endswith "[]", '
                                         f'it is reserved for list QueryString params parse')
                f = Media.find_file(data)
                if f:
                    raise TypeError(f"Invalid File param: {f} in Request.Query")
            else:
                raise TypeError(f"Request Query template should be a dict, got {data}")

    class Headers(dict):
        def __init__(self, *keys, **kwargs):
            super().__init__(kwargs)
            self.headers = get_field_name(keys)

        @classmethod
        def valid(cls, data: dict):
            import inspect
            if isinstance(data, Rule):
                data = data.template
            if inspect.isclass(data):
                assert issubclass(data, dict), f"Request Headers type should be dict subclass, got {data}"
            elif isinstance(data, dict):
                f = Media.find_file(data)
                if f:
                    raise TypeError(f"Invalid File param: {f} in Request.Headers")
            else:
                raise TypeError(f"Request Headers template should be a dict, got {data}")
