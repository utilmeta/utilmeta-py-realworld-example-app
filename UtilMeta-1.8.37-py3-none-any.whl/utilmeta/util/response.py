import json
from django.http import HttpResponse
from django.http.response import HttpResponseBase, FileResponse
from .common import GeneralType, GENERAL_TYPES, pop_null, MetaHeader, \
    STREAM_TYPES, Hint, Header, STATUS_WITHOUT_BODY, exc, \
    file_like, handle_json_float, ignore_errors

from http.client import HTTPResponse
from typing import Union, Callable, Any
from .error import Error
from .base import Util
from .media import Media

__all__ = ['Response']


class JsonResponse(HttpResponse):
    def __init__(self, data, encoder=None, safe=True,
                 json_dumps_params=None, **kwargs):
        from utilmeta.conf import config
        encoder = encoder or config.preference.json_encoder_cls
        if safe and not isinstance(data, dict):
            raise TypeError(
                'In order to allow non-dict objects to be serialized set the '
                'safe parameter to False.'
            )
        if json_dumps_params is None:
            json_dumps_params = {}
        kwargs.setdefault('content_type', 'application/json')
        json_data = json.dumps(handle_json_float(data), cls=encoder, ensure_ascii=False, **json_dumps_params)
        # edit the data ,plus ensure_ascii=False to make sure the ch word display normally
        super().__init__(content=json_data, **kwargs)


class Response(Util):
    base = HttpResponseBase
    http = HttpResponse
    file = FileResponse
    json = JsonResponse

    JSON = GeneralType.JSON
    HTML = GeneralType.HTML
    TEXT = GeneralType.TEXT
    IMAGE = GeneralType.IMAGE
    AUDIO = GeneralType.AUDIO
    VIDEO = GeneralType.VIDEO
    OCTET_STREAM = GeneralType.OCTET_STREAM

    def __init__(self, schema=None, *,
                 # result_key: str = None,
                 result_data_key: str = None,

                 # http_status_code_key: str = None,  # default set to None to let http_status_code
                 status_code_key: str = None,

                 # message_key: str = None,
                 error_message_key: str = None,

                 # count_key: str = None,
                 total_count_key: str = None,
                 action_state_key: str = None,

                 type: str = GeneralType.JSON,

                 success_action_state: Union[str, int] = 1,
                 failed_action_state: Union[str, int, Callable[[Any], bool]] = 0,
                 success_validator: Callable[[Any], bool] = None,

                 case_style: str = None,
                 headers=None,
                 name: str = None,
                 strict: bool = False,
                 status: int = None,
                 override: bool = None
                 ):

        super().__init__(locals())

        if status_code_key or error_message_key or total_count_key or action_state_key:
            result_data_key = result_data_key or 'data'

        self.case_style = case_style
        self.override = override
        # self.__defaulted = False
        self.content_type = GeneralType.content_type(type)
        type = GeneralType.get(type)
        assert type in GENERAL_TYPES, f'Response type is a general type in {GENERAL_TYPES}, got {type}'
        if status:
            assert 100 <= status <= 600, f'Invalid status code: {status} must be int in 100 ~ 600'

        from utilmeta.conf import config
        if schema:
            schema = config.preference.class_parser_cls.parse_type(schema, for_read=True)

        if headers:
            from .request import Request
            config.preference.class_parser_cls.valid_template(headers)
            Request.Headers.valid(headers)

        self.result_key = result_data_key
        self.status_key = status_code_key
        self.message_key = error_message_key
        self.state_key = action_state_key
        self.count_key = total_count_key
        self.result_only = not result_data_key
        self.name = name

        if Media.file_param(schema):
            type = Media.content_type(schema)
        self.default_status = status
        self.type = type
        self.schema = schema
        self.headers_schema = headers
        self.strict = strict

        self.success_action_state = success_action_state
        self.failed_action_state = failed_action_state
        if success_validator:
            assert callable(success_validator)
        self.success_validator = success_validator

    def _merge(self, util: 'Response') -> 'Response':
        if util.override is not False:
            return util.__copy__()
        return super()._merge(util)

    @property
    def stream(self):
        return self.type in STREAM_TYPES

    @property
    def vacuum(self):
        return self._vacuum

    def get_params_schema(self):
        from utilmeta.core.sdk import ResponseParams
        target: Response = self._origin
        if target._vacuum:
            return None
        return pop_null(ResponseParams(
            result_data_key=target.result_key,
            status_code_key=target.status_key,
            error_message_key=target.message_key,
            total_count_key=target.count_key,
            action_state_key=target.state_key,
            success_action_state=target.success_action_state if
            target.success_action_state != Response().success_action_state else None,
            failed_action_state=target.failed_action_state
            if target.failed_action_state != Response().failed_action_state else None,
        )) or None

    def union_schema(self, schema: Union[dict, list]):
        from .rule import Rule
        from utilmeta.core.schema import SchemaMeta
        _schema = self.schema
        wrapped = False
        if isinstance(_schema, list):
            wrapped = True
            _schema = _schema[0]
        if isinstance(schema, list):
            schema = schema[0]
        _schema = SchemaMeta.__retrieve__(_schema, _dict=True)
        for key, val in schema.items():
            if key not in _schema:
                _schema[key] = Rule.optional(val)
        self.schema = [_schema] if wrapped else _schema

    @classmethod
    def get_content(cls, resp: HttpResponseBase):
        if isinstance(resp, HttpResponse):
            data = resp.content.decode('utf-8', 'ignore')
            if GeneralType.JSON in resp[Header.TYPE]:
                return json.loads(data)
            return data
        return Hint.STREAMING_CONTENT

    @classmethod
    def get_clear_content(cls, resp: HttpResponseBase):
        from utilmeta.conf import config
        from utilmeta.util.common import SECRET, multi

        def clean(data):
            if multi(data):
                return [clean(d) for d in data]
            elif isinstance(data, dict):
                result = {}
                for key, val in data.items():
                    for k in config.ops.secret_names:
                        if k in key.lower():
                            val = SECRET
                            break
                    result[key] = val
                return result
            else:
                return data
        return clean(cls.get_content(resp))

    def get_result(self, resp: HttpResponseBase):
        content = self.get_content(resp)
        if isinstance(content, dict):
            if self.result_key:
                return content.get(self.result_key)
            return content
        return content

    def render(self, result):   # noqa
        """
        used to be override and define your own render logic
        """
        if self.case_style and isinstance(result, (list, dict)):
            from utilmeta.util.parser.base import FieldTransfer
            result = FieldTransfer(self.case_style)(result)

        return result

    def error(self, message=''):
        return self(message=message, status=500, state=self.failed_action_state)

    def success(self, result=''):
        return self(result=result, status=200, state=self.success_action_state)

    def fail(self, message='', result=''):
        return self(message=message, state=self.failed_action_state, result=result)

    def deny(self, message=''):
        return self(message=message, state=self.failed_action_state, status=403)

    def none(self):
        return self(status=204)

    def timeout(self):
        return self(state=self.failed_action_state, status=408)

    def conflict(self):
        return self(state=self.failed_action_state, status=409)

    def gone(self):
        return self(state=self.failed_action_state, status=410)

    def created(self):
        return self(status=201)

    def accepted(self):
        return self(status=202)

    def bad(self, message=''):
        return self(message=message, state=self.failed_action_state, status=400)

    def notfound(self, message=''):
        return self(message=message, state=self.failed_action_state, status=404)

    def not_modified(self):
        return self(status=304)

    # @classmethod
    # def get_response_schema(cls, data):
    #     if not data:
    #         return data
    #     if isinstance(data, type):
    #         return data
    #     if isinstance(data, dict):
    #         return data
    #     if multi(data):
    #         return [cls.get_response_schema(d) for d in data]

    def template(self, schema=None, status: int = None, wrapped: bool = False) -> dict:
        from .rule import Rule
        status = status or self.default_status
        persist = status == self.default_status
        status = status or 200
        schema = schema or self.schema
        data = None
        if status in STATUS_WITHOUT_BODY:
            data = None
        elif self.result_only or not wrapped:
            if schema and persist:
                data = schema
        else:
            data = {self.result_key: schema or Hint.RESULT}
            if self.message_key:
                data[self.message_key] = '' if status < 400 else Hint.MESSAGE
            if self.state_key:
                data[self.state_key] = Hint.STATE if status < 400 else self.failed_action_state
            if self.status_key:
                data[self.status_key] = status
            if self.count_key:
                data[self.count_key] = Hint.COUNT if status < 400 else 0

        if self.case_style:
            from utilmeta.util.parser.base import FieldTransfer
            data = FieldTransfer(self.case_style)(data)

        headers = self.headers_schema or None
        return Rule.note(pop_null(dict(
            type=self.type,
            status=status,
            data=data,
            headers=headers,
            params=self.get_params_schema()
        )), simplify=True)

    @ignore_errors(default=False)
    def check_success(self, data: dict, status: int = None):
        state = data
        if self.state_key:
            state = data.get(self.state_key)
        elif status and status < 400:
            return True
        if self.success_validator:
            return self.success_validator(state)
        if self.success_action_state is not None:
            return state == self.success_action_state
        if self.failed_action_state is not None:
            return state == self.failed_action_state
        return True

    def valid_headers(self, resp: HttpResponseBase):
        from .rule import Rule
        try:
            schema = self.headers_schema
            for key, val in schema.items():
                key: str
                header_key = key.replace('_', '-')
                if header_key in resp:
                    header = resp[header_key]
                    if isinstance(val, Rule):
                        resp[header_key] = val(header)
                elif isinstance(val, str):
                    resp[header_key] = val
            content_type = GeneralType.get(resp.get(Header.TYPE))
            if content_type != self.type:
                if self.type == GeneralType.OCTET_STREAM and content_type in STREAM_TYPES:
                    pass
                else:
                    raise exc.BadResponse(f'Response type: {content_type} not match target type: {self.type}')

        except (ValueError, TypeError):
            raise Error().throw(type=exc.BadResponse,
                                prepend='Response headers not match the expected schema with error: ')
        return resp

    @property
    def keys_repr(self):
        return self._repr(params=['result_data_key', 'total_count_key', 'error_message_key',
                                  'action_state_key', 'status_code_key'])

    @classmethod
    def set_headers(cls, resp, **headers):
        for key, val in headers.items():
            if val is not None:
                resp[key] = str(val)
        return resp

    def __call__(self, result=None, *, status: int = None, content_type: str = None,
                 message: Union[str, Exception, Error] = '', state: int = None, count: int = 0,
                 extra: dict = None, headers: dict = None) -> HttpResponseBase:

        response = None
        content_type = content_type or self.content_type  # if content_Type is none, will not assign value
        status = status or self.default_status

        if isinstance(result, (Exception, Error)):
            if not status:
                status = Error(result).status
            result = str(result)

        if isinstance(message, (Exception, Error)):
            if not status:
                status = Error(message).status
            message = str(message)

        status = int(status or 200)
        headers = headers or {}

        assert 100 <= status <= 600, f'Invalid status code: {status} must be int in 100 ~ 600'

        if state is None:
            if status >= 400:
                state = self.failed_action_state
            else:
                state = self.success_action_state

        if callable(state):
            state = state()

        if self.name:
            headers.update({MetaHeader.RESPONSE_NAME: self.name})

        result = self.render(result)

        if isinstance(result, HTTPResponse):
            # from Call.send or urllib, directly convert
            resp = HttpResponse(content=result.read(), status=result.status)
            for key, val in result.headers.items():
                resp[key] = val
            return resp

        if isinstance(result, HttpResponseBase):
            if self.strict and self.headers_schema:
                self.valid_headers(result)
            response = result

        if status in STATUS_WITHOUT_BODY:
            response = HttpResponse(status=status)
            del response[Header.TYPE]

        if file_like(result):
            response = FileResponse(result, status=status)
        if not response:
            if self.strict and self.schema:
                try:
                    from utilmeta.conf import config
                    result = config.preference.base_parser_cls.parse(result, self.schema)
                except (ValueError, TypeError):
                    raise Error().throw(exc.BadResponse,
                                        prepend='Response data not match the expected schema with error: ')

            response = HttpResponse(content=result or '', status=status)
            if self.type == GeneralType.JSON:
                data = result
                if not self.result_only:
                    data = dict(extra) if isinstance(extra, dict) else {}
                    data[self.result_key] = result
                    if self.message_key:
                        data[self.message_key] = message
                    if self.status_key:
                        data[self.status_key] = status
                        status = 200
                    if self.state_key:
                        data[self.state_key] = state
                    if self.count_key:
                        data[self.count_key] = int(count or 0)
                if isinstance(data, (dict, list)):
                    response = JsonResponse(data=data, status=status, safe=False)
        if headers:
            self.set_headers(response, **headers)
            if self.strict and self.headers_schema:
                self.valid_headers(response)
        if content_type:
            response.setdefault(Header.TYPE, content_type)
        return response
