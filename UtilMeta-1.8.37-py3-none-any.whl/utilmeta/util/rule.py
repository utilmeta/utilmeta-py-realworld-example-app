from .common import type_transform, COMMON_TYPES, COMMON_ERRORS, JSON_TYPES, \
    multi, Static, order_dict, type_note, readable, Attr, represent, pop, \
    distinct, copy_value, is_origin
import copy
import re
import inspect
from typing import Union, Any, Callable, Dict, List, Tuple, Type, Optional, TYPE_CHECKING
from .base import LogicUtil
from .error import Error
from enum import Enum

if TYPE_CHECKING:
    from .parser import Options

compares = (int, float, str)
multiples = (list, set, tuple)
_type = type


class Bound(Static):
    alias = 'alias'
    alias_from = 'alias_from'
    alias_for = 'alias_for'

    attname = 'attname'
    strict = 'strict'
    require = 'require'
    default = 'default'

    type = 'type'
    dict_type = 'dict_type'
    type_union = 'type_union'
    template = 'template'

    round = 'round'
    value = 'value'
    choices = 'choices'
    multiple = 'multiple'
    regex = 'regex'

    gt = 'gt'
    ge = 'ge'
    lt = 'lt'
    le = 'le'
    length = 'length'
    max_length = 'max_length'
    min_length = 'min_length'

    null = 'null'
    validator = 'validator'
    converter = 'converter'
    message = 'message'
    document = 'document'
    field = 'field'


class Valid:
    @classmethod
    def type(cls, value, t, strict):
        try:
            return type_transform(value, t)
        except TypeError as e:
            if strict:
                raise Error(e).throw()
            return t()

    @classmethod
    def dict_type(cls, value, t, strict, options=None):
        if not isinstance(value, dict):
            raise TypeError(f"Value <{readable(value)}> must be dict type")
        key_type, val_type = t
        _dict = {}
        for key, val in value.items():
            key = cls.template(key, key_type, strict=strict, options=options)
            val = cls.template(val, val_type, strict=strict, options=options)
            _dict[key] = val
        return _dict

    @classmethod
    def type_union(cls, value, u, strict, options=None):
        match = False
        errors = []

        from ..core.schema import SchemaMeta
        # pre check already satisfied
        for t in u:
            if is_origin(value, t) and isinstance(t, SchemaMeta):
                # higher origin
                return t(value)

        v = value
        for t in u:
            try:
                if isinstance(t, type):
                    v = type_transform(value, t, strict=True)
                elif isinstance(t, Rule):
                    v = t(value, options=options)
                else:
                    v = cls.template(value, t, options=options)
            except COMMON_ERRORS as e:
                errors.append(str(e))
                continue
            else:
                match = True
                break

        if not match:
            if strict:
                format_errors = ', '.join(errors)
                raise TypeError(f"value <{readable(value)}> cannot convert to any"
                                f" type of union: {repr(u)} with errors: {format_errors}")
            return u[0]()
        return v

    @classmethod
    def round(cls, value, r, strict):
        if not isinstance(value, float):
            if not strict:
                value = float(value)
        return round(value, r)

    @classmethod
    def template(cls, value, t, strict=True, options=None):
        from .parser import Options
        from utilmeta.conf import config
        if isinstance(options, Options):
            if options.vacuum and not strict:
                options = Options(
                    allow_excess=True,
                    allow_type_transform=True,
                    list_preserve_against=True
                )
        else:
            options = Options()
        return config.preference.base_parser_cls.parse(value, t, options=options)

    @classmethod
    def value(cls, value, v, strict):
        if callable(value):
            value = value()
        if value != v:
            if strict:
                raise ValueError(f"value <{readable(value)}> not match the expected value")
            return v
        return value

    @classmethod
    def choices(cls, value, lst, strict):
        if isinstance(lst, list):
            if not set(value).issubset(lst):
                if strict:
                    raise ValueError(f"value <{readable(set(value).difference(lst))}> "
                                     f"is out of choices scope: {repr(lst)}")
                return type(value)(set(value).intersection(lst))
        else:
            if value not in lst:
                if strict:
                    raise ValueError(f"value <{readable(value)}> not in choices {repr(lst)}")
                return lst[0]
        return value

    @classmethod
    def regex(cls, value, r, strict):
        strict = strict or True
        if not re.fullmatch(r, value) and strict:
            raise ValueError(f"value <{readable(value)}> not match the regex {repr(r)}")
        return value

    @classmethod
    def gt(cls, value, gt, strict):
        strict = strict or True
        if callable(gt):
            gt = gt()
        if value <= gt and strict:
            raise ValueError(f"value <{readable(value)}> not greater than {repr(gt)}")
        return value

    @classmethod
    def ge(cls, value, ge, strict):
        if callable(ge):
            ge = ge()
        if value < ge:
            if strict:
                raise ValueError(f"value <{readable(value)}> not greater or equal than {repr(ge)}")
            return ge
        return value

    @classmethod
    def lt(cls, value, lt, strict):
        if callable(lt):
            lt = lt()
        strict = strict or True
        if value >= lt and strict:
            raise ValueError(f"value <{readable(value)}> not less than {repr(lt)}")
        return value

    @classmethod
    def le(cls, value, le, strict):
        if callable(le):
            le = le()
        if value > le:
            if strict:
                raise ValueError(f"value <{readable(value)}> not less or equal than {repr(le)}")
            return le
        return value

    @classmethod
    def length(cls, value, lg, strict):
        v = value
        converted = False
        if not hasattr(value, Attr.LEN):
            converted = True
            v = str(value)
        if len(v) != lg:
            if strict or converted or len(v) < lg:
                raise ValueError(f"value <{readable(value)}> with length {len(v)} not match the length {repr(lg)}")
            return value[:lg]
        return value

    @classmethod
    def max_length(cls, value, m, strict):
        v = value
        converted = False
        if not hasattr(value, Attr.LEN):
            converted = True
            v = str(value)
        if len(v) > m:
            if strict or converted:
                raise ValueError(f"value <{readable(value)}> with length {len(v)} "
                                 f"is larger than max_length {repr(m)}")
            return value[:m]
        return value

    @classmethod
    def min_length(cls, value, m, strict):
        strict = strict or True
        v = value
        if not hasattr(value, Attr.LEN):
            v = str(value)
        if len(v) < m and strict:
            raise ValueError(f"value <{readable(value)}> with length {len(v)} is less than min_length {repr(m)}")
        return value

    @classmethod
    def validator(cls, value, e: Callable, strict):
        strict = strict or True
        try:
            if not e(value):
                raise ValueError(f"value <{readable(value)}> validate failed")
        except Exception as e:
            if strict:
                raise Error(e).throw(prepend='value validate failed with error: ')
        return value

    @classmethod
    def converter(cls, value, c: Callable, strict):
        try:
            if inspect.isclass(c):
                if isinstance(value, c):
                    return value
            return c(value)
        except Exception as e:
            if strict:
                raise Error(e).throw(prepend=f'value convert failed with error: ')
            return value


BOUND_ORDERS = Bound.gen()
SCHEMA_KEYS = [Bound.template, Bound.dict_type, Bound.type_union]


class BaseParam(LogicUtil):
    def apply(self, value, options=None):
        raise NotImplementedError

    def __invert__(self):
        raise TypeError(f'Param utils does not support invert operation')

    def __init__(self, document: str = None, message: str = None, attname: str = None,
                 alias_from: Union[str, List[str]] = None, alias_for: str = None, alias: str = None,
                 strict: bool = True, null: bool = False,
                 require: bool = True, default=..., **kwargs):

        __rule__ = {}
        if default is not Ellipsis:
            if default is None:
                __rule__[Bound.null] = True
            elif callable(default):
                # callable default value like dict, datetime.now, ...
                pass
            # elif _type(default) not in COMMON_TYPES:
            #     raise TypeError(f"Rule default must in {COMMON_TYPES}, got {repr(default)}")
            __rule__[Bound.default] = default
            require = False

        kwargs.update(locals())
        pop(kwargs, 'kwargs')
        super().__init__(kwargs)

        if not require:
            __rule__[Bound.require] = False
        if not strict:
            __rule__[Bound.strict] = False
        if null:
            __rule__[Bound.null] = True

        if document is not None:
            assert isinstance(document, str), f'Rule document must be str, got {document}'
            __rule__[Bound.document] = document

        if message is not None:
            assert isinstance(message, str), f'Rule message must be str, got {message}'
            __rule__[Bound.message] = message

        if alias is not None:
            if alias_for or alias_from:
                raise ValueError('Rule alias=<name> is identical to '
                                 'alias_for=alias_from=<name>, other params is redundant')
            # alias_for = alias_from = alias
            __rule__[Bound.alias] = alias

        if alias_for is not None:
            assert isinstance(alias_for, str), f'Rule alias_for must be a non-empty str, got {repr(alias_for)}'
            __rule__[Bound.alias_for] = alias_for

        if alias_from is not None:
            if isinstance(alias_from, str):
                alias_from = [alias_from]
            elif multi(alias_from) and alias_from:
                alias_from = distinct([str(a) for a in alias_from])
            else:
                raise TypeError(f'Rule alias must be a non-empty str or List of str, got {repr(alias_from)}')
            alias_from.sort()
            __rule__[Bound.alias_from] = alias_from

        if alias_from == [alias_for]:
            pop(__rule__, Bound.alias_for, pop(__rule__, Bound.alias_from))
            __rule__[Bound.alias] = alias_for

        if attname is not None:
            assert isinstance(attname, str)
            __rule__[Bound.attname] = attname

        self.__rule__ = __rule__

    @property
    def null(self):
        return self.get(Bound.null, False)

    @property
    def vacuum(self):
        return self._vacuum

    def assign_attname(self, name: str):
        self.__rule__[Bound.attname] = name
        return self

    @property
    def attname(self):
        return self.get(Bound.attname)

    @property
    def dict(self):
        result = {'@': self.__class__.__name__}
        for key, val in self.items():
            result[key] = val
        return result

    @property
    def alias(self):
        return self.get(Bound.alias)

    @property
    def aliases(self):
        names = [self.alias_for] if self.alias_for else []
        names += self.alias_from or []
        return distinct(names)

    @property
    def alias_from(self) -> Optional[List[str]]:
        alias = self.get(Bound.alias)
        if alias:
            return [alias]
        return self.get(Bound.alias_from)

    @property
    def alias_for(self):
        return self.get(Bound.alias_for, self.get(Bound.alias))

    @property
    def require(self):
        return self.get(Bound.require, True)

    @property
    def document(self):
        return self.get(Bound.document)

    @property
    def message(self):
        return self.get(Bound.message)

    @property
    def strict(self):
        return self.get(Bound.strict, True)

    @property
    def no_default(self):
        return Bound.default not in self

    @property
    def default(self):
        return self.get(Bound.default, ...)

    def __getitem__(self, item):
        return self.__rule__.__getitem__(item)

    def items(self):
        return self.__rule__.items()

    def order_by(self, *rule_orders):
        rule = self.__copy__()
        rule.__rule__ = order_dict(self.__rule__, rule_orders)
        return rule

    @property
    def rules(self) -> dict:
        try:
            return copy.deepcopy(dict(self.__rule__))
        except (TypeError, AttributeError):
            return dict(self.__rule__)

    @classmethod
    def make_alias(cls, rule, alias):
        if isinstance(rule, cls):
            rules = rule.rules
            rules[Bound.alias] = alias
            return cls(**rules)
        return cls(alias=alias)

    @classmethod
    def optional(cls, val, no_default: bool = False):
        if isinstance(val, cls):
            kwargs = val.rules
            if no_default:
                pop(kwargs, Bound.default)
            kwargs[Bound.require] = False
            return cls(**kwargs)
        return cls(require=False)

    @classmethod
    def make_default(cls, val, default):
        v = val
        if isinstance(val, cls):
            if val.default is ...:
                kwargs = val.rules
                kwargs[Bound.default] = default
                v = cls(**kwargs)
        else:
            v = cls(default=default)
        return v

    @property
    def field_name(self):
        return self.alias_for or self.attname

    def get(self, *args):
        return self.__rule__.get(*args)

    def copy(self, attrs=None):
        kwargs = {}
        if attrs is None:
            return self.__copy__()
        for attr in attrs:
            if attr in self:
                val = self[attr]
                if attr == Bound.dict_type:
                    kwargs[Bound.type] = {val[0]: val[1]}
                elif attr == Bound.type_union:
                    kwargs[Bound.type] = val
                else:
                    kwargs[attr] = val
        return self.__class__(**kwargs)

    def __contains__(self, item):
        return item in self.__rule__

    def __bool__(self):
        return bool(self.__rule__)

    def get_default(self):
        if callable(self.default):
            return self.default()
        return copy_value(self.default)


class Rule(BaseParam):
    # rule utility for common type parameters like int, str, float, bool, etc
    Bound = Bound

    def __init__(self, *,
                 gt=None, ge=None, lt=None, le=None,
                 value=..., regex: str = None, round: int = None,
                 length: int = None, max_length: int = None, min_length: int = None,
                 choices: Union[list, set, tuple, Type[Enum]] = None, multiple: bool = False,
                 validator: Callable[[Any], bool] = None,
                 converter: Callable[[Any], Any] = None,
                 type: Union[_type, tuple, Dict[_type, _type]] = None,
                 dict_type: Tuple[_type, _type] = None,
                 type_union: Union[List[_type], tuple] = None,
                 template: Union[list, tuple, Dict[str, Any]] = None,
                 options: 'Options' = None, field: str = None,
                 document: str = None, message: str = None, attname: str = None,
                 alias_from: Union[str, List[str]] = None, alias_for: str = None, alias: str = None,
                 convert_first: bool = False,
                 strict: bool = True, null: bool = False,
                 require: bool = True, default=...):

        BaseParam.__init__(**locals())

        __rule__ = self.__rule__
        from utilmeta.conf import config
        from ..core.schema import SchemaMeta
        from .media import Media

        parser_cls = config.preference.base_parser_cls
        if type is not None:
            if Media.file_param(type):
                type = Media.file_rule(type)

            if isinstance(type, dict):
                assert len(type) == 1, 'Dict type should be a one-item dict {<key-type>: <value-type>}'
                dict_type = list(type.items())[0]
                __rule__[Bound.type] = dict
            elif isinstance(type, tuple):
                type_union = type
            elif isinstance(type, Rule):
                __rule__.update(type.rules)
                # __rule__.update(type.rules)
                type = None
            elif isinstance(type, SchemaMeta) or _type(type) != _type:
                template = type
                type = None
            else:
                assert type in COMMON_TYPES or inspect.isclass(type), \
                    TypeError(f"Rule type must be a valid type, got {type}")
                __rule__[Bound.type] = type

        if dict_type is not None:
            key_type, val_type = dict_type
            if not isinstance(key_type, Rule):
                if not hasattr(key_type, Attr.HASH):
                    raise TypeError(f'Non hash dict key type: {key_type}')
            val_type = parser_cls.valid_template(val_type)
            __rule__[Bound.dict_type] = (key_type, val_type)

        if type_union is not None:
            union = []
            for t in type_union:
                if not isinstance(t, _type):
                    try:
                        union.append(parser_cls.valid_template(t))
                    except TypeError:
                        pass
                    continue
                if t == _type(None):
                    __rule__[Bound.default] = None
                    __rule__[Bound.null] = True
                    __rule__[Bound.require] = False
                    continue
                union.append(t)
            __rule__[Bound.type_union] = tuple(union)

        if length is not None:
            __rule__[Bound.length] = length
            assert isinstance(length, int) and length >= 0, f'Rule length: {length} must be a int >= 0'
        if min_length is not None:
            assert isinstance(min_length, int) and min_length >= 0, f'Rule min_length: {min_length} must be a int >= 0'
            __rule__[Bound.min_length] = min_length
        if max_length is not None:
            assert isinstance(max_length, int) and max_length > 0, f'Rule max_length: {max_length} must be a int > 0'
            __rule__[Bound.max_length] = max_length
            if min_length is not None:
                assert max_length >= min_length, f'Rule max_length: {max_length} must >= min_length: {min_length}'

        if regex is not None:
            assert isinstance(regex, str), TypeError(f"Rule reg must a str regex, got {repr(regex)}")
            assert ' ' not in regex, ValueError(f"Rule reg must not contains space, got {repr(regex)}")

            if '{%s,%s}' in regex:
                if None in {min_length, max_length}:
                    raise ValueError('Rule regex use {%s,%s} as length replacement'
                                     ', you muse declare min_length and max_length in Rule')
                regex = regex % (min_length, max_length)
                __rule__.pop(Bound.max_length)
                __rule__.pop(Bound.min_length)
            elif '%s' in regex:
                raise ValueError('Rule forbid to use %s as replacement unless use {%s,%s} to replace length')

            __rule__[Bound.regex] = regex

        if template is not None:
            if type:
                if type in multiples and _type(template) in multiples:
                    pass
                elif type != _type(template):
                    raise ValueError(f"Rule type {type} conflict to data template type {_type(template)}")
                pop(__rule__, Bound.type)
            template = parser_cls.valid_template(template)
            if isinstance(template, SchemaMeta):
                __rule__[Bound.template] = template
            elif isinstance(template, _type):
                assert template in COMMON_TYPES, TypeError(f"Rule type must in {COMMON_TYPES}, got {_type(template)}")
                __rule__[Bound.type] = template
            elif isinstance(template, Rule):
                __rule__.update(template.rules)
                template = None
            else:
                __rule__[Bound.template] = template

        __rule__.update(self.valid_bounds(gt=gt, ge=ge, lt=lt, le=le))

        if round is not None:
            assert isinstance(round, int), f"Rule round must be an int, got {round}"
            __rule__[Bound.round] = round
            if Bound.type not in __rule__:
                __rule__[Bound.type] = float

        if validator is not None:
            if isinstance(validator, classmethod):
                raise TypeError(f'Rule validator takes a function or a staticmethod, got classmethod')
                # staticmethod / classmethod object is not callable
            if isinstance(validator, staticmethod):
                validator = getattr(converter, Attr.FUNC)
            # param = list(inspect.signature(validator).parameters.keys())
            # assert len(param) == 1, \
            #     ValueError(f"Rule exp must be a callable with one param, got {repr(param)}")
            assert callable(validator), f"Rule exp must be a callable with one param, got {repr(validator)}"
            __rule__[Bound.validator] = validator

        if converter is not None:
            if isinstance(validator, classmethod):
                raise TypeError(f'Rule converter takes a function or a staticmethod, got classmethod')
            if isinstance(converter, staticmethod):
                func = getattr(converter, Attr.FUNC)
            elif inspect.isclass(converter):
                __rule__[Bound.type] = converter
                func = None
            else:
                func = converter

            if func:
                assert callable(func), f"Rule converter must be a callable, got {repr(converter)}"
                # params = dict(inspect.signature(func).parameters)
                # assert len(params) == 1, \
                #     TypeError(f"Rule converter function should have exactly one param to receive a value, \n"
                #               f" got {list(params.keys())}")
                #
                # p: inspect.Parameter = list(params.values())[-1]
                # if p.annotation != p.empty:
                #     from ..core.schema import SchemaMeta
                #     t = Parser.parse_type(p.annotation)
                #     if t in COMMON_TYPES:
                #         __rule__[Bound.type] = t
                #     else:
                #         __rule__[Bound.template] = t
                __rule__[Bound.converter] = converter if inspect.isclass(converter) else func

        if choices is not None:
            for key in list(__rule__.keys()):
                if key in [Bound.ge, Bound.le, Bound.gt, Bound.lt, Bound.round, Bound.regex,
                           Bound.length, Bound.min_length, Bound.max_length]:
                    __rule__.pop(key)
                # choices rule is exclusive (except for value), other weak restriction should be removed
            if inspect.isclass(choices) and issubclass(choices, Enum):
                choices = [v.value for v in choices.__members__.values()]

            assert multi(choices) and choices, \
                f'Rule choices must be a not empty multiple list/tuple/set, got {choices}'

            if multiple:
                # multiple choices
                if template:
                    assert multi(template), \
                        ValueError(f'Rule multiple choices make that the type '
                                   f'of data must be list/set/tuple, got {_type(template)}')
                elif type:
                    assert type in multiples, \
                        ValueError(f'Rule multiple choices make that '
                                   f'the type of data must be list/set/tuple, got {type}')
                else:
                    __rule__[Bound.template] = [_type(choices[0])]
                value_set = list(set(choices))
                value_set.sort()
                __rule__[Bound.choices] = value_set     # mark this choices as a multiple choice with list type
            else:
                tp = __rule__.get(Bound.type) or _type(__rule__.get(Bound.template))
                if tp in multiples:
                    raise TypeError(f'Rule multi type for choices: {tp} should apply multiple=True')
                elif tp is not _type(None):
                    for ch in choices:
                        assert isinstance(ch, tp), \
                            f'Rule choices item: {repr(ch)} type: {type(ch)} must consist to the Rule type: {tp}'
                value_list = list(set(choices))
                value_list.sort()
                __rule__[Bound.choices] = tuple(value_list)    # mark this choices as a single choice with tuple type
            __rule__[Bound.multiple] = multiple

        if value is not Ellipsis:
            if not callable(value):
                for key, val in __rule__.items():
                    if key in [Bound.require, Bound.default, Bound.strict, Bound.null,
                               Bound.type, Bound.alias, Bound.alias_for, Bound.alias_from,
                               Bound.document, Bound.message, Bound.attname]:
                        continue
                    raise TypeError(f"Rule value is exclusive, rule: <{key}> is redundant")

                if Bound.type in __rule__:
                    assert _type(value) == __rule__[Bound.type], "Rule val must as same type as Rule's type"
                else:
                    __rule__[Bound.type] = _type(value)
            __rule__[Bound.value] = value

        if field:
            __rule__[Bound.field] = str(field)

        self.convert_first = convert_first
        if convert_first:
            orders = tuple([Bound.converter, *BOUND_ORDERS])
        else:
            orders = BOUND_ORDERS

        self.__rule__ = order_dict(__rule__, orders)

        self.__spec_kwargs__ = dict(__rule__)
        self.options = options

    @classmethod
    def valid_bounds(cls, gt, ge, lt, le):
        __rule__ = {}
        if {gt, ge, lt, le} == {None}:
            return {}
        _max = _min = None
        _max_t = _min_t = None

        if gt is not None:
            # assert hasattr(gt, Attr.LT), f'Rule gt: {gt} does not support {Attr.LT} (not comparable)'
            if not callable(gt):
                _min_t = _type(gt)
                _min = gt

            __rule__[Bound.gt] = gt

        if ge is not None:
            # assert hasattr(ge, Attr.LE), f'Rule ge: {ge} does not support {Attr.LE} (not comparable)'
            assert _min is None, "Rule gt/ge cannot assign together"

            if not callable(ge):
                _min_t = _type(ge)
                _min = ge

            __rule__[Bound.ge] = ge

        if lt is not None:
            # assert hasattr(lt, Attr.GT), f'Rule lt: {lt} does not support {Attr.GT} (not comparable)'
            if not callable(lt):
                _max_t = _type(lt)
                _max = lt

            __rule__[Bound.lt] = lt

        if le is not None:
            # assert hasattr(le, Attr.GE), f'Rule le: {le} does not support {Attr.GE} (not comparable)'
            assert _max is None, "Rule lt/le cannot assign together"

            if not callable(le):
                _max_t = _type(le)
                _max = le

            __rule__[Bound.le] = le

        if _min_t and _max_t:
            assert _min_t == _max_t, f"Rule gt/ge type {_min_t} must equal to lt/le type {_max_t}"

        _t = _max_t or _min_t
        if _t:
            if Bound.type in __rule__:
                if __rule__[Bound.type] != _t:
                    if __rule__[Bound.type] == float and _t == int:
                        pass
                    else:
                        raise TypeError(f"Rule range type {_t} must equal to value type {__rule__[Bound.type]}")
            else:
                __rule__[Bound.type] = _t

        if _min is not None and _max is not None:
            assert _min < _max, f"Rule lt/le ({repr(_max)}) must > gt/ge ({repr(_min)})"
        return __rule__

    @classmethod
    def make_alias(cls, rule, alias):
        if isinstance(rule, cls):
            if rule.alias == alias:
                return rule
            rules = rule.rules
            rules[Bound.alias] = alias
            return cls(**rules)
        elif rule in COMMON_TYPES:
            return cls(type=rule, alias=alias)
        elif cls.valid_temp(rule):
            return cls(template=rule, alias=alias)
        return cls(alias=alias)

    @classmethod
    def make_field(cls, rule, field):
        if isinstance(rule, cls):
            if rule.field == field:
                return rule
            rules = rule.rules
            rules[Bound.field] = field
            return cls(**rules)
        elif rule in COMMON_TYPES:
            return cls(type=rule, field=field)
        elif cls.valid_temp(rule):
            return cls(template=rule, field=field)
        return cls(field=field)

    @classmethod
    def make_alias_for(cls, rule, alias):
        if isinstance(rule, cls):
            if rule.alias_for == alias:
                return rule
            rules = rule.rules
            rules[Bound.alias_from] = alias
            return cls(**rules)
        elif rule in COMMON_TYPES:
            return cls(type=rule, alias_for=alias)
        elif cls.valid_temp(rule):
            return cls(template=rule, alias_for=alias)
        return cls(alias_for=alias)

    @classmethod
    def add_alias_from(cls, rule, *aliases: str):
        if not aliases:
            return rule
        if isinstance(rule, cls):
            rules = rule.rules
            _from = rules.get(Bound.alias_from) or []
            _from.extend(aliases)
            rules[Bound.alias_from] = distinct(_from)
            return cls(**rules)
        elif rule in COMMON_TYPES:
            return cls(type=rule, alias_from=list(aliases))
        elif cls.valid_temp(rule):
            return cls(template=rule, alias_from=list(aliases))
        return cls(alias_from=list(aliases))

    @classmethod
    def add_converter(cls, rule, func: Callable, override: bool = False, first: bool = False):
        if isinstance(rule, cls):
            rules = rule.rules
            if override:
                rules[Bound.converter] = func
            else:
                rules.setdefault(Bound.converter, func)
            return cls(**rules, convert_first=first)
        elif rule in COMMON_TYPES:
            return cls(type=rule, converter=func, convert_first=first)
        elif cls.valid_temp(rule):
            return cls(template=rule, converter=func, convert_first=first)
        return cls(converter=func, convert_first=first)

    @classmethod
    def rid(cls, rule):
        if isinstance(rule, cls):
            attrs = [Bound.require, Bound.default, Bound.null, Bound.alias, Bound.attname,
                     Bound.round, Bound.converter,  # may need to convert result
                     Bound.document, Bound.type, Bound.type_union, Bound.template, Bound.message]
            return rule.copy(attrs)
        if rule in COMMON_TYPES or cls.valid_temp(rule):
            return rule
        return cls()

    @property
    def common_repr(self):
        attrs = []
        for k, v in self.items():
            if k in [Bound.converter, Bound.validator, Bound.type, Bound.dict_type,
                     Bound.type_union, Bound.template, Bound.default]:
                continue

            attrs.append(k + '=' + represent(v))
        s = ', '.join(attrs)
        return f'{self.__class__.__name__}({s})'

    @property
    def instance(self):
        """
        A generated instance that can pass the rule, often used in auto test cases generation
        """
        try:
            if self.value is not ...:
                return self.value
            if Bound.choices in self:
                import random
                choices = self[Bound.choices]
                if self.multiple:
                    return random.choices(choices, k=random.randrange(0, len(choices)))
                return random.choice(choices)
            if Bound.type in self:
                return self[Bound.type]()
            # ... need to add more logic
        except COMMON_ERRORS:
            return None

    def pop(self, key):
        if key not in self:
            return
        rules = self.rules
        rules.pop(key)
        self.__rule__ = rules

    @classmethod
    def set_doc(cls, rule, doc):
        rules = {}
        if isinstance(rule, cls):
            rules = rule.rules
            if rule.document:
                doc = ', '.join([rule.document, doc])
        else:
            rules[Bound.template] = rule
        rules[Bound.document] = doc
        return cls(**rules)

    @classmethod
    def valid_temp(cls, temp):
        from ..core.schema import SchemaMeta
        return isinstance(temp, (dict, list, tuple, SchemaMeta))

    @property
    def template(self):
        return self.get(Bound.template, None)

    @property
    def type_union(self):
        return self.get(Bound.type_union, None)

    @property
    def dict_type(self):
        return self.get(Bound.dict_type, None)

    @property
    def multiple(self):
        return self.get(Bound.multiple, False)

    @property
    def field(self):
        return self.get(Bound.field, None)

    def simplify(self):
        rules = self.rules
        pop(rules, Bound.attname)
        if len(rules) != 1:
            return self
        if Bound.type in self:
            return self[Bound.type]
        if Bound.template in self:
            return self[Bound.template]
        return self

    @property
    def has_type(self) -> bool:
        """
        expose generic type of Rule instance
        """
        return bool(set(self.__rule__).intersection({
            Bound.type, Bound.template, Bound.type_union,
            Bound.regex, Bound.default, Bound.choices
        }))

    @property
    def type(self) -> type:
        """
        expose generic type of Rule instance
        """
        if Bound.type in self:
            return self[Bound.type]
        elif Bound.template in self:
            return type(self[Bound.template])
        elif Bound.type_union in self:
            t = self[Bound.type_union][0]
            return t if t in COMMON_TYPES else type(t)
        elif Bound.regex in self:
            return str
        elif Bound.default in self:
            default = self[Bound.default]
            if default is not None:
                return type(default)
        elif Bound.choices in self:
            if isinstance(self[Bound.choices], list):
                return set
            else:
                return type(self[Bound.choices][0])
        return str

    @classmethod
    def insert(cls, origin, rule):
        """
        Concerned the type_union of the origin cannot be complete override by a single schema
        """
        if cls.multi(origin):
            rule = [rule]
        if not isinstance(origin, cls):
            return rule
        union = origin.__rule__.get(Bound.type_union)
        if not union:
            return rule
        from utilmeta.core.schema import SchemaMeta
        new_union = []
        for u in union:
            s = SchemaMeta.__retrieve__(u, schema=True)
            if s:
                if rule not in new_union:
                    new_union.append(rule)
            else:
                new_union.append(u)
        return Rule(type_union=new_union)

    @property
    def value(self):
        return self.get(Bound.value, ...)

    @property
    def common_type(self) -> str:
        t = repr(self.type.__name__)
        if Bound.dict_type in self:
            key_type, val_type = self[Bound.dict_type]
            if key_type in COMMON_TYPES and val_type in COMMON_TYPES:
                t = f'Dict[{repr(key_type.__name__)}, {repr(val_type.__name__)}]'
        if self.null:
            t = 'Optional[%s]' % t
        return t

    @property
    def dict(self):
        result = dict(type=type_note(self.type))
        if Bound.dict_type in self:
            result.update(dict_type=[self.note(val) for val in self[Bound.dict_type]])
        if Bound.type_union in self:
            result.update(type_union=[self.note(val) for val in self[Bound.type_union]])
        if Bound.default in self:
            # do not represent function / class default
            if isinstance(self.default, COMMON_TYPES):
                result.update(default=self.default)
        exclude_attrs = [Bound.message, Bound.validator, Bound.converter, Bound.default,
                         Bound.strict, Bound.type, Bound.dict_type, Bound.type_union]
        for key, val in self.items():
            if key in exclude_attrs:
                continue
            if key in [Bound.template, Bound.type_union]:
                val = self.note(val)
            if multi(val):
                # normalize tuple/set type
                val = list(val)
            result[key] = val
        result['@'] = self.__class__.__name__
        return result

    @classmethod
    def valid_key(cls, val):
        key_types = (int, str, float)
        if isinstance(val, cls):
            if val.template:
                raise TypeError(f'Key rule should not specify template, got {val.template}')
            if val.type not in key_types:
                raise TypeError(f'Key rule type should in {key_types}, got {val.type}')
        elif isinstance(val, type):
            if not issubclass(val, key_types):
                raise TypeError(f'Key rule type should in {key_types}, got {val}')

    @classmethod
    def note(cls, temp, simplify: bool = False):
        from ..core.schema import SchemaMeta
        from .media import File
        if temp is None:
            return None
        if isinstance(temp, bool):
            return temp
        if isinstance(temp, SchemaMeta):
            temp = getattr(temp, Attr.TEMPLATE, {})
        if isinstance(temp, File):
            return temp.dict
        if simplify and isinstance(temp, cls):
            if temp.value is not ...:
                return temp.value
            temp = temp.copy([Bound.type, Bound.template, Bound.type_union,
                              Bound.dict_type, Bound.choices,
                              Bound.alias, Bound.alias_from, Bound.alias_for,
                              Bound.field, Bound.message, Bound.require, Bound.null,
                              Bound.multiple, Bound.document]).simplify()
        if multi(temp):
            if isinstance(temp, list) and len(temp) == 1:
                return [cls.note(temp[0], simplify=simplify)]
            if simplify:
                return type(temp)([cls.note(item, simplify=simplify) for item in temp])
            data = dict(
                type=type_note(type(temp)),
                template=[cls.note(t, simplify=simplify) for t in temp]
            )
            data['@'] = cls.__name__
            return data
        elif isinstance(temp, dict):
            _temp = {}
            for k, v in temp.items():
                k = v.alias if isinstance(v, cls) and v.alias else k
                _temp[k] = cls.note(v, simplify=simplify)
            temp = _temp
        elif isinstance(temp, cls):
            temp = temp.dict
        elif type(temp) != type:
            if hasattr(temp, Attr.NAME):
                temp = temp.__name__
        if type(temp) == type:
            temp = type_note(temp)
        if type(temp) not in JSON_TYPES:
            temp = str(temp)
        return temp

    @classmethod
    def required(cls, val) -> 'Rule':
        if isinstance(val, cls):
            if val.require:
                return val
            kwargs = val.rules
            kwargs[Bound.require] = True
            return cls(**kwargs).simplify()
        return val

    @classmethod
    def optional(cls, val, no_default: bool = False) -> 'Rule':
        if isinstance(val, cls):
            kwargs = val.rules
            if no_default:
                pop(kwargs, Bound.default)
            kwargs[Bound.require] = False
            return cls(**kwargs)
        elif val in COMMON_TYPES:
            return cls(type=val, require=False)
        elif cls.valid_temp(val):
            return cls(template=val, require=False)
        return cls(require=False)

    @classmethod
    def gen_from(cls, t) -> 'Rule':
        if isinstance(t, cls):
            return t
        if t in COMMON_TYPES:
            return cls(type=t)
        if cls.valid_temp(t):
            return cls(template=t)
        return cls()

    @classmethod
    def make_default(cls, val, default) -> 'Rule':
        if callable(default):
            try:
                default()
            except COMMON_ERRORS:
                # default is not valid
                # if default is schema object, that schema has required field
                return val
        v = val
        if isinstance(val, cls):
            if val.default is ...:
                kwargs = val.rules
                kwargs[Bound.default] = default
                v = cls(**kwargs)
        elif val in COMMON_TYPES:
            v = cls(type=val, default=default)
        elif cls.valid_temp(val):
            v = cls(template=val, default=default)
        else:
            v = cls(default=default)
        return v

    def __and__(self, other) -> 'Rule':
        if not other:
            return self
        return Rule.gen_from(self.__class__.merge(self, other))

    @property
    def has_schema(self):
        if self.template:
            return True
        if self.dict_type:
            kt, vt = self.dict_type
            return Rule(type=vt).has_schema
        if self.type_union:
            for t in self.type_union:
                if Rule(type=t).has_schema:
                    return True
        return False

    @classmethod
    def multi(cls, t):
        if multi(t):
            return True
        if isinstance(t, cls):
            if t.type in multiples:
                return True
            if multi(t.template):
                return True
            union = t.get(Bound.type_union)
            if not union:
                return False
            for u in union:
                if cls.multi(u):
                    return True
        return False

    @classmethod
    def merge(cls, base, rule):
        if not rule:
            return base
        if not base:
            return rule
        from ..core.schema import SchemaMeta
        kwargs = {}
        merge_err = "Rule <%s> to be merge should be more strict than base Rule"
        if isinstance(rule, cls):
            kwargs[Bound.require] = rule.require
            if base in COMMON_TYPES:
                kwargs[Bound.type] = base
            elif cls.valid_temp(base):
                kwargs[Bound.template] = base
            elif isinstance(base, cls):
                rules = dict(base.rules)
                if Bound.max_length in base and Bound.max_length in rule:
                    assert rule[Bound.max_length] <= base[Bound.max_length], merge_err % Bound.max_length
                if Bound.min_length in base and Bound.min_length in rule:
                    assert rule[Bound.min_length] >= base[Bound.min_length], merge_err % Bound.min_length
                if Bound.le in base and Bound.le in rule:
                    assert rule[Bound.le] <= base[Bound.le], merge_err % Bound.le
                if Bound.lt in base and Bound.lt in rule:
                    assert rule[Bound.lt] <= base[Bound.lt], merge_err % Bound.lt
                if Bound.ge in base and Bound.ge in rule:
                    assert rule[Bound.ge] >= base[Bound.ge], merge_err % Bound.ge
                if Bound.gt in base and Bound.gt in rule:
                    assert rule[Bound.gt] >= base[Bound.gt], merge_err % Bound.gt
                if Bound.choices in base and Bound.choices in rule:
                    assert set(rule[Bound.choices]).issubset(base[Bound.choices]), merge_err % Bound.choices
                if Bound.regex in base:
                    if rule.type != str:
                        rules.pop(Bound.regex)
                if Bound.document in base and Bound.document in rule:
                    rules[Bound.document] = ', '.join([base.document, rule.document])
                if Bound.message in base and Bound.message in rule:
                    rules[Bound.message] = ', '.join([base.message, rule.message])

                kwargs.update(rules)
            kwargs.update(rule.rules)
        elif isinstance(base, cls):
            kwargs = base.rules
            if rule in COMMON_TYPES:
                kwargs[Bound.type] = rule
            elif cls.valid_temp(rule):
                kwargs[Bound.template] = rule
        if isinstance(base, dict) and isinstance(rule, dict):
            data = dict(base)
            for k, v in rule.items():
                if k in data:
                    data[k] = cls.merge(data[k], v)
                else:
                    data[k] = v
            return data
        if isinstance(base, list) and isinstance(rule, list):
            return [cls.merge(base[0], rule[0])]
        if isinstance(base, tuple) and isinstance(rule, tuple):
            return tuple([cls.merge(b, r) for b, r in zip(base, rule)])
        if isinstance(base, type):
            if base == rule or isinstance(rule, base):
                return rule
        if isinstance(rule, type):
            if base == rule or isinstance(base, rule):
                return base
        if Bound.type_union in kwargs:
            if Bound.type in kwargs:
                assert kwargs[Bound.type] in kwargs[Bound.type_union], merge_err % Bound.type_union
                kwargs.pop(Bound.type_union)
            elif Bound.template in kwargs:
                assert kwargs[Bound.template] in kwargs[Bound.type_union] \
                       or type(kwargs[Bound.template]) in kwargs[Bound.type_union] \
                       or isinstance(kwargs[Bound.template], SchemaMeta) and dict in kwargs[Bound.type_union], \
                       merge_err % Bound.type_union
                kwargs.pop(Bound.type_union)
        return cls(**kwargs) if kwargs else rule

    def apply(self, value, options=None):
        if not self:
            return value
        if self.null and value is None:
            return None

        if options:
            if self.options:
                options = self.options._merge(options)
        elif self.options:
            options = self.options

        def valid(v):
            for key, val in self.items():
                validator: Callable = getattr(Valid, key, None)
                if not validator:
                    continue
                kwargs = {}
                if key in SCHEMA_KEYS:
                    kwargs.update(options=options)
                v = validator(v, val, self.strict, **kwargs)
            return v

        if self.message:
            try:
                return valid(value)
            except Exception as e:
                raise e.__class__(self.message)
        else:
            return valid(value)
