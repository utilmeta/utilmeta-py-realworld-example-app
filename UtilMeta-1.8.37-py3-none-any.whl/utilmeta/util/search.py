from .base import Util
from .common import get_field, multi, distinct_add
from ..fields import (
    CharField, TextField, RichTextField, URLField, SlugField, ChoiceField, JSONField, ArrayField
)
from typing import Union, List
from django.db.models.base import ModelBase
from django.db.utils import OperationalError
from django.db.models.query import Q
from utilmeta.util.query import MetaQuerySet

SEARCH_ABLES = (
    CharField, TextField, RichTextField, URLField, SlugField, ChoiceField, JSONField, ArrayField
)

WEIGHT = 'ABCD'


class Search(Util):
    def __init__(self, module, fields, order_weight=True, relativity=0.2, base_query: Q = Q()):
        super().__init__(locals())
        from utilmeta.core.module import Module
        assert issubclass(module, Module), \
            TypeError(f'Search module must be a subset of Module, got {module}')
        self.module = module
        self.postgres = self.postgres_check(self.module.model)

        if type(fields) == str:
            fields = (fields, )

        vector = None
        if self.postgres:
            from django.contrib.postgres import search
            w = 0
            for i, field in enumerate(fields):
                field = self.check_field(field)
                v = search.SearchVector(field, weight=WEIGHT[w])
                if not i:
                    vector = v
                else:
                    vector += v
                if order_weight:
                    w += 1 if w < len(WEIGHT) - 1 else 0

        assert 0 < relativity < 1, f'Invalid relativity: {relativity}, must in 0 ~ 1'
        self.fields = fields
        self.r = relativity
        self.vector = vector
        base_query = base_query or Q()
        assert isinstance(base_query, Q), f'Invalid base_query: {base_query}, must be a Q object'
        self.base_query = base_query

    @staticmethod
    def postgres_check(model: ModelBase) -> bool:
        try:
            from django.contrib.postgres import search
            model.objects.annotate(search=search.SearchVector())
            return True
        except (OperationalError, ImportError, ModuleNotFoundError):
            return False

    def check_field(self, field: str) -> str:
        lookups = self.parse_lookup(field)
        model: ModelBase = self.module.model
        _i = 0
        _f = None
        for f in lookups:
            if _i:
                try:
                    model = _f.related_model
                except AttributeError:
                    raise AttributeError(f"Search fields lookup <field>.<relate> or <field>__"
                                         f"<relate> require relate field, got {_f}")
            _f = get_field(model, f)
            _i += 1
        assert isinstance(_f, SEARCH_ABLES), \
            ValueError(f'Search require fields in searchable fields {SEARCH_ABLES}, got {_f}')
        return '__'.join(lookups)

    @staticmethod
    def parse_lookup(f: str) -> list:
        if '__' in f:
            return f.split('__')
        elif '.' in f:
            return f.split('.')
        return [f]

    def get_queryset(self, val: str) -> MetaQuerySet:
        base = MetaQuerySet(model=self.module.model).filter(self.base_query)
        if self.postgres:
            from django.contrib.postgres import search
            query = search.SearchQuery(val)
            rank = search.SearchRank(self.vector, query)
            return base.annotate(rank=rank).filter(rank__gte=self.r).order_by('-rank')
        rel = {
            1: '__exact',
            0.9: '__iexact',
            0.7: '__iendwith',
            0.6: '__istartwith',
            0.4: '__contains',
            0.2: '__icontains',
        }
        q = Q()
        for field in self.fields:
            for v, lookup in rel.items():
                if self.r < v:
                    _q = {field + lookup: val}
                    _Q = Q(**_q)
                    q |= _Q
        return base.filter(q)

    def __call__(self, val: Union[str, List[str]]) -> List[dict]:
        if multi(val):
            pks = []
            for v in val:
                distinct_add(pks, self.get_queryset(v).pk_list)
            queryset = MetaQuerySet(model=self.module.model).filter(pk__in=pks)
        else:
            queryset = self.get_queryset(val)
        return self.module(queryset=queryset).serialize()
