from django.contrib.sessions.backends.base import SessionBase, CreateError


class SessionStore(SessionBase):
    cache_key_prefix = 'utilmeta.util.session.cluster_cache'

    def __init__(self, session_key=None):
        from utilmeta.util.cache.cluster import get_cluster_cache
        from utilmeta.conf import config
        self._cache = get_cluster_cache()
        self._key = session_key
        self._remote = config.session and config.session.from_service
        self._service = config.name
        super().__init__(session_key)

    @property
    def cache_key(self):
        return self.cache_key_prefix + self._get_or_create_session_key()

    @property
    def service_cache_key(self):
        return self.cache_key_prefix + f':{self._service}:' + self._get_or_create_session_key()

    # key with _ as prefix set to common cache key which os public to all services
    # key without _ as prefix is service-bind and with independent namespace

    def load(self, backup: bool = False):
        try:
            data = self._cache.get_many(self.cache_key, self.service_cache_key)
            if data:
                common_data = data.get(self.cache_key, {})
                session_data = data.get(self.service_cache_key, {})
                session_data.update(common_data)
            else:
                session_data = None
        except Exception:
            # Some backends (e.g. memcache) raise an exception on invalid
            # cache keys. If this happens, reset the session. See #17810.
            session_data = None
        if backup:
            return session_data
        if session_data is not None:
            return session_data
        self._session_key = None
        return {}

    def create(self):
        # Because a cache can fail silently (e.g. memcache), we don't know if
        # we are failing to create a new session because of a key collision or
        # because the cache is missing. So we try for a (large) number of times
        # and then raise an exception. That's the risk you shoulder if using
        # cache backing.
        for i in range(10000):
            self._session_key = self._get_new_session_key()
            try:
                self.save(must_create=True)
            except CreateError:
                continue
            self.modified = True
            return
        raise RuntimeError(
            "Unable to create a new session key. "
            "It is likely that the cache is unavailable.")

    def save(self, must_create=False):
        if self.session_key is None:
            return self.create()

        data = self._get_session(no_load=must_create)
        timeout = self.get_expiry_age()
        common_data = {key: val for key, val in data.items() if key.startswith('_')}
        service_data = {key: val for key, val in data.items() if not key.startswith('_')}
        if must_create:
            res = self._cache.add(self.cache_key, common_data) and \
                  self._cache.add(self.service_cache_key, service_data)
            if not res:
                raise CreateError
        else:
            self._cache.set_many({
                self.cache_key: common_data,
                self.service_cache_key: service_data
            }, timeout=timeout)

    def delete(self, session_key=None):
        if session_key is None and self.session_key is None:
            return
        self._cache.delete_many(self.cache_key, self.service_cache_key)

    def exists(self, session_key):
        return bool(session_key) and (self.cache_key_prefix + session_key) in self._cache

    @classmethod
    def clear_expired(cls):
        pass
