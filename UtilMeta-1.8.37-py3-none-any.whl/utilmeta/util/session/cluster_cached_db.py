from .db import SessionStore as MetaDBStore
from .cluster_cache import SessionStore as ClusterCachedStore


class SessionStore(MetaDBStore, ClusterCachedStore):
    cache_key_prefix = "utilmeta.util.session.cluster_cached_db"

    def __init__(self, session_key=None):
        super().__init__(session_key)

    def load(self):
        data = ClusterCachedStore.load(self, backup=True)

        if data is None:
            s = self._get_session_from_db()
            if s:
                data = self.decode(s.encoded_data)
                common_data = {key: val for key, val in data.items() if key.startswith('_')}
                service_data = {key: val for key, val in data.items() if not key.startswith('_')}
                self._cache.set_many({
                    self.cache_key: common_data,
                    self.service_cache_key: service_data
                }, timeout=s.expiry_age)
            else:
                data = {}
        return data

    def save(self, must_create=False):
        if MetaDBStore.save(self, must_create=must_create):
            return
        ClusterCachedStore.save(self, must_create=must_create)

    def delete(self, session_key=None):
        MetaDBStore.delete(self, session_key=session_key)
        ClusterCachedStore.delete(self, session_key=session_key)
