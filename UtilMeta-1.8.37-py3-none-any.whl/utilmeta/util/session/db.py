from django.contrib.sessions.backends.db import SessionStore as DBStore
from utilmeta.util.common import Key, get_based_number,\
    time_now, ignore_errors
from hashlib import md5
from django.contrib.sessions.backends.base import (
    CreateError, UpdateError,
)
from django.core.exceptions import SuspiciousOperation
from django.db import DatabaseError, IntegrityError, router, transaction
from django.utils import timezone


class SessionStore(DBStore):
    RESERVED_KEYS = [Key.IP_KEY, Key.UA_KEY]

    def __init__(self, session_key=None):
        super().__init__(session_key)

    @classmethod
    def get_model_class(cls):
        # Avoids a circular import and allows importing SessionStore when
        # django.contrib.sessions is not in INSTALLED_APPS.
        from utilmeta.ops.models.admin import Session
        return Session

    @property
    def session_id(self):
        if not self.session_key:
            return None
        return get_based_number(md5(self.session_key.encode()).hexdigest()[:12], 16, 62)

    def is_empty(self):
        try:
            return not self._session_key and not set(self._session_cache).difference(self.RESERVED_KEYS)
        except (AttributeError, TypeError):
            return True

    def setdefault(self, key, value):
        if key in self._session:
            return self._session[key]
        else:
            if key not in self.RESERVED_KEYS:
                self.modified = True
            self._session[key] = value
            return value

    def _get_session_from_db(self):
        try:
            return self.model.objects.get(
                session_key=self.session_key,
                expiry_time__gt=timezone.now(),
                delete_time=None
            )
        except (self.model.DoesNotExist, SuspiciousOperation):
            self._session_key = None

    def load(self):
        s = self._get_session_from_db()
        return self.decode(s.encoded_data) if s else {}

    @ignore_errors
    def create_model_instance(self, data: dict):
        """
        Return a new instance of the session model object, which represents the
        current session state. Intended to be used for saving the session data
        to the database.
        """
        ip = ua = agent = user_id = None
        if isinstance(data, dict):
            ip = data.get(Key.IP_KEY)
            ua = data.get(Key.UA_KEY)
            user_id = data.get(Key.USER_ID)

        session_key = self._get_or_create_session_key()
        return self.model(
            id=self.session_id,
            session_key=session_key,
            encoded_data=self.encode(data),
            expiry_time=self.get_expiry_date(),
            expiry_age=self.get_expiry_age(),
            last_activity=time_now(),

            ip=ip,
            ua_string=ua,
            user_agent=agent,
            user_id=user_id
        )

    def save(self, must_create=False):
        """
        Save the current session data to the database. If 'must_create' is
        True, raise a database error if the saving operation doesn't create a
        new entry (as opposed to possibly updating an existing entry).
        """
        if self.session_key is None:
            return self.create()
        data = self._get_session(no_load=must_create)
        obj = self.create_model_instance(data)
        using = router.db_for_write(self.model, instance=obj)
        try:
            with transaction.atomic(using=using):
                obj.save(
                    force_insert=must_create,
                    force_update=not must_create,
                    using=using,
                    update_fields=['encoded_data', 'expiry_time', 'expiry_age', 'last_activity',
                                   'ip', 'ua_string', 'user_agent', 'user_id']
                    if not must_create else None
                )
        except IntegrityError:
            if must_create:
                raise CreateError
            raise
        except DatabaseError:
            if not must_create:
                raise UpdateError
            raise

    def delete(self, session_key=None):
        if session_key is None:
            if self.session_key is None:
                return
            session_key = self.session_key
        self.model.objects.filter(session_key=session_key, delete_time=None).update(delete_time=time_now())

    @classmethod
    def clear_expired(cls):
        cls.get_model_class().objects.filter(expiry_time__lt=timezone.now()).delete()
