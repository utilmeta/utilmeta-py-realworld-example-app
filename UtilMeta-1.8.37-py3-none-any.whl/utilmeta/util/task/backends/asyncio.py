import asyncio
from .base import BaseWorker, BasePool


class AsyncWorker(BaseWorker):
    pass
