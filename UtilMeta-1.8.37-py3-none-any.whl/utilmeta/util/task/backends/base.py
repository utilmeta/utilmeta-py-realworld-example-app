from datetime import timedelta
from typing import Union, Callable, List, Dict, Iterator, Optional, Type
from utilmeta.util.common import time_now, ignore_errors, get_interval, normalize, make_hash, exc
from utilmeta.util.log import Logger
from utilmeta.util.error import Error


__all__ = ['BaseJob', 'BasePool']


class BaseJob:
    # worker context
    ON_COMPLETE = None

    def __init__(self, target: Callable, args: tuple = None, kwargs: dict = None, max_retries: int = 1,
                 logger: Logger = None, retry_interval: Union[float, int, timedelta] = None):
        if not callable(target):
            raise TypeError(f'Invalid job target: {target}, must be a callable')
        if not args:
            args = ()
        if not kwargs:
            kwargs = {}
        if not isinstance(args, (tuple, list)):
            raise TypeError(f'Invalid job args: {args}, must be tuple or list')
        if not isinstance(kwargs, dict):
            raise TypeError(f'Invalid job kwargs: {kwargs}, must be dict')

        self._target = target
        self._args = args
        self._kwargs = kwargs
        self._worker = None

        self.result = None
        self.exception = None
        self.timeout = None
        self.instance = None
        self.key = None

        self.init_time = time_now()
        self.exec_time = None
        self.done_time = None

        if not isinstance(logger, Logger) or not logger.root:
            # reject invalid logger
            logger = None
        self.log = logger
        self.max_retries = max_retries
        self.retry_interval = retry_interval

        self._retry_id = 0

    def __str__(self):
        args = [repr(arg) for arg in self._args]
        kwargs = [f'{key}={repr(val)}' for key, val in self._kwargs.items()]
        params = ','.join(args + kwargs)
        return f'{self.__class__.__name__}({self._target.__name__}, {params})'

    def __repr__(self):
        return str(self)

    def as_class(self, job_cls: Type['BaseJob']):
        if not issubclass(job_cls, BaseJob):
            return self
        return job_cls(target=self._target, args=self._args, kwargs=self._kwargs,
                       max_retries=self.max_retries, logger=self.log, retry_interval=self.retry_interval)

    @property
    def volatile(self):
        if not self.success:
            return False
        if not self.log:
            return True
        return self.log.vacuum

    @property
    def success(self):
        if not self.is_done:
            return None
        return not self.timeout and not self.exception

    @property
    def message(self) -> str:
        if self.exception:
            return self.error.full_info
        return ''

    @property
    def retry_id(self):
        return self._retry_id

    @property
    def args(self):
        return self._args

    @property
    def kwargs(self):
        return self._kwargs

    @property
    def normalized_args(self):
        return [normalize(arg, _json=True) for arg in self.args]

    @property
    def normalized_kwargs(self):
        return {key: normalize(val, _json=True) for key, val in self.kwargs.items()}

    @property
    def encoded_id(self):
        encoded_args = [str(arg) for arg in self.normalized_args]
        encoded_kwargs = [f'{key}={val}' for key, val in self.normalized_kwargs.items()]
        return ','.join(encoded_args + encoded_kwargs)

    @property
    def hash(self):
        return make_hash(self.encoded_id)

    @property
    def failed(self) -> bool:
        return bool(self.exception)

    @property
    def is_done(self) -> bool:
        return bool(self.done_time)

    @property
    def is_pending(self):
        return self.exec_time and not self.done_time

    @property
    def duration(self) -> Optional[timedelta]:
        if self.done_time:
            return self.done_time - self.exec_time
        return None

    def set_key(self, key: str):
        if not self.key:
            self.key = key

    def set_instance(self, instance=None):
        if not self.instance:
            self.instance = instance

    def exec(self):
        if not self.exec_time:
            self.exec_time = time_now()
        if not self._worker:
            self._worker = self.current()

    def complete(self, result=None, exception: Exception = None):
        if self.is_done:
            return
        self.result = result
        self.exception = exception
        self.done_time = time_now()
        self.timeout = False

    def expire(self):
        if self.is_done:
            return
        self.timeout = True
        self.done_time = time_now()

    @property
    def error(self):
        if not self.exception:
            return None
        return Error(self.exception)

    def throw(self):
        if not self.exception:
            return
        raise self.error.throw()

    @property
    def value(self):
        if self.timeout:
            return Error(TimeoutError())
        return self.result if self.success else self.error

    @classmethod
    def sleep(cls, seconds: Union[int, float]):
        import time
        time.sleep(seconds)

    def do(self, *complete_callbacks: Callable):
        try:
            result = None
            errors = []
            self.exec()
            for i in range(0, self.max_retries):
                self._retry_id = i
                try:
                    if i and self.retry_interval:
                        self.sleep(self.retry_interval)
                    result = self._target(*self._args, **self._kwargs)
                except Exception as e:
                    errors.append(e)
                else:
                    break

            if errors:
                self.complete(exception=errors[0] if len(errors) == 1 else exc.CombinedError(*errors))
                self.log_error()
            else:
                self.complete(result=result)

            for callback in complete_callbacks:
                if callable(callback):
                    callback(self)

            return result
        finally:
            self.complete()
            if self.log:
                self.log.exit(do_exit=True)

    def log_error(self):
        if not self.log or not self.exception:
            return
        self.error.log(self.log, console=True)

    @property
    def worker_id(self):
        return None

    @property
    def worker(self):
        return self._worker

    @classmethod
    def current(cls):
        raise NotImplementedError

    def execute(self, delay: Union[int, float, timedelta] = None, block: bool = False, daemon: bool = False,
                timeout: Union[int, float, timedelta] = None, done_callback: Callable = None):
        raise NotImplementedError


class BasePool:
    # executor context

    MULTI_THREAD = False
    MULTI_PROCESS = False
    DEFAULT_JOB_CLS = BaseJob

    def __init__(self,
                 max_workers: int = None,
                 job_cls: Type[BaseJob] = None,
                 timeout: Union[int, float, timedelta] = None,
                 perpetual: bool = False,
                 silent_timeout: bool = False,
                 on_complete: Callable = None,
                 ):
        self.max_workers = max_workers
        self.timeout = get_interval(timeout, null=True)
        self.silent_timeout = silent_timeout

        self.perpetual = perpetual
        job_cls = job_cls or self.DEFAULT_JOB_CLS
        if not issubclass(job_cls, BaseJob):
            raise TypeError(f'Invalid job class: {job_cls}, must be subclass of BaseJob')
        self.job_cls = job_cls

        self.on_completes = []
        if self.job_cls.ON_COMPLETE:
            self.on_completes.append(self.job_cls.ON_COMPLETE)

        if on_complete:
            self.on_completes.append(ignore_errors(on_complete))

        self._pool = None
        self._jobs: List[BaseJob] = []

    def reset(self):
        self._jobs = []

    def __enter__(self):
        if self.perpetual:
            raise TypeError(f'Perpetual task cannot enter')
        self.reset()
        # only record pending task in this context
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.perpetual:
            raise TypeError(f'Perpetual task cannot exit')
        self.shutdown(wait=True)
        # shutdown before reset, because shutdown requires to check jobs status
        self.reset()
        return False

    def __iter__(self):
        return iter(self._jobs)

    def __setitem__(self, key, value):
        for job in self._jobs:
            if job == value:
                job.set_key(key)

    def __getitem__(self, key, default=None):
        for job in self._jobs:
            if job.key == key:
                return job
        return default

    def __len__(self):
        return len(self._jobs)

    def complete_jobs(self):
        for job in self._jobs:
            if not job.is_done:
                job.expire()

    @property
    def pending_jobs(self) -> Iterator[BaseJob]:
        for job in self:
            if not job.is_done:
                yield job

    @property
    def completed_jobs(self) -> Iterator[BaseJob]:
        for job in self:
            if job.is_done:
                yield job

    @property
    def all_complete(self) -> bool:
        try:
            next(self.pending_jobs)
        except StopIteration:
            return True
        return False

    @property
    def instances(self) -> list:
        return [job.instance for job in self._jobs]

    def add_on_complete(self, func):
        if not callable(func):
            raise TypeError(f'on complete must be a callable, got {func}')
        self.on_completes.append(ignore_errors(func))

    def shutdown(self, wait: bool = True):
        raise NotImplementedError

    def submit(self, target, *args, **kwargs) -> BaseJob:
        job = self.job_cls(
            target=target,
            args=args,
            kwargs=kwargs
        )
        self.submit_job(job)
        return job

    def submit_job(self, job: BaseJob):
        raise NotImplementedError

    def wait(self, timeout: Union[timedelta, int, float] = None) -> bool:
        raise NotImplementedError

    def get_results(self, wrapped: bool = True, success_only: bool = False) -> Union[list, List[BaseJob]]:
        self.wait()
        result = []
        for job in self._jobs:
            if wrapped:
                result.append(job)
            else:
                if success_only and not job.success:
                    continue
                result.append(job.value)
        return result

    def get_result_map(self, wrapped: bool = True, success_only: bool = False) -> Union[dict, Dict[str, BaseJob]]:
        self.wait()
        result = {}
        for job in self._jobs:
            if not job.key:
                continue
            if wrapped:
                result[job.key] = result
            else:
                if success_only and not job.success:
                    continue
                result[job.key] = job.value
        return result
