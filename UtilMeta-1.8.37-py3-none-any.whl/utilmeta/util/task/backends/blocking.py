from datetime import timedelta
from typing import Union, Callable
from .base import BasePool, BaseJob
from utilmeta.util.common import get_interval, handle_timeout
import time


class BlockingJob(BaseJob):
    def execute(self, delay: Union[int, float, timedelta] = None, daemon: bool = False,
                block: bool = True, timeout: Union[int, float, timedelta] = None, done_callback: Callable = None):
        if not block:
            import warnings
            warnings.warn('Warning: blocking job does not support'
                          ' non-blocking execution, using thread')
            from .thread import ThreadJob
            return self.as_class(ThreadJob).execute(block=False, delay=delay, daemon=daemon,
                                                    timeout=timeout, done_callback=done_callback)
        if delay:
            time.sleep(get_interval(delay))
        self.do(done_callback)

    @classmethod
    def current(cls):
        return None


class BlockingPool(BasePool):
    DEFAULT_JOB_CLS = BlockingJob

    def _blocking_run_jobs(self):
        for job in self._jobs:
            job.execute()

    def wait(self, timeout: Union[timedelta, int, float] = None) -> bool:
        if self.all_complete:
            return True
        func = self._blocking_run_jobs
        if timeout:
            func = handle_timeout(timeout=timedelta(seconds=get_interval(timeout)))(func)
        try:
            func()
        except TimeoutError as e:
            if self.silent_timeout:
                return False
            raise e
        finally:
            self.complete_jobs()
        return True

    def shutdown(self, wait: bool = True):
        if wait:
            self.wait()

    def submit_job(self, job: BaseJob):
        self._jobs.append(job)
