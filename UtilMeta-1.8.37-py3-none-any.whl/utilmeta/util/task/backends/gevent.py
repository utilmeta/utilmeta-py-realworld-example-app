from __future__ import absolute_import
from datetime import timedelta
from typing import Union, Callable
from utilmeta.util.common import get_interval

try:
    import gevent
    from gevent.pool import Pool
except ImportError:  # pragma: nocover
    raise ImportError('GeventExecutor requires gevent installed')

from .base import BasePool, BaseJob


class GeventJob(BaseJob):
    @property
    def worker_id(self):
        if self._worker:
            return self._worker.minimal_ident
        return None

    def execute(self, delay: Union[int, float, timedelta] = None, block: bool = False, daemon: bool = False,
                timeout: Union[int, float, timedelta] = None, done_callback: Callable = None):
        if block:
            if delay:
                worker = gevent.spawn_later(
                    get_interval(delay, silent=True),
                    self.do, done_callback
                )
            else:
                worker = gevent.spawn(
                    self.do, done_callback
                )
            self._worker = worker
            worker.join(timeout=get_interval(timeout, null=True, silent=True))
        else:
            import warnings
            warnings.warn('Warning: native gevent does not support'
                          ' non-blocking execution in current event loop, using thread')
            from .thread import ThreadJob
            self.as_class(ThreadJob).execute(block=False, delay=delay, daemon=daemon,
                                             timeout=timeout, done_callback=done_callback)
        return

    @classmethod
    def current(cls):
        return gevent.getcurrent()


class GeventPool(BasePool):
    DEFAULT_JOB_CLS = GeventJob

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._pool = Pool(self.max_workers)

    def shutdown(self, wait: bool = True):
        if wait:
            self.wait()
        self._pool.kill(block=wait)

    def submit_job(self, job: BaseJob):
        greenlet = self._pool.spawn(job.do, *self.on_completes)
        job.set_instance(greenlet)
        self._jobs.append(job)

    def wait(self, timeout: Union[timedelta, int, float] = None) -> bool:
        if self.all_complete:
            return True
        try:
            return self._pool.join(timeout=self.timeout)
        finally:
            self.complete_jobs()
