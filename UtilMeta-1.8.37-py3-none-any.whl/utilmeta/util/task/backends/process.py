from datetime import timedelta
from typing import Union, Callable

from .base import BaseJob
from multiprocessing import Process
import os


class ProcessJob(BaseJob):
    pass

