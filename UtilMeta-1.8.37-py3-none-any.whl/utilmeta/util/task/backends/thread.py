from datetime import timedelta
from typing import Union, Callable

from .base import BasePool, BaseJob
import threading
from utilmeta.util.common import get_interval, Key, close_connections
from concurrent.futures import ThreadPoolExecutor, TimeoutError, ALL_COMPLETED


class ThreadJob(BaseJob):
    ON_COMPLETE = close_connections

    def __init__(self, *args, name: str = None, daemon: bool = None, **kwargs):
        super().__init__(*args, **kwargs)
        self._name = name
        self._daemon = daemon

    @property
    def worker_id(self):
        if self._worker:
            return self._worker.ident
        return None

    def execute(self, delay: Union[int, float, timedelta] = None, daemon: bool = False,
                block: bool = False, timeout: Union[int, float, timedelta] = None, done_callback: Callable = None):
        if delay:
            worker = threading.Timer(
                interval=get_interval(delay, silent=True),
                function=self.do,
                args=(done_callback, self.ON_COMPLETE),
            )
        else:
            worker = threading.Thread(
                target=self.do,
                args=(done_callback, self.ON_COMPLETE),
                name=self._name,
                daemon=self._daemon
            )
        if daemon:
            worker.setDaemon(True)
        self._worker = worker
        worker.start()
        if block:
            worker.join(timeout=get_interval(timeout, null=True, silent=True))

    @classmethod
    def current(cls):
        return threading.current_thread()


class ThreadPool(BasePool):
    MULTI_THREAD = True
    DEFAULT_JOB_CLS = ThreadJob

    def __init__(self, *args,
                 _thread_id_key: str = None,
                 **kwargs):
        super().__init__(*args, **kwargs)
        self._pool = ThreadPoolExecutor(self.max_workers)
        self._thread_id_key = _thread_id_key

    def wait(self, timeout: Union[timedelta, int, float] = None,
             first_complete: bool = False,
             first_exception: bool = False) -> bool:
        # return if complete, return False when timeout
        if self.all_complete:
            return True
        if timeout is None:
            timeout = self.timeout
        return_when = ALL_COMPLETED
        if first_complete:
            return_when = first_complete
        elif first_exception:
            return_when = first_exception
        from concurrent.futures import wait
        try:
            wait(self.instances, timeout=timeout, return_when=return_when)
        except TimeoutError as e:
            if self.silent_timeout:
                return False
            raise e
        finally:
            self.complete_jobs()
        return True

    def shutdown(self, wait: bool = True):
        self._pool.shutdown(wait=wait)

    def submit(self, target, *args, **kwargs):
        if self._thread_id_key and getattr(target, Key.EXECUTOR_THREAD_ID_REQUIRED, False):
            # submit function is on the same thread that start a ConcurrentTask
            kwargs[self._thread_id_key] = threading.current_thread().ident
        return super().submit(target, *args, **kwargs)

    def submit_job(self, job: BaseJob):
        future = self._pool.submit(job.do, *self.on_completes)
        job.set_instance(future)
        self._jobs.append(job)
