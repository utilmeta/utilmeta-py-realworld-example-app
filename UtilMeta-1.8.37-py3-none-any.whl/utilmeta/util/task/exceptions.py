

class TaskError(Exception):
    pass


class WaitForNextCycle(TaskError):
    pass


class ForceRetire(TaskError):
    pass


class InvalidStatus(TaskError):
    pass


class SuccessRollback(TaskError):
    pass
