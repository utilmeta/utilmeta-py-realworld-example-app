from typing import List
from utilmeta.patch import Patcher


def worker_generator(*args, patches: List[str] = (), **kwargs):
    # keep this function clean from any else former import to do the required patches properly
    if patches:
        Patcher(*patches)

    from utilmeta import conf
    conf.BACKGROUND = True
    from utilmeta.util.common import import_util
    from utilmeta.conf import config
    import threading
    if not config.task:
        return

    def load():
        # may used another db connection
        from utilmeta.service import UtilMeta
        service = UtilMeta.load_service(background=True)
        import_util(service.config.service.task)

    thread = threading.Thread(target=load)
    thread.start()
    thread.join()

    worker = config.task.manager_cls(*args, **kwargs)
    # config.task._manager = worker

    with worker.apply_redirect():
        thread = threading.Thread(target=worker.loop_worker_cycle)
        thread.start()
        thread.join()
