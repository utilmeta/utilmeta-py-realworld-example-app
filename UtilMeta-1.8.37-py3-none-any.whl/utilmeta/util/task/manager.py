from utilmeta.types import *
from utilmeta.util.common import ignore_errors, import_util, close_connections, \
    TaskStatus, remove_file, time_now, EventStatus, AlertLevel
from utilmeta.util.error import Error
import threading
import multiprocessing
import os
import time
if TYPE_CHECKING:
    from utilmeta.core.task import Task


class TaskManager:
    def __init__(self, tasks: List[Union['Task', str]], group_name: str = None, master: bool = False,
                 process: multiprocessing.Process = None):
        from utilmeta.conf import config
        from utilmeta.core.task import Task

        _tasks = []
        for inst in tasks:
            if isinstance(inst, str):
                inst = config.task.get(inst)
            assert isinstance(inst, Task), f'TaskPool only take Task objects, got: {inst}'
            _tasks.append(inst.__copy__())

        self._tasks = set(_tasks)
        self._terminates = []
        self._master = master

        self._worker_managers: List['TaskManager'] = []
        self._process = process

        self.group_name = group_name
        self.config = config.task

        self.init_time = time_now()
        self.retire_time = None
        self._worker_instance = None

        self._daemon_threads: List[threading.Thread] = []
        self._loop_tasks = set()
        self._events = set()
        self._completed = False

    @property
    def process_id(self):
        if self._process:
            return self._process.pid
        return os.getpid()

    @property
    def thread_id(self):
        return threading.current_thread().ident

    def __iter__(self) -> Iterator['Task']:
        # random order
        return iter(self._tasks)

    def __len__(self):
        return len(self._tasks)

    def __contains__(self, item: Union[str, 'Task']):
        if isinstance(item, str):
            for task in self._tasks:
                if task.name == item:
                    return True
            return False
        return item in self._tasks

    def __getitem__(self, item: str) -> Optional['Task']:
        for task in self._tasks:
            if task.name == item:
                return task
        return None

    # def start(self, block: bool = False):
    #     from utilmeta.util.common import task
    #     # self.update_storage()
    #     if block:
    #         # block until break
    #         self._loop_worker_cycle()
    #     else:
    #         task.omit(self._loop_worker_cycle)()

    @property
    def names(self) -> List[str]:
        names = []
        for task in self._tasks:
            names.append(task.name)
        return names

    def load_worker(self, update: bool = False, parent: bool = None):
        from utilmeta.ops.models.task import TaskWorker
        if parent is None:
            parent = not self.master
        worker = TaskWorker.load(self.process_id, parent=parent, group_name=self.group_name)
        if update and worker:
            worker.update()
        self._worker_instance = worker
        return worker

    @property
    def log_dir(self):
        from utilmeta.conf import config
        return os.path.join(config.deploy.service.log_root, 'tasks')

    @property
    def log_file(self) -> str:
        from utilmeta.conf import config
        if self.master:
            return os.path.join(self.log_dir, f'master.{config.name}.log')
        return os.path.join(self.log_dir, f'worker.{config.name}.{self.process_id}.log')

    @property
    def retire_log_file(self) -> str:
        from utilmeta.conf import config
        return os.path.join(self.log_dir, f'retire.{config.name}.log')

    def clear_log(self):
        if self.config.redirect_output_stream:
            return remove_file(self.log_file, ignore_not_found=True)

    def prepare_log(self):
        from utilmeta.conf import config
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)
        try:
            open(self.log_file, 'a').write('')
        except PermissionError:
            os.system(f'sudo chown -R {os.getuid()}:{os.getpid()} {self.log_dir}/')
        for ab_path, dirs, files in os.walk(self.log_dir):
            for file in files:
                if file.startswith(f'worker.{config.name}'):
                    os.remove(os.path.join(ab_path, file))
        if self.master:
            open(self.log_file, 'w').write('')
        open(self.retire_log_file, 'w').write('')       # override retire log

    def retire_log(self, msg: str):
        if not self.config.redirect_output_stream:
            print(msg)
            return
        with open(self.retire_log_file, 'a') as err_f:
            err_f.write(f'{str(datetime.now())} [{self.process_id}]: {msg}')
            err_f.write('\n')
        return

    def alert_error(self, message: str, data: dict = None,
                    level: str = AlertLevel.CRITICAL,
                    downgrade: bool = False, abandoned: bool = False):
        from utilmeta.util.alert import Alert
        wk = 'event' if abandoned else ('master' if self.master else 'worker')
        dg = 'abandoned' if abandoned else ('downgrade' if downgrade else 'error')
        ct = Alert.Category.task_unavailable if abandoned else\
            (Alert.Category.task_downgrade if downgrade else Alert.Category.task_error)
        Alert.log(
            subcategory=f'task_{wk}_{dg}',
            name=f'task {wk} {dg}',
            category=ct,
            message=message,
            level=level,
            data=data,
            ident=f'task_{wk}_{dg}',
            instance=True,
            task=True
        )
        with open(self.log_file, 'a') as err_f:
            err_f.write(message + '\n')
        return

    def fetch_events(self):
        from utilmeta.ops.models.task import TaskEvent, TaskDistribution

        next_cycle = time_now() + timedelta(seconds=self.config.worker_cycle_interval + self.config.min_interval)
        this_cycle = time_now()

        return TaskEvent.objects.filter(
            exec_time__lte=next_cycle,
            exec_time__gt=this_cycle,
            executions=None,
            task__distributions__in=TaskDistribution.currents()
        ).distinct().order_by('exec_time')

    def transfer_tasks(self):
        from utilmeta.ops.models.task import TaskDistribution
        complete = True
        for dist in TaskDistribution.currents():
            task = self.load_instance(dist.task)
            if not task.transfer():
                complete = False
        return complete

    def worker_cycle(self):
        start = time.time()
        try:
            self.load_worker(update=True)
            self.load_looped_tasks()
            self.transfer_exceeds()
            self.check_daemon_threads()

            if self.check_retire() and self.do_retire():
                if self.transfer_tasks():
                    self.retire_log('ALL TASK COMPLETE')
                    return False

                if self.config.worker_graceful_timeout:
                    if (time_now(self.retire_time) - self.retire_time).total_seconds()\
                            > self.config.worker_graceful_timeout:
                        self.retire_log('GRACEFULLY TIMEOUT')
                        return False

                # cycle continue and process the tasks

            events = set()
            for event in self.fetch_events():
                if event.id in self._events:
                    # already scheduled by last cycle
                    continue
                events.add(event.id)
                inst = self.load_instance(event.task)
                inst.delay_execute(
                    event_id=event.event_id, from_cycle=True,
                    interval=max((event.exec_time - time_now()).total_seconds(), 0)
                )
            self._events = events

            if self.empty:
                # no tasks in the queue, return
                if self.config.min_worker_lifetime:
                    # maybe newly spawned worker, waiting for new tasks to assign on
                    if (time_now(self.init_time) - self.init_time).total_seconds() < self.config.min_worker_lifetime:
                        time.sleep(self.config.worker_cycle_interval)
                        return True
                self.retire_log('RUN OUT OF TASKS')
                return False

        except Exception as e:
            self.alert_error(message=Error(e).full_info)

        seconds = self.config.worker_cycle_interval - (time.time() - start)
        if seconds <= 0:
            self.alert_error(
                message=f'WORKER: {self.process_id} TIMEOUT for {abs(round(seconds, 2))}s',
                downgrade=True,
                data=dict(
                    type='timeout',
                    pid=self.process_id,
                    seconds=seconds
                )
            )
        else:
            time.sleep(seconds)
        return True

    def transfer_exceeds(self):
        from utilmeta.ops.models.task import TaskWorker
        current = TaskWorker.current()
        if not current:
            return
        if not self.config.max_worker_tasks:
            return
        exceeds = max(0, current.tasks - self.config.max_worker_tasks)
        if not exceeds:
            return
        for inst in self._tasks:
            if exceeds <= 0:
                break
            if inst.transfer():
                exceeds -= 1

    def check_retire(self):
        if self.retire_time:
            return True

        if self.config.max_worker_lifetime:
            if (time_now(self.init_time) - self.init_time).total_seconds() + \
                    self.config.get_worker_lifetime_delta() > self.config.max_worker_lifetime:
                self.retire_log('TIME HIT')
                return True

        if self.config.max_worker_memory_percent:
            import psutil
            proc = psutil.Process(os.getpid())
            per = proc.memory_percent('uss')
            if per > self.config.max_worker_memory_percent:
                self.retire_log(f'MEM PERCENT HIT: {per}')
                return True

        if self.config.max_worker_memory_bytes:
            import psutil
            proc = psutil.Process(os.getpid())
            info = proc.memory_full_info()
            mem = getattr(info, 'uss', getattr(info, 'rss', 0))
            if mem > self.config.max_worker_memory_bytes:
                self.retire_log(f'MEM BYTES HIT: {mem}')
                return True

        if self.config.max_worker_executions:
            from utilmeta.ops.models.task import TaskDistribution
            from utilmeta.util.common import exp
            executions = TaskDistribution.objects.filter(
                worker__pid=os.getpid()).aggregate(v=exp.Sum('worker_executed_events'))['v'] or 0
            if executions > self.config.max_worker_executions:
                self.retire_log(f'EXEC HIT: {executions}')
                return True

        return False

    @ignore_errors
    def do_retire(self, force_retire: bool = False):
        if force_retire:
            self._completed = True
        if self.retire_time:
            return True
        if not force_retire:
            if self.config.min_worker_lifetime:
                if (time_now(self.init_time) - self.init_time).total_seconds() < self.config.min_worker_lifetime:
                    return False
        self.retire_time = time_now()
        from utilmeta.ops.models.task import TaskWorker
        worker = TaskWorker.current()
        worker.retire_time = self.retire_time
        worker.save(update_fields=['retire_time'])
        return True

    @ignore_errors
    def load_looped_tasks(self):
        from utilmeta.ops.models.task import TaskDistribution
        for dist in TaskDistribution.currents().filter(task__looped=True):
            inst = self.load_instance(dist.task)
            if inst.name not in self._loop_tasks:
                self.daemon_thread(self._loop_task_cycle, inst)

    @property
    def empty(self) -> bool:
        from utilmeta.ops.models.task import TaskDistribution
        return not TaskDistribution.currents().exists()

    @ignore_errors
    def contains(self, name: str) -> bool:
        from utilmeta.ops.models.task import TaskDistribution
        return TaskDistribution.currents().filter(task__name=name).exists()

    def load_instance(self, task):
        from utilmeta.ops.models.task import TaskSettings
        from utilmeta.core.task import Task
        if not isinstance(task, TaskSettings):
            raise TypeError(f'conf.Task.load_instance task a Task object, got {task}')
        if task.name in self.config.names:
            return self.config.get(task.name).__copy__()
        task_cls = import_util(task.base.ref)
        if not issubclass(task_cls, Task):
            raise TypeError(f'Invalid task class: {task_cls}')
        return task_cls.deserialize(task)

    @property
    def master(self):
        return self._master

    # MASTER COMMANDS --

    def assign(self):
        if not self.master:
            raise RuntimeError('Worker TaskManager cannot execute assign')
        max_tasks = self.config.max_worker_tasks
        min_tasks = self.config.min_worker_tasks
        groups: Dict[str, List[Task]] = {}
        for task in self:
            if task.group in groups:
                groups[task.group].append(task)
            else:
                groups[task.group] = [task]

        shortages: Dict[str, List[Task]] = {}
        short_tasks = 0

        for name in list(groups):
            values = groups[name]
            count = len(values)
            if max_tasks and count > max_tasks:
                group = []
                index = 0
                for i, task in enumerate(values):
                    group.append(task)
                    if not (i + 1) % max_tasks or i == count - 1:
                        index += 1
                        groups[f'{name}:{index}'] = group
                        group = []
                groups.pop(name)
                continue
            if min_tasks and count < min_tasks:
                if short_tasks + count >= min_tasks:
                    group = list(values)
                    for lst in shortages.values():
                        group.extend(lst)
                    group_name = ','.join([name, *shortages.keys()])
                    groups[group_name] = group
                    short_tasks = 0
                    shortages = {}
                else:
                    shortages[name] = values
                    short_tasks += len(values)
                groups.pop(name)
                continue

        if shortages:
            for name in list(groups):
                values = groups[name]
                cnt = short_tasks + len(values)
                if min_tasks <= cnt:
                    if max_tasks and cnt > max_tasks:
                        continue
                    group = list(values)
                    for lst in shortages.values():
                        group.extend(lst)
                    group_name = ','.join([name, *shortages.keys()])
                    groups[group_name] = group
                    shortages = {}
                    break
            if shortages:
                group = []
                for lst in shortages.values():
                    group.extend(lst)
                group_name = ','.join([*shortages.keys()])
                groups[group_name] = group
        # ASSIGN OVER
        # for name, tasks in groups.items():
        #     workers.append(TaskManager(group_name=name, tasks=tasks, worker_of=self))
        return groups

    def kill(self, name: str, force: bool = False):
        if not self.master:
            raise RuntimeError('Worker TaskManager cannot execute kill')
        print(locals())

    def shutdown(self, wait: bool = True, timeout: int = None):
        if not self.master:
            raise RuntimeError('Worker TaskManager cannot execute shutdown')
        # wait param will wait till all the workers finish current task (does not schedule new tasks)
        print(locals())

    def apply_redirect(self):
        from utilmeta.conf import config
        from contextlib import redirect_stdout, redirect_stderr
        log_file = self.log_file

        class _Redirect:
            def __init__(self):
                self.apply = config.task.redirect_output_stream
                if not self.apply:
                    return
                self.file = open(log_file, 'a')
                self.stdout = redirect_stdout(self.file)
                self.stderr = redirect_stderr(self.file)

            def __enter__(self):
                if not self.apply:
                    return
                self.file.__enter__()
                self.stdout.__enter__()
                self.stderr.__enter__()

            def __exit__(self, exc_type, exc_val, exc_tb):
                if not self.apply:
                    return
                self.file.__exit__(exc_type, exc_val, exc_tb)
                self.stdout.__exit__(exc_type, exc_val, exc_tb)
                self.stderr.__exit__(exc_type, exc_val, exc_tb)

        return _Redirect()

    def run(self):
        if self.config.worker_process_mode:
            multiprocessing.set_start_method(self.config.worker_process_mode)
        if not self.master:
            raise RuntimeError('Worker TaskManager cannot execute run')
        # self.config.do_patch()
        from utilmeta.conf import config
        # from .generator import worker_generator
        if not config.resolved:
            raise TypeError('config not set')
        self.prepare_log()
        groups = self.assign()
        self.load_worker(update=True)
        self.main_process_events()  # process events before worker spawn
        close_connections()
        from .generator import worker_generator
        for name, tasks in groups.items():
            # master_conn, worker_conn = Pipe()
            process = multiprocessing.Process(
                target=worker_generator,
                args=tuple([task.name for task in tasks]),
                kwargs=dict(
                    group_name=name,
                    patches=self.config.get_patches()
                    # worker_conn=worker_conn
                )
            )
            process.start()
            manager = TaskManager(
                tasks=tasks,
                group_name=name,
                # master_conn=master_conn,
                process=process
            )   # a remote copy (no memory share) of process worker manager
            self._worker_managers.append(manager)
            # threading.Thread(target=manager.wait_signal).start()
        self.loop_main_cycle()

    def update_execution_timeout(self):
        from utilmeta.ops.models.task import TaskExecution
        TaskExecution.objects.filter(
            done_time=None,
            timeout_time__lte=time_now() - timedelta(seconds=self.config.worker_cycle_interval),
            timeout=None
        ).update(
            done_time=time_now(),
            timeout=True,
            success=False
        )

    def daemon_thread(self, target, *args, **kwargs):
        thread = threading.Thread(target=target, args=args, kwargs=kwargs)
        thread.setDaemon(True)
        thread.start()
        self._daemon_threads.append(thread)

    def check_daemon_threads(self):
        for thread in self._daemon_threads:
            if not thread.is_alive():
                self._daemon_threads.remove(thread)
        return len(self._daemon_threads)

    def loop_worker_cycle(self):
        self.load_worker(update=True)

        for task in self._tasks:
            task.load_status()

            if task.looped:
                self.daemon_thread(self._loop_task_cycle, task)
                # thread.join(timeout=self.config.worker_graceful_timeout)

        self.daemon_thread(self._loop_recover_cycle)

        while True:
            if not self.worker_cycle():
                break

        self.do_retire(force_retire=True)

        while True:
            if not self.check_daemon_threads():
                # no daemon threads running
                break
            if (time_now(self.retire_time) - self.retire_time).total_seconds() > self.config.worker_graceful_timeout:
                break
            time.sleep(self.config.min_interval)

        self.clear_log()
        self.retire_log(f'EXIT for {(time_now(self.retire_time) - self.retire_time).total_seconds()} seconds')

    def _loop_task_cycle(self, task: 'Task'):
        if not task.looped:
            return
        while True:
            if not self.contains(task.name):
                # transfer
                try:
                    self._loop_tasks.remove(task.name)
                except KeyError:
                    pass
                break
            self._loop_tasks.add(task.name)
            task.execute(from_cycle=True)
            if not task.min_loop_interval:
                continue
            if task.exec_time:
                seconds = max(task.min_loop_interval -
                              (time_now(task.exec_time) - task.exec_time).total_seconds(), 0)
                time.sleep(seconds)
            else:
                time.sleep(task.min_loop_interval)
        return

    def _loop_recover_cycle(self):
        while True:
            if self._completed:
                break
            start = time_now()
            self.resolve_omitted_events()
            seconds = max(self.config.worker_cycle_interval - (time_now() - start).total_seconds(), 0)
            time.sleep(seconds)
        return

    def redistribute_task(self):
        from utilmeta.conf import config
        from utilmeta.util.query import MetaQuerySet
        from utilmeta.ops.models.task import TaskDistribution
        # tasks = TaskSettings.objects.filter(disabled=False, service=config.name)
        base_dist: MetaQuerySet = TaskDistribution.objects.filter(
            instance_id=self.config.instance_id,
            task__disabled=False,
            task__service=config.name,
            status__in=[TaskStatus.idle, TaskStatus.busy]
        )
        volatiles = base_dist.filter(worker=None).union(
            base_dist.filter(worker__connected=False)
        )
        if self.config.worker_graceful_timeout:
            volatiles = volatiles.union(base_dist.filter(
                worker__retire_time__lte=time_now() - timedelta(
                    seconds=self.config.worker_graceful_timeout + self.config.worker_cycle_interval
                )
            ))
        volatiles = list(set(volatiles))
        term = False
        index = 0
        from utilmeta.core.task import Task
        # use default task reassign strategy
        max_tasks = config.task.max_worker_tasks
        if max_tasks:
            for worker in Task().iter_reassign_workers():
                if worker.tasks >= max_tasks:
                    continue
                if term:
                    continue
                try:
                    for i in range(0, max_tasks - worker.tasks):
                        dist: TaskDistribution = volatiles[index]
                        dist.transfer_to(worker)
                        index += 1
                except IndexError:
                    term = True
                    continue

        group = []
        names = []
        if volatiles:
            for dist in volatiles[index:]:
                names.append(dist.task.name)
                if max_tasks and len(names) >= max_tasks:
                    group.append(names)
                    names = []
        if names:
            group.append(names)
        return group

    def main_load_instances(self):
        from utilmeta.ops.models.task import TaskInstance
        from utilmeta.conf import config
        TaskInstance.self_heartbeat()
        TaskInstance.objects.filter(
            service=config.name,
            connected=True,
            last_heartbeat__lte=time_now() - timedelta(
                seconds=self.config.instance_disconnect_interval
            )
        ).update(connected=False)

    def main_load_workers(self):
        self.load_worker(update=True)
        from utilmeta.ops.models.task import TaskWorker
        from utilmeta.ops.models.service import ServiceWorker
        from utilmeta.conf import config

        if config.cluster:
            config.cluster_manager.update_services()

        ServiceWorker.objects.filter(
            instance_id=config.deploy.instance_id,
            master__isnull=False,
            time__lte=time_now() - timedelta(
                seconds=config.monitor.worker_disconnect_interval
            )
        ).delete()

        TaskWorker.objects.filter(
            master__pid=self.process_id,
            connected=True,
            time__lte=time_now() - timedelta(
                seconds=config.monitor.worker_disconnect_interval
            )
        ).update(connected=False)

        self.update_execution_timeout()
        import psutil
        force_kills = TaskWorker.retire_workers().filter(
            master__pid=self.process_id,
            retire_time__lte=time_now() - timedelta(seconds=self.config.worker_graceful_timeout),
        )
        for worker in force_kills:
            try:
                proc = psutil.Process(worker.pid)
                proc.kill()
            except psutil.Error:
                continue
        force_kills.delete()
        return TaskWorker.retire_workers().filter(master__pid=self.process_id)

    def main_process_events(self):
        from utilmeta.util.common import exp, EventStatus
        from utilmeta.ops.models.task import TaskEvent, TaskSettings, TaskDistribution

        # create for all the task events
        events = []
        for dist in TaskDistribution.objects.filter(
            instance_id=self.config.instance_id,
            status__in=[TaskStatus.idle, TaskStatus.busy]
        ):
            inst = self.load_instance(dist.task)
            events.extend(inst.load_events())

        TaskEvent.objects.bulk_create(events, ignore_conflicts=True)

        # migrate all the event status
        cycle_now = time_now() - self.config.min_timedelta
        TaskEvent.objects.filter(
            exec_time__lte=cycle_now,
            executions=None
        ).exclude(status=EventStatus.abandoned).update(
            status=EventStatus.omitted,
            volatile=False
        )

        TaskEvent.objects.filter(
            task__event_abandon_window__isnull=False,
            exec_time__lte=cycle_now - exp.F('task__event_abandon_window'),
            executions=None
        ).update(
            status=EventStatus.abandoned,
            volatile=False
        )

        TaskEvent.objects.annotate(
            success_execution_num=exp.Count('executions', filter=exp.Q(executions__success=True))
        ).filter(
            task__dist_by_event=True,
            success_execution_num__gt=1
        ).update(
            status=EventStatus.redundant,
            volatile=False
        )

        TaskEvent.objects.annotate(
            failed_jobs=exp.Sum('executions__failed_jobs')
        ).filter(
            exp.Q(failed_jobs__gt=0) | exp.Q(executions__success=False) | exp.Q(executions__timeout=True)
        ).update(volatile=False)

        TaskEvent.objects.filter(
            exec_time__lte=cycle_now,
            status=EventStatus.pending,
        ).update(status=EventStatus.normal)

        TaskEvent.objects.filter(
            exec_time__lte=cycle_now,
            status__in=[EventStatus.omitted, EventStatus.abandoned],
        ).exclude(executions=None).update(status=EventStatus.recovered)

        expired_abandons = []
        for event in TaskEvent.objects.filter(
            task__event_abandon_expired=True,
            status=EventStatus.omitted,
            executions=None
        ):
            next_event = TaskEvent.objects.filter(
                task=event.task,
                event_id=event.event_id + 1,
            ).order_by('exec_time').first()

            if next_event and cycle_now >= next_event.exec_time:
                expired_abandons.append(event.pk)

        if expired_abandons:
            TaskEvent.objects.filter(pk__in=expired_abandons, status=EventStatus.omitted).update(
                status=EventStatus.abandoned
            )

        from utilmeta.conf import config
        if config.alert:
            for event_id, name in TaskEvent.objects.filter(
                exec_time__gte=cycle_now - timedelta(seconds=self.config.main_cycle_interval),
                status=EventStatus.abandoned
            ).values_list('event_id', 'task__name'):
                task = TaskSettings.get(name)
                if config.alert.abandon_event_interval_threshold and task.interval:
                    if task.interval.total_seconds() < config.alert.abandon_event_interval_threshold:
                        continue
                self.alert_error(
                    message=f'task [{task.name}] abandoned event [{event_id}]',
                    level=config.alert.abandon_event_alert_level,
                    data=dict(
                        task_id=task.id,
                        event_id=event_id
                    ),
                    abandoned=True
                )
        # self.resolve_omitted_events(block=False)

    def loop_main_cycle(self):
        start_time = time.time()
        while True:
            # main cycle should use a Thread no-matter the job
            time.sleep(max(self.config.main_cycle_interval - (time.time() - start_time), 0))
            thread = threading.Thread(target=self.main_cycle)
            thread.setDaemon(True)
            thread.start()
            start_time = time.time()
            thread.join()

    @classmethod
    def health_check(cls):
        from utilmeta.ops.tasks.health import InstanceHealthCheckTask
        InstanceHealthCheckTask(task=True).execute()

    @ignore_errors
    def resolve_omitted_events(self, block: bool = True):
        """
        Consider this is a looped task
        """
        if not block:
            return self.daemon_thread(target=self.resolve_omitted_events)

        from utilmeta.ops.models.task import TaskEvent  # , TaskDistribution

        with self.config.concurrent_executor(
            silent_timeout=True,
            on_complete=close_connections
        ) as executor:
            for event in TaskEvent.objects.filter(
                exec_time__lte=time_now() - timedelta(seconds=self.config.min_interval),
                executions=None,
                # task__distributions__in=TaskDistribution.currents()
            ).exclude(status=EventStatus.abandoned).order_by('exec_time'):
                inst = self.load_instance(event.task)
                print(f'[{time_now()}] RECOVER OMIT EVENT({event.event_id}) FOR: {inst}')
                executor.submit(inst.execute, event_id=event.event_id, from_cycle=False)

    def main_cycle(self):
        try:
            self.main_load_instances()
            self.main_process_events()
            # load instances before health check
            self.health_check()

            retire_workers = self.main_load_workers()
            new_groups = self.redistribute_task()

            alive_workers: List['TaskManager'] = []
            workings = 0
            new_retires = 0
            exits = 0
            for manager in self._worker_managers:
                if manager._process.exitcode is None:
                    alive_workers.append(manager)

                    if not manager.retire_time:
                        for worker in retire_workers:
                            if worker.pid == manager.process_id:
                                manager.retire_time = worker.retire_time
                                new_retires += 1
                                break
                    if not manager.retire_time:
                        workings += 1
                else:
                    exits += 1

            if workings >= self.config.max_workers:
                return

            spawn_num = 0
            if workings < self.config.min_workers:
                spawn_num = max(spawn_num + self.config.min_workers - workings, 0)
            if workings + spawn_num + len(new_groups) > self.config.max_workers:
                spawn_num = max(self.config.max_workers - workings - len(new_groups), 0)
            if self.config.max_worker_spawn_step:
                spawn_num = min(self.config.max_worker_spawn_step - len(new_groups), spawn_num)

            new_groups += [[]] * spawn_num

            if new_groups:
                print(f'New Worker(spawn_num={len(new_groups)}, exits={exits},'
                      f' workings={workings}, new_retires={new_retires})')

            close_connections()
            from .generator import worker_generator
            for tasks in new_groups:
                # need to spawn these workers
                process = multiprocessing.Process(
                    target=worker_generator,
                    args=tuple(tasks),
                    kwargs=dict(patches=self.config.get_patches())
                )
                process.start()
                manager = TaskManager(
                    tasks=tasks,
                    process=process
                )
                alive_workers.append(manager)

            self._worker_managers = alive_workers
        except Exception as e:
            self.alert_error(Error(e).full_info)
        finally:
            # close connection when there is error occur before trying to close connections in try block
            close_connections()
