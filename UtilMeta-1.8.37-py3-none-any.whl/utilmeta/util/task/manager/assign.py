from utilmeta.types import *
from utilmeta.util.common import ignore_errors, close_connections, \
    TaskStatus, time_now, exp
from utilmeta.util.error import Error
import multiprocessing
import time
from .base import BaseTaskManager

if TYPE_CHECKING:
    from utilmeta.core.task import Task


class AssignTaskManager(BaseTaskManager):
    def __init__(self, *tasks: str, group_name: str = None, master: bool = True,
                 process: multiprocessing.Process = None):
        super().__init__(process=process)
        self._master = master

        if master:
            self._task_names = self.config.names
        else:
            task_names = set()
            for task in tasks:
                if isinstance(task, str):
                    task_names.add(task)
                    continue
                from utilmeta.core.task import Task
                if isinstance(task, Task):
                    task_names.add(task.name)
            self._task_names = task_names

        self.group_name = group_name
        self._loop_tasks = set()

    def __iter__(self) -> Iterator['Task']:
        # random order
        for name in self._task_names:
            task = self.config.get(name)
            if not task:
                continue
            yield task

    def __len__(self):
        return len(self._task_names)

    def __contains__(self, item: Union[str, 'Task']):
        if isinstance(item, str):
            return item in self._task_names
        return item.name in self._task_names

    def __getitem__(self, item: str) -> Optional['Task']:
        if item in self:
            return self.config.get(item)
        return None

    @property
    def worker_kwargs(self):
        return dict(group_name=self.group_name)

    def fetch_events(self):
        from utilmeta.ops.models.task import TaskEvent, TaskDistribution

        next_cycle = time_now() + timedelta(seconds=self.config.worker_cycle_interval + self.config.min_interval)
        this_cycle = time_now()

        return TaskEvent.objects.filter(
            exec_time__lte=next_cycle,
            exec_time__gt=this_cycle,
            executions=None,
            task__distributions__in=TaskDistribution.currents().filter(worker_id=self.get_worker_id())
        ).distinct().order_by('exec_time')

    def transfer_task(self, task: 'Task'):
        dist = task.task_distribution
        if not dist:
            return True
        if dist.worker_id != self.worker_id:
            # already transfer
            return True
        to_worker = None
        for worker in self.iter_reassign_workers(task):
            if not self.config.max_worker_tasks:
                to_worker = worker
                break
            if worker.tasks + 1 <= self.config.max_worker_tasks:
                to_worker = worker
                break
        if not to_worker:
            to_worker = self.get_reassign_worker(task)
        if not to_worker:
            return False
        print(f'#### TRANSFER [{task.name}] from: {self.process_id} to {to_worker.pid}')
        dist.transfer_to(to_worker)
        return True

    def transfer_tasks(self):
        complete = True
        for task in self:
            if not self.transfer_task(task):
                complete = False
        return complete

    @classmethod
    def iter_reassign_workers(cls, task: 'Task'):
        from utilmeta.ops.models.task import TaskWorker
        workers = TaskWorker.reassign_targets()

        if task.reassign_strategy == task.MIN_LIFETIME:
            for worker in workers.order_by('-start_time'):
                yield worker
            return

        if task.reassign_strategy == task.MIN_MEMORY:
            for worker in workers.order_by('used_memory'):
                yield worker
            return

        if task.reassign_strategy == task.MIN_EXECUTIONS:
            from utilmeta.ops.models.task import TaskDistribution
            values = []
            for pid, executions in workers.annotate(executions=exp.Sum(
                    'task_distributions__worker_executed_events')).values_list('pid', 'executions'):
                values.append((pid, executions or 9))

            for val in sorted(values, key=lambda x: x[1]):
                yield TaskWorker.get(pid=val[0])
            return

        if task.reassign_strategy == task.MIN_TASKS:
            values = []
            for pid, tasks in workers.annotate(tasks=exp.Count(
                    'task_distributions')).values_list('pid', 'tasks'):
                values.append((pid, tasks or 9))

            for val in sorted(values, key=lambda x: x[1]):
                yield TaskWorker.get(pid=val[0])
            return

        return

    def get_reassign_worker(self, task: 'Task'):
        worker_iter = self.iter_reassign_workers(task)
        try:
            return next(worker_iter)
        except StopIteration:
            return None

    def worker_cycle(self):
        start = time.time()
        try:
            self.load_worker(update=True)
            self.load_looped_tasks()
            self.transfer_exceeds()
            self.check_daemon_threads()

            if self.check_retire() and self.do_retire():
                if self.transfer_tasks():
                    self.retire_log('ALL TASK COMPLETE')
                    return False

                if self.config.worker_graceful_timeout:
                    if (time_now(self.retire_time) - self.retire_time).total_seconds()\
                            > self.config.worker_graceful_timeout:
                        self.retire_log('GRACEFULLY TIMEOUT')
                        return False

                # cycle continue and process the tasks

            events = set()
            for event in self.fetch_events():
                if event.id in events:
                    # already scheduled by last cycle
                    continue
                events.add(event.id)
                inst = self.load_instance(event.task)
                thread = inst.delay_execute(
                    event_id=event.event_id, from_cycle=True,
                    interval=max((event.exec_time - time_now()).total_seconds(), 0)
                )
                if inst.daemon_thread:
                    self._daemon_threads.append(thread)

            if self.empty:
                # no tasks in the queue, return
                if self.config.min_worker_lifetime:
                    # maybe newly spawned worker, waiting for new tasks to assign on
                    if (time_now(self.init_time) - self.init_time).total_seconds() < self.config.min_worker_lifetime:
                        time.sleep(self.config.worker_cycle_interval)
                        return True
                self.retire_log('RUN OUT OF TASKS')
                return False

            self.alert_error(relieve=True)
        except Exception as e:
            self.alert_error(message=Error(e).full_info)

        seconds = self.config.worker_cycle_interval - (time.time() - start)
        if seconds <= 0:
            self.alert_error(
                message=f'WORKER: {self.process_id} TIMEOUT for {abs(round(seconds, 2))}s',
                downgrade=True,
                data=dict(
                    type='timeout',
                    pid=self.process_id,
                    seconds=seconds
                )
            )
        else:
            time.sleep(seconds)
        return True

    def transfer_exceeds(self):
        from utilmeta.ops.models.task import TaskWorker
        current = TaskWorker.current()
        if not current:
            return
        if not self.config.max_worker_tasks:
            return
        exceeds = max(0, current.tasks - self.config.max_worker_tasks)
        if not exceeds:
            return
        for inst in self:
            if exceeds <= 0:
                break
            if self.transfer_task(inst):
                exceeds -= 1

    @ignore_errors
    def load_looped_tasks(self):
        from utilmeta.ops.models.task import TaskDistribution
        qs = TaskDistribution.currents().filter(task__looped=True)
        if self._loop_tasks:
            qs = qs.exclude(task__name__in=list(self._loop_tasks))

        for dist in qs:
            dist: TaskDistribution
            inst = self.load_instance(dist.task)
            self.daemon_thread(self._loop_task_cycle, inst)

    @property
    def empty(self) -> bool:
        from utilmeta.ops.models.task import TaskDistribution
        return not TaskDistribution.currents().exists()

    @ignore_errors
    def contains(self, name: str) -> bool:
        from utilmeta.ops.models.task import TaskDistribution
        return TaskDistribution.currents().filter(task__name=name).exists()

    # MASTER COMMANDS --

    def assign(self):
        if not self.master:
            raise RuntimeError('Worker TaskManager cannot execute assign')
        max_tasks = self.config.max_worker_tasks
        min_tasks = self.config.min_worker_tasks
        groups: Dict[str, List[Task]] = {}
        for task in self:
            if task.group in groups:
                groups[task.group].append(task)
            else:
                groups[task.group] = [task]

        shortages: Dict[str, List[Task]] = {}
        short_tasks = 0

        for name in list(groups):
            values = groups[name]
            count = len(values)
            if max_tasks and count > max_tasks:
                group = []
                index = 0
                for i, task in enumerate(values):
                    group.append(task)
                    if not (i + 1) % max_tasks or i == count - 1:
                        index += 1
                        groups[f'{name}:{index}'] = group
                        group = []
                groups.pop(name)
                continue
            if min_tasks and count < min_tasks:
                if short_tasks + count >= min_tasks:
                    group = list(values)
                    for lst in shortages.values():
                        group.extend(lst)
                    group_name = ','.join([name, *shortages.keys()])
                    groups[group_name] = group
                    short_tasks = 0
                    shortages = {}
                else:
                    shortages[name] = values
                    short_tasks += len(values)
                groups.pop(name)
                continue

        if shortages:
            for name in list(groups):
                values = groups[name]
                cnt = short_tasks + len(values)
                if min_tasks <= cnt:
                    if max_tasks and cnt > max_tasks:
                        continue
                    group = list(values)
                    for lst in shortages.values():
                        group.extend(lst)
                    group_name = ','.join([name, *shortages.keys()])
                    groups[group_name] = group
                    shortages = {}
                    break

            if shortages:
                group = []
                for lst in shortages.values():
                    group.extend(lst)
                group_name = ','.join([*shortages.keys()])
                groups[group_name] = group

        while len(groups) < self.config.min_workers:
            large_tasks = []
            large_key = None
            for key, val in groups.items():
                if len(val) > len(large_tasks):
                    large_key = key
                    large_tasks = val

            if not large_key or len(large_tasks) <= 1:
                break

            groups.pop(large_key)
            groups[f'{large_key}:1'] = large_tasks[:len(large_tasks)//2]
            groups[f'{large_key}:2'] = large_tasks[len(large_tasks)//2:]

        return groups

    def run(self):
        if self.config.process_start_method:
            multiprocessing.set_start_method(self.config.process_start_method)
        if not self.master:
            raise RuntimeError('Worker TaskManager cannot execute run')
        # self.config.do_patch()
        from utilmeta.conf import config
        # from .generator import worker_generator
        if not config.resolved:
            raise TypeError('config not set')
        self.prepare_log()
        groups = self.assign()
        self.load_worker(update=True)
        self.load_events()  # process events before worker spawn

        close_connections()
        current_worker_loop = not self.config.master and not config.production

        from utilmeta.util.task.generator import worker_generator
        for i, (name, tasks) in enumerate(groups.items()):
            names = [task.name for task in tasks]

            if current_worker_loop and not i:
                self.group_name = name
                self._task_names = names
                continue
            # master_conn, worker_conn = Pipe()

            process = multiprocessing.Process(
                target=worker_generator,
                args=tuple(names),
                kwargs=dict(
                    group_name=name,
                    master=False,
                    patches=self.config.get_patches()
                    # worker_conn=worker_conn
                )
            )
            process.start()

        if current_worker_loop:
            return self.loop_worker_cycle()

        if self.config.master:
            self.is_representative = True
            self._loop_main_cycle()
        else:
            exit(0)  # exit

    def loop_worker_cycle(self):
        self.load_worker(update=False)

        if not self.config.master:
            self.daemon_thread(self._loop_main_cycle)

        for task in self:
            task.load_status()

            if task.looped:
                self.daemon_thread(self._loop_task_cycle, task)

        if not self.config.cache_executions:
            self.daemon_thread(self._loop_recover_cycle)

        while True:
            if not self.worker_cycle():
                break

        self.do_retire()
        while True:
            if not self.check_daemon_threads():
                # no daemon threads running
                break
            if (time_now(self.retire_time) - self.retire_time).total_seconds() > self.config.worker_graceful_timeout:
                break
            time.sleep(self.config.min_interval)

        self.clear_log()
        self.retire_log(f'EXIT for {(time_now(self.retire_time) - self.retire_time).total_seconds()} seconds')

    def _loop_task_cycle(self, task: 'Task'):
        if not task.looped:
            return
        while True:
            if self.retire_time:
                break
            if not self.contains(task.name):
                # transfer
                try:
                    self._loop_tasks.remove(task.name)
                except KeyError:
                    pass
                break
            self._loop_tasks.add(task.name)
            task.execute(from_cycle=True)
            if not task.min_loop_interval:
                continue
            if task.exec_time:
                seconds = max(task.min_loop_interval -
                              (time_now(task.exec_time) - task.exec_time).total_seconds(), 0)
                time.sleep(seconds)
            else:
                time.sleep(task.min_loop_interval)
        return

    def redistribute_task(self):
        from utilmeta.conf import config
        from utilmeta.util.query import MetaQuerySet
        from utilmeta.ops.models.task import TaskDistribution
        # tasks = TaskSettings.objects.filter(disabled=False, service=config.name)
        base_dist: MetaQuerySet = TaskDistribution.objects.filter(
            instance_id=self.config.instance_id,
            task__disabled=False,
            task__service=config.name,
            status__in=[TaskStatus.idle, TaskStatus.busy]
        )
        volatiles = base_dist.filter(worker=None).union(
            base_dist.filter(worker__connected=False)
        )
        if self.config.worker_graceful_timeout:
            volatiles = volatiles.union(base_dist.filter(
                worker__retire_time__lte=time_now() - timedelta(
                    seconds=self.config.worker_graceful_timeout + self.config.worker_cycle_interval
                )
            ))
        volatiles = list(set(volatiles))
        term = False
        index = 0
        from utilmeta.core.task import Task
        # use default task reassign strategy
        max_tasks = config.task.max_worker_tasks
        if max_tasks:
            for worker in self.iter_reassign_workers(Task()):
                if worker.tasks >= max_tasks:
                    continue
                if term:
                    continue
                try:
                    for i in range(0, max_tasks - worker.tasks):
                        dist: TaskDistribution = volatiles[index]
                        dist.transfer_to(worker)
                        index += 1
                except IndexError:
                    term = True
                    continue

        group = []
        names = []
        if volatiles:
            for dist in volatiles[index:]:
                names.append(dist.task.name)
                if max_tasks and len(names) >= max_tasks:
                    group.append(names)
                    names = []
        if names:
            group.append(names)
        return group

    def get_retire_workers(self):
        from utilmeta.ops.models.task import TaskWorker
        return TaskWorker.retire_workers().filter(master__pid=self.process_id)

    def spawn_workers(self):
        new_groups = self.redistribute_task()

        from utilmeta.ops.models.task import TaskWorker
        workings = TaskWorker.normal_workers().count()
        new_retires = TaskWorker.retire_workers().filter(
            retire_time__gte=time_now() - timedelta(seconds=self.config.main_cycle_interval)
        ).count()

        if workings >= self.config.max_workers:
            return

        spawn_num = 0
        if workings < self.config.min_workers:
            spawn_num = max(spawn_num + self.config.min_workers - workings, 0)
        if workings + spawn_num + len(new_groups) > self.config.max_workers:
            spawn_num = max(self.config.max_workers - workings - len(new_groups), 0)
        if self.config.max_worker_spawn_step:
            spawn_num = min(self.config.max_worker_spawn_step - len(new_groups), spawn_num)

        new_groups += [[]] * spawn_num

        if new_groups:
            print(f'New Worker(spawn_num={len(new_groups)}, workings={workings}, new_retires={new_retires})')

        self.alert_error(relieve=True)
        close_connections()
        from utilmeta.util.task.generator import worker_generator
        for tasks in new_groups:
            # need to spawn these workers
            process = multiprocessing.Process(
                target=worker_generator,
                args=tuple(tasks),
                kwargs=dict(
                    master=False,
                    patches=self.config.get_patches()
                )
            )
            process.start()
