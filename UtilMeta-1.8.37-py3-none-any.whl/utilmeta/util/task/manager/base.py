from typing import List, TYPE_CHECKING
from utilmeta.util.common import time_now, remove_file, exp, normalize, multi, \
    ignore_errors, TaskStatus, exc, convert_time, TaskFailure, EventStatus, pop, close_connections
import multiprocessing
import os
import threading
from datetime import timedelta
from utilmeta.util.error import Error
from utilmeta.util.task.backends.base import BaseJob
import time

if TYPE_CHECKING:
    from utilmeta.core.task import Task

DB_FAULT_ERRORS = (exc.OperationalError, exc.ProgrammingError)
STANDARD_ERRORS = ['execution_%s' % s for s in TaskFailure.gen()]


class BaseTaskManager:
    def __init__(self,  process: multiprocessing.Process = None):
        from utilmeta.conf import config
        self._process = process
        self._master = False
        self._daemon_threads: List[threading.Thread] = []
        self.is_representative = False

        self.config = config.task
        self.worker_id = None
        self.init_time = time_now()
        self.retire_time = None

    def get_worker_id(self):
        if self.worker_id:
            return self.worker_id
        self.load_worker(update=False)
        return self.worker_id

    def daemon_thread(self, target, *args, **kwargs):
        thread = threading.Thread(target=target, args=args, kwargs=kwargs)
        thread.setDaemon(True)
        thread.start()
        self._daemon_threads.append(thread)

    def check_daemon_threads(self):
        for thread in self._daemon_threads:
            if not thread.is_alive():
                self._daemon_threads.remove(thread)
        return len(self._daemon_threads)

    def run(self):
        raise NotImplementedError

    def loop_worker_cycle(self):
        raise NotImplementedError

    def _loop_main_cycle(self):
        start_time = time.time()
        while True:
            if self.retire_time:
                break
            # main cycle should use a Thread no-matter the job
            if self.config.master:
                time.sleep(max(self.config.main_cycle_interval - (time.time() - start_time), 0))
            else:
                if self.is_representative:
                    time.sleep(max(self.config.main_cycle_interval - (time.time() - start_time), 0))
                else:
                    # wait until self is rep
                    time.sleep(self.config.worker_cycle_interval)
                    if not self.is_representative:
                        # if this is representative now, execute main cycle
                        continue

            thread = threading.Thread(target=self.main_cycle)
            thread.setDaemon(True)
            thread.start()
            start_time = time.time()
            thread.join()

    def main_cycle(self):
        try:
            print(f'MAIN CYCLE: {self.process_id}')
            self.load_instances()
            self.load_events()
            self.load_executions()
            self.update_events()
            # load instances before health check
            self.health_check()
            self.load_workers()
            self.spawn_workers()
        except Exception as e:
            self.alert_error(message=Error(e).full_info)
        finally:
            # close connection when there is error occur before trying to close connections in try block
            close_connections()

    def load_instance(self, task, copy: bool = True):
        inst = self.config.load_instance(task)
        if not inst:
            return None
        if copy:
            return inst.__copy__()
        return inst

    def _loop_recover_cycle(self):
        while True:
            if self.retire_time:
                break
            start = time_now()
            self.resolve_omitted_events()
            seconds = max(self.config.worker_cycle_interval - (time_now() - start).total_seconds(), 0)
            time.sleep(seconds)
        return

    @ignore_errors
    def resolve_omitted_events(self, block: bool = True):
        """
        Consider this is a looped task
        """
        if not block:
            return self.daemon_thread(target=self.resolve_omitted_events)

        from utilmeta.ops.models.task import TaskEvent  # , TaskDistribution

        with self.config.concurrent_executor(
            silent_timeout=True,
            on_complete=close_connections
        ) as executor:
            for event in TaskEvent.objects.filter(
                    exec_time__lte=time_now() - timedelta(seconds=self.config.min_interval),
                    executions=None,
                    # task__distributions__in=TaskDistribution.currents()
            ).exclude(status=EventStatus.abandoned).order_by('exec_time'):
                inst = self.load_instance(event.task)
                print(f'[{time_now()}] RECOVER OMIT EVENT({event.event_id}) FOR: {inst}')
                executor.submit(inst.execute, event_id=event.event_id, from_cycle=False)

    @property
    def master(self):
        return self._master

    @property
    def process_id(self):
        if self._process:
            return self._process.pid
        return os.getpid()

    @property
    def thread_id(self):
        return threading.current_thread().ident

    @classmethod
    def health_check(cls):
        from utilmeta.ops.tasks.health import InstanceHealthCheckTask
        InstanceHealthCheckTask(task=True).execute()

    @property
    def worker_kwargs(self):
        # inherit
        return {}

    def load_worker(self, update: bool = False):
        from utilmeta.ops.models.task import TaskWorker

        worker = TaskWorker.load(
            self.process_id,
            parent=not self.master and self.config.master,
            **self.worker_kwargs
        )
        if worker:
            self.worker_id = worker.pk
            if worker.retire_time:
                # retire by other worker or by reload
                self.retire_time = worker.retire_time
                self.is_representative = False
            else:
                if not self.config.master:
                    self.expire_task_workers(kill=False)

                    rep = TaskWorker.normal_workers().order_by('start_time').first()
                    if rep:
                        self.is_representative = worker.pk == rep.pk
                    else:
                        self.is_representative = False
        else:
            self.is_representative = False

        if update and worker:
            worker.update()

        return worker

    @property
    def log_dir(self):
        from utilmeta.conf import config
        return os.path.join(config.deploy.service.log_root, 'tasks')

    @property
    def log_file(self) -> str:
        from utilmeta.conf import config
        if self.master:
            return os.path.join(self.log_dir, f'master.{config.name}.log')
        return os.path.join(self.log_dir, f'worker.{config.name}.{self.process_id}.log')

    @property
    def retire_log_file(self) -> str:
        from utilmeta.conf import config
        return os.path.join(self.log_dir, f'retire.{config.name}.log')

    def clear_log(self):
        if self.config.redirect_output_stream:
            return remove_file(self.log_file, ignore_not_found=True)

    def prepare_log(self):
        from utilmeta.conf import config
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)
        try:
            open(self.log_file, 'a').write('')
        except PermissionError:
            os.system(f'sudo chown -R {os.getuid()}:{os.getpid()} {self.log_dir}/')
        for ab_path, dirs, files in os.walk(self.log_dir):
            for file in files:
                if file.startswith(f'worker.{config.name}'):
                    os.remove(os.path.join(ab_path, file))
        if self.master:
            open(self.log_file, 'w').write('')
        open(self.retire_log_file, 'w').write('')       # override retire log

    def retire_log(self, msg: str):
        if not self.config.redirect_output_stream:
            print(msg)
            return
        with open(self.retire_log_file, 'a') as err_f:
            err_f.write(f'{str(time_now())} [{self.process_id}]: {msg}')
            err_f.write('\n')
        return

    def apply_redirect(self):
        from utilmeta.conf import config
        from contextlib import redirect_stdout, redirect_stderr
        log_file = self.log_file

        class _Redirect:
            def __init__(self):
                self.apply = config.task.redirect_output_stream
                if not self.apply:
                    return
                self.file = open(log_file, 'a')
                self.stdout = redirect_stdout(self.file)
                self.stderr = redirect_stderr(self.file)

            def __enter__(self):
                if not self.apply:
                    return
                self.file.__enter__()
                self.stdout.__enter__()
                self.stderr.__enter__()

            def __exit__(self, exc_type, exc_val, exc_tb):
                if not self.apply:
                    return
                self.file.__exit__(exc_type, exc_val, exc_tb)
                self.stdout.__exit__(exc_type, exc_val, exc_tb)
                self.stderr.__exit__(exc_type, exc_val, exc_tb)

        return _Redirect()

    @ignore_errors
    def alert_error(self, task: 'Task' = None, message: str = None,
                    data: dict = None, type: str = None, ident: str = None,
                    level: str = None, relieve: bool = False,
                    downgrade: bool = False, abandoned: bool = False):
        from utilmeta.conf import config
        if not config.alert:
            return

        def _make_type(t: str):
            t = str(t)
            prefix = 'execution_'
            if t.startswith(prefix):
                return t
            return prefix + t

        from utilmeta.util.alert import Alert

        if task:
            if config.ops and config.ops.ignore_ops_alerts and task.group == 'ops':
                # ignore ops task alerts
                return

            task_id = task.task_settings.id if task.task_settings else None
            if not task_id:
                return

            if relieve:
                if not config.alert.task_error_auto_relieve:
                    return

                if isinstance(type, str):
                    types = [type]
                elif multi(type):
                    types = list(type)
                else:
                    types = STANDARD_ERRORS

                from utilmeta.util.alert import Alert
                from utilmeta.ops.models.log import AlertLog
                query = dict(
                    type__task_id=task_id,
                    relieved_time=None
                )
                if types:
                    query.update(type__subcategory__in=[_make_type(tp) for tp in types])
                if ident:
                    query.update(type__ident__endswith=ident)

                for log in AlertLog.objects.filter(**query):
                    log: AlertLog
                    if log.relieve():
                        return
                    Alert.notify_supervisor(log)  # notify relieve
                return

            ident = ident or ''
            if ident:
                ident = ':' + ident

            alert_log = Alert.log(
                subcategory=_make_type(type),
                name=f'task [{task.name}] %s' % type.replace("_", " "),
                message=message,
                level=level or config.alert.failed_execution_alert_level,
                category=Alert.Category.task_downgrade if downgrade else Alert.Category.task_error,
                ident=f'{_make_type(type)}:{task.name}{ident}',
                min_times=task.alert_min_continuous_errors,
                task_id=task_id,
                instance=True,
                task=True,
                data=dict(
                    event_id=task.event_id,
                )
            )

        else:
            wk = 'event' if abandoned else ('master' if self.master else 'worker')
            dg = 'abandoned' if abandoned else ('downgrade' if downgrade else 'error')
            ct = Alert.Category.task_unavailable if abandoned else\
                (Alert.Category.task_downgrade if downgrade else Alert.Category.task_error)
            subcategory = ident = f'task_{wk}_{dg}'

            if relieve:
                if not config.alert.task_error_auto_relieve:
                    return

                from utilmeta.ops.models.log import AlertLog

                for log in AlertLog.objects.filter(
                    type__ident=ident,
                    relieved_time=None
                ):
                    log: AlertLog
                    if log.relieve():
                        return
                    Alert.notify_supervisor(log)  # notify relieve

                return

            if level is None:
                if downgrade:
                    level = config.alert.task_downgrade_alert_level
                else:
                    level = config.alert.failed_execution_alert_level

            alert_log = Alert.log(
                subcategory=subcategory,
                name=f'task {wk} {dg}',
                category=ct,
                message=message,
                level=level,
                data=data,
                ident=ident,
                instance=True,
                task=True
            )

        if self.config.console_log_execution:
            print(f'Alert: {task}', message, flush=True)
        else:
            with open(self.log_file, 'a') as err_f:
                err_f.write(message + '\n')

        return alert_log

    def check_retire(self):
        if self.retire_time:
            return True

        if self.config.min_worker_lifetime:
            if (time_now(self.init_time) - self.init_time).total_seconds() < self.config.min_worker_lifetime:
                return False

        if self.config.max_worker_lifetime:
            if (time_now(self.init_time) - self.init_time).total_seconds() + \
                    self.config.get_worker_lifetime_delta() > self.config.max_worker_lifetime:
                self.retire_log('TIME HIT')
                return True

        if self.config.max_worker_memory_percent:
            import psutil
            proc = psutil.Process(os.getpid())
            per = proc.memory_percent('uss')
            if per > self.config.max_worker_memory_percent:
                self.retire_log(f'MEM PERCENT HIT: {per}')
                return True

        if self.config.max_worker_memory_bytes:
            import psutil
            proc = psutil.Process(os.getpid())
            info = proc.memory_full_info()
            mem = getattr(info, 'uss', getattr(info, 'rss', 0))
            if mem > self.config.max_worker_memory_bytes:
                self.retire_log(f'MEM BYTES HIT: {mem}')
                return True

        if self.config.max_worker_executions:
            from utilmeta.ops.models.task import TaskDistribution
            from utilmeta.util.common import exp
            executions = TaskDistribution.objects.filter(
                worker__pid=os.getpid()).aggregate(v=exp.Sum('worker_executed_events'))['v'] or 0
            if executions > self.config.max_worker_executions:
                self.retire_log(f'EXEC HIT: {executions}')
                return True

        return False

    @ignore_errors
    def do_retire(self):
        if self.retire_time:
            return True

        from utilmeta.ops.models.task import TaskWorker
        if self.is_representative:
            if not TaskWorker.normal_workers().exclude(id=self.worker_id).exists():
                # if no other normal workers exists, representative cannot retire
                return False
        retire_time = time_now()
        worker = TaskWorker.current()
        worker.retire_time = retire_time
        worker.save(update_fields=['retire_time'])
        # set after worker save successfully
        self.retire_time = retire_time
        return True

    def load_events(self):
        from utilmeta.ops.models.task import TaskEvent, TaskDistribution
        # create for all the task events
        events = []
        for dist in TaskDistribution.objects.filter(
            instance_id=self.config.instance_id,
            status__in=[TaskStatus.idle, TaskStatus.busy]
        ):
            inst = self.load_instance(dist.task)
            task_events = TaskEvent.incoming_events(task=dist.task)
            load_event_num = max(self.config.preload_events - task_events.count(), 0)
            if not load_event_num:
                continue
            last = TaskEvent.last(task=dist.task)
            if last:
                from_time = last.exec_time
                if inst.schedule:
                    from_time += self.config.min_timedelta
            else:
                from_time = inst.cycle_start_time
            iterator = inst.iter_exec_time(from_time=from_time)
            objs = []
            i = 0
            for exec_time in iterator:
                if exec_time < time_now(exec_time):
                    continue
                i += 1
                objs.append(TaskEvent(
                    task=dist.task,
                    event_id=(last.event_id + i) if last else i,
                    exec_time=convert_time(exec_time)
                ))
                if i >= load_event_num:
                    break
            events.extend(objs)
        TaskEvent.objects.bulk_create(events, ignore_conflicts=True)
        return events

    def update_events(self):
        from utilmeta.util.common import exp, EventStatus
        from utilmeta.ops.models.task import TaskEvent, TaskSettings

        cycle_now = time_now() - self.config.min_timedelta
        TaskEvent.objects.filter(
            exec_time__lte=cycle_now,
            executions=None
        ).exclude(status=EventStatus.abandoned).update(
            status=EventStatus.omitted,
            volatile=False
        )

        TaskEvent.objects.filter(
            task__event_abandon_window__isnull=False,
            exec_time__lte=cycle_now - exp.F('task__event_abandon_window'),
            executions=None
        ).update(
            status=EventStatus.abandoned,
            volatile=False
        )

        TaskEvent.objects.annotate(
            success_execution_num=exp.Count('executions', filter=exp.Q(executions__success=True))
        ).filter(
            task__dist_by_event=True,
            success_execution_num__gt=1
        ).update(
            status=EventStatus.redundant,
            volatile=False
        )

        TaskEvent.objects.annotate(
            failed_jobs=exp.Sum('executions__failed_jobs')
        ).filter(
            exp.Q(failed_jobs__gt=0) |
            exp.Q(executions__success=False) |
            exp.Q(executions__timeout=True)
        ).update(volatile=False)

        TaskEvent.objects.filter(
            exec_time__lte=cycle_now,
            status=EventStatus.pending,
        ).exclude(
            executions__done_time__isnull=True
        ).update(status=EventStatus.normal)

        TaskEvent.objects.filter(
            exec_time__lte=cycle_now,
            status__in=[EventStatus.omitted, EventStatus.abandoned],
        ).exclude(executions=None).update(status=EventStatus.recovered)

        expired_abandons = []
        for event in TaskEvent.objects.filter(
            task__event_abandon_expired=True,
            status=EventStatus.omitted,
            executions=None
        ):
            next_event = TaskEvent.objects.filter(
                task=event.task,
                event_id=event.event_id + 1,
            ).order_by('exec_time').first()

            if next_event and cycle_now >= next_event.exec_time:
                expired_abandons.append(event.pk)

        if expired_abandons:
            TaskEvent.objects.filter(pk__in=expired_abandons, status=EventStatus.omitted).update(
                status=EventStatus.abandoned
            )

        from utilmeta.conf import config
        if config.alert:
            from utilmeta.util.alert import Alert
            from utilmeta.ops.models.log import AlertLog
            from utilmeta.ops.models.task import TaskExecution
            from utilmeta.util.common import AlertCategory

            if config.alert.task_error_auto_relieve:
                for log_id in set(TaskExecution.objects.filter(
                    success=True,
                    done_time__gte=cycle_now - timedelta(seconds=self.config.main_cycle_interval),
                    alert__type__category=AlertCategory.task_error,
                    alert__relieved_time=None
                ).values_list('alert', flat=True)):
                    log = AlertLog.get(log_id)
                    if not log:
                        continue
                    if log.relieve():
                        continue
                    Alert.notify_supervisor(log)

            for event_id, name in TaskEvent.objects.filter(
                exec_time__gte=cycle_now - timedelta(seconds=self.config.main_cycle_interval),
                status=EventStatus.abandoned
            ).values_list('event_id', 'task__name'):
                task = TaskSettings.get(name)
                if config.alert.abandon_event_interval_threshold and task.interval:
                    if task.interval.total_seconds() < config.alert.abandon_event_interval_threshold:
                        continue
                self.alert_error(
                    message=f'task [{task.name}] abandoned event [{event_id}]',
                    level=config.alert.abandon_event_alert_level,
                    data=dict(
                        task_id=task.id,
                        event_id=event_id
                    ),
                    abandoned=True
                )

    def load_instances(self):
        from utilmeta.ops.models.task import TaskInstance
        from utilmeta.conf import config
        TaskInstance.self_heartbeat()
        TaskInstance.objects.filter(
            service=config.name,
            connected=True,
            last_heartbeat__lte=time_now() - timedelta(
                seconds=self.config.instance_disconnect_interval
            )
        ).update(connected=False)
        if config.cluster:
            config.cluster_manager.update_services()

    def expire_task_workers(self, kill: bool = True):
        from utilmeta.ops.models.task import TaskWorker
        TaskWorker.current_workers().filter(
            connected=True,
            time__lte=time_now() - timedelta(
                seconds=self.config.worker_cycle_interval * 2
            )
        ).update(connected=False)

        if not kill:
            return

        from utilmeta.ops.models.task import TaskWorker
        import psutil
        force_kills = TaskWorker.current_workers().filter(
            connected=False,
        )
        for worker in force_kills:
            try:
                proc = psutil.Process(worker.pid)
                proc.terminate()
            except psutil.Error as e:
                print('KILL PROCESS ERR:', e)
                # ignore process error
                continue
        force_kills.delete()

    def load_workers(self):
        self.load_worker(update=True)
        from utilmeta.ops.models.service import ServiceWorker, Worker
        from utilmeta.ops.models.task import TaskExecution
        from utilmeta.conf import config

        ServiceWorker.current_workers().filter(
            master__isnull=False,
            connected=True,
            time__lte=time_now() - timedelta(
                seconds=config.monitor.worker_disconnect_interval
            )
        ).delete()

        if not config.master_cycle_required:
            # update service master metrics in task worker
            service_master = ServiceWorker.get_master()
            if service_master:
                Worker.update(service_master)

        self.expire_task_workers()
        # self.term_disconnected_workers()

        TaskExecution.objects.filter(
            done_time=None,
            timeout_time__lte=time_now() - timedelta(seconds=self.config.worker_cycle_interval),
            timeout=None
        ).update(
            done_time=time_now(),
            timeout=True,
            success=False
        )

    def _sync_execution(self, task: 'Task'):
        from utilmeta.ops.models.task import TaskExecution, TaskWorker
        self.sync_distribution(task, execute=True)
        event = task.current_event
        if not event:
            from utilmeta.ops.models.task import TaskEvent
            last = TaskEvent.last(task=task.task_settings)
            event = TaskEvent.objects.create(
                task=task.task_settings,
                event_id=(last.event_id + 1) if last else 1,
                exec_time=task.exec_time
            )

        exists = TaskExecution.objects.filter(
            dist=task.task_distribution,
            event=event,
        ).first()

        if exists:
            # already executed by another worker or master
            # this is also the mutex lock among the workers acquiring for execution
            return False

        if task.dist_by_event:
            if TaskExecution.objects.filter(event=event).exists():
                # already executed by another instance
                return False

        execution = TaskExecution.objects.create(
            dist=task.task_distribution,
            event=event,
            exec_time=task.exec_time,
            timeout_time=task.timeout_limit,
            total_jobs=task.jobs_num,
            worker=TaskWorker.current()
        )

        if task.event_max_executions:
            if TaskExecution.objects.filter(
                    event=event,
                    exec_time__lt=task.exec_time).count() >= task.event_max_executions:
                raise ValueError(f'Execution excess')

        task._execution = execution

    def sync_execution(self, task: 'Task'):
        if self.config.cache_executions:
            data = dict(
                event_id=task.event_id,
                exec_time=task.exec_time,
                timeout_time=task.timeout_limit,
                total_jobs=task.jobs_num,
                worker_id=self.get_worker_id()
            )
            exec_key = self.get_exec_key(task.name, event_id=task.event_id)
            return self.cache.add(exec_key, data)

        from django.db import transaction
        from utilmeta.conf import config
        if not task.exec_time or not task.task_distribution:
            # maybe worker cycle task
            return True
        try:
            if config.ops.db_support_save_transaction:
                with transaction.atomic(config.ops.db_alias):
                    self._sync_execution(task)
            else:
                self._sync_execution(task)
            return True
        except exc.IntegrityError:
            # execution lock is acquired by another worker
            return False
        except Exception as e:
            self.alert_error(task, type=TaskFailure.sync_error, message=Error(e).full_info)
            return False

    def get_dist_worker_id(self):
        return self.get_worker_id()

    def sync_distribution(self, task: 'Task', execute: bool = False, done: bool = False):
        from utilmeta.ops.models.task import TaskDistribution, TaskInstance
        try:
            if not task.task_settings:
                return
            if not done:
                task.load_cycle_start()

            data: dict = dict(status=task.status)

            if self.config.cache_executions:
                if not done and not execute:
                    if not task.task_settings:
                        return
                    data.update(worker_id=self.get_dist_worker_id())
                    dist = task.task_distribution
                    # status only
                    instance = TaskInstance.current()
                    if instance:
                        if dist:
                            TaskDistribution.objects.filter(pk=dist.pk).update(**data)
                        else:
                            dist = TaskDistribution.objects.create(
                                task=task.task_settings,
                                instance=instance,
                                **data
                            )
                    task._distribution = dist
                return

            dist = task.task_distribution
            worker_id = self.get_dist_worker_id()

            data: dict = dict(
                status=task.status,
                worker_id=worker_id
            )

            if done and task.exec_duration:
                seconds = task.exec_duration.total_seconds()
                data.update(
                    executed_events=(exp.F('executed_events') + 1) if dist else 1,
                    worker_executed_events=(exp.F('worker_executed_events') + 1) if dist else 1,
                    worker_avg_time=((exp.F('worker_executed_events') * exp.F('worker_avg_time')
                                      + seconds) / (exp.F('worker_executed_events') + 1) if dist else seconds),
                    avg_time=((exp.F('executed_events') * exp.F('avg_time')
                               + seconds) / (exp.F('executed_events') + 1) if dist else seconds),
                )

            if execute:
                if worker_id and dist and dist.worker_id != worker_id:
                    data.update(
                        worker_executed_events=0,
                        worker_avg_time=0
                    )
                data.update(
                    current_event=task.current_event,
                )

            instance = TaskInstance.current()
            if instance:
                if done:
                    seconds = task.exec_duration.total_seconds() if task.exec_duration else 0
                    TaskInstance.objects.filter(pk=instance.pk).update(
                        executions=exp.F('executions') + 1,
                        error_executions=exp.F('error_executions') + (1 if task.error else 0),
                        timeout_executions=exp.F('timeout_executions') + (1 if task.timeout else 0),
                        avg_time=(exp.F('executions') * exp.F('avg_time') + seconds) / (exp.F('executions') + 1)
                    )

                if dist:
                    TaskDistribution.objects.filter(pk=dist.pk).update(**data)
                else:
                    dist = TaskDistribution.objects.create(
                        task=task.task_settings,
                        instance=instance,
                        **data
                    )

                task._distribution = dist

        except Exception as e:
            self.alert_error(task, type='distribution_sync_error', message=Error(e).full_info)

    @ignore_errors
    def load_executions(self):
        if not self.config.cache_executions:
            return []

        from utilmeta.conf import config
        from utilmeta.ops.models.task import TaskEvent, TaskDistribution, TaskExecution, TaskJob
        from django.db.models.fields import DecimalField

        cycle_now = time_now() - self.config.min_timedelta

        event_pks = []
        event_ids = []
        task_names = []
        exec_keys = []

        for id, task_name, event_id in TaskEvent.objects.filter(
            status__in=[EventStatus.pending, EventStatus.omitted],     # flag mark
            task__service_id=config.name,
            exec_time__lte=cycle_now,
        ).order_by('exec_time').values_list('id', 'task__name', 'event_id'):
            event: TaskEvent
            event_pks.append(id)
            task_names.append(task_name)
            event_ids.append(event_id)
            exec_keys.append(self.get_exec_key(task_name, event_id=event_id))

        if not event_pks:
            return []

        exec_values = self.cache.get_many(exec_keys)

        dist_map = {v[0]: v[1] for v in TaskDistribution.objects.filter(
            instance_id=config.task.instance_id,
            task__name__in=task_names
        ).values_list('task__name', 'id')}
        dist_events = {}
        # id, +events, +duration (seconds)

        exec_map = {v[0]: v[1] for v in TaskExecution.objects.filter(
            dist__instance_id=config.task.instance_id,
            event_id__in=event_pks
        ).values_list('event_id', 'id')}

        execution_creates = []
        execution_updates = []

        store_jobs_map = {}     # event_pk: jobs
        all_jobs = []

        omit_events = []
        exec_fields = []
        done_keys = []

        for exec_key, event_pk, event_id, task_name in zip(exec_keys, event_pks, event_ids, task_names):
            dist_id = dist_map.get(task_name)
            if not dist_id:
                continue
            exec_data = exec_values.get(exec_key)

            if isinstance(exec_data, dict):
                done_time = exec_data.get('done_time')
                jobs = pop(exec_data, 'jobs', [])
                exec_id = exec_map.get(event_pk)

                exec_data.update(dist_id=dist_id, event_id=event_pk)
                # execution's event_id is Event.event_id, should update to Event.id
                execution = TaskExecution(**exec_data, id=exec_id)

                if exec_id:
                    if not exec_fields:
                        exec_fields = list(exec_data)

                    execution_updates.append(execution)
                else:
                    execution_creates.append(execution)

                if done_time:
                    # done
                    store_jobs = []
                    for job in jobs:
                        store_jobs.append(TaskJob(execution_id=exec_id, **job))

                    if not exec_id:
                        store_jobs_map[event_pk] = store_jobs
                    else:
                        all_jobs.extend(store_jobs)

                    duration_seconds = exec_data.get('duration', 0) / 1000

                    if dist_id in dist_events:
                        events, seconds, _event_pk, _status = dist_events[dist_id]
                        events += 1
                        seconds += duration_seconds
                    else:
                        events, seconds = 1, duration_seconds

                    dist_events[dist_id] = events, seconds, event_pk, TaskStatus.idle
                    done_keys.append(exec_key)
                    # up to the latter event

                else:
                    if dist_id in dist_events:
                        events, seconds, _event_pk, _status = dist_events[dist_id]
                    else:
                        events, seconds = 0, 0
                    dist_events[dist_id] = events, seconds, event_pk, TaskStatus.busy
                    # update current event

            else:
                # omitted
                omit_events.append(event_pk)
                inst = self.load_instance(task_name)
                if inst:
                    # recover
                    self.daemon_thread(inst.execute, event_id=event_id)

        if execution_creates:
            new_objs = TaskExecution.objects.bulk_create(execution_creates)
            # cannot use ignore_conflicts=True, or pk will be None
            print('NEW EXECUTIONS:', new_objs)
            for obj in new_objs:
                if not obj.pk:
                    continue
                _jobs = store_jobs_map.get(obj.event_id, [])
                for job in _jobs:
                    job.execution_id = obj.pk
                all_jobs.extend(_jobs)

        if execution_updates and exec_fields:
            TaskExecution.objects.bulk_update(execution_updates, fields=exec_fields)

        if all_jobs:
            TaskJob.objects.bulk_create(all_jobs, ignore_conflicts=True)

        if dist_events:
            # reduce query nums to constant level
            event_when_list = []
            duration_when_list = []
            current_when_list = []
            status_when_list = []

            for dist_id, (events, duration, event_pk, status) in dist_events.items():
                event_when_list.append(exp.When(
                    pk=dist_id, then=exp.F('executed_events') + events))
                duration_when_list.append(exp.When(
                    pk=dist_id, then=(exp.F('executed_events') * exp.F('avg_time')
                                      + duration) / (exp.F('executed_events') + events)))
                current_when_list.append(exp.When(
                    pk=dist_id, then=event_pk
                ))
                status_when_list.append(exp.When(
                    pk=dist_id, then=exp.Value(status)
                ))

            TaskDistribution.objects.filter(pk__in=list(dist_events)).update(
                current_event_id=exp.Case(*current_when_list),
                executed_events=exp.Case(*event_when_list),
                avg_time=exp.Case(*duration_when_list, output_field=DecimalField()),
                status=exp.Case(*status_when_list)
            )

        # clear done keys
        self.cache.delete_many(done_keys)
        return set(event_pks).difference(omit_events)

    @classmethod
    def get_job_data(cls, task: 'Task', job: BaseJob):
        return dict(
            exec_time=job.exec_time,
            timeout_time=task.timeout_limit,
            done_time=job.done_time,
            duration=int(job.duration.total_seconds() * 1000) if job.duration else None,
            args=job.normalized_args,
            kwargs=job.normalized_kwargs,
            timeout=bool(job.timeout),
            result=job.result,
            success=bool(job.success),
            message=job.message,
            messages=job.log.messages if job.log else [],
            trace=normalize(job.log.events, _json=True) if job.log else {},
            queries_num=job.log.queries_num if job.log else 0,
            queries_duration=job.log.queries_duration_ms if job.log else 0,
            thread_id=job.worker_id,
            local_retries=job.retry_id
        )

    def get_exec_key(self, name: str, event_id: int):
        from utilmeta.conf import config
        return f'{config.cache_prefix}:{config.task.instance_id}:{self.__class__.__name__}:{name}:{event_id}'

    @property
    def cache(self):
        from utilmeta.conf import config
        return config.ops.cache

    @ignore_errors
    def store_execution(self, task: 'Task', jobs: List[BaseJob], **kwargs):
        if self.config.cache_executions:
            exec_key = self.get_exec_key(task.name, event_id=task.event_id)
            exec_data = self.cache.get(exec_key)
            if isinstance(exec_data, dict):
                exec_data.update(
                    **kwargs,
                    jobs=[self.get_job_data(task, job) for job in jobs]
                )
                return self.cache.set(exec_key, exec_data)
            return

        execution = task.task_execution
        if not execution:
            return

        from utilmeta.ops.models.task import TaskJob

        execution.done(**kwargs)
        store_jobs = []
        store_queries = []

        for job in jobs:
            job_inst = TaskJob(
                execution=execution,
                **self.get_job_data(task, job=job)
            )
            slow_queries = job.log.generate_query_logs()
            for q in slow_queries:
                q.context_job = job_inst
            store_queries.extend(slow_queries)
            store_jobs.append(job_inst)

        if store_jobs:
            from utilmeta.ops.models.task import TaskJob
            TaskJob.objects.bulk_create(store_jobs, ignore_conflicts=True)

        if store_queries:
            from utilmeta.ops.models.log import QueryLog
            QueryLog.objects.bulk_create(store_queries, ignore_conflicts=True)

    def spawn_workers(self):
        raise NotImplementedError

    @ignore_errors
    def done_execution(self, task: 'Task', jobs: List[BaseJob] = ()):
        from utilmeta.util.query.resolver import std_dev
        from utilmeta.conf import config

        store_jobs = []
        durations = []
        timeouts = 0
        total = len(jobs)
        retried = 0
        failed = 0
        total_retries = 0

        for job in jobs:
            job.expire()

            if task.store_job_result or not job.volatile:
                store_jobs.append(job)

            if job.timeout:
                timeouts += 1

            if job.failed:
                failed += 1

            if job.retry_id:
                retried += 1
                total_retries += job.retry_id

            if job.duration:
                durations.append(int(job.duration.total_seconds() * 1000))

        done = len(durations)
        durations = sorted(durations, reverse=True)
        seconds = (task.done_time - task.exec_time).total_seconds()

        timeout = bool(timeouts)
        success = not timeouts and not failed and not task.error

        # print('JOBS:', task.name, timeout, task.done_time, seconds)

        alert_id = None

        if config.alert:
            if not success:
                type = TaskFailure.failed
                job_info = f'{total} jobs'
                if timeout:
                    type = TaskFailure.timeout
                elif task.error:
                    type = TaskFailure.error
                elif timeouts:
                    job_info += f', {timeouts} timeout'
                    if timeouts == total:
                        type = TaskFailure.all_timeout
                    else:
                        type = TaskFailure.partial_timeout
                elif failed:
                    job_info += f', {failed} failed'
                    if failed == total:
                        type = TaskFailure.all_failed
                    else:
                        type = TaskFailure.partial_failed

                message = f'execution {type} ({job_info})'.replace('_', ' ')
                if task.error:
                    message += f': {task.error}'

                alert_log = self.alert_error(
                    task,
                    type=type,
                    message=message,
                    level=config.alert.failed_execution_alert_level
                )
                if alert_log:
                    alert_id = alert_log.pk

        self.store_execution(
            task, jobs=store_jobs,
            done_time=task.done_time,
            timeout=timeout,
            success=success,
            message=task.error.full_info if task.error else '',
            timeout_jobs=timeouts,
            failed_jobs=failed,
            retried_jobs=retried,
            avg_job_retries=(total_retries / total) if total else 0,
            job_min_time=min(durations) if done else 0,
            job_max_time=max(durations) if done else 0,
            job_avg_time=(sum(durations) / done) if done else 0,
            job_mean_time=durations[done // 2] if done else 0,
            job_p95_time=durations[done // 20] if done else 0,
            job_p99_time=durations[done // 100] if done else 0,
            job_p999_time=durations[done // 1000] if done else 0,
            job_time_stddev=std_dev(durations, default=0),
            jobs_per_sec=total / seconds,
            duration=int(seconds * 1000),
            alert_id=alert_id
        )

        if task.status == TaskStatus.busy:
            task._status = TaskStatus.idle
            self.sync_distribution(task, done=True)

    def claim_current_event(self, task: 'Task') -> bool:
        from utilmeta.conf import config
        if not task.dist_by_event:
            return True
        instances = sorted(
            config.cluster_manager.get_instances(
                connected=True, task=True),
            key=lambda inst: inst.init_time)
        pks = [instance.id for instance in instances]
        if len(instances) <= 1:
            return True
        current = self.config.instance_id
        if task.event_dist_strategy == task.FIRST:
            return instances[0].id == current
        if task.event_dist_strategy == task.LAST:
            return instances[-1].id == current
        if task.event_dist_strategy == task.HASH:
            inst_id = config.cluster_manager.get_hash_instance(key=task.event_id)
            return inst_id == current
        from utilmeta.ops.models.task import TaskExecution, TaskDistribution
        if task.event_dist_strategy == task.ROTATE:
            exe = TaskExecution.last(task=task.task_settings)
            if not exe:
                return instances[0].id == current
            last_inst_id = exe.dist.instance.pk
            try:
                index = pks.index(last_inst_id)
            except ValueError:
                return instances[0].id == current
            point = (index + 1) % len(pks)
            return instances[point].id == current
        if task.event_dist_strategy == task.LRU:
            dist = TaskDistribution.lru(task=task.task_settings)
            if not dist:
                return True
            return dist.instance.id == current
        if task.event_dist_strategy == task.LFU:
            dist = TaskDistribution.lfu(task=task.task_settings)
            if not dist:
                return True
            return dist.instance.id == current
        return True
