from utilmeta.types import *
from utilmeta.util.common import ignore_errors, close_connections, \
    time_now, exp, COMMON_ERRORS, exc

import multiprocessing
import time
from .base import BaseTaskManager

if TYPE_CHECKING:
    from utilmeta.core.task import Task


class QueueTaskManager(BaseTaskManager):
    REDIS = 'redis'

    POP_ALL_LUA = """
local result = redis.call('lrange', KEYS[1], 0, -1)
redis.call('delete', KEYS[1])
return result"""

    class EventData:
        def __init__(self, event_id: int, task_name: str, exec_time: Union[datetime, str]):
            self.event_id = event_id
            self.task_name = task_name
            if isinstance(exec_time, str):
                exec_time = datetime.fromisoformat(exec_time)
            if not isinstance(exec_time, datetime):
                raise TypeError(f'Invalid exec_time: {exec_time}')
            self.exec_time = exec_time

    def __init__(self, process: multiprocessing.Process = None,
                 queue_backend: str = REDIS,
                 queue_sorted_set: bool = False,
                 queue_worker_max_backlogs: int = None,
                 ):
        super().__init__(process=process)
        self._loop_tasks = set()

        self.redis_con = None

        if queue_backend == self.REDIS:
            from utilmeta.conf import config
            self.redis_con = config.ops.redis_con

            if not self.redis_con:
                raise ValueError(f'QueueTaskManager with {self.REDIS} backend does not have an redis connection')

        self.backend = queue_backend
        self.sorted_set = queue_sorted_set
        self.backlogs = 0
        self.queue_worker_max_backlogs = queue_worker_max_backlogs

    @property
    def time_within(self):
        return max(self.config.preload_events * self.config.min_task_interval, self.config.main_cycle_interval)

    @ignore_errors
    def load_looped_tasks(self):
        from utilmeta.ops.models.task import TaskDistribution
        # qs = TaskDistribution.currents().filter(task__looped=True)
        qs = TaskDistribution.currents().filter(task__looped=True).filter(
            exp.Q(worker=None) |
            exp.Q(worker__retire_time__isnull=False) |
            exp.Q(worker__connected=False)
        ).exclude(worker_id=self.worker_id)
        qs.update(worker_id=self.worker_id)     # set as current worker

        for dist in qs:
            dist: TaskDistribution
            inst = self.load_instance(dist.task)
            self.daemon_thread(self._loop_task_cycle, inst)

    def run(self):
        if self.config.worker_process_mode:
            multiprocessing.set_start_method(self.config.worker_process_mode)
        from utilmeta.conf import config
        # from .generator import worker_generator
        if not config.resolved:
            raise TypeError('config not set')
        self.prepare_log()
        # self.load_worker(update=True)
        # this worker is going to exit, do not load as it will be thr representative
        self.load_events()
        for task in self.config.get_tasks():
            task.load_status()

        close_connections()
        from utilmeta.util.task.generator import worker_generator
        workers = self.config.init_workers
        current_worker_loop = not self.config.master and not config.production
        if current_worker_loop:
            workers -= 1

        while workers:
            process = multiprocessing.Process(
                target=worker_generator,
                kwargs=dict(
                    patches=self.config.get_patches()
                )
            )
            process.start()
            workers -= 1

        if current_worker_loop:
            return self.loop_worker_cycle()

        if self.config.master:
            self.is_representative = True
            self._loop_main_cycle()
        else:
            exit(0)  # exit

    def loop_worker_cycle(self):
        self.daemon_thread(self._loop_exec_cycle)
        self.daemon_thread(self._loop_main_cycle)

        if not self.config.cache_executions:
            self.daemon_thread(self._loop_recover_cycle)

        while True:
            self.load_worker(update=True)

            if self.check_retire() and self.do_retire():
                break

            self.load_looped_tasks()
            if not self.check_daemon_threads():
                break

            time.sleep(self.config.worker_cycle_interval)

        self.do_retire()
        self.clear_log()
        self.retire_log(f'EXIT for {(time_now(self.retire_time) - self.retire_time).total_seconds()} seconds')

    def _loop_task_cycle(self, task: 'Task'):
        if not task.looped:
            return
        while True:
            if self.retire_time:
                # return if retired
                break
            task.execute(from_cycle=True)
            if not task.min_loop_interval:
                continue
            if task.exec_time:
                seconds = max(task.min_loop_interval -
                              (time_now(task.exec_time) - task.exec_time).total_seconds(), 0)
                time.sleep(seconds)
            else:
                time.sleep(task.min_loop_interval)
        return

    def _loop_exec_cycle(self):
        while True:
            if self.retire_time:
                # already retire, stop getting new event
                break
            event = self.pop_event_queue()
            # this is the closest
            if not isinstance(event, self.EventData):
                time.sleep(self.config.min_interval)
                continue

            inst = self.load_instance(event.task_name)
            exec_time = event.exec_time

            if exec_time < time_now():
                next_exec = inst.get_next_exec_time(exec_time)
                if next_exec and next_exec > time_now():
                    # go on as recover omitted
                    print(f'## [{self.process_id}] RECOVER EVENT:', event.task_name,
                          event.event_id, event.exec_time, time_now(), next_exec)
                    pass
                else:
                    # left to omit / recover
                    print(f'#### [{self.process_id}] ABANDONED EVENT:',
                          event.task_name, event.event_id, event.exec_time, next_exec, time_now())
                    continue

            print(f'[{self.process_id}] GET EVENT:', event.task_name, event.event_id, event.exec_time)

            if not inst:
                continue

            worker = inst.delay_execute(
                event_id=event.event_id, from_cycle=True,
                interval=max((exec_time - time_now()).total_seconds(), 0)
            )
            if inst.daemon_thread:
                self._daemon_threads.append(worker)

            delta: float = min(max((exec_time - time_now()).total_seconds() - self.config.min_interval, 0),
                               self.config.worker_cycle_interval)   # cannot sleep more than worker cycle
            if delta:
                time.sleep(delta)

    @property
    def queue_key(self):
        from utilmeta.conf import config
        type = 'SET' if self.sorted_set else 'LIST'
        return f'{config.cache_prefix}:{config.task.instance_id}:{self.__class__.__name__}:{type}'

    @ignore_errors
    def push_event_queue(self):
        from utilmeta.ops.models.task import TaskEvent
        from utilmeta.conf import config
        from utilmeta.util.common import json_dumps
        cycle_now = time_now() - self.config.min_timedelta
        events = TaskEvent.objects.filter(
            queue=False,
            task__service_id=config.name,
            exec_time__gte=cycle_now,
            exec_time__lte=cycle_now + timedelta(seconds=self.time_within)
        ).order_by('exec_time')
        event_values = events.values('event_id', 'task__name', 'exec_time')
        if self.backend == self.REDIS:
            if self.sorted_set:
                mapping = {json_dumps(v): v['exec_time'].timestamp() for v in event_values}
                if mapping:
                    self.redis_con.zadd(self.queue_key, mapping)
            else:
                values = [json_dumps(v) for v in event_values]
                if values:
                    self.redis_con.lpush(self.queue_key, *values)

        events.update(queue=True)

    @ignore_errors
    def pop_event_queue(self) -> Optional['EventData']:
        import json
        if self.backend == self.REDIS:
            import redis
            try:
                if self.sorted_set:
                    values = self.redis_con.zpopmin(self.queue_key)
                    if not values:
                        return None
                    data = json.loads(values[0][0].decode())
                else:
                    value: bytes = self.redis_con.rpop(self.queue_key)
                    if not value:
                        return None
                    data = json.loads(value.decode())
                return self.EventData(
                    event_id=data['event_id'],
                    exec_time=data['exec_time'],
                    task_name=data['task__name']
                )
            except (*redis.ResponseError, COMMON_ERRORS) as e:
                print('!!!!!ERR:', str(e))
                pass

        # use db lock
        from utilmeta.ops.models.task import TaskEvent, TaskDistribution, TaskExecution
        from utilmeta.conf import config
        cycle_now = time_now() - self.config.min_timedelta
        event: TaskEvent = TaskEvent.objects.filter(
            queue=True,
            task__service_id=config.name,
            exec_time__gte=cycle_now,
        ).order_by('exec_time').first()
        if not event:
            return None
        dist = TaskDistribution.get(task=event.task, instance_id=self.config.instance_id)
        if not dist:
            return None
        try:
            TaskExecution.objects.create(
                dist=dist,
                event=event,
                worker_id=self.worker_id
            )
        except exc.IntegrityError:
            return None
        return self.EventData(
            event_id=event.event_id,
            task_name=event.task.name,
            exec_time=event.exec_time
        )

    def check_queue_status(self):
        # check if there is many queue backlogs exists and need to spawn new worker
        # or to many idle workers
        pass

    def get_dist_worker_id(self):
        # no fixed distribution worker
        return None

    def load_events(self):
        super().load_events()
        self.push_event_queue()

    def load_executions(self):
        event_pks = super().load_executions()
        if event_pks:
            from utilmeta.ops.models.task import TaskEvent
            TaskEvent.objects.filter(pk__in=event_pks).update(queue=False)

    def spawn_workers(self):
        from utilmeta.ops.models.task import TaskWorker
        workings = TaskWorker.normal_workers().count()
        new_retires = TaskWorker.retire_workers().filter(
            retire_time__gte=time_now() - timedelta(seconds=self.config.main_cycle_interval)
        ).count()

        if workings >= self.config.max_workers:
            return

        spawn_num = new_retires
        if workings < self.config.min_workers:
            spawn_num = max(spawn_num + self.config.min_workers - workings, 0)
        if workings + spawn_num > self.config.max_workers:
            spawn_num = max(self.config.max_workers - workings, 0)
        if self.config.max_worker_spawn_step:
            spawn_num = min(self.config.max_worker_spawn_step, spawn_num)

        self.alert_error(relieve=True)
        close_connections()
        from utilmeta.util.task.generator import worker_generator
        while spawn_num:
            # need to spawn these workers
            process = multiprocessing.Process(
                target=worker_generator,
                kwargs=dict(patches=self.config.get_patches())
            )
            process.start()
            spawn_num -= 1
