from utilmeta.types import *
from utilmeta.util.base import Util
from utilmeta.util.common import multi, Static, time_local
from datetime import datetime
from datetime import tzinfo


class ScheduleItem(Static):
    second = 'second'
    minute = 'minute'
    hour = 'hour'
    month = 'month'
    year = 'year'
    day_of_month = 'day_of_month'
    day_of_year = 'day_of_year'
    day_of_week = 'day_of_week'


class Schedule(Util):
    slots = ScheduleItem.gen()

    def __init__(self,
                 second: Union[int, List[int]] = 0,
                 minute: Union[int, List[int]] = None,
                 hour: Union[int, List[int]] = None,
                 month: Union[int, List[int]] = None,
                 year: Union[int, List[int]] = None,
                 day_of_month: Union[int, List[int]] = None,
                 day_of_year: Union[int, List[int]] = None,
                 day_of_week: Union[int, List[int]] = None,

                 crontab: str = None,   # pass this param will invalidate all prev schedule params
                 timezone: tzinfo = None,
                 # utcoffset: Union[int, datetime] = None
                 ):
        # None stand for all
        def __parse__(val: Union[int, List[int]], ge: int = None, le: int = None) -> Optional[List[int]]:
            if val is None:
                return None
            from utilmeta.util.rule import Rule
            rule = Rule(type=int, ge=ge, le=le)
            if isinstance(val, int):
                return [rule(val)]
            elif multi(val):
                return sorted(list(set([rule(v) for v in val])))
            raise TypeError(f'Invalid value: {val}. must be int or list of int')

        minute = __parse__(minute, ge=0, le=59)
        second = __parse__(second, ge=0, le=59)
        hour = __parse__(hour, ge=0, le=23)
        month = __parse__(month, ge=1, le=12)
        year = __parse__(year, ge=datetime.now().year)
        day_of_month = __parse__(day_of_month, ge=1, le=31)
        day_of_year = __parse__(day_of_year, ge=1, le=366)
        day_of_week = __parse__(day_of_week, ge=1, le=7)

        if timezone:
            assert isinstance(timezone, tzinfo), \
                f'Schedule timezone must be a datetime.timezone object, got {timezone}'

        self.crontab = crontab
        self.timezone = timezone or self.default_timezone
        utcoffset = int(datetime.now(self.timezone).utcoffset().total_seconds())
        self.utcoffset = utcoffset
        self.minute = minute
        self.second = second
        self.hour = hour
        self.month = month
        self.year = year
        self.day_of_month = day_of_month
        self.day_of_year = day_of_year
        self.day_of_week = day_of_week

        # current + offset --> target
        # target - offset --> current
        del timezone

        super().__init__(locals())

    @property
    def default_timezone(self):
        from utilmeta.conf import config
        return config.time.timezone

    def only(self, item: str):
        for slot in self.slots:
            if (slot == item) ^ bool(getattr(self, slot, False)):
                return False
        return True

    @property
    def params(self) -> dict:
        return self.__spec_kwargs__

    @staticmethod
    def get_month_days(year: int) -> List[int]:
        leap = not year % 4
        feb_days = 29 if leap else 28
        return [31, feb_days, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    @classmethod
    def get_month_day(cls, year: int, day_of_year: int) -> Tuple[int, int]:
        month = 1
        day = day_of_year
        for days in cls.get_month_days(year):
            if day > days:
                month += 1
                day -= days
            else:
                break
        if day > 31 or month > 12:
            raise ValueError(f'Invalid day_of_year')
        return month, day

    @classmethod
    def get_day_of_year(cls, dt: date):
        day_of_year = 0
        mon = 1
        for days in cls.get_month_days(dt.year):
            if dt.month == mon:
                day_of_year += dt.day
                break
            day_of_year += days
            mon += 1
        return day_of_year

    @staticmethod
    def range_iterator(start: int = 0, end: int = None):
        i = start
        while True:
            if end and i > end:
                break
            yield i
            i += 1

    @classmethod
    def bound_iterator(cls, values: List[int], low_bound: int = None):
        for val in values:
            if low_bound and val < low_bound:
                continue
            yield val

    def __iter__(self):
        return self.iter_from(datetime.now())

    def convert_time(self, dt: datetime):
        """
        Convert a datetime (maybe timezone aware or unaware) to the timezone of this Schedule (unaware)
        """
        from utilmeta.conf import config
        if not dt.tzinfo:
            return dt - timedelta(seconds=config.time.timezone_utcoffset) + timedelta(seconds=self.utcoffset)
        return dt.astimezone(self.timezone).replace(tzinfo=None)

    def output_iter(self, start_time: datetime = None, times: int = 1):
        for t in self.iter_from(start_time=start_time):
            print(t, t.tzinfo)
            times -= 1
            if not times:
                return

    def convert_back(self, dt: datetime, original_tz: tzinfo = None):
        """
        Convert a unaware datetime in schedule timezone to the original timezone
        """
        tz = original_tz or self.default_timezone
        result = dt - timedelta(seconds=self.utcoffset) + datetime.now(tz).utcoffset()
        return result.replace(tzinfo=original_tz)

    def iter_from(self, start_time: datetime = None):
        start_time = start_time or time_local()
        now = self.convert_time(start_time)     # convert to schedule timezone
        # years = iter(self.year) if self.year else self.range_iterator(start=now.year)
        for year in self.year or self.range_iterator(start=now.year, end=9999):
            year_current = year == now.year
            lb = now.month if year_current else 1
            for month in self.bound_iterator(self.month, low_bound=lb) if self.month \
                    else self.range_iterator(start=lb, end=12):

                mon_current = year_current and month == now.month
                lb = now.day if mon_current else 1
                for day in self.bound_iterator(self.day_of_month, low_bound=lb) if self.day_of_month \
                        else self.range_iterator(start=lb, end=self.get_month_days(year)[month - 1]):

                    day_current = mon_current and day == now.day
                    dt = date(year=year, month=month, day=day)
                    if self.day_of_week:
                        valid = False
                        for d in self.day_of_week:
                            if dt.weekday() == d:
                                valid = True
                                break
                        if not valid:
                            continue
                    if self.day_of_year:
                        valid = False
                        for d in self.day_of_year:
                            if self.get_day_of_year(dt) == d:
                                valid = True
                                break
                        if not valid:
                            continue

                    lb = now.hour if day_current else 0
                    for hour in self.bound_iterator(self.hour, low_bound=lb) if self.hour \
                            else self.range_iterator(start=lb, end=23):

                        hour_current = day_current and hour == now.hour
                        lb = now.minute if hour_current else 0
                        for minute in self.bound_iterator(self.minute, low_bound=lb) if self.minute \
                                else self.range_iterator(start=lb, end=59):

                            min_current = hour_current and minute == now.minute
                            lb = now.second if min_current else 0
                            for second in self.bound_iterator(self.second, low_bound=lb) if self.second \
                                    else self.range_iterator(start=lb, end=59):
                                yield self.convert_back(datetime(
                                    year=year,
                                    month=month,
                                    day=day,
                                    hour=hour,
                                    minute=minute,
                                    second=second
                                ), original_tz=start_time.tzinfo)
                                # exec_time is in the schedule timezone
                                # need to convert back to the timezone of the start_time
